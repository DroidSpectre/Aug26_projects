# Agent Note: Aetherix-Alpine Fork v0.4.7_2

## Purpose
`aetherix-alpine-fork` is the current development tree for Aetherix Alpine and supersedes the older `android-dev-env` snapshot at `v0.3.3`. The latest tagged commit is `v0.4.7_2`, with wizard wait improvements, 10k scrollback, 63-column wrapping, and reply JSON-tail handling.

## Current Status
- Latest source: `v0.4.7_2` (`63d92d7`, 2026-08-20).
- Latest APK included: `Aetherix-Alpine-v0.4.7_2.apk`.
- Source archive generated from Git commit `63d92d7`, excluding build outputs, old export bundles, the 923 MB `.git` directory, and the 1.7 GB `archive/` directory.
- The separate `android-dev-env` archive remains useful as an earlier historical tree, but it is not the latest version.

## Next Steps
1. Restore this fork as the active Android project.
2. Use the included committed source snapshot for reproducible review.
3. Continue development from `v0.4.7_2`; do not resume from `Aetherix-Alpine-v0.3.3.apk` or its tree.
