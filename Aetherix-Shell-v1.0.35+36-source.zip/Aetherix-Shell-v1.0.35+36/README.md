# Aetherix-Shell-no_proot

**Package:** `com.aetherix.shell`
**What:** Standalone on-device terminal. Native PTY (`openpty` + `/system/bin/sh`)
with a single-view editor (display + IME owner for life, dual-path key/commit
input). No root, no proot, no bundled
userland, no network, no agents.
**Lineage:** split out of Aetherix-Debian at v30-1.29.0+30 (10/10 field pass on
Samsung commit-path + Android 16). Proot/rootfs scaffolding stripped; the
Debian edition continues separately for the full-Linux track.
**Constraints:** Java only, no lambda expressions, no diamond operators
(Java 6 style). Gradle-free `nogradle` build (`scripts/build-apk-nogradle.sh`).

## Layout

```
Aetherix-Shell-no_proot/
  README.md, PROJECT_SPEC.md, PLAN.md
  next-version.properties  # versionCode/versionName single source
  docs/  # TERMINAL, KEYBOARD-TERMUX, BUILD-SYSTEM, BUG-AUDIT, CHANGELOG, VERSIONS, ADR/
  android/  # app sources, package com.aetherix.shell
  scripts/  # build-apk-nogradle, build-release, export-apk, sync, archive-source
  tools/  # pinned toolchain (aapt2 arm64, r8, ecj)
  releases/v<N>-<name>+<code>/  # immutable per-APK archive, never overwrite
```

## Quick start

1. `scripts/build-apk-nogradle.sh` builds `build/nogradle/Aetherix-Shell-v<name>+<code>.apk`.
2. `scripts/export-apk.sh releases/v<...>` copies it to device Download, byte-verified.
3. Every commit auto-mirrors to `/sdcard/Download/Aetherix-Shell-no_proot` (post-commit hook).

See `PROJECT_SPEC.md` for the full spec.
