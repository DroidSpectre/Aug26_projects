import com.aetherix.shell.RowRing;

/**
 * Plain-JVM tests for RowRing: ring overwrite, current-line editing,
 * snapshot shape. Compile + run:
 *   javac -d /tmp/rrt android/.../RowRing.java tests/RowRingTest.java
 *   java -cp /tmp/rrt RowRingTest
 */
public class RowRingTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, String got, String want) {
        if (got.equals(want)) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + ": got [" + got + "] want [" + want + "]");
        }
    }

    static void checkInt(String name, int got, int want) {
        check(name + " (got=" + got + " want=" + want + ")", String.valueOf(got), String.valueOf(want));
    }

    public static void main(String[] a) {
        // 1. Basic two lines + live tail (old StringBuilder shape: no trailing \n).
        {
            RowRing r = new RowRing(2000);
            type(r, "ab");
            r.newline();
            type(r, "cd");
            r.newline();
            type(r, "ef");
            check("shape", r.snapshot(), "ab\ncd\nef");
            checkInt("rows", r.rowCount(), 2);
        }
        // 2. Ring overwrite past capacity (cap clamps to MIN 100; use it).
        {
            RowRing r = new RowRing(50);
            checkInt("clamp", r.capacity(), 100);
            for (int i = 0; i < 105; i++) {
                type(r, "L" + i);
                r.newline();
            }
            checkInt("rows-capped", r.rowCount(), 100);
            String snap = r.snapshot();
            // Oldest kept is L5 (L0-L4 overwritten), tail is empty live line.
            boolean startsL5 = snap.startsWith("L5\nL6\n");
            check("overwrite", String.valueOf(startsL5), "true");
            boolean hasL0 = snap.indexOf("L0\n") >= 0;
            check("old-gone", String.valueOf(hasL0), "false");
        }
        // 3. Backspace never crosses into completed rows.
        {
            RowRing r = new RowRing(2000);
            type(r, "ab");
            r.newline();
            r.backspace();
            r.backspace();
            r.backspace();
            type(r, "x");
            check("bs-floor", r.snapshot(), "ab\nx");
        }
        // 4. clearLine wipes only the current line.
        {
            RowRing r = new RowRing(2000);
            type(r, "keep");
            r.newline();
            type(r, "dropme");
            r.clearLine();
            type(r, "new");
            check("clearline", r.snapshot(), "keep\nnew");
        }
        // 5. Empty ring snapshot is empty string (view handles it).
        {
            RowRing r = new RowRing(2000);
            check("empty", r.snapshot(), "");
        }
        // 6. Capacity clamps.
        {
            checkInt("max", new RowRing(99999).capacity(), 10000);
            checkInt("def", new RowRing(2000).capacity(), 2000);
        }
        // 7. P1.6 compact: keep newest N, live line untouched.
        {
            RowRing r = new RowRing(2000);
            for (int i = 0; i < 10; i++) {
                type(r, "R" + i);
                r.newline();
            }
            type(r, "live");
            checkInt("compact-dropped", r.compact(3), 7);
            check("compact-snap", r.snapshot(), "R7\nR8\nR9\nlive");
            checkInt("compact-noop", r.compact(100), 0);
        }
        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    static void type(RowRing r, String s) {
        for (int i = 0; i < s.length(); i++) {
            r.append(s.charAt(i));
        }
    }
}
