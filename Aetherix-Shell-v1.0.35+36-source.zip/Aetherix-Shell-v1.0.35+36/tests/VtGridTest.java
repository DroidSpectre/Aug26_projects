import com.aetherix.shell.VtGrid;

/**
 * Plain-JVM tests for VtGrid (no Android APIs). Compile + run:
 *   javac -d /tmp/vtgt android/.../VtGrid.java tests/VtGridTest.java
 *   java -cp /tmp/vtgt VtGridTest
 */
public class VtGridTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, String got, String want) {
        if (got.equals(want)) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + ": got [" + escape(got) + "] want [" + escape(want) + "]");
        }
    }

    static void checkInt(String name, int got, int want) {
        if (got == want) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + ": got " + got + " want " + want);
        }
    }

    static String escape(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 27) {
                sb.append("\\e");
            } else if (c < 32 || c > 126) {
                sb.append("\\u");
                String h = Integer.toHexString(c);
                while (h.length() < 4) {
                    h = "0" + h;
                }
                sb.append(h);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static void main(String[] a) {
        // 1. Plain text + wrap + newline.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("hello");
            check("t1-row0", g.screenText(0), "hello");
            checkInt("t1-cur", g.getCursorCol(), 5);
        }
        // 2. CRLF handling.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("a\r\nb");
            check("t2-r0", g.screenText(0), "a");
            check("t2-r1", g.screenText(1), "b");
        }
        // 3. CUP: ESC[2;5H then X lands at row1 col4.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("\u001b[2;5HX");
            check("t3-pos", g.screenText(1), "    X");
            checkInt("t3-addr", g.sawAddressing() ? 1 : 0, 1);
        }
        // 4. ED 2 clears + homes.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("hello\u001b[2J");
            check("t4-clear", g.screenText(0), "");
            checkInt("t4-row", g.getCursorRow(), 0);
        }
        // 5. EL 0 (erase right).
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("hello\u001b[1;3H\u001b[K");
            check("t5-el", g.screenText(0), "he");
        }
        // 6. SGR colors recorded in styles.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("\u001b[31mR\u001b[0mN");
            int[] st = g.screenStyles(0);
            checkInt("t6-len", st.length, 2);
            checkInt("t6-fg", VtGrid.styleFg(st[0]), 1);
            checkInt("t6-fgN", VtGrid.styleFg(st[1]), 7);
        }
        // 7. SGR 256 color.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("\u001b[38;5;200mX");
            int[] st = g.screenStyles(0);
            checkInt("t7-256", VtGrid.styleFg(st[0]), 200);
        }
        // 8. SGR truecolor folds into cube (255,0,0 -> 196).
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("\u001b[38;2;255;0;0mX");
            int[] st = g.screenStyles(0);
            checkInt("t8-rgb", VtGrid.styleFg(st[0]), 196);
        }
        // 9. Alt screen 1049: separate buffer, restore on exit.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("main\u001b[?1049hALT");
            check("t9-alt", g.screenText(0), "ALT");
            checkInt("t9-isalt", g.isAlt() ? 1 : 0, 1);
            checkInt("t9-nosb", g.scrollbackLines(), 0);
            g.feed("\u001b[?1049l");
            check("t9-back", g.screenText(0), "main");
            checkInt("t9-noalt", g.isAlt() ? 1 : 0, 0);
        }
        // 10. Scroll: 10 CRLF lines into 8-row screen. 10 content lines plus
        // the fresh cursor row = 11 logical, 8 visible, 3 scrollback.
        {
            VtGrid g = new VtGrid(20, 8);
            for (int i = 0; i < 10; i++) {
                g.feed("L" + i + "\r\n");
            }
            checkInt("t10-sb", g.scrollbackLines(), 3);
            check("t10-first", g.lineText(0), "L0");
        }
        // 11. Backspace + tab.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("ab\bX\tY");
            check("t11-bs", g.screenText(0).substring(0, 2), "aX");
        }
        // 12. Unknown CSI (kitty CSI = u has a restore-cursor meaning, so use
        // Media-Copy CSI = 5 i, which this grid ignores): swallowed, cursor kept.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("a\u001b[=5iq");
            check("t12-swallow", g.screenText(0), "aq");
        }
        // 12b. CSI u really is restore-cursor (SCO convention): overwrites.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("a\u001b[=5uq");
            check("t12b-csi-u", g.screenText(0), "q");
        }
        // 13. OSC title consumed.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("a\u001b]0;title\u0007b");
            check("t13-osc", g.screenText(0), "ab");
        }
        // 14. Cursor moves clamp.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("\u001b[999;999HX");
            checkInt("t14-row", g.getCursorRow(), 7);
            check("t14-x", g.screenText(7).substring(19), "X");
        }
        // 15. ED 0 erases cursor-to-end.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("ab\r\ncd\u001b[1;1H\u001b[J");
            check("t15-ed0r0", g.screenText(0), "");
            check("t15-ed0r1", g.screenText(1), "");
        }
        // 16. Scroll margins: 7 lines (no scroll yet), then ESC[2;4r binds
        // rows 1-3; typed lines scroll only inside, row 0 keeps "R0".
        {
            VtGrid g = new VtGrid(20, 8);
            for (int i = 0; i < 7; i++) {
                g.feed("R" + i + "\r\n");
            }
            g.feed("\u001b[2;4r\u001b[2;1H");
            g.feed("x\r\ny\r\nz\r\n");
            check("t16-top", g.screenText(0), "R0");
        }
        // 17. Resize keeps content (cols clamp to the 20-240 PTY range).
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("hello world");
            g.resize(20, 10);
            checkInt("t17-rows", g.getRows(), 10);
            boolean found = false;
            for (int i = 0; i < g.totalLines(); i++) {
                if (g.lineText(i).indexOf("hello") >= 0) {
                    found = true;
                }
            }
            checkInt("t17-kept", found ? 1 : 0, 1);
            g.resize(30, 8);
            checkInt("t17-cols", g.getCols(), 30);
            g.resize(10, 8);
            checkInt("t17-clamp", g.getCols(), 20);
        }
        // 18. Insert/delete line + char ops don't crash and mark addressing.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("abcdef\u001b[1;3H\u001b[2P\u001b[1;1H\u001b[2@\u001b[1;1H\u001b[2L\u001b[1;1H\u001b[M");
            checkInt("t18-addr", g.sawAddressing() ? 1 : 0, 1);
        }
        // 19. Save/restore ESC7/8.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("ab\u001b7\u001b[2;2HXY\u001b8Z");
            check("t19-restore", g.screenText(0), "abZ");
        }
        // 20. Bracketed paste mode ?2004 tracked, cleared by reset.
        {
            VtGrid g = new VtGrid(20, 8);
            checkInt("t20-off", g.isBracketedPaste() ? 1 : 0, 0);
            g.feed("\u001b[?2004h");
            checkInt("t20-on", g.isBracketedPaste() ? 1 : 0, 1);
            g.feed("\u001b[?2004l");
            checkInt("t20-off2", g.isBracketedPaste() ? 1 : 0, 0);
            g.feed("\u001b[?2004h");
            g.reset();
            checkInt("t20-reset", g.isBracketedPaste() ? 1 : 0, 0);
        }
        // 21. Application cursor mode ?1 (DECCKM): tracked, independent of
        // alt screen, cleared by reset. The keybar reads this to choose
        // ESC O A..D (app) vs ESC [ A..D (normal).
        {
            VtGrid g = new VtGrid(20, 8);
            checkInt("t21-off", g.isAppCursor() ? 1 : 0, 0);
            g.feed("\u001b[?1h");
            checkInt("t21-on", g.isAppCursor() ? 1 : 0, 1);
            g.feed("\u001b[?1049h");
            checkInt("t21-alt-keeps", g.isAppCursor() ? 1 : 0, 1);
            g.feed("\u001b[?1l");
            checkInt("t21-off2", g.isAppCursor() ? 1 : 0, 0);
            g.feed("\u001b[?1h");
            g.reset();
            checkInt("t21-reset", g.isAppCursor() ? 1 : 0, 0);
        }
        // 22. ?1 and ?2004 are not confused by multi-param private modes.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("\u001b[?1;2004h");
            checkInt("t22-both", (g.isAppCursor() ? 1 : 0) + (g.isBracketedPaste() ? 1 : 0), 2);
            g.feed("\u001b[?1;2004l");
            checkInt("t22-both-off", (g.isAppCursor() ? 1 : 0) + (g.isBracketedPaste() ? 1 : 0), 0);
        }
        // 23. leaveFullScreen (KILL key): a SIGKILLed app never restores the
        // alt screen or modes, so the view forces them off. Main buffer and
        // its rows must survive; the shell prompt lands there, not on the
        // abandoned alt screen.
        {
            VtGrid g = new VtGrid(20, 8);
            g.feed("main\u001b[?1049h\u001b[?1h\u001b[?2004hALT");
            checkInt("t23-alt", g.isAlt() ? 1 : 0, 1);
            check("t23-alt-text", g.screenText(0), "ALT");
            g.leaveFullScreen();
            checkInt("t23-alt-off", g.isAlt() ? 1 : 0, 0);
            checkInt("t23-cursor-off", g.isAppCursor() ? 1 : 0, 0);
            checkInt("t23-bracket-off", g.isBracketedPaste() ? 1 : 0, 0);
            check("t23-main-kept", g.screenText(0), "main");
        }
        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }
}
