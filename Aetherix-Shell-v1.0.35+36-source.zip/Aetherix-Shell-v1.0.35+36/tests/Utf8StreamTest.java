import com.aetherix.shell.Utf8Stream;

/**
 * Plain-JVM tests for Utf8Stream (no Android APIs). Compile + run:
 *   javac -d /tmp/u8t android/app/src/main/java/com/aetherix/shell/Utf8Stream.java tests/Utf8StreamTest.java
 *   java -cp /tmp/u8t Utf8StreamTest
 */
public class Utf8StreamTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, String got, String want) {
        if (got.equals(want)) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + ": got [" + escape(got) + "] want [" + escape(want) + "]");
        }
    }

    static String escape(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < 32 || c > 126) {
                sb.append("\\u");
                String h = Integer.toHexString(c);
                while (h.length() < 4) {
                    h = "0" + h;
                }
                sb.append(h);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    static String dec(byte[] chunk) {
        Utf8Stream d = new Utf8Stream();
        StringBuffer sb = new StringBuffer();
        d.decode(chunk, 0, chunk.length, sb);
        d.flush(sb);
        return sb.toString();
    }

    static String decSplit(byte[] full, int splitAt) {
        Utf8Stream d = new Utf8Stream();
        StringBuffer sb = new StringBuffer();
        d.decode(full, 0, splitAt, sb);
        d.decode(full, splitAt, full.length - splitAt, sb);
        d.flush(sb);
        return sb.toString();
    }

    public static void main(String[] a) throws Exception {
        // 1. Plain ASCII.
        check("ascii", dec("hello\r\n$ ".getBytes("UTF-8")), "hello\r\n$ ");
        // 2. 2-byte char split across chunks (é = C3 A9).
        byte[] e2 = "caf\u00e9".getBytes("UTF-8");
        check("split2-whole", dec(e2), "caf\u00e9");
        for (int s = 0; s <= e2.length; s++) {
            check("split2-at" + s, decSplit(e2, s), "caf\u00e9");
        }
        // 3. 3-byte char split (U+4E2D = E4 B8 AD).
        byte[] e3 = "a\u4e2dZ".getBytes("UTF-8");
        check("split3-whole", dec(e3), "a\u4e2dZ");
        for (int s = 0; s <= e3.length; s++) {
            check("split3-at" + s, decSplit(e3, s), "a\u4e2dZ");
        }
        // 4. 4-byte emoji split (U+1F600 = F0 9F 98 80).
        byte[] e4 = "x\ud83d\ude00y".getBytes("UTF-8");
        check("split4-whole", dec(e4), "x\ud83d\ude00y");
        for (int s = 0; s <= e4.length; s++) {
            check("split4-at" + s, decSplit(e4, s), "x\ud83d\ude00y");
        }
        // 5. Overlong 2-byte '/' (C0 AF) must be rejected -> FFFD.
        check("overlong", dec(new byte[] { (byte) 0xC0, (byte) 0xAF }), "�");
        // 6. Stray continuation -> FFFD, stream continues.
        check("stray", dec(new byte[] { (byte) 0x80, (byte) 'A' }), "�A");
        // 7. Surrogate half encoded (ED A0 80) -> rejected.
        check("surrogate", dec(new byte[] { (byte) 0xED, (byte) 0xA0, (byte) 0x80 }), "�");
        // 8. Truncated tail at flush -> FFFD (shell died mid-char).
        {
            Utf8Stream d = new Utf8Stream();
            StringBuffer sb = new StringBuffer();
            byte[] e = "\u4e2d".getBytes("UTF-8");
            d.decode(e, 0, 1, sb);
            check("trunc-noemit", sb.toString(), "");
            d.flush(sb);
            check("trunc-flush", sb.toString(), "�");
        }
        // 9. Broken continuation then stray tails: "E4 28 B8 AD" ->
        // FFFD + "(" + FFFD + FFFD (B8/AD are stray continuations).
        check("badcont", dec(new byte[] { (byte) 0xE4, (byte) 0x28, (byte) 0xB8, (byte) 0xAD }), "�(��");
        // 10. Split exactly between two multibyte chars.
        byte[] two = "\u00e9\u4e2d".getBytes("UTF-8");
        check("split-between", decSplit(two, 2), "\u00e9\u4e2d");
        // 11. P1.2 fuzz: every valid length fed 1 byte at a time (worst
        // split: 4-byte emoji across 3+ reads) must decode with no FFFD.
        fuzzByteAtATime("A".getBytes("UTF-8"), "A");
        fuzzByteAtATime("\u00e9".getBytes("UTF-8"), "\u00e9");
        fuzzByteAtATime("\u4e2d".getBytes("UTF-8"), "\u4e2d");
        fuzzByteAtATime("x\ud83d\ude00y".getBytes("UTF-8"), "x\ud83d\ude00y");
        fuzzByteAtATime("\ud83d\ude00\ud83d\ude00".getBytes("UTF-8"), "\ud83d\ude00\ud83d\ude00");
        // 12. Invalid corpus: exactly one FFFD per bad sequence, stream
        // resyncs after (trailing "Z" must survive in every case).
        fuzzInvalid(new byte[] { (byte) 0xC0, (byte) 0xAF }, 1); // overlong /
        fuzzInvalid(new byte[] { (byte) 0xE0, (byte) 0x80, (byte) 0xAF }, 1); // overlong 3
        fuzzInvalid(new byte[] { (byte) 0xF0, (byte) 0x80, (byte) 0x8C, (byte) 0xBC }, 1); // overlong 4
        fuzzInvalid(new byte[] { (byte) 0xF4, (byte) 0x90, (byte) 0x80, (byte) 0x80 }, 1); // >U+10FFFF
        fuzzInvalid(new byte[] { (byte) 0xF8, (byte) 0x88, (byte) 0x80, (byte) 0x80, (byte) 0x80 }, 5); // F8 lead: F8 + 4 strays, one FFFD per maximal invalid subpart (Unicode 15 s3.9)
        fuzzInvalid(new byte[] { (byte) 0xED, (byte) 0xBF, (byte) 0xBF }, 1); // U+DFFF surrogate
        fuzzInvalid(new byte[] { (byte) 0x80 }, 1); // lone continuation
        // 13. New lead while carry pending: "F0 9F" + "A" -> FFFD + "A"
        // (must not glue across the invalid boundary).
        {
            Utf8Stream d = new Utf8Stream();
            StringBuffer sb = new StringBuffer();
            d.decode(new byte[] { (byte) 0xF0, (byte) 0x9F }, 0, 2, sb);
            d.decode(new byte[] { (byte) 'A' }, 0, 1, sb);
            d.flush(sb);
            check("carry-newlead", sb.toString(), "�A");
        }
        // 14. Overlong + split combined: hold first, validate after
        // complete (C0 AF split 1/1 -> single FFFD, no double emit).
        check("overlong-split", decSplit(new byte[] { (byte) 0xC0, (byte) 0xAF }, 1), "�");
        // 15. Random valid text at all 2-chunk splits (exhaustive over a
        // mixed string incl. CJK + emoji + combining accent U+0301).
        byte[] mix = "ls \u4e2d\ud83d\ude00e\u0301 $\r\n".getBytes("UTF-8");
        String mixWant = "ls \u4e2d\ud83d\ude00e\u0301 $\r\n";
        for (int s = 0; s <= mix.length; s++) {
            check("mix-at" + s, decSplit(mix, s), mixWant);
        }
        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    // Feed bytes one at a time; valid input must never produce FFFD.
    static void fuzzByteAtATime(byte[] full, String want) {
        Utf8Stream d = new Utf8Stream();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < full.length; i++) {
            d.decode(full, i, 1, sb);
        }
        d.flush(sb);
        check("bytewise-" + escape(want), sb.toString(), want);
    }

    // Bad sequence + "Z": exactly wantFFFD replacements then "Z".
    static void fuzzInvalid(byte[] bad, int wantFFFD) {
        Utf8Stream d = new Utf8Stream();
        StringBuffer sb = new StringBuffer();
        d.decode(bad, 0, bad.length, sb);
        d.decode(new byte[] { (byte) 'Z' }, 0, 1, sb);
        d.flush(sb);
        StringBuffer want = new StringBuffer();
        for (int i = 0; i < wantFFFD; i++) {
            want.append("�");
        }
        want.append("Z");
        check("invalid-" + escape(new String(bad)), sb.toString(), want.toString());
    }
}
