import com.aetherix.shell.Keybar;

/**
 * Pins the keybar table contract. The sparkle key is RESERVED for a
 * downstream feature; this test exists so it cannot be silently
 * repurposed again (it was, once, by a hardcoded-index dispatch).
 * Compile + run:
 *   javac -d /tmp/kb android/.../Keybar.java tests/KeybarTest.java
 *   java -cp /tmp/kb KeybarTest
 */
public class KeybarTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, String got, String want) {
        if (got.equals(want)) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + ": got [" + got + "] want [" + want + "]");
        }
    }

    public static void main(String[] a) {
        // 1. Parallel arrays, or the bar renders a key with no action.
        check("t1-labels-codes", String.valueOf(Keybar.LABELS.length), String.valueOf(Keybar.CODES.length));
        check("t1-labels-kinds", String.valueOf(Keybar.LABELS.length), String.valueOf(Keybar.KINDS.length));

        // 2. The reserved contract itself.
        check("t2-slot", String.valueOf(Keybar.RESERVED_SLOT), "7");
        check("t2-kind", String.valueOf(Keybar.KINDS[Keybar.RESERVED_SLOT]), String.valueOf(Keybar.KIND_RESERVED));
        check("t2-nocode", String.valueOf(Keybar.CODES[Keybar.RESERVED_SLOT]), "null");

        // 3. Exactly one of each special kind.
        int ctrl = 0, paste = 0, end = 0, reserved = 0, cursor = 0, kill = 0;
        for (int i = 0; i < Keybar.KINDS.length; i++) {
            if (Keybar.KINDS[i] == Keybar.KIND_CTRL) {
                ctrl++;
            } else if (Keybar.KINDS[i] == Keybar.KIND_PASTE) {
                paste++;
            } else if (Keybar.KINDS[i] == Keybar.KIND_END) {
                end++;
            } else if (Keybar.KINDS[i] == Keybar.KIND_RESERVED) {
                reserved++;
            } else if (Keybar.KINDS[i] == Keybar.KIND_CURSOR) {
                cursor++;
            } else if (Keybar.KINDS[i] == Keybar.KIND_KILL) {
                kill++;
            }
        }
        check("t3-ctrl", String.valueOf(ctrl), "1");
        check("t3-paste", String.valueOf(paste), "1");
        check("t3-end", String.valueOf(end), "1");
        check("t3-reserved", String.valueOf(reserved), "1");
        check("t3-cursor", String.valueOf(cursor), "4");
        check("t3-kill", String.valueOf(kill), "1");

        // 4. Cursor order left, up, down, right = D, A, B, C (xterm order).
        String order = "";
        for (int i = 0; i < Keybar.KINDS.length; i++) {
            if (Keybar.KINDS[i] == Keybar.KIND_CURSOR) {
                order = order + Keybar.CODES[i];
            }
        }
        check("t4-order", order, "DABC");

        // 5. Literal keys carry real codes; PASTE/END/CURSOR-in-code-array
        // must not carry stray literals (their sequences are built at press).
        check("t5-esc", String.valueOf((int) Keybar.CODES[0].charAt(0)), "27");
        check("t5-tab", Keybar.CODES[2], "\t");
        check("t5-paste-nocode", String.valueOf(Keybar.CODES[8]), "null");

        // 6. Every label is non-empty (a blank key is an invisible dead key).
        int blank = 0;
        for (int i = 0; i < Keybar.LABELS.length; i++) {
            if (Keybar.LABELS[i] == null || Keybar.LABELS[i].length() == 0) {
                blank++;
            }
        }
        check("t6-blank", String.valueOf(blank), "0");

        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }
}
