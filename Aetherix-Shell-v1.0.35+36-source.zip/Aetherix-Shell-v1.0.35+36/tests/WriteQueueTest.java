import com.aetherix.shell.WriteQueue;

/**
 * Plain-JVM tests for WriteQueue: ring semantics + generation fencing.
 *   javac -d /tmp/wq android/.../WriteQueue.java tests/WriteQueueTest.java
 *   java -cp /tmp/wq WriteQueueTest
 */
public class WriteQueueTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, boolean c) {
        if (c) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name);
        }
    }

    static void checkInt(String name, int got, int want) {
        check(name + " (got=" + got + " want=" + want + ")", got == want);
    }

    public static void main(String[] a) {
        // 1. Basic enqueue/stage/commit round trip, order preserved.
        {
            WriteQueue q = new WriteQueue();
            int gen = q.getGeneration();
            byte[] in = "hello".getBytes();
            checkInt("t1-enq", q.enqueue(in, 0, in.length), 5);
            checkInt("t1-size", q.size(), 5);
            byte[] dst = new byte[16];
            checkInt("t1-stage", q.stage(gen, dst, 16), 5);
            check("t1-order", new String(dst, 0, 5).equals("hello"));
            check("t1-staged-kept", q.size() == 5);
            check("t1-commit", q.commit(gen, 5));
            checkInt("t1-empty", q.size(), 0);
        }
        // 2. Partial commit keeps the tail.
        {
            WriteQueue q = new WriteQueue();
            int gen = q.getGeneration();
            byte[] in = "abcdef".getBytes();
            q.enqueue(in, 0, 6);
            byte[] dst = new byte[16];
            checkInt("t2-stage", q.stage(gen, dst, 3), 3);
            check("t2-commit-part", q.commit(gen, 3));
            checkInt("t2-size", q.size(), 3);
            checkInt("t2-restage", q.stage(gen, dst, 16), 3);
            check("t2-tail", new String(dst, 0, 3).equals("def"));
        }
        // 3. Flood drops oldest, newest 64K survive.
        {
            WriteQueue q = new WriteQueue();
            int gen = q.getGeneration();
            byte[] big = new byte[WriteQueue.CAP + 100];
            for (int i = 0; i < big.length; i++) {
                big[i] = (byte) (i & 0xFF);
            }
            checkInt("t3-enq", q.enqueue(big, 0, big.length), big.length);
            checkInt("t3-size", q.size(), WriteQueue.CAP);
            byte[] dst = new byte[WriteQueue.CAP];
            checkInt("t3-stage", q.stage(gen, dst, WriteQueue.CAP), WriteQueue.CAP);
            check("t3-newest", (dst[0] & 0xFF) == 100 && (dst[dst.length - 1] & 0xFF) == ((big.length - 1) & 0xFF));
        }
        // 4. Generation fencing: stale gen can stage nothing and commit nothing.
        {
            WriteQueue q = new WriteQueue();
            int gen0 = q.getGeneration();
            byte[] in = "data".getBytes();
            q.enqueue(in, 0, 4);
            q.reset();
            int gen1 = q.getGeneration();
            check("t4-bumped", gen1 != gen0);
            checkInt("t4-cleared", q.size(), 0);
            byte[] dst = new byte[16];
            checkInt("t4-stale-stage", q.stage(gen0, dst, 16), -1);
            check("t4-stale-commit", q.commit(gen0, 4) == false);
            check("t4-live", q.isLive(gen1) && q.isLive(gen0) == false);
        }
        // 5. Interleave: writer stages, reset lands mid-drain, commit refused.
        {
            WriteQueue q = new WriteQueue();
            int gen = q.getGeneration();
            byte[] in = "twelve-bytes!".getBytes();
            q.enqueue(in, 0, in.length);
            byte[] dst = new byte[16];
            checkInt("t5-stage", q.stage(gen, dst, 16), in.length);
            q.reset();
            check("t5-commit-refused", q.commit(gen, in.length) == false);
            checkInt("t5-new-empty", q.size(), 0);
        }
        // 6. Wrap-around: fill, drain half, fill again, order intact.
        {
            WriteQueue q = new WriteQueue();
            int gen = q.getGeneration();
            byte[] half = new byte[WriteQueue.CAP / 2];
            for (int i = 0; i < half.length; i++) {
                half[i] = (byte) 0x41;
            }
            q.enqueue(half, 0, half.length);
            byte[] dst = new byte[WriteQueue.CAP];
            int n = q.stage(gen, dst, half.length);
            q.commit(gen, n);
            byte[] half2 = new byte[WriteQueue.CAP / 2 + 10];
            for (int i = 0; i < half2.length; i++) {
                half2[i] = (byte) 0x42;
            }
            q.enqueue(half2, 0, half2.length);
            checkInt("t6-size", q.size(), half2.length);
            int m = q.stage(gen, dst, WriteQueue.CAP);
            checkInt("t6-stage", m, half2.length);
            boolean allB = true;
            for (int i = 0; i < m; i++) {
                if (dst[i] != (byte) 0x42) {
                    allB = false;
                    break;
                }
            }
            check("t6-order", allB);
        }
        // 7. Empty stage returns 0 (not -1) for live gen.
        {
            WriteQueue q = new WriteQueue();
            checkInt("t7-empty", q.stage(q.getGeneration(), new byte[8], 8), 0);
        }
        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }
}
