import com.aetherix.shell.PasteText;

/**
 * Plain-JVM tests for PasteText: the clipboard-to-PTY funnel.
 * Compile + run:
 *   javac -d /tmp/pt android/.../PasteText.java tests/PasteTextTest.java
 *   java -cp /tmp/pt PasteTextTest
 */
public class PasteTextTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, String got, String want) {
        if (got.equals(want)) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + ": got [" + esc(got) + "] want [" + esc(want) + "]");
        }
    }

    static void checkBool(String name, boolean got, boolean want) {
        check(name, String.valueOf(got), String.valueOf(want));
    }

    static String esc(String s) {
        StringBuffer b = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 27) {
                b.append("ESC");
            } else if (c == '\r') {
                b.append("<CR>");
            } else if (c == '\n') {
                b.append("<LF>");
            } else if (c < 32) {
                b.append("<" + (int) c + ">");
            } else {
                b.append(c);
            }
        }
        return b.toString();
    }

    public static void main(String[] a) {
        // 1. Null and empty normalize to empty, and prepare then yields "".
        check("t1-null-norm", PasteText.normalize(null), "");
        check("t1-null-prep", PasteText.prepare(null, false, 0), "");
        check("t1-empty", PasteText.prepare("", false, 0), "");

        // 2. CRLF collapses to one LF (not two, not CR+LF).
        check("t2-crlf", PasteText.normalize("a\r\nb"), "a\nb");
        check("t2-crlf-many", PasteText.normalize("a\r\n\r\nb"), "a\n\nb");

        // 3. Lone CR (old-Mac endings) becomes LF.
        check("t3-cr", PasteText.normalize("a\rb"), "a\nb");

        // 4. NULs are dropped; a payload that is only NULs is empty.
        check("t4-nul", PasteText.normalize("a\u0000b"), "ab");
        check("t4-nul-only", PasteText.prepare("\u0000\u0000", false, 0), "");

        // 5. Plain paste turns LF into CR: a newline IS an Enter keypress
        // and a canonical-mode PTY expects CR (ICRNL makes it NL).
        check("t5-lf-to-cr", PasteText.prepare("a\nb", false, 0), "a\rb");
        check("t5-trailing", PasteText.prepare("ls\n", false, 0), "ls\r");
        check("t5-crlf-source", PasteText.prepare("a\r\nb", false, 0), "a\rb");
        check("t5-cr-source", PasteText.prepare("a\rb", false, 0), "a\rb");
        check("t5-no-newline", PasteText.prepare("ls -la", false, 0), "ls -la");

        // 6. Bracketed paste wraps in ESC[200~ .. ESC[201~ and keeps LF as
        // LF: the app inserts the block literally instead of running lines.
        check("t6-wrap", PasteText.prepare("a\nb", true, 0), "\u001b[200~a\nb\u001b[201~");
        check("t6-wrap-crlf", PasteText.prepare("a\r\nb", true, 0), "\u001b[200~a\nb\u001b[201~");
        check("t6-wrap-no-nl", PasteText.prepare("x", true, 0), "\u001b[200~x\u001b[201~");

        // 7. Cap truncates CONTENT, before wrapping, so the bracketed
        // markers always survive intact.
        check("t7-cap", PasteText.prepare("abcdefghij", false, 4), "abcd");
        check("t7-cap-lf", PasteText.prepare("ab\ncdef", false, 3), "ab\r");
        check("t7-cap-bracketed", PasteText.prepare("abcdefghij", true, 4), "\u001b[200~abcd\u001b[201~");

        // 8. Cap <= 0 means no cap (used by tests only; app passes CAP).
        check("t8-nocap", PasteText.prepare("abcdefghij", false, 0), "abcdefghij");

        // 9. wouldTruncate matches what prepare does. The sharp case: 8 raw
        // chars collapse to 5, so cap 7 must NOT truncate. If the cap were
        // applied before the CRLF collapse, 8 > 7 would wrongly truncate.
        checkBool("t9-under", PasteText.wouldTruncate("abc", 3), false);
        checkBool("t9-over", PasteText.wouldTruncate("abcd", 3), true);
        checkBool("t9-nocap", PasteText.wouldTruncate("abcd", 0), false);
        checkBool("t9-crlf-collapse-first", PasteText.wouldTruncate("a\r\nb\r\nc", 7), false);

        // 10. Unicode and control-ish printable bytes pass through.
        check("t10-utf8", PasteText.prepare("héllo wörld", false, 0), "héllo wörld");
        check("t10-tab", PasteText.prepare("a\tb", false, 0), "a\tb");
        check("t10-del", PasteText.prepare("a\u007fb", false, 0), "a\u007fb");

        // 11. The app's real cap is 16 KB; a 20 KB payload truncates and
        // the bracketed form stays well-formed at the boundary.
        {
            StringBuffer big = new StringBuffer();
            for (int i = 0; i < 20000; i++) {
                big.append('x');
            }
            checkBool("t11-flag", PasteText.wouldTruncate(big.toString(), PasteText.CAP), true);
            check("t11-len", String.valueOf(PasteText.prepare(big.toString(), false, PasteText.CAP).length()),
                    String.valueOf(PasteText.CAP));
            String w = PasteText.prepare(big.toString(), true, PasteText.CAP);
            checkBool("t11-open", w.startsWith("\u001b[200~"), true);
            checkBool("t11-close", w.endsWith("\u001b[201~"), true);
            check("t11-total", String.valueOf(w.length()), String.valueOf(PasteText.CAP + 12));
        }

        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }
}
