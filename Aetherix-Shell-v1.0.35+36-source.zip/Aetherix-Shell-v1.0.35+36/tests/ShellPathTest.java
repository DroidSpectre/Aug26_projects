import com.aetherix.shell.ShellPath;

/**
 * Plain-JVM tests for ShellPath: the Phase 2 #5 shell-pref validator.
 * This is the security-relevant boundary (a path that gets exec'd by the
 * child), so the rejection rules are pinned here rather than trusted.
 * Compile + run:
 *   javac -d /tmp/spt android/.../ShellPath.java tests/ShellPathTest.java
 *   java -cp /tmp/spt ShellPathTest
 */
public class ShellPathTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, String got, String want) {
        if (got.equals(want)) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + ": got [" + got + "] want [" + want + "]");
        }
    }

    static void checkBool(String name, boolean got, boolean want) {
        check(name, String.valueOf(got), String.valueOf(want));
    }

    static java.io.File mkexe(String dir, String name) {
        java.io.File f = new java.io.File(dir, name);
        try {
            f.getParentFile().mkdirs();
            java.io.FileOutputStream o = new java.io.FileOutputStream(f);
            o.write("#!/system/bin/sh\nexit 0\n".getBytes());
            o.close();
            f.setExecutable(true, false);
            return f;
        } catch (Exception e) {
            return f;
        }
    }

    public static void main(String[] a) {
        java.io.File tmp = new java.io.File(System.getProperty("java.io.tmpdir"), "shellpathtest");
        tmp.mkdirs();
        final String base = tmp.getAbsolutePath();

        // 1. Rejects: null, empty, whitespace-only (all mean "use default").
        check("null", ShellPath.validate(null), "");
        check("empty", ShellPath.validate(""), "");
        check("spaces", ShellPath.validate("    "), "");
        check("tab/newline only", ShellPath.validate("\t\n "), "");
        check("trailing CR trimmed then valid", ShellPath.validate("  /bin/sh\r  "), "/bin/sh");

        // 2. Rejects relative paths: no PATH lookup, ever.
        check("bare name", ShellPath.validate("sh"), "");
        check("relative ./x", ShellPath.validate("./bin/sh"), "");
        check("relative ../x", ShellPath.validate("../bin/sh"), "");
        check("dotdot leading", ShellPath.validate("../../bin/sh"), "");

// 3. Rejects control characters anywhere.
        check("embedded newline", ShellPath.validate("/bin/" + "sh\nrm -rf /"), "");
        check("embedded CR", ShellPath.validate("/bin/s" + "h\rfoo"), "");
        check("embedded NUL", ShellPath.validate("/bin/s" + "h\u0000foo"), "");
        check("ESC", ShellPath.validate("/bin/" + "\u001bsh"), "");
        check("DEL", ShellPath.validate("/bin/s" + "h\u007f"), "");

        // 4. Rejects paths that do not exist / are not executable.
        check("nonexistent", ShellPath.validate("/definitely/not/here/sh"), "");
        check("directory is not a shell", ShellPath.validate("/tmp"), "");
        java.io.File exe = mkexe(base, "mysh");
        java.io.File nox = mkexe(base, "notexec");
        try {
            nox.setExecutable(false, false);
        } catch (Exception ignored) {
        }
        check("real executable accepted", ShellPath.validate(exe.getAbsolutePath()), exe.getAbsolutePath());
        checkBool("non-executable rejected", ShellPath.validate(nox.getAbsolutePath()).isEmpty(), true);

        // 5. Length cap matches the native shval[256] buffer.
        StringBuilder longp = new StringBuilder("/");
        for (int i = 0; i < 300; i++) {
            longp.append('a');
        }
        check("over-long rejected", ShellPath.validate(longp.toString()), "");

        // 6. Traversal collapse: ./ and duplicate slashes normalise, and
        //    escaping the root is refused rather than clamped.
        check("double slash collapse", ShellPath.collapse("//bin//sh"), "/bin/sh");
        check("dot collapse", ShellPath.collapse("/a/./b"), "/a/b");
        check("dotdot collapse", ShellPath.collapse("/a/b/../c"), "/a/c");
        check("trailing slash dropped", ShellPath.collapse("/a/b/"), "/a/b");
        check("escape root refused", ShellPath.collapse("/../x"), "");
        check("escape root refused 2", ShellPath.collapse("/a/../../x"), "");

        // 7. Trailing slash on a real executable still validates.
        check("exe with trailing slash", ShellPath.validate(exe.getAbsolutePath() + "/"), exe.getAbsolutePath());

        // 8. baseName: pty.c sets argv[0] from this, so $0 reads normally.
        check("basename", ShellPath.baseName("/usr/bin/bash"), "bash");
        check("basename trailing slash", ShellPath.baseName("/usr/bin/bash/"), "bash");
        check("basename root", ShellPath.baseName("/"), "");
        check("basename empty", ShellPath.baseName(""), "");

        // 9. Whitespace around a good path is trimmed, not rejected: users
        //    paste paths with trailing spaces constantly.
        check("padded path accepted", ShellPath.validate("  " + exe.getAbsolutePath() + "  "), exe.getAbsolutePath());

        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }
}