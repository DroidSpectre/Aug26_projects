#!/usr/bin/env python3
"""Build the Aetherix-Shell academic project report as a wrapped PDF.

Uses reportlab Platypus (verified installed: reportlab 5.0.1, py3.11).
All wrapping handled by Platypus Paragraph flowables - no manual breaks.
Output: /root/Aetherix-Shell-no_proot/docs/Aetherix-Shell-Report.pdf
        + copy to /sdcard/Download/
"""
import textwrap
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak,
                                HRFlowable, ListFlowable, ListItem, KeepTogether)

OUT = "/root/Aetherix-Shell-no_proot/docs/Aetherix-Shell-Report.pdf"

styles = getSampleStyleSheet()
title_s = ParagraphStyle("RTitle", parent=styles["Title"], fontSize=18,
                         leading=22, alignment=TA_CENTER, spaceAfter=6)
sub_s = ParagraphStyle("RSub", parent=styles["Normal"], fontSize=11,
                       leading=14, alignment=TA_CENTER, spaceAfter=2,
                       textColor="#444444")
h1 = ParagraphStyle("RH1", parent=styles["Heading1"], fontSize=14,
                    leading=17, spaceBefore=14, spaceAfter=6)
h2 = ParagraphStyle("RH2", parent=styles["Heading2"], fontSize=12,
                    leading=15, spaceBefore=10, spaceAfter=4)
body = ParagraphStyle("RBody", parent=styles["Normal"], fontSize=10,
                      leading=14, alignment=TA_JUSTIFY, spaceAfter=6)
bull = ParagraphStyle("RBull", parent=body, leftIndent=18, spaceAfter=3)
ref = ParagraphStyle("RRef", parent=styles["Normal"], fontSize=9,
                     leading=12, leftIndent=24, firstLineIndent=-24,
                     spaceAfter=4, alignment=TA_JUSTIFY,
                     allowWidows=1, allowOrphans=1, wordWrap="CJK")
cap = ParagraphStyle("RCap", parent=styles["Normal"], fontSize=9,
                     leading=12, alignment=TA_CENTER, spaceAfter=10,
                     textColor="#555555")

S = []
A = S.append


def P(t):
    A(Paragraph(t, body))


def H1(t):
    A(Paragraph(t, h1))


def H2(t):
    A(Paragraph(t, h2))


def B(items):
    A(ListFlowable([ListItem(Paragraph(i, bull), leftIndent=18)
                    for i in items], bulletType="bullet",
                   leftIndent=18, bulletFontSize=8))


def R(t):
    # URLs have no spaces: insert zero-width spaces after "/" *inside*
    # http(s) URLs only, so the wrapper can break long reference URLs
    # within margins. Tag slashes (</i>) untouched.
    import re
    def zw(m):
        return m.group(0).replace("/", "/&#8203;")
    t = re.sub(r"https?://\S+", zw, t)
    A(Paragraph(t, ref))


# ---------------- title ----------------
A(Paragraph("Small Shell, Hard Problems: A Rootless Terminal for " +
            "Locked-Down Android", title_s))
A(Paragraph("Aetherix-Shell: project report and phased research plan", sub_s))
A(Paragraph("Field-tested on Samsung/Android 16 &bull; v1.0.20+21 &bull; " +
            "October 2026", sub_s))
A(Spacer(1, 6))
A(HRFlowable(width="100%", thickness=1))
A(Paragraph("Abstract", h2))
P("Commodity Android phones, especially Samsung devices under Knox "
  "management, refuse most Linux-on-device strategies: namespaces need "
  "privileges the owner will not grant, PRoot pays two context switches "
  "per system call, and managed devices forbid rooting outright. "
  "Aetherix-Shell takes the opposite approach. It is a 74&nbsp;KB, "
  "offline, single-purpose terminal emulator that owns exactly one "
  "pseudoterminal through a foreground service, draws its own VT grid, "
  "and asks for three permissions with per-row justification. This "
  "report describes what was built across twenty-one releases, compares "
  "the result against eight free and open-source terminal projects, "
  "identifies eight capability gaps ranked by user impact, and lays a "
  "phased, clean-room implementation plan in which every addition ships "
  "as one immutable, field-noted release. Deliberate omissions &mdash; "
  "networking, package management, privilege escalation &mdash; are "
  "argued as design decisions rather than deferred work.")
A(Paragraph("Keywords: Android terminal emulator, pseudoterminal, VT-100, " +
            "rootless, scoped storage, foreground service",
            cap))

# ---------------- 1 ----------------
H1("1. Problem and Constraints")
P("The project began as a split from a larger Linux-on-Android effort "
  "after field testing showed that a full userland was not required for "
  "the core use case: a stable local shell on a phone the user does not "
  "control at the OS level. Five constraints were fixed early and have "
  "not moved since. First, Java only, in a Java&nbsp;6 style with no "
  "lambdas and no diamond operators, plus C solely for the pseudoterminal "
  "bridge. Second, no root, no PRoot, no bundled userland, no network "
  "servers. Third, the manifest carries no INTERNET permission by "
  "design. Fourth, the build is Gradle-free, reproducible from pinned "
  "tools. Fifth, every release is immutable: a new version code, a new "
  "directory, a source archive, and field notes, with no amendments and "
  "no force-pushes.")
P("These constraints rule out entire solution families. Any design that "
  "needs Linux namespaces, chroot, or a setuid helper is excluded. Any "
  "feature that needs a socket &mdash; package repositories, SSH, "
  "loopback ADB &mdash; is excluded for as long as the no-network "
  "posture holds. What remains is the smallest thing that can still be "
  "called a terminal: a PTY, a grid, a keyboard path, and a permission "
  "story honest enough for a managed device.")

# ---------------- 2 ----------------
H1("2. What Was Built (v1&ndash;v21)")
H2("2.1 Session ownership and native bridge")
P("A single shell session object is owned by the process and kept alive "
  "by a foreground service, following the documented Android service "
  "lifecycle in which a started service persists until it stops itself "
  "or is stopped, with restart behaviour governed by the value returned "
  "from onStartCommand (Android Developers, 2026a, 2026b). The native "
  "layer opens a pseudoterminal pair, forks, and execs the on-device "
  "shell, mirroring the classic master/slave division of labour in "
  "which the emulator drives the master side and the shell reads and "
  "writes the slave side as its controlling terminal (Wikimedia "
  "Foundation, 2026). Cooked-mode line discipline is enforced natively, "
  "stray file descriptors are closed before exec, and the shared library "
  "is built dependency-free with versioned symbols so the on-device "
  "loader binds exactly the entry points the Java layer expects; a "
  "build-time gate refuses to package a skewed library. Session "
  "liveness is fenced by a generation counter so stale reader, writer, "
  "and reaper threads can never touch a recycled file descriptor.")
H2("2.2 Emulation, input, and selection")
P("The display path is a clean-room VT grid written in dependency-free "
  "Java: printables, cursor addressing, erase and scroll-margin "
  "operations, SGR colour including the 256-colour cube, an alternate "
  "screen, and bracketed-paste state tracking. Its control vocabulary "
  "is the ECMA-48 family of control sequences &mdash; parameterised "
  "CSI sequences, single-shot ESC Fs sequences, and C1 control strings "
  "&mdash; which remains the normative reference for terminal control "
  "functions (Ecma International, 1991; Dickey, 2026). Input travels two "
  "paths, hardware key events and IME commit text, with a Samsung "
  "keyboard branch; a sticky Control latch, a fixed keybar, and "
  "tap-to-show keyboard behaviour complete the loop. Selection is "
  "long-press word select with drag extension and a floating "
  "Copy/Share bar; the titlebar Copy/Paste buttons were deleted in v20 "
  "once field logs proved selection-copy reliable.")
H2("2.3 Storage bridge and permissions")
P("Android 11 replaced broad external-storage access with scoped "
  "storage plus a gated all-files permission that must be declared, "
  "justified against privacy-friendly alternatives, and approved "
  "(Google Play, 2021; Android Developers, 2026c). Aetherix-Shell "
  "requests that permission once, through the system Settings screen, "
  "probes the mount natively at spawn time, and exposes it to the "
  "shell as small cd/list/copy shims installed three ways &mdash; shell "
  "functions, login-profile functions, and real executables on a "
  "prepended PATH &mdash; so they work regardless of which shell the "
  "device ships. By v21 the launcher had become a diagnostics console: "
  "package version, session state, notification, storage, and battery "
  "lines plus event and crash logs, one state-dependent session button, "
  "and three tappable permission rows each carrying its own "
  "justification.")

# ---------------- 3 ----------------
H1("3. Comparative Method")
P("Eight free and open-source projects were surveyed live in October "
  "2026: Termux, the full Linux environment and reference design "
  "(Termux Developers, 2026a, 2026b); Jack Palevich&rsquo;s Android "
  "Terminal Emulator, the archived VT-100 ancestor of the genre "
  "(Palevich, 2015); TermOne Plus, its maintained successor "
  "(TermApps, 2026a, 2026b); ConnectBot, the SSH client whose bundled "
  "terminal library is maintained alongside the app (ConnectBot "
  "Developers, 2026); LADB, the loopback-ADB privilege shell (Draco, "
  "2026); xterm.js, the browser terminal component that codifies the "
  "modern VT expectation set (Xterm.js Contributors, 2026); Shizuku, "
  "the binder-broker privilege mechanism (RikkaApps, 2026); and the "
  "F-Droid inclusion policy as the distribution gatekeeper (F-Droid, "
  "2026). Only publicly documented behaviour was used; no outside code "
  "was copied at any point, a rule the project calls clean-room and "
  "which this plan preserves.")
P("The comparison produced eight gaps, ranked by impact on a "
  "phone-terminal user: (1)&nbsp;single session only; (2)&nbsp;no "
  "full-screen interaction; (3)&nbsp;no power keyboard; (4)&nbsp;thin "
  "clipboard; (5)&nbsp;fixed shell configuration; (6)&nbsp;no "
  "ecosystem; (7)&nbsp;throughput and polish deficits; "
  "(8)&nbsp;narrow distribution. It also surfaced durable advantages: "
  "two to three orders of magnitude smaller than Termux&rsquo;s "
  "~109&nbsp;MB plus ~180&nbsp;MB bootstrap, no network attack surface, "
  "an exec-time storage probe no comparator ships, a fenced single-PTY "
  "design with build-time symbol gating, and a launcher that doubles "
  "as a field-diagnostics console.")

# ---------------- 4 ----------------
H1("4. Gap Analysis and Planned Work")
H2("4.1 Multi-session (gap 1)")
P("Every comparator &mdash; Termux&rsquo;s service-owned session list, "
  "Jackpal&rsquo;s observable session list with per-window views, "
  "TermOne&rsquo;s drawer over the same pattern, ConnectBot&rsquo;s "
  "per-connection bridges &mdash; converges on one architecture: the "
  "service owns N concurrent sessions, the activity owns only the "
  "selection, and death is isolated per session by identity rather "
  "than by global file descriptor (Termux Developers, 2026a; TermApps, "
  "2026a). The plan generalises the current singleton into a session "
  "manager owned by the foreground service, makes the generation fence "
  "per-session, re-binds a single view first with a seam left for "
  "view-per-tab later, caps at eight sessions, and builds the drawer "
  "last so the logic must work headless before it works visibly.")
H2("4.2 Full-screen programs (gap 2)")
P("Modern curses applications assume SGR mouse reporting, application "
  "cursor and keypad modes, wide-character cells, true colour, and "
  "well-defined resize behaviour &mdash; all specified in the xterm "
  "control-sequence reference that documents the DECSET mouse modes "
  "1000/1002/1003/1006 and the alternate-screen contract (Dickey, "
  "2026). Work is tiered: tier&nbsp;1 (cursor/keypad tables, "
  "primary-screen reflow, wide-character guards, bell, cursor style, "
  "stored title) unlocks vim, less, mc, and tmux; tier&nbsp;2 (mouse, "
  "true colour, gated OSC&nbsp;52/8) adds fidelity; tier&nbsp;3 (hover, "
  "palette queries, sixel and Kitty graphics) is deferred or skipped "
  "with written rationale.")
H2("4.3 Power keyboard (gap 3)")
P("Termux&rsquo;s configurable extra-keys row, volume-as-modifier "
  "handling, and hardware-shortcut interception, together with "
  "TermOne&rsquo;s keybar-adjacent affordances, define this space "
  "(Termux Developers, 2026a; TermApps, 2026b). The plan sequences "
  "autofill suppression and accessibility labels first, then an Alt "
  "latch plus a preferences-backed keybar, then named function and "
  "editing keys with one popup each, then hardware shortcuts, with "
  "volume-as-Control opt-in and cursor blink last.")
H2("4.4 Clipboard depth (gap 4)")
P("Reference behaviour spans Termux&rsquo;s context-menu paste, "
  "Jackpal&rsquo;s edit-text dialog, and ConnectBot&rsquo;s unified "
  "paste helper. Planned: one central paste routine fed by "
  "long-press-with-no-selection, a keybar key, and hardware shortcuts, "
  "keeping the existing bracketed-paste wrapping; row-identity "
  "selection anchoring so live output stops invalidating selections; "
  "a share-intent overflow beyond the copy cap; and a gated, "
  "confirm-first OSC&nbsp;52 receiver as the final item.")
H2("4.5 Shell configurability (gap 5)")
P("Jackpal&rsquo;s shell-plus-initial-command preferences, TermOne&rsquo;s "
  "startup script and launcher shortcuts, and Termux&rsquo;s layered "
  "shell resolution with failsafe bypass (Termux Developers, 2026a; "
  "TermApps, 2026b) motivate: a probe chain with non-login failsafe "
  "first, then shell-path and initial-command preferences, an "
  "app-private startup file, file-manager receive flow, and shortcuts. "
  "A RUN_COMMAND-style external execution API is explicitly skipped: "
  "arbitrary command execution as the app UID is risk without "
  "proportionate value in a fixed-shell local terminal.")
H2("4.6 Ecosystem under constraints (gap 6)")
P("Package repositories, SSH clients, and loopback ADB each require "
  "network sockets &mdash; ConnectBot exists precisely because remote "
  "access is a networked problem (ConnectBot Developers, 2026), LADB "
  "bundles a server and needs wireless-debugging pairing (Draco, "
  "2026), and Shizuku brokers binder calls from a separately "
  "installed manager (RikkaApps, 2026). All three cross the "
  "no-INTERNET line, so all three stay out. The maximal fitting "
  "ecosystem is an in-process Unix-domain-socket bridge exposing "
  "permission-free device readouts (battery, display, build, "
  "clipboard, toast, vibration, speech) as shell shims, with "
  "docs-only notes for adjacent tools.")
H2("4.7 Throughput and polish (gap 7)")
P("Reference pipelines &mdash; exemplified by the xterm.js emphasis on "
  "coalesced rendering and batched PTY data flow (Xterm.js "
  "Contributors, 2026) &mdash; separate transport from parsing from "
  "rendering. Planned in order: a blocking-read thread replacing the "
  "poll loop, coalesced invalidation with dirty-row drawing, UTF-8 "
  "carry-over edge-case fuzzing, off-UI-thread logging, a row-based "
  "scrollback ring, then literal search, Wake/WiFi toggles, and "
  "trim-memory handling.")
H2("4.8 Distribution (gap 8)")
P("F-Droid builds from public source with a fully free toolchain, "
  "forbids proprietary tracking, and requires either bundled-signature "
  "acceptance or verified reproducible builds (F-Droid, 2026); Play "
  "additionally gates all-files access behind a core-functionality "
  "declaration (Google Play, 2021). The ladder is: release signing "
  "with pinned self-updates first, F-Droid submission second, an "
  "x86_64 universal build third, with a scoped-storage Play flavour "
  "optional-last, minimum SDK held at 26, and 32-bit ARM deferred "
  "until demand materialises.")

# ---------------- 5 ----------------
H1("5. The Skip List")
P("The user asked, reasonably, what &lsquo;the skip list&rsquo; means, "
  "since the phrase had been used as shorthand across several "
  "working sessions. It is the project&rsquo;s explicit register of "
  "considered-and-rejected work: features that were researched, found "
  "incompatible with the constraints in Section&nbsp;1, and written "
  "down with reasons so they are not re-litigated each release. An "
  "item lands on the skip list only after a documented argument, and "
  "leaves it only if a constraint changes.")
B(["<b>Package management and language runtimes.</b> Need network "
   "fetch plus a userland tree; belong to the Debian edition. Unchanged "
   "since the split.",
   "<b>SSH/Mosh client.</b> Inherently networked; maintenance treadmill "
   "of host keys, ciphers, and background sockets. Use a standalone "
   "client alongside; share text by intent.",
   "<b>ADB-privilege (loopback) mode.</b> Bundles a server, needs "
   "wireless-debugging pairing, fights Shizuku for the ADB identity, "
   "and inverts the offline posture.",
   "<b>Shizuku bundling.</b> Passive interop is tolerated and "
   "documented; shipping a loader or auto-detecting the manager is "
   "scope creep toward privilege tooling.",
   "<b>RUN_COMMAND-style external execution API.</b> Arbitrary exec as "
   "the app UID with transcript callbacks is agency without "
   "accountability at this scale.",
   "<b>Sixel and Kitty graphics.</b> Stateful image protocols with "
   "megabyte bandwidth, bitmap caches, and scrollback semantics hostile "
   "to a 74&nbsp;KB budget; safely ignored at parse time.",
   "<b>Hover mouse mode (1003 on by default).</b> Chatty motion events "
   "over touch; press/drag coverage suffices until proven otherwise.",
   "<b>Networking tools as features.</b> Anything requiring the "
   "INTERNET permission is a fork of the project&rsquo;s trust "
   "promise, not a feature."])
P("The list is a feature, not an apology. Each entry protects the "
  "constraints that make the rest of the plan coherent, and each is "
  "reversible under stated conditions rather than by drift.")

# ---------------- 6 ----------------
H1("6. Verification Regime")
P("Every addition ships as one immutable release with field notes, "
  "following the pipeline proven across v1&ndash;v21: unit tests on a "
  "plain JVM for dependency-free classes, a full Gradle-free build "
  "(pinned compiler, dexer, resource linker, aligner, signer), a "
  "native symbol gate, device testing on Samsung hardware plus "
  "Android&nbsp;16 with launcher-report logs, a source archive, a "
  "version-table row, and a one-way mirror to external storage so "
  "history survives tooling failures. Releases are never amended and "
  "never force-pushed; the next version is a separate commit. This "
  "regime is deliberately boring, because the interesting failures in "
  "this domain &mdash; stale generations, split multibyte sequences, "
  "permission-timing races &mdash; are all state problems that only "
  "repetition catches.")

# ---------------- refs ----------------
A(Paragraph("References", h1))
R("Android Developers. (2026a). <i>Services overview: Background work</i>. "
  "https://developer.android.com/develop/background-work/services")
R("Android Developers. (2026b). <i>Service: API reference</i>. "
  "https://developer.android.com/reference/android/app/Service")
R("Android Developers. (2026c). <i>Manage all files on a storage "
  "device: App data and files</i>. "
  "https://developer.android.com/training/data-storage/manage-all-files")
R("ConnectBot Developers. (2026). <i>ConnectBot: The first SSH client "
  "for Android</i> (Version 1.10.0) [Computer software]. "
  "https://github.com/connectbot/connectbot")
R("Dickey, T. E. (2026). <i>Xterm control sequences</i>. Invisible "
  "Island. http://invisible-island.net/xterm/ctlseqs/ctlseqs.html")
R("Draco, T. (2026). <i>LADB: A local ADB shell for Android</i> "
  "[Computer software]. https://github.com/tytydraco/LADB")
R("Ecma International. (1991). <i>Standard ECMA-48: Control functions "
  "for coded character sets</i> (5th ed.). "
  "https://ecma-international.org/publications-and-standards/standards/ecma-48")
R("F-Droid. (2026). <i>Inclusion policy</i>. "
  "https://f-droid.org/en/docs/Inclusion_Policy/")
R("Google Play. (2021). <i>Use of all files access "
  "(MANAGE_EXTERNAL_STORAGE) permission: Play Console help</i>. "
  "https://support.google.com/googleplay/android-developer/answer/10467955")
R("Palevich, J. (2015). <i>Android Terminal Emulator: A VT-100 terminal "
  "emulator for the Android OS</i> (Version 1.0.70) [Computer software]. "
  "https://github.com/jackpal/Android-Terminal-Emulator")
R("RikkaApps. (2026). <i>Shizuku: Using system APIs directly with "
  "adb/root privileges from normal apps</i> [Computer software]. "
  "https://github.com/RikkaApps/Shizuku")
R("TermApps. (2026a). <i>TermOne Plus: Terminal emulator for Android "
  "OS</i> (Version 5.7.0) [Computer software]. "
  "https://gitlab.com/termapps/termoneplus")
R("TermApps. (2026b). <i>TermOne Plus: Terminal Emulator for Android "
  "OS</i>. https://termoneplus.com/")
R("Termux Developers. (2026a). <i>Termux: Terminal emulator application "
  "for Android OS</i> (Version 0.119.0-beta.3) [Computer software]. "
  "https://github.com/termux/termux-app")
R("Termux Developers. (2026b). <i>Termux: Terminal emulator with "
  "packages</i>. https://f-droid.org/en/packages/com.termux/")
R("Wikimedia Foundation. (2026). <i>Pseudoterminal</i>. In "
  "<i>Wikipedia</i>. "
  "https://en.wikipedia.org/wiki/Pseudoterminal")
R("Xterm.js Contributors. (2026). <i>Xterm.js: A terminal for the "
  "web</i> (Version 6.0.0) [Computer software]. "
  "https://github.com/xtermjs/xterm.js")

doc = SimpleDocTemplate(OUT, pagesize=LETTER,
                        leftMargin=1 * inch, rightMargin=1 * inch,
                        topMargin=0.9 * inch, bottomMargin=0.9 * inch,
                        title="Small Shell, Hard Problems",
                        author="Aetherix-Shell project")
doc.build(S)
print("wrote", OUT)
