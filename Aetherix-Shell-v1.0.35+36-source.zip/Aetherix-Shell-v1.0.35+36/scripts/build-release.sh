#!/bin/sh
# Build + archive a release immutably, then git commit+tag. Never overwrites.
# Usage: scripts/build-release.sh "change description" ["test notes"]
# Flow: build-apk-nogradle -> copy APK to releases/v<code>-<name>+<code>/ ->
#   export to Download -> build-info.json + CHANGELOG.snippet.md +
#   docs-snapshot/ -> VERSIONS.md + CHANGELOG.md rows -> commit + tag ->
#   archive-source.sh. Version bump stays a separate commit (policy).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROP="$ROOT/next-version.properties"
CODE="$(grep '^versionCode=' "$PROP" | cut -d= -f2)"
NAME="$(grep '^versionName=' "$PROP" | cut -d= -f2)"
TAG="v${NAME}+${CODE}"
DIR="$ROOT/releases/v${CODE}-${NAME}+${CODE}"
CHANGE="${1:-}"
TESTS="${2:-}"
if [ -z "$CHANGE" ]; then
  echo "usage: $0 \"change description\" [\"test notes\"]" >&2
  exit 1
fi
if [ -d "$DIR" ] && ls "$DIR"/*.apk >/dev/null 2>&1; then
  echo "Release dir already has APK, refusing overwrite: $DIR" >&2
  exit 1
fi
mkdir -p "$DIR/docs-snapshot"
echo "=== [release] building APK ==="
sh "$ROOT/scripts/build-apk-nogradle.sh"
APK="$ROOT/build/nogradle/Aetherix-Shell-v${NAME}+${CODE}.apk"
if [ ! -f "$APK" ]; then
  echo "build did not produce $APK" >&2
  exit 1
fi
echo "=== [release] archiving to $DIR ==="
cp "$APK" "$DIR/"
sh "$ROOT/scripts/export-apk.sh" "$DIR"
APKBYTES="$(wc -c < "$DIR/$(basename "$APK")" | tr -d ' ')"
APKKIB="$(( (APKBYTES + 1023) / 1024 ))"
GITSHA="$(git -C "$ROOT" rev-parse --short HEAD)"
AAPT2V="$("$ROOT/tools/aapt2" version 2>&1 | head -n 1)"
if [ -z "$AAPT2V" ]; then
  AAPT2V="$(aapt2 version 2>&1 | head -n 1)"
fi
if [ -z "$AAPT2V" ]; then
  AAPT2V="unknown"
fi
CLANGV="$(clang --version 2>/dev/null | head -n 1 || echo unknown)"
if [ -z "$TESTS" ]; then
  TESTS="javac clean, symbol gate OK, apksigner verify OK."
fi
cat > "$DIR/build-info.json" <<EOF
{"versionCode":$CODE,"versionName":"$NAME","package":"com.aetherix.shell","gitTag":"$TAG","builtFrom":"$GITSHA","change":"$CHANGE","tests":"$TESTS","apk":"$(basename "$APK") ${APKKIB}KB: stored libptyjni, debug-signed verify OK","tools":{"aapt2":"$AAPT2V","clang":"$CLANGV"}}
EOF
printf '# %s snippet\n%s APK %sKB verify OK in Download.\n' "v${CODE}-${NAME}+${CODE}" "$CHANGE" "$APKKIB" > "$DIR/CHANGELOG.snippet.md"
if [ -d "$ROOT/docs" ]; then
  cp -r "$ROOT/docs/." "$DIR/docs-snapshot/"
fi
ROW="| releases/v${CODE}-${NAME}+${CODE} | $CODE | $NAME | $TAG | $CHANGE | current |"
if grep -qF "$TAG" "$ROOT/docs/VERSIONS.md" 2>/dev/null; then
  echo "VERSIONS.md already has $TAG, leaving it"
else
  printf '%s\n' "$ROW" >> "$ROOT/docs/VERSIONS.md"
fi
if [ -f "$ROOT/docs/CHANGELOG.md" ]; then
  printf '\n## %s (%s)\n%s\n' "$TAG" "$(date +%F)" "$CHANGE" >> "$ROOT/docs/CHANGELOG.md"
fi
echo "=== [release] commit + tag ==="
git -C "$ROOT" add -A
git -C "$ROOT" commit -m "release v${CODE}-${NAME}+${CODE}: $CHANGE" || echo "(nothing new to commit)"
if git -C "$ROOT" rev-parse "$TAG" >/dev/null 2>&1; then
  echo "tag $TAG already exists, leaving it"
else
  git -C "$ROOT" tag "$TAG"
fi
echo "=== [release] source archive ==="
sh "$ROOT/scripts/archive-source.sh" "$TAG"
echo "Release done: $DIR"
echo "Next: bump next-version.properties (separate commit), e.g.:"
echo "  versionCode=$((CODE + 1))"
sh "$ROOT/scripts/sync-to-downloads.sh" || echo "WARNING: sync-to-downloads failed" >&2
