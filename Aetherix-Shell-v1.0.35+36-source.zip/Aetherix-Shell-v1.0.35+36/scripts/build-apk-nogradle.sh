#!/bin/sh
# Gradle-free APK pipeline (CodeAssist model) - PROVEN v23 (aapt2/35 + stored .so).
# Steps: javac -> D8(R8 jar) -> aapt2 compile res -> aapt2 link (android-35) ->
#        zip add dex + stored lib -> zipalign -c -> apksigner.
# Why aapt2-arm64 (tools/aapt2, AOSP-source build): Google ships x86_64 only.
# Why manifest package attr + versionCode/Name: aapt rejects AGP namespace-only manifests.
# .so MUST be stored uncompressed (zip -0): PackageManager cannot load deflated libs.
# apksigner (Debian 31) syntax: --ks-pass pass:android (space form).
# NDK note: host tag is x86_64-only; libptyjni.so built with Debian clang + NDK
# sysroot + builtins .a (see docs/OFFICIAL-SOURCES.md) - rebuild separately, not here.
# Usage: scripts/build-apk-nogradle.sh
# Outputs: build/nogradle/Aetherix-Shell-v<name>+<code>.apk (then archive, never overwrite).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/android"
OUTDIR="$ROOT/build/nogradle"
mkdir -p "$OUTDIR/classes" "$OUTDIR/dex" "$OUTDIR/apk/lib/arm64-v8a" "$OUTDIR/res"
JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-arm64}"
export PATH="$JAVA_HOME/bin:$PATH"
AAPT2="${AAPT2:-$ROOT/tools/aapt2}"
ANDROID_JAR="${ANDROID_JAR:-/opt/android-sdk/platforms/android-35/android.jar}"
R8JAR="$ROOT/tools/r8.jar"
# P1: sdcardfs/ext4 round-trips strip the exec bit off tools/aapt2. Self-heal
# before use; fall back to the system aapt2 when the pinned one is unusable.
if [ ! -x "$AAPT2" ]; then
  chmod +x "$AAPT2" 2>/dev/null || true
fi
if [ ! -x "$AAPT2" ]; then
  if command -v aapt2 >/dev/null 2>&1; then
    echo "pinned aapt2 unusable, falling back to $(command -v aapt2)" >&2
    AAPT2="aapt2"
  else
    echo "no usable aapt2 (pinned $AAPT2 not executable, none on PATH)" >&2
    exit 1
  fi
fi
CODE="$(grep '^versionCode=' "$ROOT/next-version.properties" | cut -d= -f2)"
NAME="$(grep '^versionName=' "$ROOT/next-version.properties" | cut -d= -f2)"
APK="$OUTDIR/Aetherix-Shell-v${NAME}+${CODE}.apk"
echo "[1/7] aapt2 compile res"
"$AAPT2" compile --dir "$APP/app/src/main/res" -o "$OUTDIR/res/"
echo "[2/7] javac (Java 6 style sources, -source 8)"
javac -source 8 -target 8 -cp "$ANDROID_JAR" -d "$OUTDIR/classes" $(find "$APP/app/src/main/java" -name '*.java')
echo "[3/7] D8 dex (min-api 26)"
java -cp "$R8JAR" com.android.tools.r8.D8 --lib "$ANDROID_JAR" --min-api 26 --output "$OUTDIR/dex" $(find "$OUTDIR/classes" -name '*.class')
echo "[4/7] aapt2 link (manifest + assets + res flats)"
cd "$APP/app/src/main" && "$AAPT2" link -o "$OUTDIR/apk/base.apk" -I "$ANDROID_JAR" --manifest AndroidManifest.xml --min-sdk-version 26 --target-sdk-version 35 -A assets -R "$OUTDIR/res/"*.flat
cp "$OUTDIR/dex/classes.dex" "$OUTDIR/apk/classes.dex"
# Native lib, first match wins: checked-in jniLibs (self-contained) then
# legacy fallbacks. Rebuild recipe: host clang --target=aarch64-linux-android
# on jni/pty.c + jni/errno_shim.c (Bionic __errno bridge), -nostdlib -shared.
SOFILE=""
if [ -f "$APP/app/src/main/jniLibs/arm64-v8a/libptyjni.so" ]; then
  SOFILE="$APP/app/src/main/jniLibs/arm64-v8a/libptyjni.so";
elif ls "$ROOT/releases/"v${CODE}-*/libptyjni.so >/dev/null 2>&1; then
  SOFILE="$(ls "$ROOT/releases/"v${CODE}-*/libptyjni.so | head -n 1)";
else
  SOFILE="/tmp/aetherix-build/libptyjni.so";
fi
cp "$SOFILE" "$OUTDIR/apk/lib/arm64-v8a/"
# Symbol agreement gate: the packed .so MUST export the JNI names for THIS
# package, or openPty dies with UnsatisfiedLinkError on device. Derive from
# the manifest package, not the directory name.
PKGUNDER="$(grep -o 'package="[^"]*"' "$APP/app/src/main/AndroidManifest.xml" | head -n 1 | cut -d'"' -f2 | tr '.' '_')"
if command -v nm >/dev/null 2>&1; then
  SO="$OUTDIR/apk/lib/arm64-v8a/libptyjni.so"
  # Every native the Java side declares must be exported. Derive the count
  # from PtyBridge.java so adding a native without rebuilding the .so can
  # never slip through this gate again.
  WANT="$(grep -c 'public static native' "$APP/app/src/main/java/com/aetherix/shell/PtyBridge.java")"
  HAVE="$(nm -D "$SO" | grep -c " T Java_${PKGUNDER}_PtyBridge_")"
  [ "$WANT" = "$HAVE" ] || { echo "NATIVE MISMATCH: Java declares $WANT natives, .so exports $HAVE - rebuild it, refusing to pack" >&2; exit 1; }
  for sym in $(grep 'public static native' "$APP/app/src/main/java/com/aetherix/shell/PtyBridge.java" | sed 's/.*[ ]\([a-zA-Z]*\)(.*/\1/'); do
    nm -D "$SO" | grep -q "Java_${PKGUNDER}_PtyBridge_${sym}" || { echo "NATIVE MISMATCH: .so lacks Java_${PKGUNDER}_PtyBridge_${sym} - rebuild it, refusing to pack" >&2; exit 1; }
  done
  echo "native symbols OK (${PKGUNDER}, ${HAVE} entry points)"
else
  echo "WARNING: nm missing, skipping native symbol check" >&2
fi
cd "$OUTDIR/apk" && zip -uj base.apk classes.dex && zip -0 -ur base.apk lib
echo "[5/7] keystore (gitignored debug.keystore, generated once)"
if [ ! -f "$ROOT/debug.keystore" ]; then
  keytool -genkeypair -keystore "$ROOT/debug.keystore" -alias androiddebugkey -storepass android -keypass android -keyalg RSA -keysize 2048 -validity 10950 -dname "CN=Android Debug,O=Aetherix,C=US"
fi
echo "[6/7] zipalign + check"
zipalign -f 4 "$OUTDIR/apk/base.apk" "$OUTDIR/apk/aligned.apk"
zipalign -c 4 "$OUTDIR/apk/aligned.apk"
echo "[7/7] apksigner sign + verify"
apksigner sign --ks "$ROOT/debug.keystore" --ks-pass pass:android --key-pass pass:android --out "$APK" "$OUTDIR/apk/aligned.apk"
apksigner verify --print-certs "$APK"
echo "done: $APK (archive via build-release.sh, never overwrite)"
# Mirror to device Downloads (one-way, non-fatal if sdcard unmounted).
sh "$ROOT/scripts/sync-to-downloads.sh" || echo "WARNING: sync-to-downloads failed" >&2
