#!/bin/sh
# Capture reference env (this container) for parity checks. Run inside Debian container.
# Why: proves Aetherix goal = full linux+python like this env.
set -e
OUT="${1:-env-reference.txt}"
{
  echo "== os-release =="; cat /etc/os-release 2>&1
  echo "== rootfs_version =="; cat /.rootfs_version 2>&1
  echo "== python =="; python3 --version 2>&1; pip3 list 2>&1 | head -n 30
  echo "== node =="; node --version 2>&1; which node 2>&1
  echo "== dpkg count =="; dpkg -l 2>&1 | wc -l
  echo "== env =="; env | sort 2>&1
} > "$OUT"
echo "Wrote $OUT"
