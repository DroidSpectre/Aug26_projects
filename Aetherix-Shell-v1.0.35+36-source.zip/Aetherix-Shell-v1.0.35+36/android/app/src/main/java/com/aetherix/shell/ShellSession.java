package com.aetherix.shell;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;

/**
 * Shell session owned by the process, not the activity.
 * Why: Termux survives app/device state changes because sessions live in its
 * foreground service process, not in a destroyable activity. Ours died with
 * TerminalActivity (Back/task-swipe = fresh shell). Now EnvService starts the
 * session once; activities attach/detach for display without touching the fd.
 * Process death still ends it (same as Termux force-stop); service restart
 * recreates it via START_STICKY.
 * Holds: PtyBridge, fd, reader thread, transcript + display processing
 * (BS/CR/TAB/CSI, 100KB cap, CR-straddle state), main-thread listeners.
 * No lambdas, no diamonds.
 */
public class ShellSession {
    // P1.4: row-based scrollback ring (default 2000 rows, pref
    // scrollback_rows clamped 100-10000) replaces the 100KB byte cap.
    // Rows map to scroll UX; no O(n) head-trim memmove per flush.
    private static final String SCROLLBACK_PREF = "scrollback_rows";
    private RowRing transcript = new RowRing(RowRing.DEFAULT_ROWS);

    // P1.4: (re)size the ring from prefs at session start. Changing the
    // pref requires a new session (documented); reallocating here keeps
    // the field lifetime tied to the session, like fd and queues.
    private void sizeTranscriptLocked() {
        try {
            int rows = RowRing.DEFAULT_ROWS;
            if (appCtx != null) {
                try {
                    final android.content.SharedPreferences sp = appCtx.getSharedPreferences("aetherix", android.content.Context.MODE_PRIVATE);
                    rows = sp.getInt(SCROLLBACK_PREF, RowRing.DEFAULT_ROWS);
                } catch (Exception ignored) {
                }
            }
            if (rows < RowRing.MIN_ROWS) {
                rows = RowRing.MIN_ROWS;
            }
            if (rows > RowRing.MAX_ROWS) {
                rows = RowRing.MAX_ROWS;
            }
            if (transcript == null || transcript.capacity() != rows) {
                transcript = new RowRing(rows);
            }
        } catch (Exception ignored) {
        }
    }

    // Phase 2 #5: shell path preference. Lets the app become a base for a
    // userland (unpacked bash/busybox/ash under filesDir) instead of always
    // execing /system/bin/sh. Empty/absent = the existing probe chain.
    private static final String SHELL_PREF = "shell_path";
    // Last value we actually handed the native side, for the launcher report.
    private volatile String activeShell = "";

    /** Raw pref value, trimmed. "" when unset. Never validated. */
    public static String readShellPref(Context app) {
        try {
            final android.content.SharedPreferences sp = app.getSharedPreferences("aetherix", android.content.Context.MODE_PRIVATE);
            final String v = sp.getString(SHELL_PREF, "");
            if (v == null) {
                return "";
            }
            return v.trim();
        } catch (Exception ignored) {
        }
        return "";
    }

    /** Resolve the shell to exec for this session. Logs why a bad value lost. */
    private String resolveShellLocked(Context app, boolean failsafe) {
        if (failsafe) {
            // Failsafe is the recovery path: a user-chosen shell is exactly
            // what might be broken, so it is ignored by definition.
            return "";
        }
        final String raw = readShellPref(app);
        if (raw.isEmpty()) {
            activeShell = "";
            return "";
        }
        final String ok = ShellPath.validate(raw);
        if (ok.isEmpty()) {
            EventLog.append(app, "pty", "shell_path rejected (not an executable file): " + raw);
            activeShell = "";
            return "";
        }
        activeShell = ok;
        return ok;
    }

    public String shellInUse() {
        return activeShell == null ? "" : activeShell;
    }
    // Diagnostic tap: log every received chunk with visible escapes so a
    // one-enter test reveals exact wire bytes (lone CR? CSI? split pairs?).
    // Gated off: the blanking investigation is closed by field evidence
    // (v6-shell). Re-enable locally when diagnosing wire-level issues.
    private static final boolean TAP_RX = false;

    public interface Listener {
        void onOutput(String transcriptSnapshot);
        void onGrid(VtGrid grid);
        void onClosed();
    }

    private static ShellSession instance = null;

    public static synchronized ShellSession get() {
        if (instance == null) {
            instance = new ShellSession();
        }
        return instance;
    }

    // H4: natives are static (PtyBridge holds no state), so liveness is a
    // boolean, not an object. fdGen guards every native call against a stale
    // fd: start() bumps it, stop()/death invalidates, and the reader/writer/
    // watcher threads each pin their generation and bail on mismatch.
    private boolean nativeReady = false;
    private int fd = -1;
    private int fdGen = 0;
    private int childPid = -1;
    private volatile boolean running = false;
    // H2: VT grid fed by every decoded chunk. Legacy transcript pipeline is
    // kept in parallel (derived from the grid's visible screen) so plain
    // shell UX is unchanged; cursor-addressed apps use the grid path.
    private VtGrid grid = new VtGrid(80, 24);
    private volatile boolean gridDirty = false;
    private boolean pendingCR = false;
    private final ArrayList<Listener> listeners = new ArrayList<Listener>();
    private Handler mainHandler = null;
    private Context appCtx = null;
    private long lastEmitMs = 0L;
    private boolean emitScheduled = false;

    // H3/W7: async writer over a tested WriteQueue. Keystrokes enqueue and
    // return; a single writer thread stages + drains to the PTY with EAGAIN
    // retry. The queue's generation fences stale writers across restarts.
    private final WriteQueue writeQueue = new WriteQueue();
    private boolean writerAlive = false;
    // Silent-shell watchdog (v22 field: banner shown, live pid, zero output
    // for 9s). Armed per generation at start; disarmed by the first output
    // byte. On fire: log + visible marker so the next occurrence arrives
    // pre-diagnosed instead of mysterious. Never kills anything.
    private volatile int watchGen = -1;
    private volatile boolean firstByteSeen = false;
    private String lastSdProbe = "";

    private void noteFirstByte() {
        firstByteSeen = true;
    }

    // v24 child interrogation: own children are readable under /proc.
    // wchan + state + cmdline say exactly where a silent child is stuck
    // (read blocked? zombie? wrong binary?); FIONREAD says whether bytes
    // sit in the master unread (reader broken) or the slave is truly dry.
    private String describeChild() {
        final StringBuffer sb = new StringBuffer();
        try {
            final int pid;
            synchronized (ShellSession.this) {
                pid = childPid;
            }
            sb.append("pid=" + pid);
            if (pid <= 0) {
                sb.append(" (no child)");
                return sb.toString();
            }
            sb.append(" state=" + readProcField(pid, "status", "State:"));
            sb.append(" wchan=" + readProcFile(pid, "wchan"));
            sb.append(" cmdline=" + readProcFile(pid, "cmdline").replace('\0', ' '));
            sb.append(" masterAvail=" + masterAvail());
        } catch (Exception e) {
            sb.append(" probe FAILED: " + String.valueOf(e.getMessage()));
        }
        return sb.toString();
    }

    private String readProcFile(int pid, String name) {
        java.io.BufferedReader br = null;
        try {
            br = new java.io.BufferedReader(new java.io.FileReader("/proc/" + pid + "/" + name));
            final StringBuffer sb = new StringBuffer();
            final char[] buf = new char[256];
            int r;
            while ((r = br.read(buf)) != -1) {
                sb.append(buf, 0, r);
            }
            final String s = sb.toString().trim();
            if (s.length() == 0) {
                return "?";
            }
            return s;
        } catch (Exception e) {
            return "err:" + String.valueOf(e.getMessage());
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private String readProcField(int pid, String name, String prefix) {
        java.io.BufferedReader br = null;
        try {
            br = new java.io.BufferedReader(new java.io.FileReader("/proc/" + pid + "/" + name));
            String line = br.readLine();
            while (line != null) {
                if (line.startsWith(prefix)) {
                    return line.substring(prefix.length()).trim();
                }
                line = br.readLine();
            }
            return "?";
        } catch (Exception e) {
            return "err";
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private String masterAvail() {
        // Probe with the existing non-blocking JNI read (1 byte). The
        // master is blocking-mode for the parked reader, so flip
        // O_NONBLOCK around the probe via fcntl (Os.fcntlInt exists;
        // ioctlInt does not). A present byte is FED to the pipeline, not
        // dropped — the probe doubles as a stuck-reader kick. Returns
        // "dry" (no bytes), "fed=1" (byte delivered), or err.
        java.io.FileDescriptor fdesc = null;
        int savedFlags = -1;
        try {
            if (readerPfd == null) {
                return "no-pfd";
            }
            fdesc = readerPfd.getFileDescriptor();
            if (fdesc == null || fdesc.valid() == false) {
                return "bad-fd";
            }
            final int myFd;
            synchronized (ShellSession.this) {
                myFd = fd;
            }
            if (myFd < 0) {
                return "no-session";
            }
            savedFlags = android.system.Os.fcntlInt(fdesc,
                    android.system.OsConstants.F_GETFL, 0);
            android.system.Os.fcntlInt(fdesc, android.system.OsConstants.F_SETFL,
                    savedFlags | android.system.OsConstants.O_NONBLOCK);
            final byte[] one = new byte[1];
            int r = -99;
            try {
                r = PtyBridge.readPty(myFd, one, 1);
            } finally {
                try {
                    android.system.Os.fcntlInt(fdesc,
                            android.system.OsConstants.F_SETFL, savedFlags);
                } catch (Exception ignored) {
                }
            }
            if (r > 0) {
                feedProbeByte(one[0]);
                return "fed=1";
            }
            if (r == 0) {
                return "dry";
            }
            return "r=" + r;
        } catch (Exception e) {
            return "err:" + String.valueOf(e.getMessage());
        }
    }

    // Deliver a watchdog-probed byte through the normal pipeline so the
    // probe never corrupts output (marks first byte seen, same as reader).
    private void feedProbeByte(byte b) {
        try {
            final byte[] buf = new byte[] { b };
            final StringBuffer sb = new StringBuffer(4);
            final Utf8Stream d = new Utf8Stream();
            d.decode(buf, 0, 1, sb);
            if (sb.length() == 0) {
                return;
            }
            final String s = sb.toString();
            synchronized (ShellSession.this) {
                grid.feed(s);
                gridDirty = true;
                processChunk(s);
                emitMaybe();
            }
            noteFirstByte();
            EventLog.append(appCtx, "pty", "probe byte delivered (reader was stuck)");
        } catch (Exception e) {
            EventLog.append(appCtx, "pty", "probe feed FAILED: " + String.valueOf(e.getMessage()));
        }
    }

    private void armWatchdog(final int gen) {
        watchGen = gen;
        firstByteSeen = false;
        final Thread t = new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    return;
                }
                try {
                    if (watchGen == gen && firstByteSeen == false
                            && ShellSession.get().isRunning()) {
                        EventLog.append(appCtx, "pty", "WATCHDOG gen=" + gen + ": no shell output in 5s (banner shown, session running)");
                        EventLog.append(appCtx, "pty", "child state: " + describeChild());
                        ShellSession.get().printLocal("\n[shell silent 5s: still starting, or spawn hung — Stop + New session retries]\n");
                    }
                } catch (Exception ignored) {
                }
            }
        });
        try {
            t.setDaemon(true);
        } catch (Exception ignored) {
        }
        t.start();
    }

    private final Runnable emitRunnable = new Runnable() {
        public void run() {
            synchronized (ShellSession.this) {
                emitScheduled = false;
                lastEmitMs = android.os.SystemClock.uptimeMillis();
                notifySnapshot();
            }
        }
    };

    public synchronized boolean isRunning() {
        return running;
    }

    // Install the bundled mkshrc as $HOME/.mkshrc (idempotent: skips when the
    // installed copy is byte-identical). mksh sources it via $ENV at spawn;
    // without it the prompt falls back to the full /data/data/... cwd.
    // v20: dash/toybox-sh ignore $ENV, so the sd/sdl/sdc/dir functions also
    // go into $HOME/.profile (login shells read it) AND as real executables
    // in $HOME/bin (on PATH natively: works on ANY shell even with no rc).
    // sd stays a function (a child exe cannot cd its parent); sdl/sdc/dir
    // work either way. New files overwrite (they come from assets each
    // release); .profile appends our block once (user edits above survive).
    private void installShellProfile(Context app) {
        installAssetFile(app, "mkshrc", ".mkshrc");
        installAssetFile(app, "profile", ".profile");
        installAssetFile(app, "bin_sdl", "bin/sdl");
        installAssetFile(app, "bin_sdc", "bin/sdc");
        installAssetFile(app, "bin_dir", "bin/dir");
    }

    // Copy one asset to a $HOME-relative path, creating parents. Idempotent:
    // skips when the installed bytes match. New files land 0700 (bin exes
    // must be executable: sdcardfs/ext4 round-trips strip the bit, but
    // filesDir is ext4-app-private so chmod works). Java-6 style, no lambdas.
    private void installAssetFile(Context app, String asset, String rel) {
        java.io.InputStream in = null;
        java.io.OutputStream out = null;
        try {
            final java.io.File home = app.getFilesDir();
            final java.io.File dest = new java.io.File(home, rel);
            final java.io.File parent = dest.getParentFile();
            if (parent != null && parent.exists() == false) {
                parent.mkdirs();
            }
            in = app.getAssets().open(asset);
            final java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream(2048);
            final byte[] chunk = new byte[1024];
            int r;
            while ((r = in.read(chunk)) != -1) {
                buf.write(chunk, 0, r);
            }
            final byte[] fresh = buf.toByteArray();
            if (dest.exists() && dest.length() == fresh.length) {
                final java.io.FileInputStream fin = new java.io.FileInputStream(dest);
                try {
                    final byte[] cur = new byte[fresh.length];
                    int off = 0;
                    while (off < cur.length) {
                        final int k = fin.read(cur, off, cur.length - off);
                        if (k < 0) {
                            break;
                        }
                        off += k;
                    }
                    boolean same = off == fresh.length;
                    if (same) {
                        for (int i = 0; i < fresh.length; i++) {
                            if (cur[i] != fresh[i]) {
                                same = false;
                                break;
                            }
                        }
                    }
                    if (same) {
                        chmodExec(dest);
                        return;
                    }
                } finally {
                    fin.close();
                }
            }
            out = new java.io.FileOutputStream(dest);
            out.write(fresh);
            try {
                out.close();
                out = null;
            } catch (Exception ignored) {
            }
            chmodExec(dest);
        } catch (Exception ignored) {
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ignored) {
            }
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    // bin/ entries must stay executable. Best effort, never throws.
    private void chmodExec(java.io.File f) {
        try {
            try {
                final Class c = Class.forName("android.system.Os");
                final java.lang.reflect.Method m = c.getMethod("chmod",
                        new Class[] { String.class, Integer.TYPE });
                m.invoke(null, new Object[] { f.getAbsolutePath(),
                        Integer.valueOf(448) });
                return;
            } catch (Exception ignored) {
            }
            try {
                final Runtime rt = Runtime.getRuntime();
                final Process p = rt.exec(new String[] { "chmod", "700",
                        f.getAbsolutePath() });
                p.waitFor();
            } catch (Exception ignored) {
            }
        } catch (Exception ignored) {
        }
    }

    // P1.1: blocking-reader plumbing. adoptFd wraps the master fd in a
    // ParcelFileDescriptor whose stream read() parks in the kernel (zero
    // idle wakeups, ~1ms latency) instead of the old 50ms poll+sleep.
    // The PFD owns the fd after adopt: teardown closes via readerPfd, and
    // closeFdLocked nulls it first so closePty never double-closes.
    // Direct android.system.Os use is safe (minSdk 26, Os since 21).
    private android.os.ParcelFileDescriptor readerPfd = null;
    private java.io.FileInputStream readerStream = null;

    private synchronized boolean adoptReaderLocked() {
        try {
            closeReaderLocked();
            // Adopt first (gives a FileDescriptor handle), then clear
            // O_NONBLOCK on it so stream reads park in the kernel.
            readerPfd = android.os.ParcelFileDescriptor.adoptFd(fd);
            final java.io.FileDescriptor fdesc = readerPfd.getFileDescriptor();
            final int flags = android.system.Os.fcntlInt(fdesc,
                    android.system.OsConstants.F_GETFL, 0);
            android.system.Os.fcntlInt(fdesc, android.system.OsConstants.F_SETFL,
                    flags & ~android.system.OsConstants.O_NONBLOCK);
            readerStream = new java.io.FileInputStream(fdesc);
            return true;
        } catch (Exception e) {
            closeReaderLocked();
            EventLog.append(appCtx, "pty", "blocking-reader fallback (poll): " + String.valueOf(e.getMessage()));
            return false;
        }
    }

    private void closeReaderLocked() {
        try {
            if (readerStream != null) {
                readerStream.close();
            }
        } catch (Exception ignored) {
        }
        readerStream = null;
        try {
            if (readerPfd != null) {
                readerPfd.close();
            }
        } catch (Exception ignored) {
        }
        readerPfd = null;
    }
    public synchronized void setSize(int rows, int cols) {
        if (running == false || nativeReady == false || fd < 0) {
            return;
        }
        if (rows < 8) {
            rows = 8;
        }
        if (rows > 80) {
            rows = 80;
        }
        if (cols < 20) {
            cols = 20;
        }
        if (cols > 240) {
            cols = 240;
        }
        try {
            PtyBridge.resizePty(fd, rows, cols);
        } catch (Exception ignored) {
        }
        try {
            grid.resize(cols, rows);
            gridDirty = true;
        } catch (Exception ignored) {
        }
    }

    public synchronized void start(Context ctx) {
        startInner(ctx, false);
    }

    // P1.5 failsafe: non-login shell, system rc only (jenv failsafe flag).
    // Skips no installs (install is harmless); the spawned shell simply
    // never sources user rc, so a broken .profile/.mkshrc cannot brick it.
    public synchronized void startFailsafe(Context ctx) {
        try {
            running = false;
            closeFdLocked();
        } catch (Exception ignored) {
        }
        startInner(ctx, true);
    }

    private void startInner(Context ctx, boolean failsafe) {
        // v16 reconcile (stale-flag fix): v15 early-returned on running==true
        // even when the fd was already closed (log: service start with no pty
        // open). If flagged running but the fd/pid is gone, drop the stale
        // flag and start fresh instead of returning a dead session.
        if (running) {
            if (fd >= 0 && childPid > 0) {
                return;
            }
            EventLog.append(ctx, "pty", "stale running flag (fd=" + fd + " pid=" + childPid + "), restarting");
            running = false;
            closeFdLocked();
        }
        if (PtyBridge.ensureLoaded() == false) {
            return;
        }
        appCtx = ctx.getApplicationContext();
        nativeReady = true;
        installShellProfile(appCtx);
        final int myGen;
        try {
            // v24: SD probe lives HERE (parent side), not in the child
            // pre-exec: opendir on FUSE mounts wedged spawns after
            // permission changes. File API probes are containable; a
            // wedged child is not (no timeout pre-exec, slave open, pid
            // alive, zero output — the v23 banner-forever signature).
            final String sd = probeSharedStorage();
            lastSdProbe = sd;
            // v33: user-chosen shell wins over the probe chain. Empty when
            // unset, invalid, or failsafe.
            final String sh = resolveShellLocked(appCtx, failsafe);
            final java.util.ArrayList<String> ev = new java.util.ArrayList<String>(4);
            if (failsafe) {
                ev.add("failsafe");
            }
            ev.add("SD=" + sd);
            if (sh.isEmpty() == false) {
                ev.add("SH=" + sh);
                EventLog.append(appCtx, "pty", "using custom shell " + sh);
            }
            final String[] jenv = ev.toArray(new String[ev.size()]);
            fd = PtyBridge.openPty("/system/bin/sh", appCtx.getFilesDir().getAbsolutePath(), jenv);
        } catch (UnsatisfiedLinkError e) {
            // Java/native skew must degrade to a log line, never a crash loop.
            EventLog.append(appCtx, "pty", "native mismatch: " + String.valueOf(e.getMessage()));
            nativeReady = false;
            fd = -1;
            return;
        }
        if (fd < 0) {
            EventLog.append(appCtx, "pty", "open FAILED");
            nativeReady = false;
            return;
        }
        fdGen++;
        myGen = fdGen;
        PtyBridge.resizePty(fd, 24, 80);
        try {
            childPid = PtyBridge.lastChildPid();
        } catch (UnsatisfiedLinkError e) {
            childPid = -1;
        }
        mainHandler = new Handler(Looper.getMainLooper());
        running = true;
        // P1.1: adopt the master fd for the blocking reader. On failure the
        // reader falls back to the old poll rhythm (logged in adopt).
        final boolean blockingReader = adoptReaderLocked();
        // Rendezvous: wait (bounded 500ms) for any previous-generation writer
        // to exit. Its pinned fd number may be recycled by the openPty below;
        // proceeding while it still drains would leak bytes across sessions.
        // wait() releases this monitor so the old writer can synchronize out.
        try {
            final long deadline = android.os.SystemClock.uptimeMillis() + 500L;
            while (writerAlive) {
                final long left = deadline - android.os.SystemClock.uptimeMillis();
                if (left <= 0L) {
                    break;
                }
                ShellSession.this.wait(left);
            }
        } catch (InterruptedException ignored) {
        }
        // Fresh session owns a fresh queue: reset() bumps the queue
        // generation (stale writers exit) and drops unsent bytes from the
        // dead shell so they can never leak into the new one.
        writeQueue.reset();
        startWriterLocked();
        // Clean slate: exit (or any death) wipes the transcript AND the grid
        // and starts fresh with the banner. The grid used to keep the dead
        // session's screen (split brain: fresh banner over stale vim).
        // P1.4: ring capacity (re)read from prefs at every session start so
        // a changed scrollback_rows value applies to the next session.
        sizeTranscriptLocked();
        transcript.clear();
        pendingCR = false;
        final String banner = "Aetherix-Shell";
        for (int bi = 0; bi < banner.length(); bi++) {
            transcript.append(banner.charAt(bi));
        }
        transcript.newline();
        // v30: one-line helper disclosure. sd/sdl/sdc/dir are OUR shims, not
        // standard Unix commands — users typed `dir` expecting coreutils
        // (v28 field) and the prompt looked hardcoded. Also advertises the
        // standard escape hatch: $SD is exported by the shell rc.
        {
            final String hint = "sd/sdl/sdc/dir are Aetherix helpers for shared storage ("
                    + (lastSdProbe == null || lastSdProbe.isEmpty() ? "not granted yet" : lastSdProbe) + "); $SD holds the path";
            for (int hi = 0; hi < hint.length(); hi++) {
                transcript.append(hint.charAt(hi));
            }
            transcript.newline();
        }
        try {
            grid.reset();
            gridDirty = true;
        } catch (Exception ignored) {
        }
        final Thread t = new Thread(new Runnable() {
            public void run() {
                readLoop(myGen);
            }
        });
        t.start();
        final Thread w = new Thread(new Runnable() {
            public void run() {
                watchChild(myGen);
            }
        });
        w.start();
        armWatchdog(myGen);
        EventLog.append(appCtx, "pty", "open fd=" + fd + " pid=" + childPid + (blockingReader ? " blocking" : " poll") + (failsafe ? " failsafe" : "") + " shells=" + probeShells());
    }

    // v24: Java-side shared-storage probe (see startInner). Returns the
    // first readable+writable candidate or "". Bounded: File API only, no
    // shell-outs, no recursion — must return fast on every mount state.
    private String probeSharedStorage() {
        try {
            final String[] cands = new String[] { "/sdcard", "/storage/emulated/0", "/storage/self/primary" };
            for (int i = 0; i < cands.length; i++) {
                try {
                    final java.io.File f = new java.io.File(cands[i]);
                    if (f.isDirectory() && f.canRead() && f.canExecute()) {
                        return cands[i];
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    // Java-side view of the native probe chain (informational: native is
    // authoritative, but this shows what the app layer saw pre-exec).
    private String probeShells() {
        final String[] cands = new String[] { "/system/bin/sh", "/system/bin/mksh", "/vendor/bin/sh" };
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < cands.length; i++) {
            try {
                final java.io.File f = new java.io.File(cands[i]);
                final boolean x = f.exists() && f.canExecute();
                if (i > 0) {
                    sb.append(',');
                }
                sb.append(cands[i]);
                if (x) {
                    sb.append("=x");
                } else {
                    sb.append("=-");
                }
            } catch (Exception e) {
                sb.append(cands[i]);
                sb.append("=?");
            }
        }
        return sb.toString();
    }

    // Reap the child when it dies so no zombie lingers. Polls with WNOHANG;
    // on death closes the fd (reader loop sees running=false and exits) and
    // emits a visible marker, Termux-style "process completed" UX.
    private void watchChild(int myGen) {
        final int pid;
        synchronized (ShellSession.this) {
            pid = childPid;
        }
        if (pid <= 0) {
            return;
        }
        final int[] st = new int[1];
        while (true) {
            synchronized (ShellSession.this) {
                if (running == false || myGen != fdGen) {
                    return;
                }
            }
            int r = 0;
            try {
                r = PtyBridge.pollChild(pid, st);
            } catch (Exception e) {
                return;
            }
            if (r != 0) {
                final int code = (r > 0) ? exitCode(st[0]) : -1;
                synchronized (ShellSession.this) {
                    // A restart may have buried this generation already.
                    if (myGen != fdGen) {
                        return;
                    }
                    running = false;
                    closeFdLocked();
                }
                EventLog.append(appCtx, "pty", "child pid=" + pid + " exited code=" + code);
                processChunk("\r\n[process exited (" + code + ")]\r\n");
                emitMaybe();
                notifyClosed();
                return;
            }
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    // Decode a waitpid status word without W* macros (pure Java).
    private static int exitCode(int status) {
        if ((status & 0x7F) == 0) {
            return (status >> 8) & 0xFF;
        }
        if (((status & 0x7F) + 1) >> 1 > 0 && (status & 0x7F) != 0x7F) {
            return 128 + (status & 0x7F);
        }
        return -1;
    }

    private void closeFdLocked() {
        // P1.1: the adopted reader owns the fd when present — closing via
        // the stream/PFD wakes the parked blocking read AND closes the fd,
        // so closePty must not run after it (double-close could hit a
        // recycled fd number). Fall back to closePty only when adoption
        // never happened (poll path).
        if (readerPfd != null || readerStream != null) {
            closeReaderLocked();
        } else if (nativeReady && fd >= 0) {
            try {
                PtyBridge.closePty(fd);
            } catch (Exception ignored) {
            }
        }
        fd = -1;
        childPid = -1;
        fdGen++;
    }

    // Graceful teardown: SIGHUP the child group, bounded reap, close the fd,
    // bump the generation so stale threads exit. Wired from
    // EnvService.onDestroy; previously dead code with zero callers.
    // Never blocks the caller: reap polls ~1s on a helper thread; a stubborn
    // child is orphaned (process is dying anyway) but never a zombie while
    // we are still alive to wait on it.
    /**
     * v36 KILL: SIGKILL whatever currently owns the terminal - the escape
     * hatch for a wedged full-screen app (vi with a lost ESC). With job
     * control the foreground group is the app's own group, so the shell
     * survives and prints a fresh prompt.
     *
     * Refuses when the shell itself owns the terminal (idle prompt, or a
     * shell without job control): killing there would silently end the
     * session, which is what the launcher Stop action is for. Returns the
     * pgid killed, or -1 when nothing was killed.
     */
    public synchronized int killForeground() {
        if (running == false || nativeReady == false || fd < 0) {
            return -1;
        }
        int pg = -1;
        try {
            pg = PtyBridge.foregroundPgrp(fd);
        } catch (Exception ignored) {
        }
        if (pg <= 0 || pg == childPid) {
            return -1;
        }
        try {
            if (PtyBridge.signalChild(-pg, 9) != 0) {
                return -1;
            }
        } catch (Exception ignored) {
            return -1;
        }
        return pg;
    }

    public synchronized void stop() {
        running = false;
        ShellSession.this.notifyAll();
        final int pid = childPid;
        if (nativeReady && pid > 0) {
            try {
                PtyBridge.signalChild(-pid, 1);
            } catch (Exception ignored) {
            }
            final Thread t = new Thread(new Runnable() {
                public void run() {
                    final int[] st = new int[1];
                    final long deadline = android.os.SystemClock.uptimeMillis() + 1000L;
                    while (android.os.SystemClock.uptimeMillis() < deadline) {
                        try {
                            final int r = PtyBridge.pollChild(pid, st);
                            if (r != 0) {
                                return;
                            }
                        } catch (Exception e) {
                            return;
                        }
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException e) {
                            return;
                        }
                    }
                    // v36: SIGHUP was not enough. A wedged full-screen app can
                    // ignore it; SIGKILL the whole group so no orphan keeps the
                    // PTY slave open after the master is closed.
                    try {
                        PtyBridge.signalChild(-pid, 9);
                    } catch (Exception ignored) {
                    }
                }
            });
            t.start();
        }
        closeFdLocked();
        transcript.clear();
        pendingCR = false;
    }

    private void notifyClosed() {
        // Termux-aligned: the session dying may leave the service idle. Ping
        // EnvService (no revive) so it can stop itself when nothing runs.
        try {
            if (appCtx != null) {
                EnvService.sessionStateChanged(appCtx);
            }
        } catch (Exception ignored) {
        }
        final ArrayList<Listener> copy = copyListeners();
        if (mainHandler == null) {
            return;
        }
        for (int i = 0; i < copy.size(); i++) {
            final Listener l = (Listener) copy.get(i);
            mainHandler.post(new Runnable() {
                public void run() {
                    l.onClosed();
                }
            });
        }
    }

    public synchronized void attach(Listener l) {
        boolean found = false;
        for (int i = 0; i < listeners.size(); i++) {
            if (listeners.get(i) == l) {
                found = true;
            }
        }
        if (found == false) {
            listeners.add(l);
        }
        final String snap = transcript.snapshot();
        final Listener target = l;
        if (mainHandler != null) {
            mainHandler.post(new Runnable() {
                public void run() {
                    target.onOutput(snap);
                }
            });
            mainHandler.post(new Runnable() {
                public void run() {
                    target.onGrid(grid);
                }
            });
        }
    }

    public synchronized void detach(Listener l) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            if (listeners.get(i) == l) {
                listeners.remove(i);
            }
        }
    }

    public synchronized int writeText(String s) {
        if (running == false || nativeReady == false || fd < 0 || s == null) {
            return 0;
        }
        try {
            final byte[] b = s.getBytes("UTF-8");
            final int queued = writeQueue.enqueue(b, 0, b.length);
            ShellSession.this.notifyAll();
            return queued;
        } catch (Exception ignored) {
        }
        return 0;
    }

    public synchronized int[] writeDel(int n) {
        final int[] res = new int[] { 0, 0 };
        if (running == false || nativeReady == false || fd < 0) {
            return res;
        }
        final byte[] del = new byte[] { 127 };
        int ok = 0;
        for (int i = 0; i < n; i++) {
            // enqueue() always queues (drops oldest on flood), so err stays 0;
            // the count is kept for API shape. See W5 paste cap for floods.
            if (writeQueue.enqueue(del, 0, 1) == 1) {
                ok++;
            } else {
                res[1]++;
            }
        }
        res[0] = ok;
        ShellSession.this.notifyAll();
        return res;
    }

    private void startWriterLocked() {
        if (writerAlive) {
            return;
        }
        writerAlive = true;
        final int sessionGen = fdGen;
        final int queueGen = writeQueue.getGeneration();
        final Thread t = new Thread(new Runnable() {
            public void run() {
                writeLoop(sessionGen, queueGen);
            }
        });
        t.start();
    }

    // All writer exits funnel here so start() can rendezvous: flag + wake.
    private void writerExit() {
        synchronized (ShellSession.this) {
            writerAlive = false;
            ShellSession.this.notifyAll();
        }
    }

    private void writeLoop(int sessionGen, int queueGen) {
        final byte[] chunk = new byte[4096];
        while (true) {
            final int n;
            synchronized (ShellSession.this) {
                if (sessionGen != fdGen || writeQueue.isLive(queueGen) == false) {
                    writerExit();
                    return;
                }
                if (writeQueue.size() == 0) {
                    if (running == false) {
                        writerExit();
                        return;
                    }
                    try {
                        ShellSession.this.wait();
                    } catch (InterruptedException e) {
                        writerExit();
                        return;
                    }
                    continue;
                }
                final int staged = writeQueue.stage(queueGen, chunk, chunk.length);
                if (staged < 0) {
                    writerExit();
                    return;
                }
                if (staged == 0) {
                    continue;
                }
                n = staged;
            }
            // Drain outside the lock: EAGAIN (r==0) retries after 10ms,
            // error (r<0) drops the chunk (fd is dead; reader closes it).
            // The fd is pinned per-drain and re-checked against the live
            // session generation so a restart can never hijack these bytes.
            // Commit removes staged bytes only while our queue generation is
            // live; a reset (new session) refuses the commit and we exit.
            final int myFd;
            synchronized (ShellSession.this) {
                if (sessionGen != fdGen || writeQueue.isLive(queueGen) == false) {
                    writerExit();
                    return;
                }
                myFd = fd;
            }
            int off = 0;
            while (off < n) {
                synchronized (ShellSession.this) {
                    if (sessionGen != fdGen || writeQueue.isLive(queueGen) == false) {
                        writerExit();
                        return;
                    }
                }
                int r = -1;
                try {
                    final byte[] slice = java.util.Arrays.copyOfRange(chunk, off, n);
                    r = PtyBridge.writePty(myFd, slice, slice.length);
                } catch (Exception e) {
                    r = -1;
                }
                if (r < 0) {
                    break;
                }
                if (r == 0) {
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        break;
                    }
                    continue;
                }
                off += r;
            }
            synchronized (ShellSession.this) {
                if (writeQueue.commit(queueGen, off) == false) {
                    writerExit();
                    return;
                }
                // Drained bytes are gone even on partial write: the remainder
                // was either EAGAIN-retried above or the fd died (r<0 break).
                // Unwritten tail on dead fd is dropped with the session.
                if (off < n && running == false) {
                    writerExit();
                    return;
                }
            }
        }
    }

    public synchronized void printLocal(String s) {
        if (s != null) {
            try {
                grid.feed(s);
                gridDirty = true;
            } catch (Exception ignored) {
            }
        }
        processChunk(s);
        emitMaybe();
    }

    private void emitMaybe() {
        try {
            final long now = android.os.SystemClock.uptimeMillis();
            if (now - lastEmitMs >= 50L) {
                lastEmitMs = now;
                notifySnapshot();
                return;
            }
            if (emitScheduled) {
                return;
            }
            emitScheduled = true;
            if (mainHandler != null) {
                mainHandler.postDelayed(emitRunnable, 50L);
            } else {
                emitScheduled = false;
            }
        } catch (Exception ignored) {
        }
    }

    private void readLoop(int myGen) {
        final byte[] buf = new byte[4096];
        final byte[] scratch = new byte[4096];
        final Utf8Stream decoder = new Utf8Stream();
        final StringBuffer pending = new StringBuffer(8192);
        final int myPid;
        final java.io.FileInputStream stream;
        final boolean blocking;
        synchronized (ShellSession.this) {
            myPid = childPid;
            stream = readerStream;
            blocking = stream != null;
        }
        // P1.1: blocking path parks in kernel read() (zero idle CPU);
        // after each wake, drain whatever else is already available via
        // non-blocking readPty so one flood = one parse + one emit.
        // Poll path (adoption failed) keeps the old 50ms rhythm.
        while (true) {
            final int myFd;
            synchronized (ShellSession.this) {
                // Stale generation (restart happened): exit quietly. Only the
                // current generation may read, bury, or revive the session.
                if (running == false || myGen != fdGen) {
                    return;
                }
                myFd = fd;
            }
            int r = 0;
            if (blocking && stream != null) {
                try {
                    r = stream.read(buf, 0, buf.length);
                } catch (Exception e) {
                    r = -1;
                }
                if (r > 0) {
                    // Drain burst: pull whatever else is already available
                    // into the tail via a scratch buffer (readPty always
                    // writes at [0,k)), so one flood = one parse + one emit.
                    // v26 fix: the master is BLOCKING now (adopt cleared
                    // O_NONBLOCK), so a raw readPty here parks forever
                    // waiting for one more byte than exists — the v22+
                    // banner-forever bug (prompt held, never processed).
                    // available() (FIONREAD) gates each drain read: >0
                    // guarantees immediate return, no fcntl dance, no race
                    // (this thread is the sole consumer).
                    int total = r;
                    while (total < buf.length) {
                        boolean ready = false;
                        try {
                            ready = stream.available() > 0;
                        } catch (Exception e) {
                            break;
                        }
                        if (ready == false) {
                            break;
                        }
                        final int k;
                        try {
                            k = PtyBridge.readPty(myFd, scratch, Math.min(scratch.length, buf.length - total));
                        } catch (Exception e) {
                            break;
                        }
                        if (k <= 0) {
                            break;
                        }
                        int i = 0;
                        while (i < k && total < buf.length) {
                            buf[total] = scratch[i];
                            total++;
                            i++;
                        }
                        if (i < k) {
                            break;
                        }
                    }
                    r = total;
                }
            } else {
                r = PtyBridge.readPty(myFd, buf, buf.length);
            }
            if (r > 0) {
                // Reader-death log (v22 field: banner-forever with live pid
                // is exactly a dead reader thread). Any processing throw is
                // logged with the generation instead of killing output
                // silently; the loop continues on the next chunk.
                String s = null;
                try {
                    pending.setLength(0);
                    decoder.decode(buf, 0, r, pending);
                    if (pending.length() > 0) {
                        s = pending.toString();
                    }
                } catch (Exception e) {
                    EventLog.append(appCtx, "pty", "reader decode FAILED gen=" + myGen + ": " + String.valueOf(e.getMessage()));
                    continue;
                }
                if (s != null) {
                    if (TAP_RX) {
                        EventLog.append(appCtx, "pty-rx", "len=" + s.length() + " [" + escapeChunk(s) + "]");
                    }
                    try {
                        synchronized (ShellSession.this) {
                            if (myGen != fdGen) {
                                return;
                            }
                            grid.feed(s);
                            gridDirty = true;
                            processChunk(s);
                            emitMaybe();
                        }
                        noteFirstByte();
                    } catch (Exception e) {
                        EventLog.append(appCtx, "pty", "reader process FAILED gen=" + myGen + ": " + String.valueOf(e.getMessage()));
                    }
                }
            } else if (r < 0) {
                synchronized (ShellSession.this) {
                    if (myGen != fdGen) {
                        return;
                    }
                    if (myFd != fd) {
                        return;
                    }
                    running = false;
                    // W1: reap here, not just in the watcher. EOF means the
                    // slave closed = child is dead; waitChild returns at once
                    // (no block) and the zombie can never escape, regardless
                    // of who wins the reader/watcher race.
                    if (myPid > 0) {
                        try {
                            PtyBridge.waitChild(myPid, new int[1]);
                        } catch (Exception ignored) {
                        }
                    }
                    closeFdLocked();
                }
                EventLog.append(appCtx, "pty", "closed");
                notifyClosed();
                return;
            } else {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    private ArrayList<Listener> copyListeners() {
        final ArrayList<Listener> copy = new ArrayList<Listener>();
        for (int i = 0; i < listeners.size(); i++) {
            copy.add((Listener) listeners.get(i));
        }
        return copy;
    }

    private static String escapeChunk(final String s) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c == '\r') {
                sb.append("\\r");
            } else if (c == '\n') {
                sb.append("\\n");
            } else if (c == '\b') {
                sb.append("\\b");
            } else if (c == '\t') {
                sb.append("\\t");
            } else if (c == 27) {
                sb.append("\\e");
            } else if (c == 7) {
                sb.append("\\a");
            } else if (c < 32 || c == 127) {
                sb.append("\\x");
                sb.append(Character.forDigit((c >> 4) & 15, 16));
                sb.append(Character.forDigit(c & 15, 16));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private void notifySnapshot() {        final String snap = transcript.snapshot();
        final ArrayList<Listener> copy = copyListeners();
        final boolean sendGrid;
        synchronized (ShellSession.this) {
            sendGrid = gridDirty;
        }
        if (mainHandler == null) {
            return;
        }
        for (int i = 0; i < copy.size(); i++) {
            final Listener l = (Listener) copy.get(i);
            mainHandler.post(new Runnable() {
                public void run() {
                    l.onOutput(snap);
                }
            });
            if (sendGrid) {
                mainHandler.post(new Runnable() {
                    public void run() {
                        l.onGrid(grid);
                    }
                });
            }
        }
        if (sendGrid) {
            synchronized (ShellSession.this) {
                gridDirty = false;
            }
        }
    }

    // P1.6: low-memory compact. Drops oldest scrollback to keep rows;
    // never touches fd/threads/child (killing the PTY loses user work).
    // Caller (EnvService.onTrimMemory) logs the drop count it returns.
    public synchronized int compactTranscript(int keepRows) {
        try {
            return transcript.compact(keepRows);
        } catch (Exception e) {
            return -1;
        }
    }

    private void truncateLine() {
        transcript.clearLine();
    }

    private void processChunk(final String s) {
        int i = 0;
        int n = s.length();
        if (pendingCR) {
            pendingCR = false;
            if (n == 0) {
                pendingCR = true;
                return;
            }
            if (n > 0 && s.charAt(0) == '\n') {
                transcript.newline();
                i = 1;
            } else {
                // A CR run may continue across the chunk boundary: fold it
                // with the same rule as below instead of truncating blindly.
                int j = 0;
                while (j < n && s.charAt(j) == '\r') {
                    j++;
                }
                if (j < n && s.charAt(j) == '\n') {
                    i = j;
                } else if (j >= n && n > 0) {
                    pendingCR = true;
                    i = n;
                } else {
                    truncateLine();
                }
            }
        }
        while (i < n) {
            final char c = s.charAt(i);
            if (c == '\b') {
                transcript.backspace();
                i++;
            } else if (c == '\r') {
                // Fold runs: \r\r*\n is ONLCR-doubled CRLF (newline only), a
                // lone \r followed by text is a redraw (truncate once).
                int j = i;
                while (j < n && s.charAt(j) == '\r') {
                    j++;
                }
                if (j < n && s.charAt(j) == '\n') {
                    i = j;
                    continue;
                } else if (j >= n) {
                    pendingCR = true;
                    i = n;
                } else {
                    truncateLine();
                    i = j;
                }
            } else if (c == '\t') {
                final int lineLen = transcript.currentLength();
                int spaces = 8 - (lineLen % 8);
                for (int k = 0; k < spaces; k++) {
                    transcript.append(' ');
                }
                i++;
            } else if (c == 27) {
                int j = i + 1;
                if (j < n && s.charAt(j) == '[') {
                    j++;
                    while (j < n) {
                        final char d = s.charAt(j);
                        j++;
                        if (d >= '@' && d <= '~') {
                            break;
                        }
                    }
                } else if (j < n && s.charAt(j) == ']') {
                    // OSC: consume until BEL or ESC-backslash.
                    j++;
                    while (j < n) {
                        final char d = s.charAt(j);
                        if (d == 7) {
                            j++;
                            break;
                        }
                        if (d == 27 && j + 1 < n && s.charAt(j + 1) == '\\') {
                            j += 2;
                            break;
                        }
                        j++;
                    }
                } else if (j < n) {
                    j++;
                }
                i = j;
            } else if (c < 32 && c != '\n') {
                i++;
            } else if (c == '\n') {
                transcript.newline();
                i++;
            } else {
                transcript.append(c);
                i++;
            }
        }
        // P1.4: no byte cap — the ring self-bounds by row count.
    }
}
