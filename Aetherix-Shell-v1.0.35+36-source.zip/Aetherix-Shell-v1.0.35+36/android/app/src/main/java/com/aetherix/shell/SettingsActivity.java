package com.aetherix.shell;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Permissions + settings page. Why a page, not rows on the launcher:
 * the launcher is a status console; grants deserve what+why+state each
 * without crowding it. Same grant flows as the v21 rows (moved here
 * verbatim); Deny stays re-tappable, asked-once flags still gate nags.
 * Room left below for future prefs (scrollback, theme) without touching
 * the launcher again. No lambdas, no diamonds.
 */
public class SettingsActivity extends Activity {
    private Button pNotify = null;
    private Button pFiles = null;
    private Button pBatt = null;
    private EditText shellInput = null;
    private TextView shellStatus = null;

    public void onCreate(Bundle savedInstanceState) {
        CrashLog.install(this);
        super.onCreate(savedInstanceState);
        final float density;
        try {
            density = getResources().getDisplayMetrics().density;
        } catch (Exception e) {
            return;
        }
        final int pad = (int) (16.0f * density + 0.5f);
        final int gap = (int) (10.0f * density + 0.5f);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(false);
        root.setBackgroundColor(0xFF0D1117);
        root.setPadding(pad, pad, pad, pad);
        final TextView title = new TextView(this);
        title.setText("Permissions");
        title.setTextSize(20.0f);
        title.setTextColor(0xFF58A6FF);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final TextView sub = new TextView(this);
        sub.setText("Each grant covers one thing. Deny stays re-tappable.");
        sub.setTextColor(0xFF8B949E);
        root.addView(sub, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.topMargin = gap;
        pNotify = Ui.darkButton(this);
        root.addView(Ui.card(this, pNotify), cardLp);
        pFiles = Ui.darkButton(this);
        root.addView(Ui.card(this, pFiles), cardLp);
        pBatt = Ui.darkButton(this);
        root.addView(Ui.card(this, pBatt), cardLp);

        // v33: shell path. Kept on the settings page (not the launcher) to
        // match the permission rows: this is configuration, not status.
        final LinearLayout.LayoutParams secLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        secLp.topMargin = gap * 2;
        root.addView(Ui.section(this, "SHELL"), secLp);
        final TextView shellNote = new TextView(this);
        shellNote.setText("Absolute path to a shell binary, e.g. an unpacked userland under files. Empty uses the system shell. Takes effect on the next New session. Failsafe always uses the system shell.");
        shellNote.setTextColor(Ui.DIM);
        shellNote.setTextSize(12.0f);
        final LinearLayout shellCard = new LinearLayout(this);
        shellCard.setOrientation(LinearLayout.VERTICAL);
        shellCard.addView(shellNote);
        shellInput = new EditText(this);
        shellInput.setTextColor(Ui.TEXT);
        shellInput.setHint("/system/bin/sh (default)");
        shellInput.setSingleLine(true);
        try {
            shellInput.setText(ShellSession.readShellPref(this));
        } catch (Exception ignored) {
        }
        shellCard.addView(shellInput);
        shellStatus = new TextView(this);
        shellStatus.setTextSize(12.0f);
        shellCard.addView(shellStatus);
        final LinearLayout shellBtns = new LinearLayout(this);
        shellBtns.setOrientation(LinearLayout.HORIZONTAL);
        final Button shellSave = Ui.darkButton(this);
        shellSave.setText("Save");
        final Button shellClear = Ui.darkButton(this);
        shellClear.setText("Use default");
        shellBtns.addView(shellSave, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
        shellBtns.addView(shellClear, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
        shellCard.addView(shellBtns);
        root.addView(Ui.card(this, shellCard), cardLp);

        final LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        backLp.topMargin = gap;
        final Button back = Ui.darkButton(this);
        back.setText("Back");
        root.addView(back, backLp);
        setContentView(root);
        if (android.os.Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try {
                        final int top = insets.getSystemWindowInsetTop();
                        final int bottom = insets.getSystemWindowInsetBottom();
                        v.setPadding(v.getPaddingLeft(), top + pad, v.getPaddingRight(), bottom + pad);
                    } catch (Exception ignored) {
                    }
                    return insets;
                }
            });
        }
        pNotify.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Perms.ensureNotifyPermission(SettingsActivity.this);
            }
        });
        pFiles.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Perms.ensureFilesAccess(SettingsActivity.this);
            }
        });
        pBatt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Perms.requestBatteryExemption(SettingsActivity.this);
            }
        });
        shellSave.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                saveShellPref(SettingsActivity.this, true);
            }
        });
        shellClear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                saveShellPref(SettingsActivity.this, false);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    finish();
                } catch (Exception ignored) {
                }
            }
        });
        paintRows();
    }

    // v33: write (or clear) the shell pref. Refuses to save a value that would
    // not validate, so the launcher never shows a silently-rejected path; the
    // user learns here instead. Clearing always succeeds.
    private void saveShellPref(Context ctx, boolean save) {
        String msg = "";
        int color = Ui.DIM;
        try {
            final String raw = save && shellInput != null ? shellInput.getText().toString().trim() : "";
            if (raw.isEmpty()) {
                writeShellPref(ctx, "");
                msg = "Using the system shell (probe chain).";
            } else {
                final String ok = ShellPath.validate(raw);
                if (ok.isEmpty()) {
                    msg = "Not an executable file: " + raw;
                    color = Ui.RED;
                    if (shellStatus != null) {
                        shellStatus.setText(msg);
                        shellStatus.setTextColor(color);
                    }
                    return; // do not persist a value that cannot be used
                }
                writeShellPref(ctx, ok);
                msg = "Saved. New sessions will use it.";
                color = Ui.GREEN;
            }
            if (shellInput != null) {
                shellInput.setText(raw);
            }
        } catch (Exception ignored) {
            msg = "Could not save (error)";
            color = Ui.RED;
        }
        if (shellStatus != null) {
            shellStatus.setText(msg);
            shellStatus.setTextColor(color);
        }
    }

    private static void writeShellPref(Context ctx, String value) {
        try {
            final android.content.SharedPreferences sp = ctx.getSharedPreferences("aetherix", Context.MODE_PRIVATE);
            final android.content.SharedPreferences.Editor ed = sp.edit();
            ed.putString("shell_path", value);
            ed.commit();
        } catch (Exception ignored) {
        }
    }

    public void onResume() {
        super.onResume();
        paintRows();
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        Perms.onRequestPermissionsResult(this, requestCode, permissions, grantResults);
        paintRows();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Perms.onActivityResult(this, requestCode, resultCode, data);
        paintRows();
    }

    private void paintRows() {
        final String nL;
        if (Perms.needsNotifyPermission(this)) {
            nL = "Notifications: GRANT — shows the session Stop button (why: without it a live session has no visible off-switch)";
        } else {
            nL = "Notifications: done";
        }
        final String fL;
        if (Perms.needsFilesAccess(this)) {
            fL = "Shared files: GRANT — lets sd reach /sdcard (why: without it the shell sees only its private dir)";
        } else {
            fL = "Shared files: done";
        }
        final String bL;
        if (Perms.needsBatteryExemption(this)) {
            bL = "Stay alive: GRANT — exempts the session from Doze/OEM killers (why: without it the shell dies in background)";
        } else {
            bL = "Stay alive: done";
        }
        runOnUiThread(new Runnable() {
            public void run() {
                try {
                    if (pNotify != null) {
                        pNotify.setText(nL);
                    }
                    if (pFiles != null) {
                        pFiles.setText(fL);
                    }
                    if (pBatt != null) {
                        pBatt.setText(bL);
                    }
                } catch (Exception ignored) {
                }
            }
        });
    }

    // Summary for the launcher badge ("2 of 3 granted"). Static so the
    // launcher reads it without opening this activity.
    public static String summary(Context ctx) {
        try {
            int missing = 0;
            if (Perms.needsNotifyPermission(ctx)) {
                missing++;
            }
            if (Perms.needsFilesAccess(ctx)) {
                missing++;
            }
            if (Perms.needsBatteryExemption(ctx)) {
                missing++;
            }
            final int done = 3 - missing;
            return done + " of 3 granted";
        } catch (Exception e) {
            return "? of 3";
        }
    }
}
