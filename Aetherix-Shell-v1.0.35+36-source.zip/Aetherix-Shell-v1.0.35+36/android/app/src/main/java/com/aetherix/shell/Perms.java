package com.aetherix.shell;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Permission flows, extracted verbatim from the v21 launcher rows so the
 * settings page grants identically. Context-param style (not MainActivity
 * methods) so both activities share them. Refresh callbacks route back
 * through the caller's paint: launcher uses refresh(), settings uses
 * paintRows() — callers repaint after each call that may change state.
 * No lambdas, no diamonds.
 */
public class Perms {
    public static final int REQ_NOTIFY = 4101;
    public static final int REQ_FILES = 4102;

    public static boolean needsNotifyPermission(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT < 33) {
                return false;
            }
            return ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean needsFilesAccess(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                return android.os.Environment.isExternalStorageManager() == false;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                final boolean r = ctx.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == android.content.pm.PackageManager.PERMISSION_GRANTED;
                final boolean w = ctx.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == android.content.pm.PackageManager.PERMISSION_GRANTED;
                return (r && w) == false;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean needsBatteryExemption(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT < 23) {
                return false;
            }
            final android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (pm == null) {
                return false;
            }
            return pm.isIgnoringBatteryOptimizations(ctx.getPackageName()) == false;
        } catch (Exception e) {
            return false;
        }
    }

    public static void ensureNotifyPermission(Activity act) {
        try {
            if (Build.VERSION.SDK_INT < 33) {
                return;
            }
            final int g;
            try {
                g = act.checkSelfPermission("android.permission.POST_NOTIFICATIONS");
            } catch (Exception e) {
                return;
            }
            if (g == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return;
            }
            boolean asked = false;
            try {
                final android.content.SharedPreferences sp = act.getSharedPreferences("aetherix", Context.MODE_PRIVATE);
                asked = sp.getBoolean("notifyAsked", false);
            } catch (Exception ignored) {
            }
            if (asked) {
                EventLog.append(act, "app", "notify perm denied earlier, not re-asking");
                return;
            }
            try {
                act.requestPermissions(new String[] { "android.permission.POST_NOTIFICATIONS" }, REQ_NOTIFY);
            } catch (Exception ignored) {
            }
        } catch (Exception ignored) {
        }
    }

    public static void ensureFilesAccess(Activity act) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                boolean managed = false;
                try {
                    managed = android.os.Environment.isExternalStorageManager();
                } catch (Exception ignored) {
                }
                if (managed) {
                    return;
                }
                boolean asked = false;
                try {
                    final android.content.SharedPreferences sp = act.getSharedPreferences("aetherix", Context.MODE_PRIVATE);
                    asked = sp.getBoolean("filesAsked", false);
                } catch (Exception ignored) {
                }
                if (asked) {
                    EventLog.append(act, "app", "all-files not granted, not re-asking");
                    return;
                }
                try {
                    final Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    i.setData(android.net.Uri.parse("package:" + act.getPackageName()));
                    act.startActivityForResult(i, REQ_FILES);
                } catch (Exception e) {
                    try {
                        final Intent i2 = new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        act.startActivityForResult(i2, REQ_FILES);
                    } catch (Exception ignored) {
                    }
                }
                return;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                boolean haveR = false;
                boolean haveW = false;
                try {
                    haveR = act.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == android.content.pm.PackageManager.PERMISSION_GRANTED;
                    haveW = act.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == android.content.pm.PackageManager.PERMISSION_GRANTED;
                } catch (Exception ignored) {
                }
                if (haveR && haveW) {
                    return;
                }
                try {
                    act.requestPermissions(new String[] { "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE" }, REQ_FILES);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void requestBatteryExemption(Activity act) {
        try {
            if (Build.VERSION.SDK_INT < 23) {
                EventLog.append(act, "app", "battery exemption needs Android 6+");
                return;
            }
            final android.os.PowerManager pm = (android.os.PowerManager) act.getSystemService(Context.POWER_SERVICE);
            if (pm != null && pm.isIgnoringBatteryOptimizations(act.getPackageName())) {
                EventLog.append(act, "app", "already exempt from battery optimization");
                return;
            }
            final Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(android.net.Uri.parse("package:" + act.getPackageName()));
            act.startActivity(i);
            EventLog.append(act, "app", "battery exemption requested");
        } catch (Exception e) {
            EventLog.append(act, "app", "battery screen blocked: " + String.valueOf(e.getMessage()));
        }
    }

    public static void onActivityResult(Activity act, int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == REQ_FILES) {
                try {
                    final android.content.SharedPreferences sp = act.getSharedPreferences("aetherix", Context.MODE_PRIVATE);
                    sp.edit().putBoolean("filesAsked", true).commit();
                } catch (Exception ignored) {
                }
                boolean managed = false;
                try {
                    managed = android.os.Environment.isExternalStorageManager();
                } catch (Exception ignored) {
                }
                EventLog.append(act, "app", "all-files " + (managed ? "granted" : "not granted"));
            }
        } catch (Exception ignored) {
        }
    }

    public static void onRequestPermissionsResult(Activity act, int requestCode, String[] permissions, int[] grantResults) {
        try {
            if (requestCode == REQ_FILES) {
                boolean ok = false;
                try {
                    ok = grantResults != null && grantResults.length >= 2
                            && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
                            && grantResults[1] == android.content.pm.PackageManager.PERMISSION_GRANTED;
                } catch (Exception ignored) {
                }
                EventLog.append(act, "app", "external rw " + (ok ? "granted" : "denied"));
                return;
            }
            if (requestCode == REQ_NOTIFY) {
                try {
                    final android.content.SharedPreferences sp = act.getSharedPreferences("aetherix", Context.MODE_PRIVATE);
                    sp.edit().putBoolean("notifyAsked", true).commit();
                } catch (Exception ignored) {
                }
                boolean ok = false;
                try {
                    ok = grantResults != null && grantResults.length > 0
                            && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
                } catch (Exception ignored) {
                }
                EventLog.append(act, "app", "notify perm " + (ok ? "granted" : "denied"));
            }
        } catch (Exception ignored) {
        }
    }
}
