package com.aetherix.shell;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Single-view terminal: ShellView owns display + IME for life.
 * v8: output TextView + 1px catcher removed. No selection mode, no focus
 * ping-pong. Copy is via dialog/Share (output never focusable). Keyboard is
 * user-toggle + tap + conditional resume only; no unconditional restartInput,
 * no onWindowFocusChanged rebind, no retry timers. Typing never needs a
 * handoff, so it also ends selection by construction (nothing to exit).
 * No lambdas, no diamonds.
 */
public class TerminalActivity extends Activity {
    private ShellView shell = null;
    private LinearLayout root = null;
    private Button ctrlBtn = null;
    private volatile boolean ctrlLatched = false;
    private boolean imeWasVisible = false;
    private boolean created = false;

    private final ShellSession.Listener sessionListener = new ShellSession.Listener() {
        public void onOutput(String transcriptSnapshot) {
            if (shell != null) {
                shell.setTranscript(transcriptSnapshot);
            }
        }
        public void onGrid(VtGrid grid) {
            if (shell != null) {
                shell.setGrid(grid);
            }
        }
        public void onClosed() {
            // v20: the dead session belongs to the launcher now. Finish back
            // to MainActivity (which shows New session when idle) instead of
            // growing an in-terminal button. Backgrounded: finish silently so
            // the idle service can stop itself.
            try {
                final android.content.Intent i = new android.content.Intent(TerminalActivity.this, MainActivity.class);
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
            } catch (Exception ignored) {
            }
            try {
                finish();
            } catch (Exception ignored) {
            }
        }
    };

    private int themeColor(int attr, int fallback) {
        try {
            final android.util.TypedValue tv = new android.util.TypedValue();
            if (getTheme().resolveAttribute(attr, tv, true)) {
                return tv.data;
            }
        } catch (Exception ignored) {
        }
        return fallback;
    }

    public void onCreate(Bundle savedInstanceState) {
        CrashLog.install(this);
        super.onCreate(savedInstanceState);
        final int fg = themeColor(android.R.attr.textColorPrimary, 0xFF212121);
        final int bg;
        final int nightMask = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        final boolean night = nightMask == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            bg = 0xFF121212;
        } else {
            bg = 0xFFFFFFFF;
        }
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(false);
        final LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        final android.widget.TextView barTitle = new android.widget.TextView(this);
        barTitle.setText("Aetherix shell");
        barTitle.setTextColor(fg);
        barTitle.setClickable(true);
        barTitle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // v20: show-only. The old toggle hid the keyboard when it was
                // already up, so tapping around felt dead/backwards (v19
                // field: "tapping does nothing except shrink the keyboard").
                showKeyboard();
            }
        });
        final LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        bar.addView(barTitle, titleLp);
        barRow = bar;
        // v20: Copy/Paste buttons removed. Selection-copy is proven (long-press
        // word select + drag + floating Copy/Share) and paste comes from the
        // keyboard's own clipboard — the buttons were dead screen space.
        // Code paths (copySelection/pasteFromClipboard) deleted with them.
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        shell = new ShellView(this);
        shell.setColors(fg, bg);
        final LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(0xFF39FF14);
        final int edge = (int) (2.0f * getResources().getDisplayMetrics().density + 0.5f);
        screen.setPadding(edge, edge, edge, edge);
        screen.addView(shell, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        final LinearLayout.LayoutParams shellLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f);
        root.addView(screen, shellLp);
        buildKeybar();
        if (android.os.Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try {
                        final int top;
                        final int bottom;
                        if (android.os.Build.VERSION.SDK_INT >= 30) {
                            final android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                            final android.graphics.Insets ime = insets.getInsets(android.view.WindowInsets.Type.ime());
                            top = bars.top;
                            final int sysBottom = bars.bottom;
                            final int imeBottom = ime.bottom;
                            if (sysBottom > imeBottom) {
                                bottom = sysBottom;
                            } else {
                                bottom = imeBottom;
                            }
                            if (imeBottom > 0) {
                                imeWasVisible = true;
                            }
                        } else {
                            top = insets.getSystemWindowInsetTop();
                            bottom = insets.getSystemWindowInsetBottom();
                        }
                        v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), bottom);
                    } catch (Exception ignored) {
                    }
                    return insets;
                }
            });
        }
        shell.setSink(new ShellView.Sink() {
            // Map a character under a latched CTRL to its control code.
            // Letters: a-z/A-Z -> 1-26. Extra original mappings: space -> NUL(0),
            // ? -> DEL(127), [/] -> ESC/GS, 2/@ -> NUL, 4-7 -> FS-US.
            // Returns -1 when the char has no CTRL meaning (latch still consumed).
            private int ctrlCode(char c) {
                if (c >= 'a' && c <= 'z') {
                    return c - 96;
                }
                if (c >= 'A' && c <= 'Z') {
                    return c - 64;
                }
                if (c == ' ' || c == '2' || c == '@') {
                    return 0;
                }
                if (c == '[') {
                    return 27;
                }
                if (c == '\\') {
                    return 28;
                }
                if (c == ']') {
                    return 29;
                }
                if (c == '^' || c == '6') {
                    return 30;
                }
                if (c == '_' || c == '7') {
                    return 31;
                }
                if (c == '?') {
                    return 127;
                }
                return -1;
            }
            public void sendText(String s, String src) {
                final boolean hadCtrl = ctrlLatched;
                setCtrl(false);
                if (hadCtrl && s.length() == 1) {
                    final int code = ctrlCode(s.charAt(0));
                    if (code >= 0) {
                        if (ensureSession() == false) {
                            return;
                        }
                        final int w = ShellSession.get().writeText(String.valueOf((char) code));
                        EventLog.append(TerminalActivity.this, "input", "[" + src + "] ctrl code=" + code + " wrote=" + w);
                        return;
                    }
                    // Unmapped char under CTRL: fall through as literal text
                    // (latch already consumed above, like a real sticky key).
                }
                if (ensureSession() == false) {
                    return;
                }
                final int wrote = ShellSession.get().writeText(s);
                EventLog.append(TerminalActivity.this, "input", "[" + src + "] text len=" + s.length() + " wrote=" + wrote);
            }
            public void sendDel(int n, String src) {
                // CTRL+DEL (from a latched CTRL) sends DEL-as-BS word kill ^W
                // instead of a plain erase; plain DEL otherwise.
                final boolean hadCtrl = ctrlLatched;
                setCtrl(false);
                if (ensureSession() == false) {
                    return;
                }
                if (hadCtrl) {
                    final int w = ShellSession.get().writeText(String.valueOf((char) 23));
                    EventLog.append(TerminalActivity.this, "input", "[" + src + "] ctrl-del (^W) wrote=" + w);
                    return;
                }
                final int[] r = ShellSession.get().writeDel(n);
                EventLog.append(TerminalActivity.this, "input", "[" + src + "] del n=" + n + " wrote=" + r[0] + " err=" + r[1]);
            }
            public void sendEnter(String src) {
                setCtrl(false);
                if (ensureSession() == false) {
                    return;
                }
                final int w = ShellSession.get().writeText("\r");
                EventLog.append(TerminalActivity.this, "input", "[" + src + "] enter wrote=" + w);
            }
        });
        shell.setTapListener(new ShellView.TapListener() {
            public void onTap() {
                ensureKeyboard();
            }
            public void onLongPress(float x, float y) {
                EventLog.append(TerminalActivity.this, "copy", "select start");
            }
            public void onSelectionDrag(float x, float y) {
                // v31: the finger moved during a scroll-drag, so the user is
                // reading, not editing the selection. Drop the floating
                // Copy/Share/Select-all bar — it covered the screen after
                // Select All and the terminal felt "stuck in the menu".
                // keepSelectionOnModeDestroy stops onDestroyActionMode from
                // wiping the anchors we just kept pinned to their rows.
                if (selectionMode != null) {
                    keepSelectionOnModeDestroy = true;
                    finishSelectionActions();
                }
            }
            public void onSelectionDone() {
                // Platform behavior: TextView shows Copy/Share in a floating
                // ActionMode anchored at the selection, never a modal dialog.
                // The dialog stole focus + covered the text, which is why
                // fine-tuning the selection felt broken.
                showSelectionActions();
            }
        });
        setContentView(root);
        PtyBridge.ensureLoaded();
        shell.setSizeListener(new ShellView.SizeListener() {
            public void onSize(int rows, int cols) {
                try {
                    ShellSession.get().setSize(rows, cols);
                } catch (Exception ignored) {
                }
            }
        });
        // v16: onCreate is the explicit entry path (user tapped Open
        // terminal), so start here is allowed. All implicit paths
        // (onResume / keypress / Back-return) must NOT start.
        // v24: also start the service explicitly. EnvService owns the
        // session and its foreground notification (with Stop) — since v16
        // nothing on the terminal path started it, so live sessions ran
        // with no notification at all (v23 field: granted perm, no notice).
        startEnvService();
        ShellSession.get().start(getApplicationContext());
        ShellSession.get().attach(sessionListener);
        // W3: layout may already be settled (no onSizeChanged coming), and the
        // session may have ignored the earlier report while down. Push the
        // real geometry now so winsize is right from the first prompt.
        shell.post(new Runnable() {
            public void run() {
                try {
                    shell.reportSize();
                } catch (Exception ignored) {
                }
            }
        });
        created = true;
        shell.postDelayed(new Runnable() {
            public void run() {
                ensureKeyboard();
            }
        }, 300L);
    }

    // Blank-screen fix (v22 field): this activity is singleTask, so a New
    // session tap while an instance lives re-fronts it via onNewIntent —
    // onCreate (the only start() path) never runs, and onResume attaches
    // the cleared transcript: blank. Explicit re-entry IS a user tap, so
    // start fresh when dead; when alive just re-attach (onResume covers).
    public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        try {
            setIntent(intent);
        } catch (Exception ignored) {
        }
        try {
            if (ShellSession.get().isRunning() == false) {
                EventLog.append(this, "pty", "re-entry on dead session, starting fresh");
                startEnvService();
                ShellSession.get().start(getApplicationContext());
                ShellSession.get().attach(sessionListener);
                if (shell != null) {
                    shell.post(new Runnable() {
                        public void run() {
                            try {
                                shell.reportSize();
                            } catch (Exception ignored) {
                            }
                        }
                    });
                }
            }
        } catch (Exception ignored) {
        }
    }

    public void onResume() {
        super.onResume();
        // v16: dead stays dead. onResume never revives: the user sees the
        // [process exited] marker + New session button. Silent revive here
        // is what undid stopSelf after exit+swipe in v15 field logs.
        // v28: re-assert the notice WITHOUT starting a session (dead stays
        // dead, v16). Swiping the notification away stops the service while
        // the session lives on detached; REASSERT re-posts the Stop button
        // on return. Dead session -> service self-stops, nothing revived.
        reassertService();
        ShellSession.get().attach(sessionListener);
        if (imeWasVisible) {
            ensureKeyboard();
        }
        // Same W3 push on every return: the session may have died and been
        // revived with default 24x80 while we were away.
        if (shell != null) {
            shell.post(new Runnable() {
                public void run() {
                    try {
                        shell.reportSize();
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }

    public void onPause() {
        try {
            imeWasVisible = imeAlive();
        } catch (Exception ignored) {
        }
        try {
            finishSelectionActions();
        } catch (Exception ignored) {
        }
        try {
            ShellSession.get().detach(sessionListener);
        } catch (Exception ignored) {
        }
        super.onPause();
    }

    private void buildKeybar() {
        final int fg = themeColor(android.R.attr.textColorPrimary, 0xFF212121);
        final android.widget.HorizontalScrollView hscroll = new android.widget.HorizontalScrollView(this);
        final LinearLayout keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        // Table lives in Keybar (Android-free, unit-tested): kind 2 is the
        // RESERVED sparkle slot and must stay that way. Never dispatch on
        // hardcoded indices.
        final String[] labels = Keybar.LABELS;
        final String[] codes = Keybar.CODES;
        final int[] kinds = Keybar.KINDS;
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            final Button b = new Button(this);
            b.setText(labels[idx]);
            b.setTextColor(fg);
            b.setTextSize(12.0f);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            if (kinds[idx] == 1) {
                ctrlBtn = b;
            }
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    onKeybarPress(idx, codes, kinds);
                }
            });
            keys.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        hscroll.addView(keys, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(hscroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void onKeybarPress(final int idx, final String[] codes, final int[] kinds) {
        final int kind = kinds[idx];
        if (kind == Keybar.KIND_CTRL) {
            if (ctrlLatched) {
                setCtrl(false);
            } else {
                setCtrl(true);
            }
            return;
        }
        if (kind == Keybar.KIND_RESERVED) {
            // Reserved for a downstream app feature. Keep the slot and do
            // not reuse it; log so a field report can prove it is still live.
            EventLog.append(this, "keybar", "sparkle reserved");
            return;
        }
        if (kind == Keybar.KIND_PASTE) {
            pasteFromClipboard();
            return;
        }
        if (kind == Keybar.KIND_KILL) {
            killForeground();
            return;
        }
        final boolean hadCtrl = ctrlLatched;
        setCtrl(false);
        // Cursor keys depend on the app's mode: a full-screen app (vi, less)
        // sets ?1h (DECCKM) and then expects ESC O A..D, not ESC [ A..D.
        // Sending the wrong form is why arrows can go dead inside vi.
        final String seq;
        if (kind == Keybar.KIND_CURSOR) {
            seq = cursorSeq(codes[idx].charAt(0));
        } else if (kind == Keybar.KIND_END) {
            seq = cursorSeq('F');
        } else {
            seq = codes[idx];
        }
        if (kind == Keybar.KIND_END) {
            if (shell != null) {
                shell.setFollowBottom(true);
            }
            if (hadCtrl) {
                EventLog.append(this, "keybar", "end (ctrl cleared)");
                return;
            }
            if (ensureSession() == false) {
                return;
            }
            final int w = ShellSession.get().writeText(seq);
            EventLog.append(this, "keybar", "end wrote=" + w);
            return;
        }
        // CTRL+arrow (latched CTRL + cursor key): send the xterm-style
        // modified sequence ESC[1;5X instead of the plain one. The modified
        // form is always CSI, even in application-cursor mode.
        if (hadCtrl && kind == Keybar.KIND_CURSOR) {
            final char last = codes[idx].charAt(0);
            final String mod = String.valueOf((char) 27) + "[1;5" + String.valueOf(last);
            if (ensureSession() == false) {
                return;
            }
            final int w = ShellSession.get().writeText(mod);
            EventLog.append(this, "keybar", "ctrl-arrow wrote=" + w);
            return;
        }
        sendKey(seq);
    }

    /**
     * v36 KILL: SIGKILL the process group that owns the terminal right now.
     * The session deliberately survives app restarts, so a wedged
     * full-screen app (vi whose ESC never landed) would otherwise trap the
     * user with no way out. Refuses to kill the shell itself - ending the
     * session is the launcher Stop action, not a stray keybar tap. When the
     * kill lands, full-screen modes are cleared here because the dead app
     * never restored the alt screen.
     */
    private void killForeground() {
        if (ctrlLatched) {
            setCtrl(false);
        }
        if (ensureSession() == false) {
            return;
        }
        final int pg = ShellSession.get().killForeground();
        if (pg > 0) {
            if (shell != null) {
                shell.leaveFullScreen();
            }
            EventLog.append(this, "keybar", "kill fg pgrp=" + pg);
            android.widget.Toast.makeText(this,
                    "Foreground process killed (pgrp " + pg + ")",
                    android.widget.Toast.LENGTH_SHORT).show();
        } else {
            EventLog.append(this, "keybar", "kill skipped (no fg job)");
            android.widget.Toast.makeText(this,
                    "No foreground job - Stop ends the session",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private String cursorSeq(final char last) {
        final char second;
        if (shell != null && shell.isAppCursor()) {
            second = 'O';
        } else {
            second = '[';
        }
        return String.valueOf((char) 27) + String.valueOf(second) + String.valueOf(last);
    }

    /**
     * Clipboard -> PTY. Explicit user action only (no background polling);
     * the payload rules live in PasteText so they are unit-tested. A latched
     * CTRL is cleared first: otherwise the first pasted char would be turned
     * into a control code.
     */
    private void pasteFromClipboard() {
        if (ctrlLatched) {
            setCtrl(false);
        }
        String text = null;
        try {
            final android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip()) {
                final android.content.ClipData clip = cm.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    final CharSequence cs = clip.getItemAt(0).coerceToText(this);
                    if (cs != null) {
                        text = cs.toString();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        if (text == null || text.length() == 0) {
            EventLog.append(this, "input", "[paste] empty");
            return;
        }
        final boolean bracketed = (shell != null && shell.isBracketedPaste());
        final boolean truncated = PasteText.wouldTruncate(text, PasteText.CAP);
        final String payload = PasteText.prepare(text, bracketed, PasteText.CAP);
        if (payload.length() == 0) {
            EventLog.append(this, "input", "[paste] empty after normalize");
            return;
        }
        if (ensureSession() == false) {
            return;
        }
        final int w = ShellSession.get().writeText(payload);
        EventLog.append(this, "input", "[paste] chars=" + text.length()
                + " sent=" + payload.length() + " bracketed=" + bracketed
                + " truncated=" + truncated + " wrote=" + w);
        if (truncated) {
            android.widget.Toast.makeText(this,
                    "Paste capped at " + PasteText.CAP + " characters",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
        if (shell != null) {
            shell.setFollowBottom(true);
        }
    }

    private void setCtrl(final boolean on) {
        if (ctrlLatched == on) {
            return;
        }
        ctrlLatched = on;
        paintKeybar();
        if (on) {
            EventLog.append(this, "keybar", "ctrl on");
        } else {
            EventLog.append(this, "keybar", "ctrl off");
        }
    }

    private void paintKeybar() {
        try {
            if (ctrlBtn == null) {
                return;
            }
            final boolean on = ctrlLatched;
            ctrlBtn.post(new Runnable() {
                public void run() {
                    try {
                        if (on) {
                            ctrlBtn.setBackgroundColor(0xFF39FF14);
                        } else {
                            ctrlBtn.setBackgroundColor(0x00000000);
                            ctrlBtn.invalidate();
                        }
                    } catch (Exception ignored) {
                    }
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void sendKey(final String seq) {
        if (seq == null) {
            return;
        }
        if (ensureSession() == false) {
            return;
        }
        final int w = ShellSession.get().writeText(seq);
        EventLog.append(this, "keybar", "len=" + seq.length() + " wrote=" + w);
    }

    private void logIme(String where) {
        try {
            final boolean f = shell.hasFocus();
            final boolean wf = shell.hasWindowFocus();
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            boolean acc = false;
            if (imm != null) {
                acc = imm.isAcceptingText();
            }
            final String cur = where + " focus=" + f + " win=" + wf + " acc=" + acc;
            if (cur.equals(lastImeLog)) {
                return;
            }
            lastImeLog = cur;
            EventLog.append(this, "ime", cur);
        } catch (Exception ignored) {
        }
    }

    private String lastImeLog = "";

    private boolean ensureSession() {
        // v16: input paths never start sessions. A keypress that resurrects
        // a stopped service is the v15 linger bug (log 00:44:40+ input after
        // stopSelf). v20: dead input returns to the launcher (New session
        // lives there); the terminal never grows its own revive button.
        try {
            final ShellSession s = ShellSession.get();
            if (s.isRunning()) {
                return true;
            }
            goLauncher();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    // v24: explicit service start for the terminal path. Plain intent
    // (no STOP action): the service starts the session itself if needed
    // and posts the ongoing notification with Stop. Safe to call when the
    // service already runs (start is idempotent-ish: reconcile keeps).
    private void startEnvService() {
        try {
            final Intent svc = new Intent(this, EnvService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                try {
                    startForegroundService(svc);
                } catch (Exception e) {
                    startService(svc);
                }
            } else {
                startService(svc);
            }
        } catch (Exception e) {
            EventLog.append(this, "pty", "service start blocked: " + String.valueOf(e.getMessage()));
        }
    }

    // v28: REASSERT ping (see EnvService.ACTION_REASSERT). Refreshes the
    // notification without starting anything — safe on live AND dead.
    private void reassertService() {
        try {
            final Intent svc = new Intent(this, EnvService.class);
            svc.setAction(EnvService.ACTION_REASSERT);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                try {
                    startForegroundService(svc);
                } catch (Exception e) {
                    startService(svc);
                }
            } else {
                startService(svc);
            }
        } catch (Exception e) {
            EventLog.append(this, "pty", "reassert blocked: " + String.valueOf(e.getMessage()));
        }
    }

    // v20: the single path back to the launcher (dead session, exit, Back).
    private void goLauncher() {        try {
            final android.content.Intent i = new android.content.Intent(this, MainActivity.class);
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Exception ignored) {
        }
        try {
            finish();
        } catch (Exception ignored) {
        }
    }

    private boolean imeAlive() {
        try {
            if (shell.hasFocus() == false || shell.hasWindowFocus() == false) {
                return false;
            }
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm == null) {
                return false;
            }
            return imm.isAcceptingText();
        } catch (Exception e) {
            return false;
        }
    }

    private void ensureKeyboard() {
        // v20: tap means SHOW. The old path called showSoftInput while the
        // view lacked focus (silently ignored) and only repaired when
        // isAcceptingText was already false — so taps felt dead (v19 field:
        // "have to back out or reopen"). Now: force focus first, then
        // SHOW_FORCED, retrying on the next frame while the window is dead.
        logIme("ensure");
        showKeyboard();
    }

    private int kbRetries = 0;

    private void showKeyboard() {
        try {
            if (shell.hasFocus() == false) {
                shell.requestFocus();
            }
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm == null) {
                return;
            }
            if (shell.hasWindowFocus() == false) {
                // Window not ready (first tap after launch): retry a few
                // frames later instead of dropping the tap silently.
                if (kbRetries < 5) {
                    kbRetries++;
                    shell.postDelayed(new Runnable() {
                        public void run() {
                            showKeyboard();
                        }
                    }, 120L);
                }
                return;
            }
            kbRetries = 0;
            try {
                imm.restartInput(shell);
            } catch (Exception ignored) {
            }
            imm.showSoftInput(shell, InputMethodManager.SHOW_FORCED);
        } catch (Exception ignored) {
        }
    }

    private boolean keepSelectionOnModeDestroy = false;
    private ActionMode selectionMode = null;
    private LinearLayout barRow = null;

    // v20: the toolbar row is title-only now (Copy/Paste buttons removed), so
    // there is nothing to hide while selecting. Floating Copy/Share still
    // anchors at the selection. Kept as no-ops for the call sites.
    private void setBarSelecting(boolean selecting) {
    }

    private String currentSelection() {
        try {
            String sel = "";
            if (shell != null) {
                sel = shell.getSelectedText();
            }
            if (sel == null) {
                sel = "";
            }
            if (sel.length() > 8000) {
                sel = sel.substring(0, 8000);
            }
            return sel;
        } catch (Exception e) {
            return "";
        }
    }

    private void finishSelectionActions() {
        if (selectionMode != null) {
            try {
                selectionMode.finish();
            } catch (Exception ignored) {
            }
            selectionMode = null;
        }
    }

    // v17: floating Copy/Share bar anchored AT the selection
    // (TYPE_FLOATING), not the window top bar. v15/v16 used the default
    // startActionMode, which lands in the decor top bar and reads as a
    // doubled COPY/SHARE row under our toolbar. Floating matches TextView.
    // While selecting, the toolbar COPY/PASTE row hides so only one bar shows.
    private void showSelectionActions() {
        try {
            if (shell == null || shell.hasSelection() == false) {
                return;
            }
            if (selectionMode != null) {
                try {
                    selectionMode.invalidate();
                } catch (Exception ignored) {
                }
                return;
            }
            setBarSelecting(true);
            ActionMode.Callback cb = new ActionMode.Callback() {
                public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                    try {
                        // v31: a fresh bar means a fresh intent — reset the
                        // scroll-away exception so a later Copy/Share/tap
                        // clears the selection normally.
                        keepSelectionOnModeDestroy = false;
                        menu.add(0, 1, 0, "Copy");
                        menu.add(0, 2, 1, "Share");
                        // v30: Select all (no comparator ships one; this is
                        // the only practical way to capture a full scroll).
                        menu.add(0, 3, 2, "Select all");
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                    return false;
                }
                public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                    try {
                        final int id = item.getItemId();
                        if (id == 1) {
                            copySelection();
                            mode.finish();
                            return true;
                        }
                        if (id == 2) {
                            shareSelection();
                            mode.finish();
                            return true;
                        }
                        if (id == 3) {
                            // Select all: expand, keep the bar open so Copy
                            // is one tap away (mode.finish() would clear it).
                            if (shell != null) {
                                shell.selectAll();
                                mode.invalidate();
                            }
                            return true;
                        }
                    } catch (Exception ignored) {
                    }
                    return false;
                }
                public void onDestroyActionMode(ActionMode mode) {
                    selectionMode = null;
                    setBarSelecting(false);
                    if (keepSelectionOnModeDestroy) {
                        // v31: scrolled away from the bar on purpose; the
                        // selection survives so Copy still works on a
                        // long-press.
                        return;
                    }
                    try {
                        if (shell != null) {
                            shell.clearSelection();
                        }
                    } catch (Exception ignored) {
                    }
                }
            };
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                selectionMode = startActionMode(cb, ActionMode.TYPE_FLOATING);
            } else {
                selectionMode = startActionMode(cb);
            }
            if (selectionMode == null) {
                // Pre-M / OEM without floating mode: fall back to a direct
                // copy of the word so long-press never silently does nothing.
                setBarSelecting(false);
                copySelection();
                if (shell != null) {
                    shell.clearSelection();
                }
            }
        } catch (Exception e) {
            EventLog.append(this, "copy", "actions blocked: " + String.valueOf(e.getMessage()));
        }
    }

    private void copySelection() {
        try {
            final String msg = currentSelection();
            if (msg.length() == 0) {
                return;
            }
            final android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("aetherix-terminal", msg));
            EventLog.append(TerminalActivity.this, "copy", "chars=" + msg.length());
        } catch (Exception e) {
            EventLog.append(TerminalActivity.this, "copy", "blocked: " + String.valueOf(e.getMessage()));
        }
        try {
            if (shell != null) {
                shell.clearSelection();
            }
        } catch (Exception ignored) {
        }
        ensureKeyboard();
    }

    private void shareSelection() {
        try {
            final String msg = currentSelection();
            if (msg.length() == 0) {
                return;
            }
            final android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(android.content.Intent.EXTRA_TEXT, msg);
            startActivity(android.content.Intent.createChooser(i, "Share terminal text"));
            EventLog.append(TerminalActivity.this, "copy", "shared chars=" + msg.length());
        } catch (Exception e) {
            EventLog.append(TerminalActivity.this, "copy", "share blocked: " + String.valueOf(e.getMessage()));
        }
        try {
            if (shell != null) {
                shell.clearSelection();
            }
        } catch (Exception ignored) {
        }
        ensureKeyboard();
    }

    public void onBackPressed() {
        try {
            if (selectionMode != null) {
                finishSelectionActions();
                if (shell != null) {
                    shell.clearSelection();
                }
                return;
            }
        } catch (Exception ignored) {
        }
        try {
            if (shell != null && shell.hasSelection()) {
                shell.clearSelection();
                return;
            }
        } catch (Exception ignored) {
        }
        boolean hidden = false;
        try {
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && shell != null) {
                try {
                    hidden = imm.hideSoftInputFromWindow(shell.getWindowToken(), 0);
                } catch (Exception ignored) {
                    hidden = false;
                }
            }
        } catch (Exception ignored) {
        }
        if (hidden) {
            return;
        }
        // v24: Back leaves via goLauncher (finishes this activity). The old
        // REORDER_TO_FRONT without finish kept a dead Terminal under Main:
        // every return re-attached the cleared transcript and Back bounced
        // between the two until something blew up (v23 field: 10+ presses).
        goLauncher();
    }

    public void onDestroy() {
        try {
            ShellSession.get().detach(sessionListener);
        } catch (Exception ignored) {
        }
        // If the session is already dead, this destroy was the last UI going
        // away: tell the service to re-evaluate idle so it stops itself.
        try {
            if (ShellSession.get().isRunning() == false) {
                EnvService.sessionStateChanged(this);
            }
        } catch (Exception ignored) {
        }
        EventLog.append(this, "pty", "activity destroy (running=" + ShellSession.get().isRunning() + ")");
        super.onDestroy();
    }

    // P1.6: activity-side trim — drop view caches only. Session memory
    // belongs to the service; see EnvService.onTrimMemory.
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        try {
            if (shell != null) {
                shell.dropCaches();
            }
        } catch (Exception ignored) {
        }
    }
}
