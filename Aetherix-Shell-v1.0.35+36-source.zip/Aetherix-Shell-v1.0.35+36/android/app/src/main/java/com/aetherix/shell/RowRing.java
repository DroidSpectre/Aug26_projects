package com.aetherix.shell;

/**
 * Row-based scrollback ring for the legacy transcript pipeline.
 * Why: the old StringBuilder + 100KB byte cap penalized CJK/emoji
 * (3-4 bytes/char), cost O(n) memmove per flush (delete(0,N)), and had
 * no user-meaningful size. Rows map directly to scrollback UX and draw
 * cost. P1.4: default 2000 rows (~Termux parity), pref 100-10000.
 *
 * Model: ring of completed rows + one editable current line. Newline
 * pushes the current line (oldest overwritten past capacity). All
 * editing ops (backspace, clear-line, tab-fill, append) touch only the
 * current line — matches the old truncateLine semantics (CR redraw
 * affects the current line only). snapshot() joins oldest-to-newest
 * with \n, the exact protocol ShellView.setTranscript already parses.
 * Pure Java, unit-tested on a plain JVM. No lambdas, no diamonds.
 */
public class RowRing {
    public static final int DEFAULT_ROWS = 2000;
    public static final int MIN_ROWS = 100;
    public static final int MAX_ROWS = 10000;

    private final String[] ring;
    private final int cap;
    private int count = 0;
    private int head = 0;
    private final StringBuffer cur = new StringBuffer(256);

    public RowRing(int rows) {
        int r = rows;
        if (r < MIN_ROWS) {
            r = MIN_ROWS;
        }
        if (r > MAX_ROWS) {
            r = MAX_ROWS;
        }
        cap = r;
        ring = new String[cap];
    }

    public int capacity() {
        return cap;
    }

    public synchronized void clear() {
        count = 0;
        head = 0;
        cur.setLength(0);
        for (int i = 0; i < ring.length; i++) {
            ring[i] = null;
        }
    }

    // Completed-row count (excludes the live current line).
    public synchronized int rowCount() {
        return count;
    }

    public synchronized int currentLength() {
        return cur.length();
    }

    public synchronized void append(char c) {
        cur.append(c);
    }

    public synchronized void newline() {
        push(cur.toString());
        cur.setLength(0);
    }

    // Backspace: delete last char of the current line only (never crosses
    // into completed rows — matches the old guard on trailing '\n').
    public synchronized void backspace() {
        if (cur.length() > 0) {
            cur.deleteCharAt(cur.length() - 1);
        }
    }

    // CR-redraw truncate: wipe the current line only.
    public synchronized void clearLine() {
        cur.setLength(0);
    }

    private void push(String line) {
        if (count < cap) {
            ring[(head + count) % cap] = line;
            count++;
        } else {
            ring[head] = line;
            head = (head + 1) % cap;
        }
    }

    // P1.6 emergency compact: keep only the newest keep rows (+ live line).
    // Returns rows dropped. Never touches the current line.
    public synchronized int compact(int keep) {
        if (keep < 0) {
            keep = 0;
        }
        if (count <= keep) {
            return 0;
        }
        final int drop = count - keep;
        head = (head + drop) % cap;
        count = keep;
        return drop;
    }

    // Oldest-to-newest, \n-joined, current line as the tail (no trailing
    // newline — same shape the old StringBuilder produced mid-line).
    public synchronized String snapshot() {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < count; i++) {
            String s = ring[(head + i) % cap];
            if (s != null) {
                sb.append(s);
            }
            sb.append('\n');
        }
        sb.append(cur.toString());
        return sb.toString();
    }
}
