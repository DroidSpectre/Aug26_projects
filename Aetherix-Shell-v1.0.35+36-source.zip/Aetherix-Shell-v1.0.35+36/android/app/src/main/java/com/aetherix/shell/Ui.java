package com.aetherix.shell;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Dark card styling shared by launcher + settings (Alpine dashboard feel:
 * near-black background, slightly lighter rounded cards, blue accent).
 * One place for the palette so future theme work edits here. No lambdas.
 */
public class Ui {
    public static final int BG = 0xFF0D1117;
    public static final int CARD = 0xFF161B22;
    public static final int BORDER = 0xFF21262D;
    public static final int ACCENT = 0xFF58A6FF;
    public static final int TEXT = 0xFFC9D1D9;
    public static final int DIM = 0xFF8B949E;
    public static final int GREEN = 0xFF238636;
    public static final int RED = 0xFFDA3633;

    public static float density(Context ctx) {
        try {
            return ctx.getResources().getDisplayMetrics().density;
        } catch (Exception e) {
            return 1.0f;
        }
    }

    public static int dp(Context ctx, float v) {
        return (int) (v * density(ctx) + 0.5f);
    }

    // Rounded card container holding one content view.
    public static LinearLayout card(Context ctx, android.view.View inner) {
        final LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        try {
            final GradientDrawable d = new GradientDrawable();
            d.setColor(CARD);
            d.setCornerRadius(dp(ctx, 8.0f));
            d.setStroke(dp(ctx, 1.0f), BORDER);
            c.setBackgroundDrawable(d);
        } catch (Exception ignored) {
        }
        c.setPadding(dp(ctx, 14.0f), dp(ctx, 14.0f), dp(ctx, 14.0f), dp(ctx, 14.0f));
        c.addView(inner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    // Section label: small caps-ish dim header above a card.
    public static TextView section(Context ctx, String text) {
        final TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextColor(DIM);
        t.setTextSize(11.0f);
        return t;
    }

    // Button readable on dark cards (default Button is light-gray; keep it
    // but force dark text for contrast on both themes).
    public static Button darkButton(Context ctx) {
        final Button b = new Button(ctx);
        try {
            b.setTextColor(0xFF212121);
        } catch (Exception ignored) {
        }
        return b;
    }

    // Status pill line: bold label + coloured state word.
    public static TextView badge(Context ctx, String label, boolean good) {
        final TextView t = new TextView(ctx);
        t.setText(label);
        t.setTextSize(12.0f);
        try {
            if (good) {
                t.setTextColor(GREEN);
            } else {
                t.setTextColor(RED);
            }
        } catch (Exception ignored) {
        }
        return t;
    }
}
