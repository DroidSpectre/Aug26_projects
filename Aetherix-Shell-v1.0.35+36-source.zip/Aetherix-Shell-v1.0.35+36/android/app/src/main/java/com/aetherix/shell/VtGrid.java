package com.aetherix.shell;

/**
 * Clean-room VT grid: screen buffer + escape parser + scrollback.
 * Why: the old string pipeline strips all CSI, so vim/less/htop render as
 * garbage. This grid understands cursor addressing, erase, SGR colors and an
 * alt screen, while degrading to plain text for the legacy transcript view.
 *
 * Original implementation (no borrowed code): cell rows with packed int
 * styles, a main ring buffer with scrollback plus a fixed alt screen, and a
 * small hand-written parser for the subset below.
 *
 * Supported subset (deliberately minimal, extended on demand):
 *  printables, BS HT LF VT FF CR, ESC 7 / ESC 8 (save/restore cursor),
 *  CSI A B C D E F G H f (cursor), J (0/1/2 erase display), K (0/1/2 erase
 *  line), m (SGR 0/1/2/3/4/7/22-28/30-37/40-47/90-97/100-107/38;5;n/48;5;n/
 *  38;2;r;g;b/48;2;r;g;b/39/49), r (scroll margins), h/l ?25 (cursor show),
 *  h/l ?1049 and ?47 (alt screen), s/u (save/restore cursor), d (row),
 *  OSC 0/2 (title, consumed). Unknown sequences are skipped, never printed.
 *
 * Pure Java, no Android APIs: unit-testable on a plain JVM.
 * No lambdas, no diamonds.
 */
public class VtGrid {
    // Style packing (int per cell): [flags:8][bg:8][fg:8][unused:8].
    // fg/bg 0-7 standard, 8-15 bright, 16-255 xterm-256, 256+ truecolor
    // stored as palette index remap (see colorToFg). Flags below.
    public static final int F_BOLD = 1;
    public static final int F_DIM = 2;
    public static final int F_ITALIC = 4;
    public static final int F_UNDERLINE = 8;
    public static final int F_INVERSE = 16;
    public static final int F_HIDDEN = 32;

    private static final int MAX_SCROLLBACK = 1000;
    private static final int MAX_PARAMS = 16;

    // Parser states (own numbering).
    private static final int P_GROUND = 0;
    private static final int P_ESC = 1;
    private static final int P_CSI = 2;
    private static final int P_CSI_Q = 3;
    private static final int P_OSC = 4;

    private static class Row {
        char[] text;
        int[] style;
        boolean wrapped;
        Row(int cols) {
            text = new char[cols];
            style = new int[cols];
            for (int i = 0; i < cols; i++) {
                text[i] = ' ';
                style[i] = 0;
            }
            wrapped = false;
        }
    }

    private int cols;
    private int rows;
    // Main buffer ring: ring[ringStart..] holds scrollback + screen.
    private Row[] ring;
    private int ringCap;
    private int ringStart;
    private int ringLen;
    // Alt screen: fixed rows x cols, no scrollback.
    private Row[] alt;
    private boolean useAlt;
    // Cursor into the *visible* area (0..rows-1); maps to ring index.
    private int curRow;
    private int curCol;
    private int savedRow;
    private int savedCol;
    // Scroll margins (inclusive, 0-based) for the visible area.
    private int topMargin;
    private int botMargin;
    // Active style for new cells.
    private int curStyle;
    private int curFg;
    private int curBg;
    private boolean wrapPending;
    // Parser scratch.
    private int pState;
    private final int[] params = new int[MAX_PARAMS];
    private int nParams;
    private boolean paramFresh;
    private final StringBuffer oscBuf = new StringBuffer();
    // Bracketed paste (?2004): when the app enables it, pastes are wrapped in
    // ESC[200~ ... ESC[201~ so the app treats them as one literal block.
    private boolean bracketedPaste = false;
    // Application cursor keys (?1h, DECCKM): arrows/keypad switch from
    // CSI A..D to SS3 A..D while a full-screen app (vi, less) is running.
    // Ignoring this is why arrows can go dead inside vi.
    private boolean appCursor = false;
    // C0 tracking for the transcript bridge.
    private boolean sawAddressing;
// W8: coarse mutation counter for the view's line cache. Bumped once per
    // feed()/resize()/reset(), not per cell — readers rebuild caches when it
    // changes instead of allocating per line per frame.
    private long modCount = 0L;

    public VtGrid(int cols, int rows) {
        if (cols < 20) {
            cols = 20;
        }
        if (cols > 240) {
            cols = 240;
        }
        if (rows < 8) {
            rows = 8;
        }
        if (rows > 80) {
            rows = 80;
        }
        this.cols = cols;
        this.rows = rows;
        ringCap = rows + MAX_SCROLLBACK;
        ring = new Row[ringCap];
        for (int i = 0; i < ringCap; i++) {
            ring[i] = new Row(cols);
        }
        ringStart = 0;
        ringLen = rows;
        alt = new Row[rows];
        for (int i = 0; i < rows; i++) {
            alt[i] = new Row(cols);
        }
        useAlt = false;
        curRow = 0;
        curCol = 0;
        topMargin = 0;
        botMargin = rows - 1;
        curStyle = 0;
        curFg = 7;
        curBg = 0;
        wrapPending = false;
        pState = P_GROUND;
        nParams = 0;
        sawAddressing = false;
    }

    private void fireDirty() {
        modCount++;
    }

    public synchronized long getModCount() {
        return modCount;
    }

    public synchronized boolean sawAddressing() {
        return sawAddressing;
    }

    // Test-facing accessors below: exercised by tests/VtGridTest.java, not by
    // the app. Kept deliberately — they are the only way the suite can assert
    // grid state without reaching into privates.
    public synchronized int getCols() {
        return cols;
    }

    public synchronized int getRows() {
        return rows;
    }

    public synchronized int getCursorRow() {
        return curRow;
    }

    public synchronized int getCursorCol() {
        return curCol;
    }

    private Row visibleRow(int r) {
        if (useAlt) {
            return alt[r];
        }
        return ring[(ringStart + ringLen - rows + r) % ringCap];
    }

    private static int pack(int fg, int bg, int flags) {
        return ((flags & 0xFF) << 16) | ((bg & 0xFF) << 8) | (fg & 0xFF);
    }

    public static int styleFg(int packed) {
        return packed & 0xFF;
    }

    public static int styleBg(int packed) {
        return (packed >> 8) & 0xFF;
    }

    public static int styleFlags(int packed) {
        return (packed >> 16) & 0xFF;
    }

    private void scrollUp(int top, int bot) {
        if (useAlt) {
            for (int r = top; r < bot; r++) {
                final Row a = alt[r];
                final Row b = alt[r + 1];
                alt[r] = b;
                alt[bot] = a;
                clearRow(a);
            }
            clearRow(alt[bot]);
            return;
        }
        // Main buffer: rotate ring so the top line becomes scrollback.
        if (top == 0 && bot == rows - 1) {
            if (ringLen < ringCap) {
                ringLen++;
            } else {
                ringStart = (ringStart + 1) % ringCap;
            }
            clearRow(visibleRow(rows - 1));
            return;
        }
        // Margined scroll: shift row contents inside the region.
        for (int r = top; r < bot; r++) {
            copyRow(visibleRow(r + 1), visibleRow(r));
        }
        clearRow(visibleRow(bot));
    }

    private void scrollDown(int top, int bot) {
        for (int r = bot; r > top; r--) {
            copyRow(visibleRow(r - 1), visibleRow(r));
        }
        clearRow(visibleRow(top));
    }

    private void clearRow(Row row) {
        for (int i = 0; i < cols; i++) {
            row.text[i] = ' ';
            row.style[i] = 0;
        }
        row.wrapped = false;
    }

    private void copyRow(Row src, Row dst) {
        for (int i = 0; i < cols; i++) {
            dst.text[i] = src.text[i];
            dst.style[i] = src.style[i];
        }
        dst.wrapped = src.wrapped;
    }

    private void lineFeed() {
        wrapPending = false;
        if (curRow == botMargin) {
            scrollUp(topMargin, botMargin);
        } else if (curRow < rows - 1) {
            curRow++;
        } else {
            scrollUp(topMargin, botMargin);
        }
    }

    private void carriageReturn() {
        wrapPending = false;
        curCol = 0;
    }

    private void putChar(char c) {
        if (wrapPending) {
            wrapPending = false;
            visibleRow(curRow).wrapped = true;
            carriageReturn();
            lineFeed();
        }
        final Row row = visibleRow(curRow);
        row.text[curCol] = c;
        row.style[curCol] = pack(curFg, curBg, curStyle);
        if (curCol == cols - 1) {
            wrapPending = true;
        } else {
            curCol++;
        }
    }

    private void backspace() {
        wrapPending = false;
        if (curCol > 0) {
            curCol--;
        }
    }

    private void tab() {
        wrapPending = false;
        int next = ((curCol / 8) + 1) * 8;
        if (next >= cols) {
            next = cols - 1;
        }
        curCol = next;
    }

    private int param(int idx, int def) {
        if (idx < nParams) {
            final int v = params[idx];
            if (v >= 0) {
                return v;
            }
        }
        return def;
    }

    private void doSgr() {
        if (nParams == 0) {
            curStyle = 0;
            curFg = 7;
            curBg = 0;
            return;
        }
        int i = 0;
        while (i < nParams) {
            final int p = params[i];
            if (p < 0 || p == 0) {
                curStyle = 0;
                curFg = 7;
                curBg = 0;
            } else if (p == 1) {
                curStyle |= F_BOLD;
            } else if (p == 2) {
                curStyle |= F_DIM;
            } else if (p == 3) {
                curStyle |= F_ITALIC;
            } else if (p == 4) {
                curStyle |= F_UNDERLINE;
            } else if (p == 7) {
                curStyle |= F_INVERSE;
            } else if (p == 8) {
                curStyle |= F_HIDDEN;
            } else if (p == 22) {
                curStyle &= ~(F_BOLD | F_DIM);
            } else if (p == 23) {
                curStyle &= ~F_ITALIC;
            } else if (p == 24) {
                curStyle &= ~F_UNDERLINE;
            } else if (p == 27) {
                curStyle &= ~F_INVERSE;
            } else if (p == 28) {
                curStyle &= ~F_HIDDEN;
            } else if (p >= 30 && p <= 37) {
                curFg = p - 30;
            } else if (p == 39) {
                curFg = 7;
            } else if (p >= 40 && p <= 47) {
                curBg = p - 40;
            } else if (p == 49) {
                curBg = 0;
            } else if (p >= 90 && p <= 97) {
                curFg = (p - 90) + 8;
            } else if (p >= 100 && p <= 107) {
                curBg = (p - 100) + 8;
            } else if ((p == 38 || p == 48) && i + 2 < nParams && params[i + 1] == 5) {
                final int color = params[i + 2];
                if (color >= 0 && color <= 255) {
                    if (p == 38) {
                        curFg = color;
                    } else {
                        curBg = color;
                    }
                }
                i += 2;
            } else if ((p == 38 || p == 48) && i + 4 < nParams && params[i + 1] == 2) {
                final int r = params[i + 2];
                final int g = params[i + 3];
                final int b = params[i + 4];
                if (r >= 0 && r <= 255 && g >= 0 && g <= 255 && b >= 0 && b <= 255) {
                    // Fold truecolor into the 256-cube: 16 + 36*(r/51) + 6*(g/51) + b/51.
                    final int approx = 16 + (36 * (r / 51)) + (6 * (g / 51)) + (b / 51);
                    if (p == 38) {
                        curFg = approx;
                    } else {
                        curBg = approx;
                    }
                }
                i += 4;
            }
            i++;
        }
    }

    private void eraseDisplay(int mode) {
        sawAddressing = true;
        if (mode == 2) {
            for (int r = 0; r < rows; r++) {
                clearRow(visibleRow(r));
            }
            curRow = 0;
            curCol = 0;
            wrapPending = false;
        } else if (mode == 1) {
            for (int r = 0; r < curRow; r++) {
                clearRow(visibleRow(r));
            }
            final Row row = visibleRow(curRow);
            for (int c = 0; c <= curCol && c < cols; c++) {
                row.text[c] = ' ';
                row.style[c] = 0;
            }
        } else {
            final Row row = visibleRow(curRow);
            for (int c = curCol; c < cols; c++) {
                row.text[c] = ' ';
                row.style[c] = 0;
            }
            for (int r = curRow + 1; r < rows; r++) {
                clearRow(visibleRow(r));
            }
        }
    }

    private void eraseLine(int mode) {
        sawAddressing = true;
        final Row row = visibleRow(curRow);
        if (mode == 2) {
            clearRow(row);
        } else if (mode == 1) {
            for (int c = 0; c <= curCol && c < cols; c++) {
                row.text[c] = ' ';
                row.style[c] = 0;
            }
        } else {
            for (int c = curCol; c < cols; c++) {
                row.text[c] = ' ';
                row.style[c] = 0;
            }
        }
    }

    private void moveCursor(char verb) {
        sawAddressing = true;
        final int n = param(0, 1);
        if (verb == 'A') {
            curRow -= n;
            if (curRow < topMargin) {
                curRow = topMargin;
            }
            wrapPending = false;
        } else if (verb == 'B') {
            curRow += n;
            if (curRow > botMargin) {
                curRow = botMargin;
            }
            wrapPending = false;
        } else if (verb == 'C') {
            curCol += n;
            if (curCol >= cols) {
                curCol = cols - 1;
            }
            wrapPending = false;
        } else if (verb == 'D') {
            curCol -= n;
            if (curCol < 0) {
                curCol = 0;
            }
            wrapPending = false;
        } else if (verb == 'E') {
            curRow += n;
            if (curRow > botMargin) {
                curRow = botMargin;
            }
            curCol = 0;
            wrapPending = false;
        } else if (verb == 'F') {
            curRow -= n;
            if (curRow < topMargin) {
                curRow = topMargin;
            }
            curCol = 0;
            wrapPending = false;
        } else if (verb == 'G') {
            curCol = param(0, 1) - 1;
            if (curCol < 0) {
                curCol = 0;
            }
            if (curCol >= cols) {
                curCol = cols - 1;
            }
            wrapPending = false;
        } else if (verb == 'H' || verb == 'f') {
            curRow = param(0, 1) - 1;
            curCol = param(1, 1) - 1;
            if (curRow < 0) {
                curRow = 0;
            }
            if (curRow >= rows) {
                curRow = rows - 1;
            }
            if (curCol < 0) {
                curCol = 0;
            }
            if (curCol >= cols) {
                curCol = cols - 1;
            }
            wrapPending = false;
        } else if (verb == 'd') {
            curRow = param(0, 1) - 1;
            if (curRow < 0) {
                curRow = 0;
            }
            if (curRow >= rows) {
                curRow = rows - 1;
            }
            wrapPending = false;
        }
    }

    private void setAlt(boolean on) {
        if (on == useAlt) {
            return;
        }
        useAlt = on;
        sawAddressing = true;
        if (on) {
            for (int i = 0; i < rows; i++) {
                clearRow(alt[i]);
            }
        }
        curRow = 0;
        curCol = 0;
        wrapPending = false;
        topMargin = 0;
        botMargin = rows - 1;
    }

    private void doCsi(char verb) {
        if (verb == 'm') {
            doSgr();
        } else if (verb == 'J') {
            eraseDisplay(param(0, 0));
        } else if (verb == 'K') {
            eraseLine(param(0, 0));
        } else if (verb == 'A' || verb == 'B' || verb == 'C' || verb == 'D'
                || verb == 'E' || verb == 'F' || verb == 'G' || verb == 'H'
                || verb == 'f' || verb == 'd') {
            moveCursor(verb);
        } else if (verb == 'L') {
            sawAddressing = true;
            int n = param(0, 1);
            while (n > 0) {
                scrollDown(curRow, botMargin);
                n--;
            }
        } else if (verb == 'M') {
            sawAddressing = true;
            int n = param(0, 1);
            while (n > 0) {
                scrollUp(curRow, botMargin);
                n--;
            }
        } else if (verb == 'P') {
            sawAddressing = true;
            int n = param(0, 1);
            final Row row = visibleRow(curRow);
            while (n > 0 && curCol < cols) {
                for (int c = curCol; c < cols - 1; c++) {
                    row.text[c] = row.text[c + 1];
                    row.style[c] = row.style[c + 1];
                }
                row.text[cols - 1] = ' ';
                row.style[cols - 1] = 0;
                n--;
            }
        } else if (verb == '@') {
            sawAddressing = true;
            int n = param(0, 1);
            final Row row = visibleRow(curRow);
            while (n > 0 && curCol < cols) {
                for (int c = cols - 1; c > curCol; c--) {
                    row.text[c] = row.text[c - 1];
                    row.style[c] = row.style[c - 1];
                }
                row.text[curCol] = ' ';
                row.style[curCol] = 0;
                n--;
            }
        } else if (verb == 'r') {
            int top = param(0, 1) - 1;
            int bot = param(1, rows) - 1;
            if (top < 0) {
                top = 0;
            }
            if (bot >= rows) {
                bot = rows - 1;
            }
            if (top < bot) {
                topMargin = top;
                botMargin = bot;
                curRow = top;
                curCol = 0;
                wrapPending = false;
                sawAddressing = true;
            }
        } else if (verb == 's') {
            savedRow = curRow;
            savedCol = curCol;
        } else if (verb == 'u') {
            curRow = savedRow;
            curCol = savedCol;
            if (curRow < 0) {
                curRow = 0;
            }
            if (curRow >= rows) {
                curRow = rows - 1;
            }
            if (curCol < 0) {
                curCol = 0;
            }
            if (curCol >= cols) {
                curCol = cols - 1;
            }
            wrapPending = false;
        }
    }

    private void doCsiPrivate(char verb) {
        // ?-prefixed modes: 25 cursor show, 47/1049 alt screen, 2004 paste.
        for (int i = 0; i < nParams; i++) {
            final int p = params[i];
            if (p == 1049 || p == 47) {
                setAlt(verb == 'h');
            } else if (p == 2004) {
                bracketedPaste = (verb == 'h');
            } else if (p == 1) {
                appCursor = (verb == 'h');
            }
        }
    }

    private void feedEsc(char c) {
        if (c == '[') {
            pState = P_CSI;
            nParams = 0;
            paramFresh = false;
        } else if (c == ']') {
            pState = P_OSC;
            oscBuf.setLength(0);
        } else if (c == '7') {
            savedRow = curRow;
            savedCol = curCol;
            pState = P_GROUND;
        } else if (c == '8') {
            curRow = savedRow;
            curCol = savedCol;
            wrapPending = false;
            pState = P_GROUND;
        } else if (c == 'M') {
            // Reverse index.
            sawAddressing = true;
            if (curRow == topMargin) {
                scrollDown(topMargin, botMargin);
            } else if (curRow > 0) {
                curRow--;
            }
            wrapPending = false;
            pState = P_GROUND;
        } else if (c == 'c') {
            // Full reset.
            reset();
            pState = P_GROUND;
        } else {
            // Unknown ESC + x: skip both.
            pState = P_GROUND;
        }
    }

    private void feedCsi(char c) {
        if (c == '?') {
            pState = P_CSI_Q;
            nParams = 0;
            paramFresh = false;
            return;
        }
        if (c == '<' || c == '=' || c == '>' || c == '!') {
            // Private-marker prefixes (e.g. kitty CSI = u, CSI > q):
            // consumed, stay in CSI so the sequence never leaks text.
            return;
        }
        if (c >= '0' && c <= '9') {
            if (nParams == 0) {
                params[0] = 0;
                nParams = 1;
            }
            if (paramFresh == false) {
                params[nParams - 1] = 0;
                paramFresh = true;
            }
            params[nParams - 1] = params[nParams - 1] * 10 + (c - '0');
            return;
        }
        if (c == ';') {
            if (nParams < MAX_PARAMS) {
                params[nParams] = -1;
                nParams++;
            }
            paramFresh = false;
            return;
        }
        if (c == ' ' || c == '"' || c == '\'' || c == '$' || c == '#'
                || c == '%' || c == '(' || c == ')' || c == '*'
                || c == '+' || c == '-') {
            // Intermediate bytes: ignored, stay in CSI.
            return;
        }
        if (c >= '@' && c <= '~') {
            doCsi(c);
            fireDirty();
            pState = P_GROUND;
            return;
        }
        // Anything else aborts the sequence.
        pState = P_GROUND;
    }

    private void feedCsiQ(char c) {
        if (c >= '0' && c <= '9') {
            if (nParams == 0) {
                params[0] = 0;
                nParams = 1;
            }
            if (paramFresh == false) {
                params[nParams - 1] = 0;
                paramFresh = true;
            }
            params[nParams - 1] = params[nParams - 1] * 10 + (c - '0');
            return;
        }
        if (c == ';') {
            if (nParams < MAX_PARAMS) {
                params[nParams] = -1;
                nParams++;
            }
            paramFresh = false;
            return;
        }
        if (c == 'h' || c == 'l') {
            doCsiPrivate(c);
            fireDirty();
            pState = P_GROUND;
            return;
        }
        if (c >= '@' && c <= '~') {
            // Other private verbs: consumed, ignored.
            pState = P_GROUND;
            return;
        }
        pState = P_GROUND;
    }

    private void feedOsc(char c) {
        if (c == 7) {
            // BEL terminates; title consumed (not stored in v1).
            oscBuf.setLength(0);
            pState = P_GROUND;
            return;
        }
        if (c == 27) {
            // ESC may start ESC-backslash; hold: drop ESC, next \ ends.
            oscBuf.append(c);
            return;
        }
        if (c == '\\' && oscBuf.length() > 0 && oscBuf.charAt(oscBuf.length() - 1) == 27) {
            oscBuf.setLength(0);
            pState = P_GROUND;
            return;
        }
        if (oscBuf.length() < 512) {
            oscBuf.append(c);
        }
    }

    private void feedGround(char c) {
        if (c == 27) {
            pState = P_ESC;
        } else if (c == 7) {
            // BEL: ignored (no audible bell in v1).
        } else if (c == '\b') {
            backspace();
        } else if (c == '\t') {
            tab();
        } else if (c == '\n' || c == '\013' || c == '\014') {
            lineFeed();
        } else if (c == '\r') {
            carriageReturn();
        } else if (c < 32) {
            // Other C0 controls: ignored.
        } else if (c == 127) {
            // DEL: ignored on output.
        } else {
            putChar(c);
        }
    }

    /**
     * Feed one decoded chunk. Caller must hold no lock (method synchronizes).
     */
    public void feed(String s) {
        if (s == null || s.length() == 0) {
            return;
        }
        synchronized (this) {
            final int n = s.length();
            for (int i = 0; i < n; i++) {
                final char c = s.charAt(i);
                if (pState == P_GROUND) {
                    feedGround(c);
                } else if (pState == P_ESC) {
                    feedEsc(c);
                } else if (pState == P_CSI) {
                    feedCsi(c);
                } else if (pState == P_CSI_Q) {
                    feedCsiQ(c);
                } else {
                    feedOsc(c);
                }
            }
        }
        fireDirty();
    }

    public synchronized void reset() {
        for (int i = 0; i < ringCap; i++) {
            clearRow(ring[i]);
        }
        for (int i = 0; i < rows; i++) {
            clearRow(alt[i]);
        }
        ringStart = 0;
        ringLen = rows;
        useAlt = false;
        bracketedPaste = false;
        appCursor = false;
        topMargin = 0;
        botMargin = rows - 1;
        curRow = 0;
        curCol = 0;
        savedRow = 0;
        savedCol = 0;
        curStyle = 0;
        curFg = 7;
        curBg = 0;
        wrapPending = false;
        pState = P_GROUND;
        sawAddressing = false;
        modCount++;
    }

    /**
     * Resize preserving content: re-flow main buffer lines onto the new width
     * (wrap-aware), keep up to MAX_SCROLLBACK. Alt screen is cleared (matches
     * xterm: alt has no scrollback and no reflow across resizes).
     */
    public synchronized void resize(int newCols, int newRows) {
        if (newCols < 20) {
            newCols = 20;
        }
        if (newCols > 240) {
            newCols = 240;
        }
        if (newRows < 8) {
            newRows = 8;
        }
        if (newRows > 80) {
            newRows = 80;
        }
        if (newCols == cols && newRows == rows) {
            return;
        }
        // Snapshot visible + scrollback text (plain) then rebuild.
        final int total = ringLen;
        final StringBuffer[] texts = new StringBuffer[total];
        final int[][] styles = new int[total][];
        for (int i = 0; i < total; i++) {
            final Row r = ring[(ringStart + i) % ringCap];
            final StringBuffer sb = new StringBuffer(cols);
            int end = cols;
            while (end > 0 && r.text[end - 1] == ' ') {
                end--;
            }
            for (int c = 0; c < end; c++) {
                sb.append(r.text[c]);
            }
            texts[i] = sb;
            final int[] st = new int[end];
            for (int c = 0; c < end; c++) {
                st[c] = r.style[c];
            }
            styles[i] = st;
        }
        cols = newCols;
        rows = newRows;
        ringCap = rows + MAX_SCROLLBACK;
        ring = new Row[ringCap];
        for (int i = 0; i < ringCap; i++) {
            ring[i] = new Row(cols);
        }
        alt = new Row[rows];
        for (int i = 0; i < rows; i++) {
            alt[i] = new Row(cols);
        }
        ringStart = 0;
        ringLen = rows;
        useAlt = false;
        topMargin = 0;
        botMargin = rows - 1;
        curRow = 0;
        curCol = 0;
        wrapPending = false;
        // Replay snapshot lines through the normal path so wrap reflows to
        // the new width and scrollback regrows naturally. Trailing blank
        // snapshot rows replay harmlessly.
        for (int i = 0; i < total; i++) {
            final StringBuffer sb = texts[i];
            final int[] st = styles[i];
            for (int c = 0; c < sb.length(); c++) {
                if (c < st.length) {
                    final int packed = st[c];
                    curFg = styleFg(packed);
                    curBg = styleBg(packed);
                    curStyle = styleFlags(packed);
                }
                putChar(sb.charAt(c));
            }
            lineFeed();
        }
        useAlt = false;
        topMargin = 0;
        botMargin = rows - 1;
        fireDirty();
    }

    // ---- Readouts for the view / transcript bridge ----

    /** Total logical lines (scrollback + screen) in main buffer. */
    /** Number of scrollback lines above the visible screen (main buffer). */
    public synchronized int scrollbackLines() {
        if (useAlt) {
            return 0;
        }
        final int extra = ringLen - rows;
        return extra > 0 ? extra : 0;
    }

    public synchronized int totalLines() {
        if (useAlt) {
            return rows;
        }
        return ringLen;
    }

    /**
     * Plain text of logical line idx (0 = oldest). Trailing spaces trimmed.
     * For alt screen, idx 0..rows-1.
     */
    public synchronized String lineText(int idx) {
        final Row r = logicalRow(idx);
        if (r == null) {
            return "";
        }
        int end = cols;
        while (end > 0 && r.text[end - 1] == ' ') {
            end--;
        }
        return new String(r.text, 0, end);
    }

    /** Packed styles parallel to lineText(idx). Length == lineText length. */
    public synchronized int[] lineStyles(int idx) {
        final Row r = logicalRow(idx);
        final String t = lineText(idx);
        final int[] out = new int[t.length()];
        if (r != null) {
            for (int i = 0; i < out.length && i < cols; i++) {
                out[i] = r.style[i];
            }
        }
        return out;
    }

    /** Visible row r (0-based) as text. */
    public synchronized String screenText(int r) {
        if (r < 0 || r >= rows) {
            return "";
        }
        final Row row = visibleRow(r);
        int end = cols;
        while (end > 0 && row.text[end - 1] == ' ') {
            end--;
        }
        return new String(row.text, 0, end);
    }

    /** Packed styles for visible row r. */
    public synchronized int[] screenStyles(int r) {
        if (r < 0 || r >= rows) {
            return new int[0];
        }
        final Row row = visibleRow(r);
        int end = cols;
        while (end > 0 && row.text[end - 1] == ' ') {
            end--;
        }
        final int[] out = new int[end];
        for (int i = 0; i < end; i++) {
            out[i] = row.style[i];
        }
        return out;
    }

    public synchronized boolean isAlt() {
        return useAlt;
    }

    public synchronized boolean isBracketedPaste() {
        return bracketedPaste;
    }

    public synchronized boolean isAppCursor() {
        return appCursor;
    }

    /**
     * v36: force out of full-screen modes after the foreground app was
     * SIGKILLed - it never got to restore them, so the shell prompt would
     * otherwise land on the abandoned alt screen. Alt buffer, DECCKM and
     * bracketed paste are cleared; row contents are left intact.
     */
    public synchronized void leaveFullScreen() {
        if (useAlt) {
            setAlt(false);
        }
        appCursor = false;
        bracketedPaste = false;
        modCount++;
    }

    private Row logicalRow(int idx) {
        if (useAlt) {
            if (idx < 0 || idx >= rows) {
                return null;
            }
            return alt[idx];
        }
        if (idx < 0 || idx >= ringLen) {
            return null;
        }
        return ring[(ringStart + idx) % ringCap];
    }
}
