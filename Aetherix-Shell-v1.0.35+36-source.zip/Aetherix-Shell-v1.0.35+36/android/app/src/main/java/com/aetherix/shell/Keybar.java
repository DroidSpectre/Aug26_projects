package com.aetherix.shell;

/**
 * Keybar layout table. Android-free so the contract is unit-tested.
 *
 * The sparkle key (slot 7) is RESERVED for a downstream app feature that
 * is not wired yet. It must keep KIND_RESERVED and a null code until that
 * feature lands - do not repurpose the slot, and do not dispatch on
 * hardcoded indices (that is how the slot got clobbered once).
 */
public final class Keybar {
    public static final int KIND_LITERAL = 0;
    public static final int KIND_CTRL = 1;
    public static final int KIND_RESERVED = 2;
    public static final int KIND_END = 3;
    public static final int KIND_PASTE = 4;
    public static final int KIND_CURSOR = 5;
    public static final int KIND_KILL = 6;

    public static final int RESERVED_SLOT = 7;

    public static final String[] LABELS = new String[] {
        "ESC", "CTRL", "TAB",
        "\u2b05\ufe0f", "\u2b06\ufe0f", "\u2b07\ufe0f", "\u27a1\ufe0f",
        "\u2728\ufe0f",
        "PASTE", "END", "KILL"
    };

    // Cursor slots carry only the direction letter (D=left, A=up, B=down,
    // C=right); the DECCKM-dependent prefix is chosen at press time.
    public static final String[] CODES = new String[] {
        "\u001b", null, "\t",
        "D", "A", "B", "C",
        null,
        null, null, null
    };

    public static final int[] KINDS = new int[] {
        KIND_LITERAL, KIND_CTRL, KIND_LITERAL,
        KIND_CURSOR, KIND_CURSOR, KIND_CURSOR, KIND_CURSOR,
        KIND_RESERVED,
        KIND_PASTE, KIND_END, KIND_KILL
    };

    private Keybar() {
    }
}
