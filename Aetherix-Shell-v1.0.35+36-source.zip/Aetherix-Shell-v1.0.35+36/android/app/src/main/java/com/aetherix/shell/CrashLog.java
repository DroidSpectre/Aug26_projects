package com.aetherix.shell;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * Writes uncaught exceptions to files/crash.log and reads it back for
 * on-screen display. Why: we cannot pull logcat from the field, so the
 * app must show its own crash trace in MainActivity status text.
 * No lambdas, no diamonds.
 */
public class CrashLog {
    public static final String NAME = "crash.log";
    private static boolean installed = false;

    public static void install(final Context ctx) {
        synchronized (CrashLog.class) {
            if (installed) {
                return;
            }
            installed = true;
        }
        final Context app = ctx.getApplicationContext();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    final File f = new File(app.getFilesDir(), NAME);
                    final PrintWriter pw = new PrintWriter(new FileWriter(f, true));
                    try {
                        pw.println("=== " + String.valueOf(new java.util.Date()) + " thread=" + t.getName() + " ===");
                        e.printStackTrace(pw);
                    } finally {
                        pw.close();
                    }
                } catch (Exception ignored) {
                }
                if (prev != null) {
                    prev.uncaughtException(t, e);
                }
            }
        });
    }

    public static String readTail(final Context ctx, final int maxChars) {
        try {
            final File f = new File(ctx.getFilesDir(), NAME);
            if (f.exists() == false) {
                return "";
            }
            final BufferedReader br = new BufferedReader(new FileReader(f));
            try {
                final StringBuffer sb = new StringBuffer();
                final char[] buf = new char[2048];
                int r;
                while ((r = br.read(buf)) != -1) {
                    sb.append(buf, 0, r);
                }
                final String all = sb.toString();
                if (all.length() <= maxChars) {
                    return all;
                }
                return all.substring(all.length() - maxChars);
            } finally {
                br.close();
            }
        } catch (Exception e) {
            return "crash-log read error: " + String.valueOf(e.getMessage());
        }
    }
}
