package com.aetherix.shell;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Launcher: status console + session entry. Dark card layout (v27):
 * header, session card, settings entry with granted-count badge, log
 * card with copy/share/clear. Permission grants live in
 * SettingsActivity (shared Perms flows); terminal untouched.
 * Back minimizes the task so neither screen traps the other.
 * No lambdas, no diamonds.
 */
public class MainActivity extends Activity {
    private TextView status = null;
    private Button sessionBtn = null;
    private TextView stateBadge = null;
    private Button settingsBtn = null;

    public void onCreate(Bundle savedInstanceState) {
        CrashLog.install(this);
        super.onCreate(savedInstanceState);
        EventLog.append(this, "app", "launcher create");
        final int pad = Ui.dp(this, 16.0f);
        final int gap = Ui.dp(this, 10.0f);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(false);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(pad, pad, pad, pad);
        final TextView title = new TextView(this);
        title.setText("Aetherix-Shell");
        title.setTextSize(22.0f);
        title.setTextColor(Ui.ACCENT);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final TextView ver = new TextView(this);
        ver.setText(versionLine());
        ver.setTextColor(Ui.DIM);
        ver.setTextSize(12.0f);
        root.addView(ver, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        stateBadge = new TextView(this);
        stateBadge.setTextSize(12.0f);
        final LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        badgeLp.topMargin = gap;
        root.addView(stateBadge, badgeLp);
        // Session card.
        root.addView(Ui.section(this, "SESSION"), sectionLp(gap));
        final LinearLayout sessCard = new LinearLayout(this);
        sessCard.setOrientation(LinearLayout.VERTICAL);
        final Button open = Ui.darkButton(this);
        open.setText("Open terminal");
        sessionBtn = open;
        sessCard.addView(open, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final Button stop = Ui.darkButton(this);
        stop.setText("Stop session");
        final LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stopLp.topMargin = Ui.dp(this, 6.0f);
        sessCard.addView(stop, stopLp);
        root.addView(Ui.card(this, sessCard), cardLp(gap));
        // Settings entry (permissions live on the settings page).
        root.addView(Ui.section(this, "SETTINGS"), sectionLp(gap));
        final LinearLayout setCard = new LinearLayout(this);
        setCard.setOrientation(LinearLayout.VERTICAL);
        settingsBtn = Ui.darkButton(this);
        settingsBtn.setText("Permissions & settings");
        setCard.addView(settingsBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(Ui.card(this, setCard), cardLp(gap));
        // Log card.
        root.addView(Ui.section(this, "LOG"), sectionLp(gap));
        // Log card. v28: wrap content with a capped scroll instead of
        // weight-fill — the old weight=1 stretched a half-empty card over
        // the screen (v27 screenshot). Long reports scroll inside the card.
        status = new TextView(this);
        status.setText("starting...");
        status.setTextIsSelectable(true);
        status.setTextColor(Ui.TEXT);
        status.setTextSize(11.0f);
        final android.widget.ScrollView logScroll = new android.widget.ScrollView(this);
        logScroll.addView(status, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final int logMaxH = Ui.dp(this, 220.0f);
        logScrollView = logScroll;
        logScrollMaxH = logMaxH;
        final LinearLayout logCard = new LinearLayout(this);
        logCard.setOrientation(LinearLayout.VERTICAL);
        // v29: buttons FIRST, scroll second. The old order (scroll then
        // buttons) let a growing report push Copy/Share/Clear out of frame
        // for a frame-plus between setText and the post-cap. Buttons laid
        // out first can never be displaced by content below them.
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final Button copy = Ui.darkButton(this);
        copy.setText("Copy");
        final LinearLayout.LayoutParams third = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        row.addView(copy, third);
        final Button share = Ui.darkButton(this);
        share.setText("Share");
        row.addView(share, third);
        final Button clear = Ui.darkButton(this);
        clear.setText("Clear");
        row.addView(clear, third);
        final LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = Ui.dp(this, 6.0f);
        logCard.addView(row, rowLp);
        logCard.addView(logScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(Ui.card(this, logCard), cardLp(gap));
        setContentView(root);
        if (android.os.Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try {
                        final int top = insets.getSystemWindowInsetTop();
                        final int bottom = insets.getSystemWindowInsetBottom();
                        v.setPadding(v.getPaddingLeft(), top + pad, v.getPaddingRight(), bottom + pad);
                    } catch (Exception ignored) {
                    }
                    return insets;
                }
            });
        }
        wireButtons(open, stop, copy, share, clear);
        refresh();
    }

    private LinearLayout.LayoutParams cardLp(int gap) {
        final LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 4.0f);
        return lp;
    }

    private LinearLayout.LayoutParams sectionLp(int gap) {
        final LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = gap;
        return lp;
    }

    private String versionLine() {
        try {
            final android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pi.versionName + "+" + pi.versionCode + " / android " + String.valueOf(Build.VERSION.RELEASE) + " (sdk " + String.valueOf(Build.VERSION.SDK_INT) + ")";
        } catch (Exception e) {
            return "";
        }
    }

    private void wireButtons(final Button open, final Button stop, final Button copy, final Button share, final Button clear) {
        open.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    if (sessionRunning() == false) {
                        try {
                            ShellSession.get().stop();
                        } catch (Exception ignored) {
                        }
                    }
                    final Intent i = new Intent(MainActivity.this, TerminalActivity.class);
                    startActivity(i);
                } catch (Exception e) {
                    status.setText("terminal blocked: " + String.valueOf(e.getMessage()));
                }
            }
        });
        // P1.5 failsafe: long-press the session button for a non-login
        // shell with the system rc only. Recovery when user rc is broken.
        open.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                try {
                    try {
                        ShellSession.get().stop();
                    } catch (Exception ignored) {
                    }
                    try {
                        ShellSession.get().startFailsafe(MainActivity.this);
                    } catch (Exception e) {
                        status.setText("failsafe blocked: " + String.valueOf(e.getMessage()));
                        return true;
                    }
                    EventLog.append(MainActivity.this, "app", "failsafe session requested");
                    final Intent i = new Intent(MainActivity.this, TerminalActivity.class);
                    startActivity(i);
                } catch (Exception e) {
                    status.setText("failsafe blocked: " + String.valueOf(e.getMessage()));
                }
                return true;
            }
        });
        // Explicit Termux-Exit equivalent: kill the session + stop the
        // service now, so `exit`-then-swipe can never leave a linger.
        stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    final Intent i = new Intent(MainActivity.this, EnvService.class);
                    i.setAction(EnvService.ACTION_STOP_SERVICE);
                    if (Build.VERSION.SDK_INT >= 26) {
                        try {
                            startForegroundService(i);
                        } catch (Exception e) {
                            startService(i);
                        }
                    } else {
                        startService(i);
                    }
                    EventLog.append(MainActivity.this, "app", "stop requested");
                    refresh();
                } catch (Exception e) {
                    status.setText("stop blocked: " + String.valueOf(e.getMessage()));
                }
            }
        });
        // v27: permissions live on the settings page. This button opens
        // it; its label carries the granted-count badge (repainted below).
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    final Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                    startActivity(i);
                } catch (Exception e) {
                    status.setText("settings blocked: " + String.valueOf(e.getMessage()));
                }
            }
        });
        copy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copyLog();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                shareLog();
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                clearLog();
            }
        });
        refresh();
    }

    public void onResume() {
        super.onResume();
        refresh();
    }

    public void onBackPressed() {
        // Terminal Back comes here; our Back leaves the app so neither screen traps the other.
        try {
            moveTaskToBack(true);
        } catch (Exception e) {
            super.onBackPressed();
        }
    }

    private String buildReport() {
        final boolean nativeOk = PtyBridge.ensureLoaded();
        final String events = EventLog.readTail(MainActivity.this, 2000);
        final String crash = CrashLog.readTail(MainActivity.this, 1500);
        final boolean sessionUp = sessionRunning();
        // Never hardcode: v15-v18 all displayed a stale literal, hiding which
        // build was actually under test. Read the real package version.
        String vname = "?";
        int vcode = -1;
        try {
            final android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            vname = pi.versionName;
            vcode = pi.versionCode;
        } catch (Exception ignored) {
        }
        final String head = "Aetherix-Shell " + vname + "+" + vcode + " / android " + String.valueOf(Build.VERSION.RELEASE) + " (sdk " + String.valueOf(Build.VERSION.SDK_INT) + ")\nsession: " + (sessionUp ? "running" : "idle (service stops itself)") + "\n" + EnvService.notifyState(MainActivity.this) + "\n" + MainActivity.storageState(MainActivity.this) + "\n" + batteryState() + "\nnative: " + (nativeOk ? "ok" : ("missing: " + PtyBridge.getLoadError())) + "\n" + shellState();
        final String ev = events.length() > 0 ? events : "(no events yet)";
        final String cr = crash.length() > 0 ? crash : "(no recorded crashes)";
        return head + "\n--- events ---\n" + ev + "\n--- last crash ---\n" + cr;
    }

    // v33: shell path pref line. Four states, each distinguishable in a field
    // report. Validation is re-run here (stateless, cheap) rather than trusting
    // activeShell: an idle session never populated it, and reporting
    // "rejected" for a perfectly good pref that simply has not spawned yet
    // would be a lie in the exact place we ask people to look for lies.
    private String shellState() {
        final String raw = ShellSession.readShellPref(this);
        if (raw.isEmpty()) {
            return "shell: system default (probe chain)";
        }
        if (ShellPath.validate(raw).isEmpty()) {
            return "shell: pref INVALID, using default (" + raw + ")";
        }
        if (sessionRunning()) {
            final String active = ShellSession.get().shellInUse();
            if (active.isEmpty()) {
                return "shell: session running, custom shell not applied (check events)";
            }
            return "shell: " + active;
        }
        return "shell: " + raw + " (applied on next New session)";
    }

    // v27: session button label + state badge + settings badge repaint on
    // every refresh. Permission rows live in SettingsActivity now.
    private void paintButtons(final boolean sessionUp) {
        try {
            final String sessLabel;
            final String badgeText;
            final boolean badgeGood;
            if (sessionUp) {
                sessLabel = "Open terminal";
                badgeText = "SESSION RUNNING";
                badgeGood = true;
            } else {
                sessLabel = "New session";
                badgeText = "IDLE";
                badgeGood = false;
            }
            final String setLabel = "Permissions & settings (" + SettingsActivity.summary(MainActivity.this) + ")";
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if (sessionBtn != null) {
                            sessionBtn.setText(sessLabel);
                        }
                        if (stateBadge != null) {
                            stateBadge.setText(badgeText);
                            if (badgeGood) {
                                stateBadge.setTextColor(Ui.GREEN);
                            } else {
                                stateBadge.setTextColor(Ui.DIM);
                            }
                        }
                        if (settingsBtn != null) {
                            settingsBtn.setText(setLabel);
                        }
                    } catch (Exception ignored) {
                    }
                }
            });
        } catch (Exception ignored) {
        }
    }

    // v27: permission grants live in SettingsActivity (Perms). Result
    // callbacks refresh the badge + report here.
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Perms.onActivityResult(this, requestCode, resultCode, data);
        refresh();
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        Perms.onRequestPermissionsResult(this, requestCode, permissions, grantResults);
        refresh();
    }

    // v19: storage state in the launcher report so `sd` failing is
    // diagnosable without logcat (granted? sdcard mounted? where?).
    public static String storageState(Context ctx) {
        try {
            boolean managed = false;
            try {
                managed = android.os.Environment.isExternalStorageManager();
            } catch (Exception ignored) {
            }
            boolean rw = false;
            try {
                if (Build.VERSION.SDK_INT < 23) {
                    rw = true;
                } else {
                    rw = ctx.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == android.content.pm.PackageManager.PERMISSION_GRANTED;
                }
            } catch (Exception ignored) {
            }
            String st = "?";
            try {
                st = android.os.Environment.getExternalStorageState();
            } catch (Exception ignored) {
            }
            return "storage: allfiles=" + managed + " read=" + rw + " state=" + st;
        } catch (Exception e) {
            return "storage: err " + String.valueOf(e.getMessage());
        }
    }

    // v20: battery state in the launcher report so the Request-permissions
    // button has something to show (exempt? still needed?).
    private String batteryState() {
        try {
            if (Build.VERSION.SDK_INT < 23) {
                return "battery: n/a (pre-23)";
            }
            final android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null) {
                return "battery: no manager";
            }
            final boolean exempt;
            try {
                exempt = pm.isIgnoringBatteryOptimizations(getPackageName());
            } catch (Exception e) {
                return "battery: err " + String.valueOf(e.getMessage());
            }
            return "battery: exempt=" + exempt;
        } catch (Exception e) {
            return "battery: err " + String.valueOf(e.getMessage());
        }
    }

    private static boolean sessionRunning() {
        try {
            return ShellSession.get().isRunning();
        } catch (Exception e) {
            return false;
        }
    }

    private android.widget.ScrollView logScrollView = null;
    private int logScrollMaxH = 0;

    // v28: keep the log card compact — cap scroll height every refresh
    // (short reports wrap tight, long ones scroll inside the card).
    private void capLogScroll() {
        try {
            if (logScrollView == null || logScrollMaxH <= 0) {
                return;
            }
            final android.widget.ScrollView sv = logScrollView;
            sv.post(new Runnable() {
                public void run() {
                    try {
                        final ViewGroup.LayoutParams lp = sv.getLayoutParams();
                        if (sv.getHeight() > logScrollMaxH) {
                            if (lp.height != logScrollMaxH) {
                                lp.height = logScrollMaxH;
                                sv.setLayoutParams(lp);
                            }
                        } else {
                            if (lp.height != ViewGroup.LayoutParams.WRAP_CONTENT) {
                                lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                                sv.setLayoutParams(lp);
                            }
                        }
                    } catch (Exception ignored) {
                    }
                }
            });
        } catch (Exception ignored) {
        }
    }

    private boolean refreshing = false;

    private void refresh() {
        synchronized (this) {
            if (refreshing) {
                return;
            }
            refreshing = true;
        }
        final Thread t = new Thread(new Runnable() {
            public void run() {
                final String msg = buildReport();
                final boolean up = sessionRunning();
                runOnUiThread(new Runnable() {
                    public void run() {
                        status.setText(msg);
                        capLogScroll();
                        synchronized (MainActivity.this) {
                            refreshing = false;
                        }
                    }
                });
                // v21: button labels track state on every refresh (session +
                // permission rows). Runs off-UI; paintButtons re-posts.
                paintButtons(up);
            }
        });
        t.start();
    }

    private void copyLog() {
        try {
            final String text = status.getText().toString();
            final android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("aetherix-log", text));
            EventLog.append(this, "app", "log copied");
        } catch (Exception e) {
            status.setText("copy blocked: " + String.valueOf(e.getMessage()));
        }
    }

    private void clearLog() {
        try {
            final java.io.File ev = new java.io.File(getFilesDir(), EventLog.NAME);
            ev.delete();
            final java.io.File cr = new java.io.File(getFilesDir(), CrashLog.NAME);
            cr.delete();
            EventLog.append(this, "app", "logs cleared");
            refresh();
        } catch (Exception e) {
            status.setText("clear blocked: " + String.valueOf(e.getMessage()));
        }
    }

    private void shareLog() {
        try {
            final String text = status.getText().toString();
            final Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, "Share Aetherix log"));
            EventLog.append(this, "app", "log shared");
        } catch (Exception e) {
            status.setText("share blocked: " + String.valueOf(e.getMessage()));
        }
    }
}
