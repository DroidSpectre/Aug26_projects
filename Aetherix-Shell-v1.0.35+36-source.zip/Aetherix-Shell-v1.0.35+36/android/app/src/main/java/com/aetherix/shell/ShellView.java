package com.aetherix.shell;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Build;
import android.text.Editable;
import android.text.InputType;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

/**
 * Single editor view: display + IME owner for life.
 * Why: two views (selectable output + 1px catcher) split focus and every
 * scroll/rebind could break the live Gboard binding. One view cannot split.
 * Copy is via dialog/Share (never a second focusable view); typing never
 * needs a focus handoff. Methodology follows the public Termux pattern
 * (TYPE_NULL default, Samsung password branch, drain-and-clear, DEL funnel,
 * CR enter mapping, user-driven toggle); all code here is original.
 * No lambdas, no diamonds.
 */
public class ShellView extends View {
    public interface Sink {
        void sendText(String s, String src);
        void sendDel(int n, String src);
        void sendEnter(String src);
    }

    public interface TapListener {
        void onTap();
        void onLongPress(float x, float y);
        void onSelectionDrag(float x, float y);
        void onSelectionDone();
    }

    public interface SizeListener {
        void onSize(int rows, int cols);
    }

    private SizeListener sizeListener = null;
    private int lastRows = -1;
    private int lastCols = -1;

    public void setSizeListener(SizeListener s) {
        sizeListener = s;
    }

    private Sink sink = null;
    private TapListener tapListener = null;
    private String transcript = "";
    private String[] lines = new String[] { "" };
    private String[] wrapped = new String[] { "" };
    private final Paint paint = new Paint();
    private int lineHeight = 20;
    private int yOff = 0;
    private boolean followBottom = true;
    private int fgColor = 0xFF212121;
    private int bgColor = 0xFFFFFFFF;
    private float downX = 0.0f;
    private float downY = 0.0f;
    private float lastY = 0.0f;
    private long downTime = 0L;
    private boolean dragging = false;
    private boolean longPressSent = false;
    private boolean selecting = false;
    private int selStartLine = -1;
    private int selStartChar = -1;
    private int selEndLine = -1;
    private int selEndChar = -1;
    private final Paint selPaint = new Paint();
    private int selAnchorLine = -1;
    private int selAnchorChar = -1;
    private boolean selHandleDrag = false;
    private boolean selScrollDrag = false;
    private int selDragHandle = 0;
    // v17: grab radius matches the fat circle handles (~14dp). Kept in px so
    // hitHandle() stays cheap per touch event; density-scaled at draw time.
    private static final float HANDLE_R = 24.0f;
    private float charW = 8.0f;
    private int lastLineCount = 0;
    private int lastMaxChars = -1;

    // H2 grid path: when the session drove cursor addressing, draw the grid
    // (colors + cursor) instead of the plain transcript. Original palette.
    private VtGrid grid = null;
    private boolean gridMode = false;
    // W8 grid line cache: rebuilt only when the grid's modCount changes,
    // not per frame. drawGrid reads rows from here (no per-line allocs).
    private long gridCacheMod = -1L;
    private int gridCacheTotal = 0;
    private String[] gridCacheText = new String[0];
    private int[][] gridCacheStyles = new int[0][];

    // P1.6: drop decoded grid-line caches under memory pressure. The next
    // draw rebuilds them from the grid (modCount mismatch); transient cost
    // only, no state lost.
    public void dropCaches() {
        gridCacheMod = -1L;
        gridCacheText = new String[0];
        gridCacheStyles = new int[0][];
        invalidate();
    }

    private void refreshGridCache(VtGrid g) {        final long mod = g.getModCount();
        if (mod == gridCacheMod) {
            return;
        }
        gridCacheMod = mod;
        final int total = g.totalLines();
        gridCacheTotal = total;
        if (gridCacheText.length < total) {
            gridCacheText = new String[total];
            gridCacheStyles = new int[total][];
        }
        for (int i = 0; i < total; i++) {
            gridCacheText[i] = g.lineText(i);
            gridCacheStyles[i] = g.lineStyles(i);
        }
    }
    private static final int[] PALETTE = new int[] {
        0xFF000000, 0xFFAA0000, 0xFF00AA00, 0xFFAA5500,
        0xFF0000AA, 0xFFAA00AA, 0xFF00AAAA, 0xFFAAAAAA,
        0xFF555555, 0xFFFF5555, 0xFF55FF55, 0xFFFFFF55,
        0xFF5555FF, 0xFFFF55FF, 0xFF55FFFF, 0xFFFFFFFF,
    };

    private static int cubeColor(int idx) {
        // xterm 256-cube 16-231 and grayscale 232-255.
        if (idx < 16) {
            return PALETTE[idx];
        }
        if (idx < 232) {
            final int v = idx - 16;
            final int b = v % 6;
            final int g = (v / 6) % 6;
            final int r = v / 36;
            return 0xFF000000 | (comp36(r) << 16) | (comp36(g) << 8) | comp36(b);
        }
        final int g = 8 + (idx - 232) * 10;
        return 0xFF000000 | (g << 16) | (g << 8) | g;
    }

    private static int comp36(int v) {
        if (v <= 0) {
            return 0;
        }
        return 55 + v * 40;
    }

    public synchronized void setGrid(VtGrid g) {
        grid = g;
        if (g != null && g.sawAddressing()) {
            if (gridMode == false) {
                gridMode = true;
                clearSelectionLocked();
            }
        } else if (g != null && g.sawAddressing() == false) {
            if (gridMode) {
                gridMode = false;
                // Transcript snapshots were skipped while hidden; re-derive
                // from the stored raw string so the view is current at once.
                rewrapTranscript();
            } else {
                gridMode = false;
            }
        }
        invalidate();
    }

    // Input-mode reads for the keybar. Null grid means no full-screen app
    // has driven addressing yet, so plain (normal) sequences are correct.
    public synchronized boolean isBracketedPaste() {
        if (grid == null) {
            return false;
        }
        return grid.isBracketedPaste();
    }

    public synchronized boolean isAppCursor() {
        if (grid == null) {
            return false;
        }
        return grid.isAppCursor();
    }

    // v36: called after the KILL key SIGKILLs a full-screen app, which never
    // restored the alt screen / modes itself.
    public synchronized void leaveFullScreen() {
        if (grid != null) {
            grid.leaveFullScreen();
        }
        invalidate();
    }

    private final Runnable longPressCheck = new Runnable() {
        public void run() {
            if (dragging == false && longPressSent == false) {
                longPressSent = true;
                beginSelection(downX, downY);
                if (tapListener != null) {
                    tapListener.onLongPress(downX, downY);
                }
            }
        }
    };

    public ShellView(Context ctx) {
        super(ctx);
        setFocusable(true);
        setFocusableInTouchMode(true);
        paint.setAntiAlias(true);
        paint.setTypeface(Typeface.MONOSPACE);
        final float scaled = ctx.getResources().getDisplayMetrics().scaledDensity;
        float ts = 12.0f * scaled;
        if (ts < 10.0f) {
            ts = 10.0f;
        }
        paint.setTextSize(ts);
        final Paint.FontMetrics fm = paint.getFontMetrics();
        lineHeight = (int) (fm.bottom - fm.top + 0.5f);
        if (lineHeight < 10) {
            lineHeight = 10;
        }
        paint.setColor(fgColor);
        selPaint.setColor(0x6639FF14);
    }

    public void setColors(int fg, int bg) {
        fgColor = fg;
        bgColor = bg;
        paint.setColor(fgColor);
        invalidate();
    }

    public void setSink(Sink s) {
        sink = s;
    }

    public void setTapListener(TapListener t) {
        tapListener = t;
    }

    public boolean hasSelection() {
        return selecting && selStartLine >= 0 && selEndLine >= 0;
    }

    public synchronized String getSelectedText() {
        if (selecting == false || selStartLine < 0 || selEndLine < 0) {
            return "";
        }
        // W6: in grid mode the screen shows grid lines, not the transcript
        // wrap — copy from the grid so the text matches the display.
        final VtGrid g;
        final boolean useGrid;
        synchronized (this) {
            g = grid;
            useGrid = gridMode && g != null;
        }
        if (useGrid) {
            return gridSelectedText(g);
        }
        return wrappedSelectedText();
    }

    private String gridSelectedText(VtGrid g) {
        int aL = selStartLine;
        int aC = selStartChar;
        int bL = selEndLine;
        int bC = selEndChar;
        if (aL > bL || (aL == bL && aC > bC)) {
            final int tL = aL;
            final int tC = aC;
            aL = bL;
            aC = bC;
            bL = tL;
            bC = tC;
        }
        final int total = g.totalLines();
        if (aL < 0) {
            aL = 0;
        }
        if (bL >= total) {
            bL = total - 1;
        }
        if (aL >= total || bL < 0) {
            return "";
        }
        final StringBuffer sb = new StringBuffer();
        for (int l = aL; l <= bL; l++) {
            final String s = g.lineText(l);
            int st = 0;
            int en = s.length();
            if (l == aL && aC > 0 && aC < en) {
                st = aC;
            }
            if (l == bL && bC >= 0 && bC < en) {
                en = bC + 1;
            }
            if (st > s.length()) {
                st = s.length();
            }
            if (en > s.length()) {
                en = s.length();
            }
            if (en > st) {
                sb.append(s.substring(st, en));
            }
            if (l < bL) {
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    private String wrappedSelectedText() {
        int aL = selStartLine;
        int aC = selStartChar;
        int bL = selEndLine;
        int bC = selEndChar;
        if (aL > bL || (aL == bL && aC > bC)) {
            final int tL = aL;
            final int tC = aC;
            aL = bL;
            aC = bC;
            bL = tL;
            bC = tC;
        }
        if (aL < 0) {
            aL = 0;
        }
        if (bL >= wrapped.length) {
            bL = wrapped.length - 1;
        }
        if (aL >= wrapped.length || bL < 0) {
            return "";
        }
        final StringBuffer sb = new StringBuffer();
        for (int l = aL; l <= bL; l++) {
            String s = wrapped[l];
            if (s == null) {
                s = "";
            }
            int st = 0;
            int en = s.length();
            if (l == aL && aC > 0 && aC < en) {
                st = aC;
            }
            if (l == bL && bC >= 0 && bC < en) {
                en = bC + 1;
            }
            if (st > s.length()) {
                st = s.length();
            }
            if (en > s.length()) {
                en = s.length();
            }
            if (en > st) {
                sb.append(s.substring(st, en));
            }
            if (l < bL) {
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    public void clearSelection() {
        selecting = false;
        selStartLine = -1;
        selStartChar = -1;
        selEndLine = -1;
        selEndChar = -1;
        selAnchorLine = -1;
        selAnchorChar = -1;
        selHandleDrag = false;
        selScrollDrag = false;
        invalidate();
    }

    // v30: select every wrapped row (the "select all + copy" path that no
    // comparator ships — desktop shift+Home/drag equivalents; Termux has no
    // select-all either). Whole screen including scrollback.
    public synchronized void selectAll() {
        if (wrapped == null || wrapped.length == 0) {
            return;
        }
        selecting = true;
        selStartLine = 0;
        selStartChar = 0;
        selEndLine = wrapped.length - 1;
        final int len = wrapped[selEndLine] == null ? 0 : wrapped[selEndLine].length();
        selEndChar = len > 0 ? len - 1 : 0;
        selAnchorLine = selStartLine;
        selAnchorChar = 0;
        invalidate();
    }

    private float viewDensity() {
        try {
            return getResources().getDisplayMetrics().density;
        } catch (Exception e) {
            return 1.0f;
        }
    }

    private void measureChar() {
        try {
            final float[] widths = new float[1];
            paint.getTextWidths("M", widths);
            if (widths[0] > 1.0f) {
                charW = widths[0];
            }
        } catch (Exception ignored) {
        }
    }

    private int[] xyToCell(float x, float y) {
        final int[] out = new int[] { 0, 0 };
        try {
            measureChar();
            final int h = getHeight();
            if (h <= 0 || lineHeight <= 0) {
                return out;
            }
            // Same baseline math as onDraw: baseline0 = -yMod positions line
            // `startLine + drawn` at (drawn*lineHeight - yMod - fm.top), so
            // invert with the FontMetrics top instead of ignoring it.
            final Paint.FontMetrics fm = paint.getFontMetrics();
            final float top = (fm == null) ? 0.0f : fm.top;
            int yMod = 0;
            if (yOff > 0 && yOff != Integer.MAX_VALUE && lineHeight > 0) {
                yMod = yOff % lineHeight;
            }
            int startLine = 0;
            if (lineHeight > 0 && yOff > 0 && yOff != Integer.MAX_VALUE) {
                startLine = yOff / lineHeight;
            }
            if (startLine < 0) {
                startLine = 0;
            }
            int line = startLine + (int) ((((float) y) + (float) yMod + top) / (float) lineHeight);
            if (line < 0) {
                line = 0;
            }
            // W6: coordinate space follows the displayed source. In grid mode
            // lines are grid logical lines (0 = oldest scrollback), matching
            // drawGrid's (li - sb) mapping; otherwise transcript wrap lines.
            final VtGrid g;
            final boolean useGrid;
            synchronized (this) {
                g = grid;
                useGrid = gridMode && g != null;
            }
            final int lineCount;
            if (useGrid) {
                lineCount = g.totalLines();
            } else {
                final String[] wv = wrapped;
                lineCount = (wv == null) ? 0 : wv.length;
            }
            if (lineCount == 0) {
                return out;
            }
            if (line >= lineCount) {
                line = lineCount - 1;
            }
            final String s;
            if (useGrid) {
                s = g.lineText(line);
            } else {
                final String[] wv = wrapped;
                String t = "";
                if (wv != null && line < wv.length) {
                    t = wv[line];
                }
                s = (t == null) ? "" : t;
            }
            float fx = x - 8.0f;
            int ch = 0;
            if (fx > 0.0f && charW > 0.5f) {
                ch = (int) (fx / charW);
            }
            if (ch < 0) {
                ch = 0;
            }
            if (ch >= s.length() && s.length() > 0) {
                ch = s.length() - 1;
            }
            out[0] = line;
            out[1] = ch;
        } catch (Exception ignored) {
        }
        return out;
    }

    private void beginSelection(float x, float y) {
        try {
            final int[] cell = xyToCell(x, y);
            selecting = true;
            followBottom = false;
            // The anchor stays at the long-press word; the free end follows
            // the finger, so drags extend one side instead of jumping both.
            selAnchorLine = cell[0];
            selAnchorChar = cell[1];
            selStartLine = cell[0];
            selEndLine = cell[0];
            // W6: word-expand against the displayed source (grid or wrap).
            final VtGrid g;
            final boolean useGrid;
            synchronized (this) {
                g = grid;
                useGrid = gridMode && g != null;
            }
            String s = "";
            if (useGrid) {
                s = g.lineText(cell[0]);
            } else if (wrapped != null && cell[0] < wrapped.length) {
                s = wrapped[cell[0]];
                if (s == null) {
                    s = "";
                }
            }
            int c = cell[1];
            if (c < 0) {
                c = 0;
            }
            if (c >= s.length() && s.length() > 0) {
                c = s.length() - 1;
            }
            int st = c;
            int en = c;
            while (st > 0 && isWordChar(s.charAt(st - 1))) {
                st--;
            }
            while (en < s.length() - 1 && isWordChar(s.charAt(en + 1))) {
                en++;
            }
            if (s.length() == 0) {
                st = 0;
                en = -1;
            }
            selAnchorChar = st;
            selStartChar = st;
            selEndChar = en;
            invalidate();
        } catch (Exception ignored) {
        }
    }

    private static boolean isWordChar(char c) {
        if (c >= 'a' && c <= 'z') {
            return true;
        }
        if (c >= 'A' && c <= 'Z') {
            return true;
        }
        if (c >= '0' && c <= '9') {
            return true;
        }
        if (c == '_' || c == '-' || c == '.' || c == '/' || c == ':') {
            return true;
        }
        return false;
    }

    private void extendSelection(float x, float y) {
        try {
            if (selecting == false) {
                return;
            }
            // Anchor/floating-end: the long-press word stays fixed, the drag
            // point moves only the free end. Matches TextView behavior.
            final int[] cell = xyToCell(x, y);
            selStartLine = selAnchorLine;
            selStartChar = selAnchorChar;
            selEndLine = cell[0];
            selEndChar = cell[1];
            invalidate();
        } catch (Exception ignored) {
        }
    }

    private void moveSelectionHandle(int which, float x, float y) {
        try {
            if (selecting == false) {
                return;
            }
            final int[] cell = xyToCell(x, y);
            if (which == 0) {
                selStartLine = cell[0];
                selStartChar = cell[1];
            } else {
                selEndLine = cell[0];
                selEndChar = cell[1];
            }
            invalidate();
        } catch (Exception ignored) {
        }
    }

    // Hit-test the two selection handles. Returns 0 (start), 1 (end), -1 none.
    // Handles are drawn as vertical bars +/-HANDLE_R around the edge char, so
    // accept the same radius here to make them grabbable by finger.
    private int hitHandle(float x, float y) {
        try {
            if (selecting == false || selStartLine < 0 || selEndLine < 0) {
                return -1;
            }
            int aL = selStartLine;
            int aC = selStartChar;
            int bL = selEndLine;
            int bC = selEndChar;
            if (aL > bL || (aL == bL && aC > bC)) {
                final int tL = aL;
                final int tC = aC;
                aL = bL;
                aC = bC;
                bL = tL;
                bC = tC;
            }
            final float hx0 = cellCenterX(aL, aC);
            final float hy0 = cellCenterY(aL);
            final float hx1 = cellCenterX(bL, bC + 1);
            final float hy1 = cellCenterY(bL);
            final float dx0 = x - hx0;
            final float dy0 = y - hy0;
            final float dx1 = x - hx1;
            final float dy1 = y - hy1;
            final boolean h0 = dx0 * dx0 + dy0 * dy0 <= HANDLE_R * HANDLE_R * 4.0f;
            final boolean h1 = dx1 * dx1 + dy1 * dy1 <= HANDLE_R * HANDLE_R * 4.0f;
            if (h0 && h1) {
                // Overlapping handles: pick the nearer one.
                if (dx0 * dx0 + dy0 * dy0 <= dx1 * dx1 + dy1 * dy1) {
                    return 0;
                }
                return 1;
            }
            if (h0) {
                return 0;
            }
            if (h1) {
                return 1;
            }
            return -1;
        } catch (Exception ignored) {
            return -1;
        }
    }

    private float cellCenterX(int line, int ch) {
        try {
            measureChar();
            final float cw = charW > 0.5f ? charW : 8.0f;
            int c = ch;
            if (c < 0) {
                c = 0;
            }
            return 8.0f + (float) c * cw;
        } catch (Exception ignored) {
            return 8.0f;
        }
    }

    private float cellCenterY(int line) {
        try {
            // Invert of xyToCell: center of `line` in view coordinates.
            final Paint.FontMetrics fm = paint.getFontMetrics();
            final float top = (fm == null) ? 0.0f : fm.top;
            int yMod = 0;
            int startLine = 0;
            if (yOff > 0 && yOff != Integer.MAX_VALUE && lineHeight > 0) {
                yMod = yOff % lineHeight;
                startLine = yOff / lineHeight;
            }
            return (float) ((line - startLine) * lineHeight) - (float) yMod - top + (float) lineHeight / 2.0f;
        } catch (Exception ignored) {
            return 0.0f;
        }
    }

    public synchronized void setTranscript(String snap) {
        if (snap == null) {
            snap = "";
        }
        transcript = snap;
        // W8: while the grid is displayed, skip the split + rewrap + redraw
        // entirely (the transcript pipeline is invisible). The raw string is
        // kept, so leaving gridMode re-derives on the next snapshot (≤50ms
        // stale, one emit). Grid mode exits via setGrid, which rewarms below.
        final boolean gm;
        synchronized (this) {
            gm = gridMode;
        }
        if (gm) {
            return;
        }
        rewrapTranscript();
    }

    // Re-derive wrap + scroll from the stored raw transcript (used when
    // leaving gridMode, where snapshots were skipped while hidden).
    public void rewrapTranscript() {
        lines = transcript.split("\n", -1);
        if (lines.length > 3000) {
            final String[] tail = new String[3000];
            int st = lines.length - 3000;
            int o = 0;
            while (o < 3000) {
                tail[o] = lines[st + o];
                o++;
            }
            lines = tail;
        }
        rewrap();
        // v30: selection SURVIVES output (Termux norm: anchors live in
        // buffer coords and are clamped, never dropped, when rows are
        // appended — v28 field: "selector resets when scrolling"). Old
        // rows keep their wrapped indices while new rows append, so the
        // only risk is a ring trim, handled by the clamp below.
        if (selecting) {
            final int delta = linesGrewDelta();
            if (delta < 0) {
                // Ring dropped `delta` oldest rows: shift anchors down by
                // the same amount so they still point at the same text.
                selStartLine += delta;
                selEndLine += delta;
                selAnchorLine += delta;
            }
            clampSelectionLocked();
        }
        if (followBottom) {
            resolveFollow();
        }
        post(new Runnable() {
            public void run() {
                rewrap();
                clampScroll();
                invalidate();
            }
        });
    }

    // v30: signed row delta since the last snapshot. Negative = rows were
    // dropped from the head (ring trim), so selection anchors must shift by
    // it to keep pointing at the same text. Also refreshes the baseline.
    private int linesGrewDelta() {
        final int n = lines.length;
        final int delta = n - lastLineCount;
        lastLineCount = n;
        return delta;
    }

    // v30: keep the selection, clamped into current bounds. Drops it only
    // when its rows were trimmed away entirely (indices fall off the head).
    private void clampSelectionLocked() {
        final int max = wrapped.length - 1;
        if (max < 0) {
            clearSelectionLocked();
            return;
        }
        // If both anchors were trimmed past the head, the text is gone.
        if (selEndLine + lastLineDelta < 0 || selStartLine + lastLineDelta < 0) {
            clearSelectionLocked();
            return;
        }
        if (selStartLine > max) {
            selStartLine = max;
        }
        if (selEndLine > max) {
            selEndLine = max;
        }
        if (selAnchorLine > max) {
            selAnchorLine = max;
        }
        final String[] wv = wrapped;
        if (selStartLine >= 0 && wv != null && wv.length > 0) {
            final int len = wv[selStartLine] == null ? 0 : wv[selStartLine].length();
            if (selStartChar > len) {
                selStartChar = len;
            }
        }
        if (selEndLine >= 0 && wv != null && wv.length > 0) {
            final int len = wv[selEndLine] == null ? 0 : wv[selEndLine].length();
            if (selEndChar > len) {
                selEndChar = len;
            }
        }
    }

    private int lastLineDelta = 0;

    private void clearSelectionLocked() {
        selecting = false;
        selStartLine = -1;
        selStartChar = -1;
        selEndLine = -1;
        selEndChar = -1;
        selAnchorLine = -1;
        selAnchorChar = -1;
        selHandleDrag = false;
    }

    private void rewrap() {
        try {
            final int w = getWidth();
            if (w <= 16 || lines.length == 0) {
                final String[] wv = lines;
                if (wv != wrapped) {
                    final String[] frozen = wrapped;
                    if (selecting && frozen != null && wv != frozen && wv.length != frozen.length) {
                        clearSelectionLocked();
                    }
                    wrapped = wv;
                }
                return;
            }
            float cw = 8.0f;
            try {
                final float[] widths = new float[1];
                paint.getTextWidths("M", widths);
                if (widths[0] > 1.0f) {
                    cw = widths[0];
                }
            } catch (Exception ignored) {
            }
            int maxChars = (int) (((float) (w - 16)) / cw);
            if (maxChars < 8) {
                maxChars = 8;
            }
            if (maxChars > 512) {
                maxChars = 512;
            }
            int total = 0;
            int i = 0;
            while (i < lines.length) {
                final String s = lines[i];
                if (s.length() <= maxChars) {
                    total++;
                } else {
                    total += (s.length() + maxChars - 1) / maxChars;
                }
                i++;
                if (total > 4000) {
                    break;
                }
            }
            if (total < 1) {
                total = 1;
            }
            final String[] out = new String[total];
            int o = 0;
            i = 0;
            while (i < lines.length && o < total) {
                final String s = lines[i];
                if (s.length() <= maxChars) {
                    out[o] = s;
                    o++;
                } else {
                    int st = 0;
                    int guard = 0;
                    while (st < s.length() && o < total && guard < 64) {
                        guard++;
                        int en = st + maxChars;
                        if (en > s.length()) {
                            en = s.length();
                        }
                        if (en <= st) {
                            break;
                        }
                        out[o] = s.substring(st, en);
                        o++;
                        st = en;
                    }
                }
                i++;
            }
            while (o < total) {
                out[o] = "";
                o++;
            }
            final String[] frozen = wrapped;
            // v30: only a WIDTH change invalidates anchors (rotation /
            // font change re-wraps every row). Appended rows leave old
            // indices intact — clamp instead of clear (Termux norm).
            if (selecting && frozen != null && out.length != frozen.length
                    && maxChars != lastMaxChars) {
                clearSelectionLocked();
            }
            lastMaxChars = maxChars;
            wrapped = out;
        } catch (Exception e) {
            wrapped = lines;
        }
    }

    public void setFollowBottom(boolean f) {
        followBottom = f;
        if (f) {
            resolveFollow();
            clampScroll();
            invalidate();
        }
    }

    private int maxYOff(int viewH) {
        final int total = wrapped.length * lineHeight;
        final int m = total - viewH;
        if (m < 0) {
            return 0;
        }
        return m;
    }

    // Resolve the follow-tail offset immediately on the calling thread so the
    // next onDraw already shows the tail. The old sentinel + post() deferred
    // the fix by one frame (visible jump on every emit).
    private void resolveFollow() {
        final int h = getHeight();
        if (h <= 0) {
            yOff = Integer.MAX_VALUE;
            return;
        }
        yOff = maxYOff(h);
    }

    private void clampScroll() {
        final int h = getHeight();
        if (h <= 0) {
            return;
        }
        final int m = maxYOff(h);
        if (yOff == Integer.MAX_VALUE || followBottom) {
            yOff = m;
            return;
        }
        if (yOff < 0) {
            yOff = 0;
        }
        if (yOff > m) {
            yOff = m;
        }
    }

    protected void onDraw(Canvas c) {
        c.drawColor(bgColor);
        final int w = getWidth();
        final int h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }
        final VtGrid g;
        final boolean useGrid;
        synchronized (this) {
            g = grid;
            useGrid = gridMode && g != null;
        }
        if (useGrid) {
            drawGrid(c, g, w, h);
            return;
        }
        final String[] wv;
        synchronized (this) {
            wv = wrapped;
        }
        if (wv == null || wv.length == 0) {
            return;
        }
        int startLine = 0;
        if (lineHeight > 0 && yOff > 0 && yOff != Integer.MAX_VALUE) {
            startLine = yOff / lineHeight;
        }
        if (startLine < 0) {
            startLine = 0;
        }
        if (startLine >= wv.length) {
            startLine = wv.length - 1;
        }
        final Paint.FontMetrics fm = paint.getFontMetrics();
        int yMod = 0;
        if (yOff > 0 && yOff != Integer.MAX_VALUE && lineHeight > 0) {
            yMod = yOff % lineHeight;
        }
        final float baseline0 = (float) yMod;
        int drawn = 0;
        final float x = 8.0f;
        final int maxDraw = (h / lineHeight) + 4;
        final int cap;
        if (maxDraw < 200) {
            cap = maxDraw;
        } else {
            cap = 200;
        }
        final boolean showSel = selecting && selStartLine >= 0 && selEndLine >= 0;
        int sAL = selStartLine;
        int sAC = selStartChar;
        int sBL = selEndLine;
        int sBC = selEndChar;
        if (showSel && (sAL > sBL || (sAL == sBL && sAC > sBC))) {
            final int tL = sAL;
            final int tC = sAC;
            sAL = sBL;
            sAC = sBC;
            sBL = tL;
            sBC = tC;
        }
        if (showSel) {
            if (sAL < 0) {
                sAL = 0;
            }
            if (sBL >= wv.length) {
                sBL = wv.length - 1;
            }
        }
        final Paint handlePaint = new Paint();
        handlePaint.setColor(0xFF39FF14);
        for (int i = startLine; i < wv.length; i++) {
            final float y = (float) (drawn * lineHeight) - baseline0 - fm.top;
            if (y > (float) (h + lineHeight)) {
                break;
            }
            if (y >= (float) (-lineHeight)) {
                String s = wv[i];
                if (s != null && s.length() > 0) {
                    if (s.length() > 512) {
                        s = s.substring(0, 512);
                    }
                    if (showSel && i >= sAL && i <= sBL) {
                        int st = 0;
                        int en = s.length();
                        if (i == sAL && sAC > 0 && sAC < en) {
                            st = sAC;
                        }
                        if (i == sBL && sBC >= 0 && sBC < en) {
                            en = sBC + 1;
                        }
                        if (en > st) {
                            float rx = x;
                            float rw = (float) (en - st) * charW;
                            if (charW < 0.5f) {
                                measureChar();
                                rw = (float) (en - st) * charW;
                            }
                            rx += (float) st * charW;
                            try {
                                c.drawRect(rx, y + fm.top, rx + rw, y + fm.bottom, selPaint);
                            } catch (Exception ignored) {
                            }
                        }
                    }
                    try {
                        c.drawText(s, x, y, paint);
                    } catch (Exception ignored) {
                        break;
                    }
                    // v17 fat handles: system TextView handles are ~24dp teardrops;
                    // ours were 6px bars. Draw filled circles (14dp radius, same
                    // green) below/above the edge chars so fingers can grab them.
                    // Hit radius in hitHandle() already matches (2x HANDLE_R).
                    if (showSel && i >= sAL && i <= sBL) {
                        final float density = viewDensity();
                        float hr = 14.0f * density;
                        if (hr < 14.0f) {
                            hr = 14.0f;
                        }
                        if (hr > 28.0f) {
                            hr = 28.0f;
                        }
                        if (i == sAL) {
                            float hx = x;
                            if (sAC >= 0 && sAC <= s.length()) {
                                hx += (float) sAC * charW;
                            }
                            try {
                                c.drawCircle(hx, y + fm.bottom + hr * 0.6f, hr * 0.55f, handlePaint);
                            } catch (Exception ignored) {
                            }
                        }
                        if (i == sBL) {
                            float hx = x;
                            int bc = sBC + 1;
                            if (bc < 0) {
                                bc = 0;
                            }
                            if (bc > s.length()) {
                                bc = s.length();
                            }
                            hx += (float) bc * charW;
                            try {
                                c.drawCircle(hx, y + fm.top - hr * 0.6f, hr * 0.55f, handlePaint);
                            } catch (Exception ignored) {
                            }
                        }
                    }
                }
            }
            drawn++;
            if (drawn > cap) {
                break;
            }
        }
    }

    // Original grid renderer: per-cell fg/bg from packed styles, block
    // cursor at the grid cursor, scrollback reachable via the same yOff
    // scroll as the transcript path (line 0 = oldest scrollback).
    private void drawGrid(Canvas c, VtGrid g, int w, int h) {
        final Paint cellPaint = new Paint(paint);
        refreshGridCache(g);
        final int total = gridCacheTotal;
        if (total <= 0) {
            return;
        }
        final int visRows = g.getRows();
        final int sb = total - visRows;
        int startLine = 0;
        if (lineHeight > 0 && yOff > 0 && yOff != Integer.MAX_VALUE) {
            startLine = yOff / lineHeight;
        }
        if (startLine < 0) {
            startLine = 0;
        }
        if (startLine >= total) {
            startLine = total - 1;
        }
        final Paint.FontMetrics fm = paint.getFontMetrics();
        int yMod = 0;
        if (yOff > 0 && yOff != Integer.MAX_VALUE && lineHeight > 0) {
            yMod = yOff % lineHeight;
        }
        measureChar();
        final float cw = charW > 0.5f ? charW : 8.0f;
        final float x0 = 8.0f;
        final int maxDraw = (h / lineHeight) + 4;
        final int cap = maxDraw < 200 ? maxDraw : 200;
        final int curR = g.getCursorRow();
        final int curC = g.getCursorCol();
        int drawn = 0;
        for (int li = startLine; li < total; li++) {
            final float y = (float) (drawn * lineHeight) - (float) yMod - fm.top;
            if (y > (float) (h + lineHeight)) {
                break;
            }
            if (y >= (float) (-lineHeight)) {
                final String s = li < gridCacheText.length ? gridCacheText[li] : "";
                final int[] st = li < gridCacheStyles.length && gridCacheStyles[li] != null
                        ? gridCacheStyles[li] : new int[0];
                final String line = (s == null) ? "" : s;
                final boolean cursorHere = (li - sb) == curR;
                int i = 0;
                while (i < line.length()) {
                    final int packed = i < st.length ? st[i] : 0;
                    int fg = VtGrid.styleFg(packed);
                    int bg = VtGrid.styleBg(packed);
                    final int flags = VtGrid.styleFlags(packed);
                    int j = i + 1;
                    while (j < line.length() && (j < st.length ? st[j] : 0) == packed) {
                        j++;
                    }
                    int fgColor = fg < 256 ? cubeColor(fg & 0xFF) : cubeColor(7);
                    int bgColor = bg < 256 ? cubeColor(bg & 0xFF) : cubeColor(0);
                    if ((flags & VtGrid.F_INVERSE) != 0) {
                        final int t = fgColor;
                        fgColor = bgColor;
                        bgColor = t;
                    }
                    if ((flags & VtGrid.F_BOLD) != 0 && fg < 8) {
                        fgColor = cubeColor(fg + 8);
                    }
                    final float rx = x0 + (float) i * cw;
                    final float rw = (float) (j - i) * cw;
                    if (bg != 0 || (flags & VtGrid.F_INVERSE) != 0) {
                        cellPaint.setColor(bgColor);
                        try {
                            c.drawRect(rx, y + fm.top, rx + rw, y + fm.bottom, cellPaint);
                        } catch (Exception ignored) {
                        }
                    }
                    if ((flags & VtGrid.F_HIDDEN) == 0) {
                        cellPaint.setColor(fgColor);
                        if ((flags & VtGrid.F_UNDERLINE) != 0) {
                            cellPaint.setUnderlineText(true);
                        }
                        try {
                            c.drawText(line.substring(i, j), rx, y, cellPaint);
                        } catch (Exception ignored) {
                            break;
                        }
                        cellPaint.setUnderlineText(false);
                    }
                    i = j;
                }
                if (cursorHere && followBottom) {
                    final float cx = x0 + (float) curC * cw;
                    cellPaint.setColor(0xFF39FF14);
                    try {
                        c.drawRect(cx, y + fm.top, cx + cw, y + fm.bottom, cellPaint);
                    } catch (Exception ignored) {
                    }
                }
            }
            drawn++;
            if (drawn > cap) {
                break;
            }
        }
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rewrap();
        clampScroll();
        reportSize();
    }

    // Measure visible rows/cols from real metrics and tell the session so the
    // kernel winsize (and SIGWINCH) follows the view. Original design: derive
    // cols from measured glyph width, rows from line height, clamp to the PTY
    // limits (8-80 x 20-240) enforced natively.
    public void reportSize() {
        try {
            final int w = getWidth();
            final int h = getHeight();
            if (w <= 0 || h <= 0 || lineHeight <= 0) {
                return;
            }
            measureChar();
            float cw = charW;
            if (cw < 1.0f) {
                cw = 8.0f;
            }
            int cols = (int) (((float) (w - 16)) / cw);
            int rows = h / lineHeight;
            if (cols < 20) {
                cols = 20;
            }
            if (cols > 240) {
                cols = 240;
            }
            if (rows < 8) {
                rows = 8;
            }
            if (rows > 80) {
                rows = 80;
            }
            if (rows != lastRows || cols != lastCols) {
                lastRows = rows;
                lastCols = cols;
                if (sizeListener != null) {
                    sizeListener.onSize(rows, cols);
                }
            }
        } catch (Exception ignored) {
        }
    }

    public boolean onTouchEvent(MotionEvent e) {
        final int action = e.getAction();
        if (action == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
            lastY = downY;
            downTime = android.os.SystemClock.uptimeMillis();
            dragging = false;
            longPressSent = false;
            selHandleDrag = false;
            selScrollDrag = false;
            if (selecting) {
                // v31 selection model (Termux handle norm, minus the scroll
                // lock): only a HANDLE drag resizes. Every other drag
                // scrolls, including drags that start inside the selection —
                // v30 field: after Select All the selection covered the
                // screen, so "inside" was everywhere and scrolling was
                // impossible while the Copy/Select bar was up. Extending
                // still works during the initial long-press gesture
                // (longPressSent path in MOVE), which is the gesture users
                // actually perform. Tap still clears.
                final int h = hitHandle(downX, downY);
                if (h >= 0) {
                    selHandleDrag = true;
                    selDragHandle = h;
                    dragging = true;
                    return true;
                }
                selScrollDrag = true;
                dragging = false;
                lastY = downY;
                return true;
            }
            postDelayed(longPressCheck, 500L);
            return true;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            final float y = e.getY();
            final float dy = y - lastY;
            float total = y - downY;
            if (total < 0.0f) {
                total = 0.0f - total;
            }
            float totalX = e.getX() - downX;
            if (totalX < 0.0f) {
                totalX = 0.0f - totalX;
            }
            if (selHandleDrag && selecting) {
                moveSelectionHandle(selDragHandle, e.getX(), y);
                lastY = y;
                return true;
            }
            if (selScrollDrag && selecting) {
                // v31: drag started outside a handle -> scroll the
                // transcript; selection stays pinned to its rows. Once the
                // finger has actually moved, tell the host so it can drop
                // the floating Copy/Select bar — v30 field: with Select All
                // the bar covered the screen and the terminal felt stuck
                // "in the menu". Scroll = user moved on.
                final float sdy = y - lastY;
                if (sdy != 0.0f) {
                    followBottom = false;
                    yOff = (int) ((float) yOff - sdy);
                    clampScroll();
                    invalidate();
                    lastY = y;
                }
                if (Math.abs(total) > 6.0f || Math.abs(totalX) > 6.0f) {
                    dragging = true;
                    if (tapListener != null) {
                        tapListener.onSelectionDrag(e.getX(), y);
                    }
                }
                return true;
            }
            if (longPressSent && selecting) {
                extendSelection(e.getX(), y);
                if (tapListener != null) {
                    tapListener.onSelectionDrag(e.getX(), y);
                }
                lastY = y;
                return true;
            }
            if (dragging && selecting) {
                // Finger-down inside selection without handle: live-extend the
                // free end (anchor stays), same as TextView drag.
                extendSelection(e.getX(), y);
                lastY = y;
                return true;
            }
            if (dragging == false && (total > 12.0f || totalX > 12.0f)) {
                dragging = true;
                removeCallbacks(longPressCheck);
                clearSelection();
            }
            if (dragging && selecting == false) {
                followBottom = false;
                yOff = (int) ((float) yOff - dy);
                clampScroll();
                invalidate();
                lastY = y;
            }
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            removeCallbacks(longPressCheck);
            if (selScrollDrag) {
                // v30: scroll-drag ends here. A real drag keeps the
                // selection; a bare tap (never moved) clears it as before.
                selScrollDrag = false;
                if (dragging) {
                    dragging = false;
                    final int m = maxYOff(getHeight());
                    if (yOff >= m - lineHeight) {
                        followBottom = true;
                        yOff = m;
                        invalidate();
                    }
                    return true;
                }
            }
            if (selHandleDrag && selecting) {
                selHandleDrag = false;
                if (tapListener != null) {
                    tapListener.onSelectionDone();
                }
                return true;
            }
            if (longPressSent && selecting) {
                if (tapListener != null) {
                    tapListener.onSelectionDone();
                }
                longPressSent = false;
                return true;
            }
            if (dragging) {
                if (selecting) {
                    // A drag that extended the selection ends it at the finger;
                    // show actions rather than scrolling.
                    dragging = false;
                    if (tapListener != null) {
                        tapListener.onSelectionDone();
                    }
                    return true;
                }
                dragging = false;
                final int m = maxYOff(getHeight());
                if (yOff >= m - lineHeight) {
                    followBottom = true;
                    yOff = m;
                    invalidate();
                }
                return true;
            }
            if (selecting) {
                clearSelection();
                if (tapListener != null) {
                    tapListener.onTap();
                }
                return true;
            }
            if (longPressSent == false && tapListener != null) {
                final long dt = android.os.SystemClock.uptimeMillis() - downTime;
                if (dt < 500L) {
                    tapListener.onTap();
                }
            }
            longPressSent = false;
            return true;
        }
        return super.onTouchEvent(e);
    }

    public boolean onCheckIsTextEditor() {
        return true;
    }

    private static int chooseInputType() {
        try {
            if ("samsung".equalsIgnoreCase(Build.MANUFACTURER)) {
                return InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
            }
        } catch (Exception ignored) {
        }
        return InputType.TYPE_NULL;
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        try {
            final int action = event.getAction();
            if (sink != null && (action == KeyEvent.ACTION_DOWN || action == KeyEvent.ACTION_MULTIPLE)) {
                final int kc = event.getKeyCode();
                if (kc == KeyEvent.KEYCODE_DEL) {
                    followBottom = true;
                    sink.sendDel(1, "key");
                    return true;
                }
                if (kc == KeyEvent.KEYCODE_ENTER) {
                    followBottom = true;
                    sink.sendEnter("key");
                    return true;
                }
                if (action == KeyEvent.ACTION_MULTIPLE && kc == KeyEvent.KEYCODE_UNKNOWN) {
                    final CharSequence ch = event.getCharacters();
                    if (ch != null && ch.length() > 0) {
                        followBottom = true;
                        sink.sendText(ch.toString(), "key");
                        return true;
                    }
                }
                if (action == KeyEvent.ACTION_DOWN) {
                    final int mask = KeyEvent.META_CTRL_MASK | KeyEvent.META_ALT_MASK | KeyEvent.META_ALT_LEFT_ON | KeyEvent.META_ALT_RIGHT_ON;
                    final int effectiveMeta = event.getMetaState() & ~mask;
                    final int uni = event.getUnicodeChar(effectiveMeta);
                    if (uni != 0 && (uni & KeyCharacterMap.COMBINING_ACCENT) == 0) {
                        followBottom = true;
                        sink.sendText(String.valueOf((char) uni), "key");
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return super.dispatchKeyEvent(event);
    }

    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        outAttrs.inputType = chooseInputType();
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_FLAG_NO_FULLSCREEN;
        super.onCreateInputConnection(outAttrs);
        return new ShellConnection(this, true);
    }

    private class ShellConnection extends BaseInputConnection {
        ShellConnection(View v, boolean full) {
            super(v, full);
        }

        private void drainEditable(String src) {
            try {
                final Editable e = getEditable();
                if (e != null && e.length() > 0) {
                    final String s = e.toString();
                    e.clear();
                    if (sink != null && s.length() > 0) {
                        followBottom = true;
                        sink.sendText(s, src);
                    }
                }
            } catch (Exception ignored) {
            }
        }

        public boolean commitText(CharSequence text, int newCursorPosition) {
            if (text == null) {
                return true;
            }
            super.commitText(text, newCursorPosition);
            drainEditable("commit");
            return true;
        }

        public boolean setComposingText(CharSequence text, int newCursorPosition) {
            super.setComposingText(text, newCursorPosition);
            return true;
        }

        public boolean setComposingRegion(int start, int end) {
            // Composition churn (glide/swipe candidates) carries no committed
            // text: acknowledge without sending. The old code emitted DELs
            // here, double-deleting on Gboard (region replace + our DEL).
            return true;
        }

        public boolean finishComposingText() {
            super.finishComposingText();
            drainEditable("commit");
            return true;
        }

        public boolean deleteSurroundingText(int beforeLength, int afterLength) {
            if (sink != null && beforeLength > 0) {
                followBottom = true;
                sink.sendDel(beforeLength, "commit");
            }
            return true;
        }

        public boolean deleteSurroundingTextInCodePoints(int beforeLength, int afterLength) {
            return deleteSurroundingText(beforeLength, afterLength);
        }

        public boolean sendKeyEvent(KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                final int kc = event.getKeyCode();
                if (kc == KeyEvent.KEYCODE_DEL) {
                    if (sink != null) {
                        followBottom = true;
                        sink.sendDel(1, "commit-key");
                    }
                    return true;
                }
                if (kc == KeyEvent.KEYCODE_ENTER) {
                    if (sink != null) {
                        followBottom = true;
                        sink.sendEnter("commit-key");
                    }
                    return true;
                }
            }
            return super.sendKeyEvent(event);
        }

        public boolean performEditorAction(int action) {
            // Only newline-grade actions reach the shell. SEARCH/DONE/NEXT
            // from password-mode keyboards are spurious here; the old code
            // sent Enter for all of them.
            if (action == EditorInfo.IME_ACTION_UNSPECIFIED
                    || action == EditorInfo.IME_ACTION_NONE
                    || action == EditorInfo.IME_ACTION_GO
                    || action == EditorInfo.IME_ACTION_SEND
                    || action == EditorInfo.IME_ACTION_NEXT) {
                if (sink != null) {
                    followBottom = true;
                    sink.sendEnter("commit");
                }
            }
            return true;
        }
    }
}
