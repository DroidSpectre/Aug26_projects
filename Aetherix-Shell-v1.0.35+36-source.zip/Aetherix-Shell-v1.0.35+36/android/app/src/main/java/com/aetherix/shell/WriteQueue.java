package com.aetherix.shell;

/**
 * Bounded writer queue with generation fencing (W7).
 * Why extracted: the restart/interleave logic (ring + generation + drain
 * protocol) is the most intricate concurrent code in the app and was locked
 * inside ShellSession (Android deps) with zero coverage. This class is pure
 * Java and unit-tested on a plain JVM.
 *
 * Protocol (callers synchronize externally on the session monitor):
 *  enqueue: drops OLDEST bytes past capacity (flood protection), returns
 *    bytes queued. reset(): generation++ and queue clear for a new session.
 *  beginDrain(gen, max): returns chunk start or -1 when the caller generation
 *    is stale or the queue is empty. finishDrain(len): advance head.
 *  The owner thread pins its generation at birth; any mismatch means "a
 *  restart happened, exit without touching the new session".
 * No lambdas, no diamonds.
 */
public class WriteQueue {
    public static final int CAP = 64 * 1024;

    private final byte[] buf = new byte[CAP];
    private int head = 0;
    private int tail = 0;
    private int count = 0;
    private int generation = 0;

    public synchronized int getGeneration() {
        return generation;
    }

    public synchronized int size() {
        return count;
    }

    public synchronized int enqueue(byte[] b, int off, int len) {
        int queued = 0;
        for (int i = 0; i < len; i++) {
            if (count >= CAP) {
                head = (head + 1) % CAP;
                count--;
            }
            buf[tail] = b[off + i];
            tail = (tail + 1) % CAP;
            count++;
            queued++;
        }
        return queued;
    }

    /** New session: invalidate all pinned generations, drop queued bytes. */
    public synchronized void reset() {
        generation++;
        head = 0;
        tail = 0;
        count = 0;
    }

    /** True while gen is the live generation. */
    public synchronized boolean isLive(int gen) {
        return gen == generation;
    }

    /**
     * Copy up to max bytes into dst[0..] without removing. Returns bytes
     * staged, 0 when empty, -1 when gen is stale (caller must exit).
     */
    public synchronized int stage(int gen, byte[] dst, int max) {
        if (gen != generation) {
            return -1;
        }
        int take = count;
        if (take > max) {
            take = max;
        }
        if (take > dst.length) {
            take = dst.length;
        }
        for (int i = 0; i < take; i++) {
            dst[i] = buf[(head + i) % CAP];
        }
        return take;
    }

    /** Remove len staged bytes. Returns false when gen went stale. */
    public synchronized boolean commit(int gen, int len) {
        if (gen != generation) {
            return false;
        }
        if (len > count) {
            len = count;
        }
        head = (head + len) % CAP;
        count -= len;
        return true;
    }
}
