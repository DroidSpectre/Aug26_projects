package com.aetherix.shell;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * Append-only runtime event log, writes off the UI thread.
 * v8: append() only enqueues; a single daemon worker does file open/write/
 * close. Readers (launcher refresh thread) still read synchronously.
 * No lambdas, no diamonds.
 */
public class EventLog {
    public static final String NAME = "events.log";
    public static final long MAX_BYTES = 50 * 1024;

    private static class Entry {
        final String dir;
        final String line;
        Entry(String d, String l) {
            dir = d;
            line = l;
        }
    }

    private static final ArrayList queue = new ArrayList();
    private static boolean workerStarted = false;
    // L1 batching: under output floods (cat big file) append() used to enqueue
    // one Entry per line and the worker did open/write/close per line. Now the
    // worker drains up to BATCH lines into one file open, and append() sheds
    // load past SHED_CAP (drops oldest, counts drops) instead of OOMing.
    private static final int BATCH = 50;
    private static final int SHED_CAP = 2000;
    private static int shedDrops = 0;

    public static void append(Context ctx, String tag, String msg) {
        try {
            if (ctx == null) {
                return;
            }
            final Context app = ctx.getApplicationContext();
            if (app == null) {
                return;
            }
            final File filesDir = app.getFilesDir();
            if (filesDir == null) {
                return;
            }
            final String dir = filesDir.getAbsolutePath();
            final String line = String.valueOf(new java.util.Date()) + " [" + tag + "] " + msg;
            final Entry e = new Entry(dir, line);
            synchronized (queue) {
                if (queue.size() >= SHED_CAP) {
                    queue.remove(0);
                    shedDrops++;
                }
                queue.add(e);
                if (workerStarted == false) {
                    workerStarted = true;
                    startWorker();
                }
                queue.notifyAll();
            }
        } catch (Exception ignored) {
        }
    }

    private static void startWorker() {
        try {
            final Thread t = new Thread(new Runnable() {
                public void run() {
                    workerLoop();
                }
            });
            try {
                t.setDaemon(true);
            } catch (Exception ignored) {
            }
            t.start();
        } catch (Exception ignored) {
        }
    }

    private static void workerLoop() {
        final ArrayList batch = new ArrayList();
        while (true) {
            Entry first = null;
            synchronized (queue) {
                while (queue.isEmpty()) {
                    try {
                        queue.wait();
                    } catch (InterruptedException ie) {
                        return;
                    }
                }
                first = (Entry) queue.remove(0);
                while (batch.size() < BATCH && queue.isEmpty() == false) {
                    batch.add(queue.remove(0));
                }
            }
            if (first != null) {
                writeBatch(first, batch);
                batch.clear();
            }
        }
    }

    private static void writeBatch(Entry first, ArrayList rest) {
        try {
            final File f = new File(first.dir, NAME);
            if (f.exists() && f.length() > MAX_BYTES) {
                rotate(f);
            }
            final PrintWriter pw = new PrintWriter(new FileWriter(f, true));
            try {
                pw.println(first.line);
                for (int i = 0; i < rest.size(); i++) {
                    final Entry e = (Entry) rest.get(i);
                    pw.println(e.line);
                }
                synchronized (queue) {
                    if (shedDrops > 0) {
                        pw.println("[log] shed " + shedDrops + " lines under flood");
                        shedDrops = 0;
                    }
                }
            } finally {
                pw.close();
            }
        } catch (Exception ignored) {
        }
    }

    private static void rotate(File f) throws Exception {
        final BufferedReader br = new BufferedReader(new FileReader(f));
        try {
            final StringBuffer sb = new StringBuffer();
            final char[] buf = new char[4096];
            int r;
            while ((r = br.read(buf)) != -1) {
                sb.append(buf, 0, r);
            }
            final String all = sb.toString();
            final int keepFrom = Math.max(0, all.length() - (int) (MAX_BYTES / 2));
            final String tail = all.substring(keepFrom);
            final int nl = tail.indexOf('\n');
            String trimmed = tail;
            if (nl >= 0 && keepFrom > 0) {
                trimmed = tail.substring(nl + 1);
            }
            final PrintWriter pw = new PrintWriter(new FileWriter(f, false));
            try {
                pw.print(trimmed);
            } finally {
                pw.close();
            }
        } finally {
            br.close();
        }
    }

    public static String readTail(Context ctx, int maxChars) {
        try {
            final File f = new File(ctx.getFilesDir(), NAME);
            if (f.exists() == false) {
                return "";
            }
            final BufferedReader br = new BufferedReader(new FileReader(f));
            try {
                final StringBuffer sb = new StringBuffer();
                final char[] buf = new char[2048];
                int r;
                while ((r = br.read(buf)) != -1) {
                    sb.append(buf, 0, r);
                }
                final String all = sb.toString();
                if (all.length() <= maxChars) {
                    return all;
                }
                return all.substring(all.length() - maxChars);
            } finally {
                br.close();
            }
        } catch (Exception e) {
            return "event-log read error: " + String.valueOf(e.getMessage());
        }
    }
}
