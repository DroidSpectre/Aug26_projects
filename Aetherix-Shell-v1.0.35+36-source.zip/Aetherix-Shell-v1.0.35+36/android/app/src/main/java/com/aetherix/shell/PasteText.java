package com.aetherix.shell;

/**
 * Clipboard-to-PTY payload prep. Android-free so the rules are testable
 * off-device: newline normalization, bracketed-paste wrapping (?2004),
 * and the flood cap. This is the whole paste funnel - TerminalActivity
 * only reads the clip and hands the text here.
 */
public final class PasteText {
    /**
     * Content cap before wrapping. WriteQueue is 64 KB and drops OLDEST
     * bytes under flood, which would silently corrupt a paste; 16 KB
     * leaves ample headroom and is far more than a shell command needs.
     */
    public static final int CAP = 16 * 1024;

    private PasteText() {
    }

    /**
     * CRLF and lone CR both become LF; NULs are dropped (a PTY write of
     * NUL is either swallowed or truncates, and shells never want them).
     */
    public static String normalize(String s) {
        if (s == null) {
            return "";
        }
        StringBuffer out = new StringBuffer(s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c == 0) {
                continue;
            }
            if (c == '\r') {
                if (i + 1 < s.length() && s.charAt(i + 1) == '\n') {
                    continue;
                }
                out.append('\n');
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }

    public static boolean wouldTruncate(String s, int cap) {
        if (cap <= 0) {
            return false;
        }
        return normalize(s).length() > cap;
    }

    /**
     * Returns the exact bytes to hand the PTY, or "" when there is
     * nothing to send.
     *
     * bracketed (app set ?2004) - the app asked to treat the paste as one
     * literal block, so it is wrapped and newlines stay newlines: the app
     * inserts them into its buffer instead of running each line.
     *
     * plain - a newline IS an Enter keypress, and a canonical-mode PTY
     * expects CR (the line discipline's ICRNL turns it into NL). Sending
     * bare LF here is the classic pasted-script-runs-wrong bug.
     */
    public static String prepare(String s, boolean bracketed, int cap) {
        String n = normalize(s);
        if (cap > 0 && n.length() > cap) {
            n = n.substring(0, cap);
        }
        if (n.length() == 0) {
            return "";
        }
        if (bracketed) {
            return "\u001b[200~" + n + "\u001b[201~";
        }
        StringBuffer out = new StringBuffer(n.length());
        for (int i = 0; i < n.length(); i++) {
            final char c = n.charAt(i);
            out.append(c == '\n' ? '\r' : c);
        }
        return out.toString();
    }
}
