package com.aetherix.shell;

/**
 * Streaming UTF-8 decoder for PTY output.
 * Why: readPty returns arbitrary 4KB chunks; a multi-byte sequence can split
 * across two reads. Decoding each chunk independently (new String(bytes)) turns
 * the split tail into U+FFFD mojibake. This decoder carries the incomplete
 * tail and completes it when the next chunk arrives.
 * Original implementation from the UTF-8 bit layout (RFC 3629): no Android
 * APIs, pure Java, unit-testable on a plain JVM.
 * No lambdas, no diamonds.
 */
public class Utf8Stream {
    // Replacement char emitted for a structurally invalid sequence.
    private static final char REPLACEMENT = '�';

    // Pending bytes of an incomplete sequence (max 3: a 4-byte head + 3 tail).
    private final byte[] pending = new byte[4];
    private int pendingLen = 0;
    // How many continuation bytes are still missing for the pending head.
    private int pendingNeed = 0;

    // Smallest legal code point for a sequence of a given total length
    // (rejects overlong encodings: E0 must be >= U+0800, F0 >= U+10000...).
    private static int minForLen(int len) {
        if (len == 2) {
            return 0x80;
        }
        if (len == 3) {
            return 0x800;
        }
        return 0x10000;
    }

    public synchronized void reset() {
        pendingLen = 0;
        pendingNeed = 0;
    }

    /**
     * Decode bytes b[off..off+len) and append characters to out.
     * Incomplete trailing sequences are held internally, not emitted.
     * Returns the number of chars appended.
     */
    public synchronized int decode(byte[] b, int off, int len, StringBuffer out) {
        final int before = out.length();
        int end = off + len;
        int i = off;
        // First: try to complete a carried-over head with the new bytes.
        if (pendingNeed > 0) {
            while (i < end && pendingNeed > 0) {
                final byte c = b[i];
                if ((c & 0xC0) != 0x80) {
                    // New head byte where a continuation was expected: flush
                    // the broken head as replacement and restart at this byte.
                    out.append(REPLACEMENT);
                    pendingLen = 0;
                    pendingNeed = 0;
                    break;
                }
                pending[pendingLen] = c;
                pendingLen++;
                pendingNeed--;
                i++;
            }
            if (pendingNeed == 0 && pendingLen > 0) {
                emitPending(out);
            }
            if (pendingNeed > 0) {
                // Still incomplete after consuming all input: wait for more.
                return out.length() - before;
            }
        }
        while (i < end) {
            final int c = b[i] & 0xFF;
            if (c < 0x80) {
                out.append((char) c);
                i++;
            } else if ((c & 0xE0) == 0xC0) {
                i += takeSequence(b, i, end, 2, out);
            } else if ((c & 0xF0) == 0xE0) {
                i += takeSequence(b, i, end, 3, out);
            } else if ((c & 0xF8) == 0xF0) {
                i += takeSequence(b, i, end, 4, out);
            } else {
                // Stray continuation or 0xF8+ lead: structurally invalid.
                out.append(REPLACEMENT);
                i++;
            }
        }
        return out.length() - before;
    }

    /**
     * Consume one sequence starting at b[i] (b[i] is the head, total length
     * want). Returns bytes consumed from this chunk (may be 0 when the head
     * is stashed for the next chunk). Emits chars or REPLACEMENT directly.
     */
    private int takeSequence(byte[] b, int i, int end, int want, StringBuffer out) {
        final int avail = end - i;
        if (avail < want) {
            // Incomplete: stash what we have, complete on the next decode().
            pendingLen = 0;
            for (int k = 0; k < avail; k++) {
                pending[k] = b[i + k];
            }
            pendingLen = avail;
            pendingNeed = want - avail;
            return avail;
        }
        // Validate continuation bytes.
        for (int k = 1; k < want; k++) {
            if ((b[i + k] & 0xC0) != 0x80) {
                out.append(REPLACEMENT);
                return 1;
            }
        }
        pendingLen = 0;
        for (int k = 0; k < want; k++) {
            pending[k] = b[i + k];
        }
        pendingLen = want;
        pendingNeed = 0;
        emitPending(out);
        return want;
    }

    // Decode pending[0..pendingLen) (a complete head) into out.
    // Returns 1 (one append operation; caller counts via buffer growth).
    private int emitPending(StringBuffer out) {
        final int want = pendingLen;
        int cp;
        if (want == 2) {
            cp = ((pending[0] & 0x1F) << 6) | (pending[1] & 0x3F);
        } else if (want == 3) {
            cp = ((pending[0] & 0x0F) << 12) | ((pending[1] & 0x3F) << 6) | (pending[2] & 0x3F);
        } else {
            cp = ((pending[0] & 0x07) << 18) | ((pending[1] & 0x3F) << 12) | ((pending[2] & 0x3F) << 6) | (pending[3] & 0x3F);
        }
        pendingLen = 0;
        pendingNeed = 0;
        if (cp < minForLen(want) || cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) {
            // Overlong, out of range, or surrogate half: reject.
            out.append(REPLACEMENT);
            return 1;
        }
        if (cp < 0x10000) {
            out.append((char) cp);
        } else {
            final int v = cp - 0x10000;
            out.append((char) (0xD800 + (v >> 10)));
            out.append((char) (0xDC00 + (v & 0x3FF)));
        }
        return 1;
    }

    /**
     * Flush at stream end (shell died): emit a replacement for any dangling
     * head instead of dropping it silently.
     */
    public synchronized void flush(StringBuffer out) {
        if (pendingLen > 0) {
            out.append(REPLACEMENT);
        }
        pendingLen = 0;
        pendingNeed = 0;
    }
}
