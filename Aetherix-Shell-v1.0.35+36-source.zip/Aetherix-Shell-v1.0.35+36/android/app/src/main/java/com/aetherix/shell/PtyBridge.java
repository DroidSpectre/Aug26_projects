package com.aetherix.shell;

/**
 * JNI to libptyjni (openpty). Mirrors hermes terminal.py queue/winsize/PDEATHSIG.
 * writePty added for test-install shell input. loadLibrary wrapped by callers
 * (TerminalActivity) so a missing .so shows text instead of crashing.
 * No lambdas/diamonds.
 */
public class PtyBridge {
    private static boolean loaded = false;
    private static String loadError = "";
    public static synchronized boolean ensureLoaded() {
        if (loaded) {
            return true;
        }
        try {
            System.loadLibrary("ptyjni");
            loaded = true;
            return true;
        } catch (UnsatisfiedLinkError e) {
            loadError = e.getMessage();
            return false;
        }
    }
    public static String getLoadError() {
        return loadError;
    }
    public static native int openPty(String cmd, String cwd, String[] env);
    public static native int readPty(int fd, byte[] buf, int len);
    public static native int writePty(int fd, byte[] buf, int len);
    public static native void resizePty(int fd, int rows, int cols);
    public static native void closePty(int fd);
    // Child lifecycle (C2): pid of the last forked shell, non-blocking poll,
    // blocking wait, signal delivery. Original JNI over waitpid/kill.
    public static native int lastChildPid();
    public static native int pollChild(int pid, int[] status);
    public static native int waitChild(int pid, int[] status);
    public static native int signalChild(int pid, int sig);
    // v36 KILL key: foreground process group of the PTY (TIOCGPGRP). -1 when
    // there is no separate foreground job. Escape hatch for a wedged
    // full-screen app that ignored SIGHUP.
    public static native int foregroundPgrp(int fd);
}
