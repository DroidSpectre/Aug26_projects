package com.aetherix.shell;

/**
 * Shell-path preference validation (Phase 2 #5).
 *
 * Deliberately free of android.* imports so the security-relevant rules are
 * unit-testable off-device, exactly like RowRing/WriteQueue/Utf8Stream. The
 * only inputs are a raw string and the filesystem; no Context is needed.
 *
 * Why parent-side: the v25 field bug was a child pre-exec filesystem probe
 * wedging the spawn on a FUSE remount race, with no timeout and no way to
 * recover. A user-chosen path may legitimately point into /sdcard, so that
 * risk is real here, not theoretical. pty.c therefore only ever execs the
 * value this class approves; it never probes it.
 *
 * The approved value is exec'd directly by path, never handed to a shell for
 * parsing, so anything ambiguous is rejected rather than guessed at.
 */
public class ShellPath {
    /** Longest accepted path. Matches the native shval[256] buffer. */
    public static final int MAX_LEN = 255;

    /**
     * Returns the trimmed path when it is safe and usable, else "".
     *
     * "" means "use the system probe chain" and is also the failure value, so
     * an invalid preference degrades the feature rather than the shell.
     */
    public static String validate(String raw) {
        if (raw == null) {
            return "";
        }
        final String v = raw.trim();
        if (v.isEmpty()) {
            return "";
        }
        if (v.length() > MAX_LEN) {
            return "";
        }
        // Absolute only: no PATH lookup, so no dependence on our own PATH
        // ordering and no way for a bare name to resolve unexpectedly.
        if (v.charAt(0) != '/') {
            return "";
        }
        // Control characters have no place in a path we exec. NUL cannot
        // survive the JNI String round-trip anyway; reject the rest.
        for (int i = 0; i < v.length(); i++) {
            final char c = v.charAt(i);
            if (c < 0x20 || c == 0x7f) {
                return "";
            }
        }
        // Directory traversal is pointless for an exec and only widens the
        // surface, so normalise it away and re-check the result.
        final String flat = collapse(v);
        if (flat.isEmpty()) {
            return "";
        }
        try {
            final java.io.File f = new java.io.File(flat);
            // isFile() rejects directories, FIFOs and device nodes: exec'ing
            // anything but a regular file is never what a user means here.
            if (f.exists() == false || f.isFile() == false || f.canExecute() == false) {
                return "";
            }
        } catch (Exception ignored) {
            return "";
        }
        return flat;
    }

    /** Collapse ".", ".." and duplicate slashes. Never returns a trailing slash.
     *  Public for the unit test; not part of the app-facing surface. */
    public static String collapse(String in) {
        final StringBuilder out = new StringBuilder();
        String[] parts = in.split("/");
        for (int i = 0; i < parts.length; i++) {
            final String p = parts[i];
            if (p.isEmpty() || p.equals(".")) {
                continue;
            }
            if (p.equals("..")) {
                final int cut = out.lastIndexOf("/");
                if (cut <= 0) {
                    return ""; // escaped the root: refuse rather than clamp
                }
                out.setLength(cut);
                continue;
            }
            out.append('/');
            out.append(p);
        }
        return out.toString();
    }

    /** Basename for argv[0]; "" when there is none. Mirrors pty.c's own scan. */
    public static String baseName(String path) {
        if (path == null) {
            return "";
        }
        int i = path.length();
        while (i > 0 && path.charAt(i - 1) == '/') {
            i--;
        }
        int start = i;
        while (start > 0 && path.charAt(start - 1) != '/') {
            start--;
        }
        return path.substring(start, i);
    }
}