package com.aetherix.shell;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/**
 * Foreground keep-alive.
 * Why foreground: Android kills background shell sessions without notification + Doze exemption.
 * Termux-aligned lifecycle: the service outlives activities while a session
 * runs, but stops itself when the last session exits and nobody is bound
 * (stop-when-idle), plus an explicit ACTION_STOP_SERVICE intent wired to the
 * notification Stop button and the launcher. So `exit` + swipe no longer
 * leaves a cached process visible in recents; a live session still survives
 * Back/task-swipe behind its notification.
 * START_NOT_STICKY: a killed-idle service stays dead until the user returns.
 * No lambdas, no diamonds.
 */
public class EnvService extends Service {
    public static final String CHANNEL = "aetherix-shell";
    public static final int NOTIF_ID = 4201;
    public static final String ACTION_STOP_SERVICE = "com.aetherix.shell.STOP_SERVICE";
    public static final String ACTION_REASSERT = "com.aetherix.shell.REASSERT";
    private static boolean wantsStop = false;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        CrashLog.install(this);
        EventLog.append(this, "service", "onCreate");
        try {
            ensureChannel();
            final Notification n = buildNotification();
            try {
                startForeground(NOTIF_ID, n);
                EventLog.append(EnvService.this, "service", "foreground ok");
            } catch (Exception e) {
                // API 34+ throws without FOREGROUND_SERVICE_SPECIAL_USE or on some OEMs.
                // Fall back to a plain notification so the app survives without FGS.
                EventLog.append(EnvService.this, "service", "foreground FAILED, notify fallback: " + String.valueOf(e.getMessage()));
            try {
                final NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    nm.notify(NOTIF_ID, n);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            // Never let service creation crash the app; launcher shows crash.log.
            try {
                final java.io.File f = new java.io.File(getFilesDir(), CrashLog.NAME);
                final java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter(f, true));
                try {
                    pw.println("=== EnvService.onCreate guard ===");
                    e.printStackTrace(pw);
                } finally {
                    pw.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    public int onStartCommand(final Intent intent, int flags, int startId) {
        EventLog.append(this, "service", "start");
        if (intent != null && ACTION_STOP_SERVICE.equals(intent.getAction())) {
            actionStopService();
            return START_NOT_STICKY;
        }
        // Plain SESSION_CHANGED ping (no session start): just re-evaluate
        // idle state. Lets ShellSession report death without reviving it.
        if (intent != null && "com.aetherix.shell.SESSION_CHANGED".equals(intent.getAction())) {
            updateNotification();
            return START_NOT_STICKY;
        }
        // v28 re-assert: refresh the notification WITHOUT starting anything.
        // The terminal sends this on resume so a swiped-away notice comes
        // back while the session lives on. Dead session -> updateNotification
        // self-stops (v16 rule intact, no revive: start() never called here).
        if (intent != null && ACTION_REASSERT.equals(intent.getAction())) {
            wantsStop = false;
            updateNotification();
            return START_NOT_STICKY;
        }
        wantsStop = false;
        // Own the shell session (Termux-style): activities attach for display.
        // Survives Back/task-swipe while this foreground service lives.
        // No bootstrap: this edition runs the on-device shell directly,
        // there is no rootfs to extract and no runtime to select.
        ShellSession.get().start(this);
        updateNotification();
        return START_NOT_STICKY;
    }

    // Termux-aligned: refresh the notification after every state change, and
    // stop when there is nothing left to keep alive (no running session).
    // Called from onStartCommand and from the session-closed callback.
    public static void sessionStateChanged(Context ctx) {
        try {
            final Context app = ctx.getApplicationContext();
            final Intent i = new Intent(app, EnvService.class);
            i.setAction("com.aetherix.shell.SESSION_CHANGED");
            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    app.startForegroundService(i);
                } catch (Exception e) {
                    app.startService(i);
                }
            } else {
                app.startService(i);
            }
        } catch (Exception ignored) {
        }
    }

    public void onDestroy() {
        // W4: bury the session with the service: SIGHUP + bounded reap + fd
        // close, so no zombie shell outlives the service process.
        try {
            ShellSession.get().stop();
            EventLog.append(this, "service", "session stopped");
        } catch (Exception ignored) {
        }
        runStopForeground();
        super.onDestroy();
    }

    // Termux updateNotification: idle (no running session, no explicit keep)
    // means stopSelf. A live session re-posts the notification instead.
    // v29: change-aware + alert-once. DEFAULT importance re-alerts on every
    // notify (buzz/heads-up while already shown — v28 field); LOW hid the
    // notice in Android 16's silent section (v18 field). So: DEFAULT stays
    // for visibility, but setOnlyAlertOnce silences updates, and identical
    // content skips notify entirely (tracked in lastNotifyText).
    private String lastNotifyText = null;

    private void updateNotification() {
        if (wantsStop || ShellSession.get().isRunning() == false) {
            lastNotifyText = null;
            requestStopService();
            return;
        }
        try {
            final String text = notifyText();
            if (text.equals(lastNotifyText == null ? "" : lastNotifyText) && lastNotifyText != null) {
                return;
            }
            lastNotifyText = text;
            final NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIF_ID, buildNotification(text));
        } catch (Exception ignored) {
        }
    }

    // Stateful text (Termux/Alpine pattern): session state in the notice
    // itself, so updates carry information instead of noise.
    private String notifyText() {
        try {
            if (ShellSession.get().isRunning()) {
                return "Terminal session running — tap to open";
            }
            return "Session idle";
        } catch (Exception e) {
            return "Terminal session";
        }
    }

    private void runStopForeground() {
        lastNotifyText = null;
        try {
            stopForeground(true);
        } catch (Exception ignored) {
        }
        try {
            final NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.cancel(NOTIF_ID);
        } catch (Exception ignored) {
        }
    }

    private void requestStopService() {
        EventLog.append(this, "service", "stopSelf (idle)");
        runStopForeground();
        stopSelf();
    }

    private void actionStopService() {
        wantsStop = true;
        EventLog.append(this, "service", "explicit stop");
        try {
            ShellSession.get().stop();
        } catch (Exception ignored) {
        }
        requestStopService();
    }

    // P1.6: low-memory citizenship. Trim caches and scrollback only; the
    // PTY (fd/threads/child) is never killed to save memory — that loses
    // user work and breaks the session promise. Levels: moderate trims
    // view caches (via session ping is unnecessary — grid cache rebuilds
    // lazily); critical+ compacts scrollback to a 500-row floor.
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        try {
            if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
                    || level >= android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE) {
                final int dropped = ShellSession.get().compactTranscript(500);
                EventLog.append(this, "service", "trim level=" + level + " compact dropped=" + dropped);
            } else if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
                EventLog.append(this, "service", "trim level=" + level + " (caches only, session kept)");
            }
        } catch (Exception ignored) {
        }
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            final NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            // v18: DEFAULT (not LOW) + ongoing. LOW collapsed the FGS
            // notification into Android 16's silent section — effectively
            // invisible, so the Stop button was unreachable. Delete + recreate
            // so the importance change applies on upgrade (channels are
            // sticky once created).
            try {
                nm.deleteNotificationChannel(CHANNEL);
            } catch (Exception ignored) {
            }
            final NotificationChannel ch = new NotificationChannel(CHANNEL, "Aetherix-Shell", NotificationManager.IMPORTANCE_DEFAULT);
            try {
                ch.setShowBadge(false);
            } catch (Exception ignored) {
            }
            nm.createNotificationChannel(ch);
        }
    }

    // v18: Diagnose notification state for the field. Callers (launcher
    // report) use this to show blocked vs denied vs posted.
    public static String notifyState(Context ctx) {
        try {
            final NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) {
                return "notify: no manager";
            }
            boolean enabled = true;
            try {
                enabled = nm.areNotificationsEnabled();
            } catch (Exception ignored) {
            }
            String chan = "?";
            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    final NotificationChannel ch = nm.getNotificationChannel(CHANNEL);
                    if (ch == null) {
                        chan = "no-channel";
                    } else {
                        chan = "imp=" + ch.getImportance();
                    }
                } catch (Exception e) {
                    chan = "chan-err";
                }
            } else {
                chan = "pre-O";
            }
            boolean granted = true;
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    granted = ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == android.content.pm.PackageManager.PERMISSION_GRANTED;
                } catch (Exception ignored) {
                }
            }
            return "notify: enabled=" + enabled + " perm=" + granted + " " + chan;
        } catch (Exception e) {
            return "notify: err " + String.valueOf(e.getMessage());
        }
    }

    private Notification buildNotification() {
        String text = "Terminal session running";
        try {
            text = notifyText();
        } catch (Exception ignored) {
        }
        return buildNotification(text);
    }

    private Notification buildNotification(String text) {
        final Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle("Aetherix-Shell");
        b.setContentText(text);
        b.setSmallIcon(android.R.drawable.stat_notify_sync);
        // v29: update in place without re-alerting (DEFAULT channel stays
        // visible per v18, but silent on refresh per v28 field).
        try {
            b.setOnlyAlertOnce(true);
        } catch (Exception ignored) {
        }
        // v18: ongoing so swipe can't dismiss a live session's notification
        // (Stop is the way out). Without this the FGS notice is flickable.
        try {
            b.setOngoing(true);
        } catch (Exception ignored) {
        }
        // Explicit Stop (Termux Exit-button equivalent): kills the session
        // and stops the service, so the user can always kill the linger.
        try {
            final Intent stop = new Intent(this, EnvService.class);
            stop.setAction(ACTION_STOP_SERVICE);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            final PendingIntent pi = PendingIntent.getService(this, 1, stop, flags);
            b.addAction(new Notification.Action.Builder(null, "Stop", pi).build());
        } catch (Exception ignored) {
        }
        // Tap returns to the terminal.
        try {
            final Intent open = new Intent(this, TerminalActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            b.setContentIntent(PendingIntent.getActivity(this, 0, open, flags));
        } catch (Exception ignored) {
        }
        return b.build();
    }
}
