/* Bionic exports __errno, not glibc __errno_location. Bridge the host
 * headers errno macro to Bionic inside our own library. Versioned like
 * every other libc reference (see pty.c note). */
__asm__(".symver __errno,__errno@LIBC");
extern int *__errno(void);
int *__errno_location(void)
{
    return __errno();
}
