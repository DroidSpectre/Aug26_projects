/* pty.c: openpty + fork + exec /bin/bash, winsize clamp, PDEATHSIG.
 * Why: mirrors hermes api/terminal.py (Queue 2000, 8-80x20-240, killpg).
 * No systemd on Android, so parent holds child via foreground service.
 */
#include <jni.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#ifdef __linux__
#include <pty.h>
#include <sys/prctl.h>
#endif

/* Versioned libc bindings: this library is built with -nostdlib (no NDK
 * import libs), so references default to UNVERSIONED symbols. The on-device
 * loader only binds the VERSIONED ones (ioctl was the first refusal), while
 * the NDK-built original references everything as sym@LIBC. Mirror that or
 * dlopen fails. One line per libc function this file calls. */
__asm__(".symver _exit,_exit@LIBC");
__asm__(".symver access,access@LIBC");
__asm__(".symver chdir,chdir@LIBC");
__asm__(".symver close,close@LIBC");
__asm__(".symver closedir,closedir@LIBC");
__asm__(".symver dup2,dup2@LIBC");
__asm__(".symver execl,execl@LIBC");
__asm__(".symver fcntl,fcntl@LIBC");
__asm__(".symver fork,fork@LIBC");
__asm__(".symver getenv,getenv@LIBC");
__asm__(".symver ioctl,ioctl@LIBC");
__asm__(".symver kill,kill@LIBC");
__asm__(".symver openpty,openpty@LIBC");
__asm__(".symver opendir,opendir@LIBC");
__asm__(".symver prctl,prctl@LIBC");
__asm__(".symver read,read@LIBC");
__asm__(".symver readdir,readdir@LIBC");
__asm__(".symver setenv,setenv@LIBC");
__asm__(".symver setsid,setsid@LIBC");
__asm__(".symver strlen,strlen@LIBC");
__asm__(".symver strcmp,strcmp@LIBC");
__asm__(".symver strncmp,strncmp@LIBC");
__asm__(".symver tcgetattr,tcgetattr@LIBC");
__asm__(".symver tcsetattr,tcsetattr@LIBC");
__asm__(".symver waitpid,waitpid@LIBC");
__asm__(".symver write,write@LIBC");

/* Last forked child pid. Sessions are serial (one live shell at a time), so
 * a single slot is exact: openPty stores, Java fetches right after open.
 * Volatile + single writer (openPty) / single reader pattern. */
static volatile pid_t lastChildPid = -1;

static int clamp_int(int v, int lo, int hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

/* W9: close every fd the child inherited from the app except stdio + slave.
 * Java-level writers/sockets carry no CLOEXEC, so without this the shell and
 * its children hold our log files open (locks, offsets, leaks). Original
 * /proc/self/fd scan: collect numeric fds first, closedir, then close them —
 * so the scan dir itself needs no special-casing and no dirfd() symbol.
 * Fail-open (best effort before exec). */
static void close_stray_fds(int slave) {
    DIR* d = opendir("/proc/self/fd");
    if (d == 0) {
        return;
    }
    int victims[256];
    int n = 0;
    struct dirent* e;
    while ((e = readdir(d)) != 0 && n < 256) {
        const char* name = e->d_name;
        if (name[0] < '0' || name[0] > '9') {
            continue;
        }
        int f = 0;
        int i = 0;
        while (name[i] >= '0' && name[i] <= '9') {
            f = f * 10 + (name[i] - '0');
            i++;
        }
        if (name[i] != '\0') {
            continue;
        }
        if (f <= 2 || f == slave) {
            continue;
        }
        victims[n++] = f;
    }
    closedir(d);
    {
        int k;
        for (k = 0; k < n; k++) {
            close(victims[k]);
        }
    }
}

jint Java_com_aetherix_shell_PtyBridge_openPty(JNIEnv* env, jclass cls, jstring jcmd, jstring jcwd, jobjectArray jenv) {
    const char* cmd = (*env)->GetStringUTFChars(env, jcmd, 0);
    const char* cwd = (*env)->GetStringUTFChars(env, jcwd, 0);
    /* P1.5: flags via jenv entries (Java passes null normally):
     * "failsafe" = non-login exec + system rc only; "SD=<path>" = shared
     * storage probed JAVA-side (opendir in the child pre-exec wedged on
     * FUSE remount races after permission changes — v23 field: three
     * silent spawns incl. failsafe. The child must never block on
     * external filesystem state; parent-side probes are containable).
     * v33: "SH=<path>" = user-chosen shell. Validated Java-side
     * (ShellSession.validateShellPref) so no filesystem probe is added to
     * this pre-exec; this side only execs. */
    int failsafe = 0;
    char sdval[256];
    sdval[0] = '\0';
    char shval[256];
    shval[0] = '\0';
    if (jenv != 0) {
        jsize n = (*env)->GetArrayLength(env, jenv);
        jsize ei;
        for (ei = 0; ei < n; ei++) {
            jstring e = (jstring)(*env)->GetObjectArrayElement(env, jenv, ei);
            if (e == 0) {
                continue;
            }
            const char* s = (*env)->GetStringUTFChars(env, e, 0);
            if (s != 0) {
                if (strcmp(s, "failsafe") == 0) {
                    failsafe = 1;
                } else if (s[0] == 'S' && s[2] == '='
                           && (s[1] == 'D' || s[1] == 'H')) {
                    /* SD=<path> and SH=<path> share one copy loop; keeping
                     * them in a single branch saves the duplicate. Both
                     * buffers are the same size and the same 250 cap. */
                    char* out = (s[1] == 'D') ? sdval : shval;
                    size_t si = 0;
                    size_t sj = 3;
                    while (s[sj] != '\0' && si < 250) {
                        out[si++] = s[sj++];
                    }
                    out[si] = '\0';
                }
                (*env)->ReleaseStringUTFChars(env, e, s);
            }
        }
    }
    int master = -1;
    int slave = -1;
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = 24;
    ws.ws_col = 80;
    if (openpty(&master, &slave, 0, 0, &ws) != 0) {
        (*env)->ReleaseStringUTFChars(env, jcmd, cmd);
        (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
        return -1;
    }
    int flags = fcntl(master, F_GETFL, 0);
    fcntl(master, F_SETFL, flags | O_NONBLOCK);
    pid_t pid = fork();
    if (pid < 0) {
        close(master);
        close(slave);
        (*env)->ReleaseStringUTFChars(env, jcmd, cmd);
        (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
        return -1;
    }
    if (pid == 0) {
        setsid();
#ifdef TIOCSCTTY
        ioctl(slave, TIOCSCTTY, 0);
#endif
#ifdef __linux__
        prctl(PR_SET_PDEATHSIG, SIGHUP);
#endif
        /* Enforce known-good cooked mode: the slave may inherit odd flags
         * (missing ECHOE, or VERASE != DEL), which makes the shell ignore
         * backspace even though the byte arrives. Force ECHOE/ECHOK/ERASE=DEL. */
        {
            struct termios t;
            if (tcgetattr(slave, &t) == 0) {
                t.c_iflag |= (BRKINT | ISTRIP | ICRNL | IXON);
                t.c_oflag |= (OPOST | ONLCR);
                t.c_lflag |= (ECHO | ECHOE | ECHOK | ECHOCTL | ECHOKE | ICANON | ISIG | IEXTEN);
                t.c_cc[VERASE] = 127;
                t.c_cc[VKILL] = 21;
                t.c_cc[VINTR] = 3;
                t.c_cc[VQUIT] = 28;
                t.c_cc[VEOF] = 4;
                t.c_cc[VMIN] = 1;
                t.c_cc[VTIME] = 0;
                tcsetattr(slave, TCSANOW, &t);
            }
        }
        dup2(slave, 0);
        dup2(slave, 1);
        dup2(slave, 2);
        if (slave > 2) close(slave);
        close(master);
        /* Drop inherited app fds before exec (W9); master already closed. */
        close_stray_fds(slave);
        if (cwd != 0 && cwd[0] != '\0') {
            chdir(cwd);
        }
        setenv("TERM", "xterm-256color", 1);
        setenv("COLORTERM", "truecolor", 1);
        /* HOME must be the app dir (mksh finds .mkshrc via $HOME; Android has
         * no passwd entry to fall back on). */
        if (cwd != 0 && cwd[0] != '\0') {
            setenv("HOME", cwd, 1);
        }
        /* Trim the cwd for the prompt: keep the tail that fits ~24 columns so
         * the shell prompt stays short. Done here (not Java) so the value is
         * exact at exec time. /data/data/com.aetherix.shell/files (39 chars)
         * becomes com.aetherix.shell/files.
         * Native PS1 is STATIC ("<trim> $ "): dash/toybox expand only \$ and
         * \w in PS1, not ${...}, so an escaped PS1 would print literally.
         * mksh gets the same text eagerly via $ENV/.mkshrc (primary path). */
        {
            char ps1[32];
            const char* base = cwd;
            if (base != 0) {
                size_t len = strlen(base);
                if (len > 24) {
                    const char* cut = base + len - 24;
                    while (*cut != '\0' && *cut != '/') {
                        cut++;
                    }
                    if (*cut == '/') {
                        cut++;
                    }
                    if (*cut != '\0') {
                        base = cut;
                    } else {
                        base = base + len - 24;
                    }
                }
                setenv("AETHERIX_PWD", base, 1);
            } else {
                base = "#:";
                setenv("AETHERIX_PWD", "", 1);
            }
            {
                size_t i = 0;
                while (base[i] != '\0' && i < 24) {
                    ps1[i] = base[i];
                    i++;
                }
                ps1[i++] = ' ';
                ps1[i++] = '$';
                ps1[i++] = ' ';
                ps1[i] = '\0';
            }
            setenv("PS1", ps1, 1);
        }
        setenv("ENV", "$HOME/.mkshrc", 1);
        /* v20: also cover shells that ignore $ENV. dash/toybox-sh (what
         * /system/bin/sh is on most builds) never read $ENV; login shells do
         * read $HOME/.profile, so install the sd/dir/dir functions there too.
         * The real executables live in $HOME/bin (sd cannot be an exe: a
         * child process cannot cd its parent). PATH gets $HOME/bin first so
         * sdl/sdc/dir work on ANY shell even when neither rc file is read. */
        {
            const char* oldp = getenv("PATH");
            char pathbuf[512];
            size_t hi = 0;
            size_t pi = 0;
            const char* homep = cwd;
            if (homep == 0) {
                homep = "";
            }
            while (homep[hi] != '\0' && hi < 200) {
                pathbuf[hi] = homep[hi];
                hi++;
            }
            {
                const char* tail = "/bin";
                size_t ti = 0;
                while (tail[ti] != '\0' && hi < 240) {
                    pathbuf[hi++] = tail[ti++];
                }
            }
            pathbuf[hi++] = ':';
            if (oldp != 0) {
                while (oldp[pi] != '\0' && hi < 500) {
                    pathbuf[hi++] = oldp[pi++];
                }
            }
            pathbuf[hi] = '\0';
            setenv("PATH", pathbuf, 1);
        }
        /* v19/v24: external storage bridge. AETHERIX_SD arrives via jenv
         * (probed Java-side: opendir/access in the child pre-exec wedged
         * the spawn on FUSE remount races — the child now only setenvs).
         * Empty = denied/unmounted; the sd shim errors loudly instead of
         * silently landing in the private dir. */
        setenv("AETHERIX_SD", sdval, 1);
        /* P1.5: probe chain + failsafe exec. Normal: login shells in
         * preference order (mksh honors ENV+.profile; dash honors
         * .profile via -l). Failsafe: non-login /system/bin/sh with the
         * system rc only — user rc cannot poison recovery. Last resort:
         * caller cmd via -c. Chosen binary logged to the master so the
         * launcher report shows it. */
        {
            const char* shells[3];
            shells[0] = "/system/bin/sh";
            shells[1] = "/system/bin/mksh";
            shells[2] = "/vendor/bin/sh";
            int k;
            /* v33: user-chosen shell first. Java already proved the path is
             * an executable file, so this is exec-only (no access() probe,
             * which could stall on a FUSE-backed path). argv[0] is the
             * basename so $0 reads like a normal shell. No -l: an arbitrary
             * userland binary may not accept it. Any exec failure (wrong
             * ELF, ENOEXEC, permission) returns and falls through to the
             * normal probe chain, so a bad pref costs the feature, never the
             * shell. Failsafe never reaches here: Java omits SH for it. */
            if (shval[0] != '\0' && failsafe == 0) {
                const char* base = shval;
                size_t bi = 0;
                while (shval[bi] != '\0') {
                    if (shval[bi] == '/') {
                        base = shval + bi + 1;
                    }
                    bi++;
                }
                execl(shval, base, (char*)0);
            }
            for (k = 0; k < 3; k++) {
                if (access(shells[k], X_OK) != 0) {
                    continue;
                }
                if (failsafe == 0) {
                    execl(shells[k], "sh", "-l", (char*)0);
                } else {
                    setenv("ENV", "/system/etc/mkshrc", 1);
                    execl(shells[k], "sh", (char*)0);
                }
            }
        }
        if (cmd != 0 && cmd[0] != '\0') {
            /* Best effort: run the requested command through the shell only
             * when an explicit command was given (cmd is ours, not -l). */
            execl("/system/bin/sh", "sh", "-c", cmd, (char*)0);
        }
        {
            const char msg[] = "\r\n[spawn failed: no shell]\r\n";
            ssize_t k;
            for (k = 0; msg[k] != '\0'; k++) {
                (void)write(master, &msg[k], 1);
            }
        }
        _exit(127);
    }
    close(slave);
    lastChildPid = pid;
    (*env)->ReleaseStringUTFChars(env, jcmd, cmd);
    (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
    return master;
}

/* Fetch the pid stored by the most recent openPty. */
jint Java_com_aetherix_shell_PtyBridge_lastChildPid(JNIEnv* env, jclass cls) {
    return (jint)lastChildPid;
}

/* Non-blocking reap check: returns 1 + fills status when the child died,
 * 0 while it lives, -1 on error. WNOHANG so Java polls from a thread. */
jint Java_com_aetherix_shell_PtyBridge_pollChild(JNIEnv* env, jclass cls, jint pid, jintArray jstatus) {
    if (pid <= 0 || jstatus == 0) return -1;
    int status = 0;
    pid_t r = waitpid((pid_t)pid, &status, WNOHANG);
    if (r < 0) return -1;
    if (r == 0) return 0;
    jint s = (jint)status;
    (*env)->SetIntArrayRegion(env, jstatus, 0, 1, &s);
    return 1;
}

/* Blocking wait used at session teardown (short timeout driven by Java). */
jint Java_com_aetherix_shell_PtyBridge_waitChild(JNIEnv* env, jclass cls, jint pid, jintArray jstatus) {
    if (pid <= 0 || jstatus == 0) return -1;
    int status = 0;
    pid_t r = waitpid((pid_t)pid, &status, 0);
    if (r < 0) return -1;
    jint s = (jint)status;
    (*env)->SetIntArrayRegion(env, jstatus, 0, 1, &s);
    return 1;
}

/* Send a signal to the child (or its process group when pid is negative).
 * Returns 0 on success, -1 on error. */
jint Java_com_aetherix_shell_PtyBridge_signalChild(JNIEnv* env, jclass cls, jint pid, jint sig) {
    if (pid == 0) return -1;
    if (kill((pid_t)pid, (int)sig) != 0) return -1;
    return 0;
}

/* Foreground process group of the PTY (tcgetpgrp on the master). Returns
 * the pgid, or -1 when the fd is bad or the shell never handed the
 * terminal to a job. Used by the KILL key: a wedged full-screen app can
 * ignore SIGHUP, and SIGKILL to the group it actually owns is the only
 * escape that cannot be refused. */
jint Java_com_aetherix_shell_PtyBridge_foregroundPgrp(JNIEnv* env, jclass cls, jint fd) {
    int pg = -1;
    if (fd < 0) return -1;
    /* tcgetpgrp is not in the link stub; TIOCGPGRP is the same query and
     * ioctl is already a proven symbol here (winsize uses it). Same
     * asm-generic constant the kernel dispatches on. */
    if (ioctl((int)fd, TIOCGPGRP, &pg) != 0) return -1;
    if (pg <= 0) return -1;
    return (jint)pg;
}

jint Java_com_aetherix_shell_PtyBridge_readPty(JNIEnv* env, jclass cls, jint fd, jbyteArray buf, jint len) {
    if (fd < 0 || buf == 0 || len <= 0) return -1;
    /* Critical region: raw pointer, no copy, no GC moves mid-read. Short
     * region (one syscall); never blocks (master is O_NONBLOCK). */
    jbyte* p = (*env)->GetPrimitiveArrayCritical(env, buf, 0);
    if (p == 0) return -1;
    ssize_t r = read((int)fd, p, (size_t)len);
    (*env)->ReleasePrimitiveArrayCritical(env, buf, p, 0);
    if (r < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
        return -1;
    }
    return (jint)r;
}

void Java_com_aetherix_shell_PtyBridge_resizePty(JNIEnv* env, jclass cls, jint fd, jint rows, jint cols) {
    if (fd < 0) return;
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = (unsigned short)clamp_int(rows, 8, 80);
    ws.ws_col = (unsigned short)clamp_int(cols, 20, 240);
    ioctl((int)fd, TIOCSWINSZ, &ws);
}

void Java_com_aetherix_shell_PtyBridge_closePty(JNIEnv* env, jclass cls, jint fd) {
    if (fd >= 0) close((int)fd);
}

jint Java_com_aetherix_shell_PtyBridge_writePty(JNIEnv* env, jclass cls, jint fd, jbyteArray buf, jint len) {
    if (fd < 0 || buf == 0 || len <= 0) return -1;
    /* Critical region for the same reason; JNI_ABORT keeps contents. */
    jbyte* p = (*env)->GetPrimitiveArrayCritical(env, buf, 0);
    if (p == 0) return -1;
    ssize_t w = write((int)fd, p, (size_t)len);
    (*env)->ReleasePrimitiveArrayCritical(env, buf, p, JNI_ABORT);
    if (w < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
        return -1;
    }
    return (jint)w;
}
