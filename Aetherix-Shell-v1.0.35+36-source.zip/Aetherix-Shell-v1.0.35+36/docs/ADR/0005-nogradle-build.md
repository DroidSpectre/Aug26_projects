# ADR-0005: Gradle-free build (CodeAssist model)

Status: accepted. Context: need on-device/in-container APK without Gradle daemon/heap. Decision: `app_config.json` model + `build-apk-nogradle.sh` driving `ecj + aapt2(subprocess) + D8/R8 + apksigner` with fingerprint up-to-date checks, variant target single (debug). Why: CodeAssist proves 1868 tests, 1.9k stars, R-as-bytecode, bucketed dex merge, content-hash lib cache; pure-Java tools run on ART/Linux, only aapt2 forks. Rejected Gradle-first (heavy download, unsigned-code risk, beginner on-ramp), kept Gradle files for Studio/CI compat only.
