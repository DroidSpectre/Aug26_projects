# ADR-0004: Version-code-as-directory + git tag per APK

Status: accepted. Context: requirement never overwrite, track changes, document versions. Decision: `releases/v<code>-<name>+<code>/` + `build-info.json` + docs snapshot + tag. Why: APKs not diffable, directory preserves binary+metadata together; tags alone lose files. Rejected `latest.apk` mutable, amended commits, force-push.
