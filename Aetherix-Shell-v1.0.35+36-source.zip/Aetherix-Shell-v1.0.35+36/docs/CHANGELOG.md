# Changelog

## v13-1.0.12+13 (2026-10-05) - back/select/keybar fixes
* Back after keyboard-minimize goes to launcher (hide call no longer gates
  on imeAlive; dismiss-selection first, then hide, then launcher). IME log
  deduped (repeated identical lines suppressed). Selection survives output
  growth only when line count is stable; green handles drawn at both ends
  of the highlight so drag targets are visible. CTRL key is two-state only
  (green latched, default otherwise; stale black-off removed). APK 49KB.

## v12-1.0.11+12 (2026-10-05) - real selection + clean exit
* Copy works like the industry: long-press selects the word under the
  finger (green highlight), drag extends, release pops Copy/Share/Close for
  the selected text only. Tap clears. Typing keeps focus (single view).
  The full-text dialog is gone. Exit gives a clean slate: transcript wiped,
  fresh banner + prompt, no separators or glued banners (Termux/Alpine
  behavior). APK 49KB.

## v11-1.0.10+11 (2026-10-05) - keybar emoji + END key
* Keybar labels back to emoji (ESC/CTRL/TAB/arrows/SPK) in the v10 order,
  plus END: sends ESC[F, follows bottom. CTRL latch clears on every keybar
  key, soft key, DEL, and Enter (no stuck latch). SPK stays reserved.

## v10-1.0.9+10 (2026-10-05) - flood/blank + keybar order
* Flood fix: huge `ls -R` output split into 3000+ wrapped lines and the draw
  loop walked all of them per frame, so the screen flashed then blanked and
  stayed dead (scroll math overflowed). Now: display capped to 3000 lines,
  draw loop paints visible rows only, wrap inner loop guarded. Keybar order
  is ESC/CTRL/TAB/LT/UP/DN/RT/SPK/END per field spec (SPK reserved for later
  AI chat mode, END jumps to bottom). Permissions unchanged.

## v9-1.0.8+9 (2026-10-04) - wrap + keybar + dialog/back fixes
* Field fixes on v8: ShellView now soft-wraps long lines to the view width
  (commands no longer run off-screen). Keybar restored to the v7 look
  (ESC/TAB/CTRL/UP/DN/LF/RT/SPK, SPK reserved); the extra keybar Copy key
  removed (bar Copy next to Paste stays). Copy dialog tracked and dismissed
  on Back/pause (no more Back/keyboard lockup). Snapshot coalesce tightened
  100ms to 50ms for livelier flood streaming. Permissions unchanged.

## v8-1.0.7+8 (2026-10-03) - single-view shell
* Two views (selectable output + 1px catcher) split focus: every scroll and
  rebind could break the live keyboard binding. Replaced with one original
  ShellView owning display + IME for life (methodology only from Termux,
  no copied code). Copy via dialog/Share, output never focusable, typing
  ends selection by construction. Keyboard is toggle + tap + conditional
  resume only: unconditional restartInput, window-focus rebind, and retry
  timers deleted. Session snapshots coalesced to ~100ms; EventLog writes
  off the UI thread. Permissions kept. APK 45KB.

## v7-1.0.6+7 (2026-10-02) - selection fix, portrait lock
* Long-press consumed the event before the TextView raised handles (vibrate,
  no selection): listener now returns false so framework selection starts.
  Portrait locked on both activities. Selection-exit refocuses the catcher
  before rebinding (field log showed a stood-down pass). Telemetry verdict:
  exactly one justified repair, no doubles, no crashes. APK 41KB.

## v6-1.0.5+6 (2026-10-02) - keyboard release
* Single-focus architecture: output selectable only inside long-press
  selection mode (Back exits, focus returns to the catcher); scroll updates
  never steal selection. Rebind state-gated on `isAcceptingText` instead of
  the 1.5 s cooldown. Attach telemetry (`ime` tag: focus/win/acc) on every
  transition. TAP_RX wiretap gated off; plausible cursor context. APK 41KB.

## v5-1.0.4+5 (2026-10-02) - versioned native bindings
* Clean-line v1 plus the real fix, in one release (codes 2-4 retired with the
  discarded diagnostic line). Device loader binds only `sym@LIBC`; our
  `-nostdlib` build emitted unversioned refs and died on `ioctl` at load.
  Fixed with a link-time `libc.so` stub (`tools/nativelib/`, never shipped)
  + deterministic `scripts/rebuild-native.sh` (byte-identical output).
  APK 41KB verify OK in Download. See releases/v5-1.0.4+5/build-info.json.

## v1-1.0.0+1 (2026-10-02) - clean repackage from Debian v30
* Standalone shell under `com.aetherix.shell`, derived from Debian
  v30-1.29.0+30 (10/10 field pass, Samsung + Android 16) in one pass.
  Proot/rootfs scaffolding stripped. Native lib rebuilt for this package
  (symbol gate in the build refuses any Java/native skew; mismatch
  degrades to a log line, never a crash loop). APK 41KB verify OK in
  Download. See releases/v1-1.0.0+1/build-info.json.

## v1.0.13+14 (2026-10-11)
clean-room fixes (winsize, reap, UTF-8, writer, VT grid) + hardening (guards, IME, perms, logging) + W1-W9 + stable pipeline

## v1.0.14+15 (2026-10-11)
stop-when-idle service (Termux-aligned: exit+swipe stops, START_NOT_STICKY, notification Stop + launcher Stop button, session line) + platform ActionMode copy/share (modal dialog gone) + selection accuracy (draw-space hit test, anchor/free-end, grabbable handles)

## v1.0.15+16 (2026-10-12)
kill silent-revive (keypress/onResume/launcher never start sessions; dead shows New session button, Termux-style) + stale-flag reconcile in start() (service start with no pty open fixed)

## v1.0.16+17 (2026-10-12)
floating ActionMode at selection (no more doubled top bar; toolbar hides while selecting) + fat green circle handles (finger-grabbable)

## v1.0.17+18 (2026-10-12)
visible notification (DEFAULT channel recreated on upgrade, ongoing, runtime POST_NOTIFICATIONS prompt once + notify state in launcher report)

## v1.0.18+19 (2026-10-12)
full-external storage (MANAGE_EXTERNAL_STORAGE + Settings flow, sd/sdl/sdc shims via AETHERIX_SD native probe, storage line in report)

## v1.0.19+20 (2026-10-12)
titlebar Copy/Paste buttons gone (selection-copy proven, keyboard clipboard for paste) + tap-to-show keyboard (focus+SHOW_FORCED+retry, title show-only) + real sd fix (sd/sdl/sdc/dir in .profile + ~/bin on PATH, works on dash/toybox) + one Request-permissions button (notify->files->battery chain, no launch bombardment, battery line in report) + New session on launcher (exit returns there, terminal never revives)

## v1.0.20+21 (2026-10-12)
single session button (idle=New session, running=Open terminal; v20 two-button split confused) + permissions as tappable rows (what+why+state per row, grant-just-that-one, Deny stays re-tappable, no chain/nag)

## v1.0.21+22 (2026-10-12)
Phase 1 hardening: blocking PTY reader (adoptFd, burst drain, zero idle wakeups) + UTF-8 fuzz (141 unit tests) + EventLog audit (v8 worker confirmed, crash path intentionally sync) + row scrollback ring (2000/pref, no byte cap) + shell probe chain + failsafe start (long-press) + trim-memory citizenship (PTY never killed) + IME matrix status

## v1.0.22+23 (2026-10-13)
blank-screen fix (onNewIntent starts fresh on singleTask re-entry; was attaching cleared transcript) + reader-death logging (processing throws logged per generation, loop survives) + silent-shell watchdog (5s marker + log) + shell probe logging + honest destroy log

## v1.0.23+24 (2026-10-13)
Back-stack fix (Back uses goLauncher+finish; dead Terminal no longer lingers under Main) + terminal starts EnvService (live sessions get the ongoing notification with Stop) + silence interrogation (child wchan/state/cmdline + master probe that feeds stuck bytes) + reader-death logging

## v1.0.24+25 (2026-10-13)
spawn-hang fix (shared-storage probe moved Java-side via jenv SD=; child pre-exec does zero filesystem calls, FUSE opendir wedge eliminated) + audit trail (line-by-line pty.c/ShellSession review)

## v1.0.25+26 (2026-10-13)
PROMPT FIX (v22 regression, root-caused): burst drain called raw readPty on the blocking master and parked forever holding the first chunk; drain now gated by available(). Banner/watchdog paths never used the reader, which is why they displayed.

## v1.0.26+27 (2026-10-14)
launcher redesign (Alpine-dashboard feel, native): dark cards, session badge, settings page with permission rows + granted badge, log card; grant flows unchanged (moved to Perms); terminal untouched

## v1.0.27+28 (2026-10-14)
notification re-assert on terminal resume (REASSERT action: re-posts without reviving; swiped notice returns) + log card capped scroll (no screen-hog) + dir names-only (ls -1, detail stays in ls)

## v1.0.28+29 (2026-10-15)
silent notification refresh (Termux/Alpine pattern, adapted: DEFAULT channel kept per v18 visibility evidence, setOnlyAlertOnce + skip-identical so resume/posting never re-alerts; stateful tap-to-open text) + log card buttons pinned above the scroll (growth can no longer displace them)

## v1.0.29+30 (2026-10-16)
dynamic prompt (last path component, recomputed via POSIX 'command cd' wrapper - dash-safe), selection survives output + trim-delta anchoring (Termux norm), scroll-when-dragging-outside-selection, Select all action, helper disclosure with $SD escape hatch

## v1.0.30+31 (2026-10-16)
selection model: handle-only resize, all other drags scroll; scroll drops floating Copy/Select bar and keeps anchors (v30 field: Select All blocked scrolling and terminal felt stuck in menu)

## v1.0.31+32 (2026-10-16)
audit: remove verified-dead code (DirtyListener subsystem, SelectionListener, linesGrew twin, currentGrid, 5 unused imports); FIX $SD export (was only in mkshrc, but PTY runs /system/bin/sh which reads .profile - $SD was empty in the real shell while the banner advertised it); dedupe mkshrc/profile function copies; remove long-prompt branch

## v1.0.32+33 (2026-10-17)
shell path preference (Phase 2 #5): exec a user-chosen shell instead of always /system/bin/sh - the network-free stepping stone to a real userland. Validated parent-side (absolute, executable regular file, traversal collapsed, control chars rejected); failsafe ignores it by construction; bad pref falls through to the probe chain. Settings UI + launcher 'shell:' report line. No INTERNET permission.

## v1.0.33+34 (2026-10-19)
paste + application cursor mode (DECCKM): PASTE key (replaces the dead reserved button) with CRLF/NUL normalization, 16KB flood-safe cap, bracketed-paste wrapping when the app sets ?2004, and CTRL-latch clearing; VtGrid now tracks ?1h so the keybar sends ESC O A..D inside vi instead of going dead. No C changes (.so byte-identical), no new permissions.

## v1.0.34+35 (2026-10-19)
restore the reserved sparkle key slot (held for a downstream app feature) and add PASTE as its own key. Keybar layout moves to a testable Android-free table dispatched by kind, not hardcoded indices - the root cause of the slot being clobbered. tools: tests/KeybarTest.java pins slot 7 as RESERVED.

## v1.0.35+36 (2026-10-19)
KILL escape hatch for wedged full-screen apps: a KILL key SIGKILLs the terminal's foreground process group (ioctl TIOCGPGRP), clears the alt screen/DECCKM/bracketed-paste state the dead app never restored, and leaves the shell alive with a fresh prompt; stop() escalates SIGHUP to SIGKILL after 1s so no orphan holds the PTY. Build symbol gate now derives the expected JNI set from PtyBridge.java. No new permissions.
