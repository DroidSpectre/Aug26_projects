# Aetherix-Shell-no_proot Plan

Lineage baseline: Aetherix-Debian v30-1.29.0+30 (field-proven terminal +
keyboard). This project starts at v1-1.0.0+1 with identical behavior under
the new package, minus proot/rootfs scaffolding, with the native lib rebuilt
for this package and gated by the build.

## Direction (2026-10-19) - read this before re-ordering anything

Product: Aetherix-Shell is the base platform. It is meant to be everything
a shell is, plus full device access as a core feature, with no other apps
required (Termux needs Termux:API for that; we do not). Aetherix-<Linux> is
a separate, second app; userland distro work belongs there, not here.

Distribution: personal use + GitHub releases. No app store, so no store
policy gates: SMS/Call Log, accessibility, MANAGE_EXTERNAL_STORAGE and
QUERY_ALL_PACKAGES are all usable. "Offline" means self-contained (assets
in the APK, nothing downloaded at install or launch), not network-free;
INTERNET is allowed when a feature needs it.

Device access ladder (highest rung reachable without root is the goal):
1. App-held dangerous perms + a UDS bridge to helper shims in ~/bin.
2. Special access: accessibility (UI automation), notification listener,
   usage stats, write-settings, VPN.
3. Elevated shell: ADB pairing implemented in-app (user enables wireless
   debugging). Unlocks pm/am/settings/dumpsys/input as shell UID.
4. Root, only if a device already has it. Never required.
Hard limits any honest description must keep: no reading other apps'
private data, no silent APK installs, no mobile-data toggling, no raw
partitions without rung 3/4.

Working order (revised 2026-10-19, replacing the Phase 2 sequence below
where they disagree):
v34 paste + DECCKM (done) -> v35 reserved sparkle slot restored + PASTE key
+ testable Keybar table (done) -> v36 KILL escape hatch + SIGKILL escalation
on stop (done) -> v37 font size + color scheme ->
v38 bridge tier 1 (zero-danger shims) -> v39 dangerous-perm shims ->
v40 notification listener + accessibility -> v41 in-app ADB pairing ->
interleaved: multi-session, Home/Delete keys, VTE tier 1, search.

Reserved - DO NOT IMPLEMENT until explicitly directed: the sparkle key
(Keybar slot 7) will launch an in-app background llama.cpp instance for
in-terminal AI assistance and agent functions, using a sub-1B model such
as Qwen3.5-0.8B-GGUF or a similar distilled small model. It must keep
KIND_RESERVED with a null code until then; tests/KeybarTest.java enforces
that, because the slot was clobbered once.
When it is eventually scheduled, two known constraints: llama.cpp is
C/C++ needing libc and threads, so it cannot reuse the PTY lib's
-nostdlib recipe; and a several-hundred-MB GGUF fits the "components
installed later, offline" policy, not the bundle-everything-in-the-APK
rule.

## Phase 0 - Clean repackage (done, v1)

Why: a stable shell deserves its own version line; the Debian edition keeps
its numbering for the distribution track. How: derive from the v30 tag in
one pass (rename, strip, rebuilt `.so`, symbol gate, native-mismatch
hardening), fresh repo, build + archive + tag.
Verify: clean compile, style checks, gate firing, full APK pipeline, then
the same 10-test field battery as Debian v29/v30.

## Phase 1 - Shell hardening (v14-v21 done, plus pipeline work below)

Shipped across v14-v21: clean-room fixes (winsize, reap, UTF-8, writer, VT
grid) + hardening (guards, IME, perms, logging) + stop-when-idle service +
platform selection + kill silent-revive + floating ActionMode + visible
notification + full-external storage + titlebar cleanup + tap-to-show +
real sd fix + single session button + tappable permission rows.
Remaining Phase 1 (no new user features until green):

1. Throughput pipeline (gap 7, P0): blocking-read thread (drop 50ms poll),
   coalesced invalidate + dirty-row draw, UTF-8 carry-over edge cases
   (overlongs/surrogates/split emoji fuzz). Verdict: idle drain flat,
   floods ~15fps, zero FFFD on valid splits.
2. Logging off UI thread (gap 7, P1 + BUG-AUDIT B4): HandlerThread writer,
   batched flush, bounded drop-oldest. Verdict: no per-keystroke ANR risk.
3. Row-based scrollback (gap 7, P1): 2000-row ring default, pref key
   100-10000, replaces 100KB byte cap. Verdict: predictable history.
4. Shell fallback + failsafe (gap 5): probe chain (/system/bin/sh, mksh,
   vendor, toybox), non-login last resort, failsafe entry skips user rc.
   Verdict: no black-screen on odd OEMs.
5. Low-memory behavior (gap 7, P3 + Phase 1 item): onTrimMemory drops
   caches/dead records, emergency scrollback compact, never kills PTY.
6. IME edge keyboards (4+ apps matrix): Gboard/Samsung/SwiftKey/Hacker's
   Key on commit/key paths, DEL funnel, enter mapping.

## Phase 2 - Careful additions (one immutable release each, field notes)

In order (user-impact ranked, rootless, clean-room throughout):

1. Multi-session (gap 1): SessionManager in EnvService, per-session
   (id, gen) fencing (fdGen goes per-record), single re-bound view first
   (attach/detach seam for view-per-tab later), cap 8, drawer list,
   per-record death isolation. This erases the #1 daily friction.
2. VTE tier 1 (gap 2): app cursor/keypad encoder table, primary-screen
   reflow (alt-screen no-reflow), wide-char guard + wcwidth + combining
   attach, bell + cursor style + stored title. Unlocks vim/less/mc/tmux.
3. Paste + stable selection (gap 4a/4d/4f): central doPaste helper
   (long-press-no-selection + keybar PASTE + Ctrl+Shift+V funnel, keep
   bracketed-paste wrap), row-ID selection anchoring, Share overflow
   past 8000 chars.
4. Power keyboard (gap 3): autofill-off + TalkBack labels first, then ALT
   latch + prefs-backed keybar (same default), then F/Pg/Home/End names +
   one popup per key, HW shortcuts, volume-as-Ctrl opt-in, blink last.
5. Shell prefs + startup (gap 5): shell path + initial-command prefs,
   app-private startup file (sourced from .mkshrc tail, skipped in
   failsafe), Term Here receive, launcher shortcuts. RUN_COMMAND: SKIP
   (documented — arbitrary exec as app UID, risk over value).
6. Font size + color scheme (original Phase 2 items): pinch/pref font
   scale, scheme toggle. Small, independent, ship anytime after (2).
7. VTE tier 2 (gap 2): SGR-1006 mouse (1000 only, throttled 1002, select
   override UI), truecolor side arrays, OSC 52 write-only capped +
   confirm, OSC 8 underline-tap. Tier 3 (hover, palette queries,
   SIXEL/Kitty) deferred/skip.
8. Search + locks (gap 7, P2): literal case-insensitive search overlay,
   Wake/WiFi lock toggles (default off).
9. Device readout bridge (gap 6, tier 1 only): in-process UDS bridge +
   dev-battery/display/build/clip/toast/vibrate/tts shims in ~/bin.
   Zero new dangerous perms. SSH/Mosh/ADB-loopback/packages: no longer
   excluded by policy (INTERNET permitted); not scheduled - revisit
   after the offline core is solid.
10. Distribution (gap 8): release signing + self-update with hash +
    signer pin (first), F-Droid recipe + metadata (second), x86_64
    universal (third). Play scoped flavor optional-last; minSdk stays 26;
    armeabi-v7a deferred.

## Explicitly out or deferred (policy clarified 2026-10-19)

Package management, language runtimes, networking tools: deferred, not
forbidden. The earlier no-network ruling is retired; these are backlog
items, gated on the offline core being solid.
SSH/Mosh client, ADB-privilege mode, Shizuku bundling, RUN_COMMAND API,
SIXEL/Kitty graphics, hover mouse (1003 default-off) — each SKIP is
documented with rationale in its phase item, not just listed here.

## Ground rules (unchanged)

Clean-room everything: methodologies may be studied, no outside code
copied. Java 6 style, no lambdas, no diamonds. JNI C for PTY only. No
root. Offline-first means self-contained, not network-free (clarified
2026-10-19): all core assets ship inside the APK with no download at
install or launch, and the app must work fully with networking off.
Components may be installed later, offline and incrementally. INTERNET
permission is allowed for optional client-only features. One immutable
release per addition with field notes. Never amend a pushed release,
never force-push.
