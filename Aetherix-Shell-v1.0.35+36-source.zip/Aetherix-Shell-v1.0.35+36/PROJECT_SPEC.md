# Aetherix-Shell-no_proot Project Spec

## 1. Identity

* Project: Aetherix-Shell-no_proot
* Package: `com.aetherix.shell` (co-installs alongside `com.aetherix.debian`)
* App label: Aetherix-Shell
* minSdk 26, targetSdk 35, arm64-v8a
* Language: Java only, no lambdas, no diamonds. JNI C for PTY only.

## 2. Goals (v1)

* Stable local terminal: foreground-service-owned PTY session, native view,
  dual-path keyboard input (TYPE_NULL key events + commit fallback, Samsung
  password-mode branch), keybar (ESC/TAB/CTRL/arrows), paste, clipboard-safe.
* Display fidelity for a phone screen: BS/CR/TAB/CSI/OSC processing,
  CR-run folding, 100KB transcript cap, dead-shell auto-revive.
* Offline, no permissions beyond foreground service + notifications.
* Self-contained single APK, Gradle-free reproducible build.
* Native lib correctness by construction: the packed `.so` is rebuilt from
  the in-tree `jni/pty.c` for this package, and the build refuses a
  Java/native symbol skew; a native mismatch degrades to a log line, never
  a crash loop.

## 3. Non-goals (v1)

* No proot/proroot/ld.so userland, no bundled rootfs, no python/node/apt.
* No agents, no network servers, no root requirement.
* The full-Linux track stays in Aetherix-Debian; this project does not
  re-add distribution features.

## 4. Architecture

```
APK (TerminalActivity + PtyEditText + keybar)
 -> ShellSession (process-owned, transcript + display processor, reader thread)
 -> PtyBridge (JNI) -> pty.c + errno_shim.c (openpty, cooked mode ERASE=DEL,
    PDEATHSIG, Bionic __errno bridge) -> fork+exec /system/bin/sh -l
 -> EnvService (foreground keep-alive, START_STICKY)
 -> MainActivity (launcher: version + native + events/crash report, copy/share)
```

## 5. Versioning / git / docs (normative)

* `next-version.properties`: `versionCode`, `versionName`. Each APK gets a new
  `releases/v<code>-<name>+<code>/` with APK + `build-info.json` +
  `CHANGELOG.snippet.md` + `source-<tag>.zip` (rebuildable, see
  `scripts/archive-source.sh`) + docs snapshot. Fail if dir exists.
  Never amend a pushed release, never force-push.
* Docs required per release: `docs/CHANGELOG.md`, `docs/VERSIONS.md`.
