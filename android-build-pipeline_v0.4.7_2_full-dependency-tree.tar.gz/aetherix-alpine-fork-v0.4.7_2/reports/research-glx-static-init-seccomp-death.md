# The glibc Static Init SIGSYS Trap on Samsung Knox

**Project:** Aetherix-Alpine (formerly DevEnv-PRoot)  
**Documented at:** v0.2.5 (July 23, 2026)  
**Device:** Samsung SM-S166V (Android 16, API 36, kernel 5.15.189, Knox 3.x, ARM64 aarch64)

---

## 1. Abstract

When attempting to execute a statically-linked glibc binary from an Android `untrusted_app` context on Samsung Knox devices, the process is killed by SIGSYS (seccomp violation) **before any application code executes**. The binary produces zero output on stdout or stderr, and the exit code indicates a signal termination (159 = 128 + 31). This document describes the mechanism, the symptoms, the root cause, and a working workaround.

---

## 2. The Phenomenon

A naive `fork()`-based PTY bridge, compiled as a static glibc binary (708 KB):

```c
#include <unistd.h>
int main() {
    write(2, "hello\n", 6);  // never reached
    pid_t pid = fork();        // never reached
    ...
}
```

When executed via `ProcessBuilder` on Android (targeted as `libpty-bridge.so` in the app's `nativeLibraryDir`):

- **stdout**: empty
- **stderr**: empty
- **Exit code**: 159 (128 + 31, where 31 = SIGSYS)

No amount of diagnostic stderr output placed at the top of `main()` produces any visible output. The process vanishes silently.

Even with `redirectErrorStream(true)` in Java, which merges stderr into stdout for capture, the Java `BufferedReader` returns nothing.

---

## 3. Root Cause: glibc __libc_start_main

The issue is not in the application code. It is in **glibc's internal startup sequence**, which runs before `main()` is called.

### 3.1 The Startup Chain

When the kernel loads a statically-linked glibc ELF binary:

```
kernel execve
  -> ELF entry point = _start (glibc's start.S)
    -> __libc_start_main
      -> __cxa_atexit registration
      -> personality(syscall 135)     *** BLOCKED ***
      -> prctl(syscall 167)           *** BLOCKED ***
      -> TLS/threading init (futex)   *** BLOCKED ***
      -> main()                       *** NEVER REACHED ***
```

### 3.2 The Blocked Syscalls

Samsung Knox applies a custom seccomp-BPF filter to all `untrusted_app` processes. Based on observed behavior:

1. **`personality` (syscall 135, aarch64)**: Glibc calls `personality(READ_IMPLIES_EXEC)` to handle legacy binary compatibility. Samsung Knox blocks this for untrusted domains, possibly because changing personality could alter memory permission semantics.

2. **`prctl` (syscall 167, aarch64)**: Glibc uses `prctl` for:
   - Architecture-specific CPU feature detection (e.g., `PR_GET_FP_MODE` on ARM64)
   - Thread naming and TLS setup
   Knox blocks non-thread `prctl` calls from `untrusted_app`.

3. **Futex/threading init**: Glibc's startup initializes threading primitives (mutexes, TLS allocator). On aarch64, this involves `futex` syscalls or `mprotect` with specific patterns that Knox intercepts.

### 3.3 Why Bionic Works

Android's native libc (bionic) does NOT have the same startup sequence:

- **No `personality` call**: Bionic does not call `personality()` during startup.
- **Minimal `prctl` usage**: Bionic defers `prctl` to when threads are actually created.
- **No static TLS allocation**: Bionic's TLS is per-thread, lazily allocated.

This is why Termux and other Android-native binaries work fine \u2014 they link against bionic, which is designed to run within Android's seccomp constraints.

---

## 4. Diagnostic Method

To confirm the glibc static init death:

1. Compile a minimal static binary with glibc:
   ```c
   // test.c
   #include <unistd.h>
   int main() {
       write(1, "REACHED_MAIN\n", 13);
       return 0;
   }
   ```
   Compile with: `aarch64-linux-gnu-gcc -static -Os -o test test.c`

2. Execute via `ProcessBuilder` on the Samsung device:
   - If output contains `REACHED_MAIN`: glibc init is not blocked (unlikely on Knox)
   - If output is empty with exit code 159: glibc init is killed by seccomp

3. As a control, compile the same code as a freestanding binary:
   ```c
   // test_freestanding.c
   static void sys_exit(int c) {
       asm volatile("mov x8, #93; svc #0" : : "r"(c));
   }
   void _start(void) {
       asm volatile("mov x0, #1; ldr x1, =msg; mov x2, #13; mov x8, #64; svc #0");
       sys_exit(0);
   }
   ```
   Compile with: `aarch64-linux-gnu-gcc -nostdlib -static -Os -o test-freestanding test_freestanding.c`

---

## 5. The Workaround: Freestanding Binary

### 5.1 Approach

Eliminate libc entirely. The application is compiled with `-nostdlib` and provides its own entry point and syscall wrappers.

For aarch64:

```asm
.section .text
.globl _start
_start:
    ldr w0, [sp]        // argc from stack
    add x1, sp, #8      // argv from stack
    bl main
    mov x8, #93         // __NR_exit
    svc #0
```

Syscall inline wrapper:

```c
static long syscall6(long n, long a1, long a2, long a3, long a4, long a5, long a6) {
    register long x8 asm("x8") = n;
    register long x0 asm("x0") = a1;
    register long x1 asm("x1") = a2;
    register long x2 asm("x2") = a3;
    register long x3 asm("x3") = a4;
    register long x4 asm("x4") = a5;
    register long x5 asm("x5") = a6;
    asm volatile("svc #0" : "=r"(x0) : "r"(x0), "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5), "r"(x8) : "memory");
    return x0;
}
```

### 5.2 What You Lose

- **No `printf`/`fprintf`**: You must use raw `write(2)` with manual formatting.
- **No `malloc`/`free`**: All buffers must be stack-allocated or use `mmap()`.
- **No libc types**: Redefine `size_t`, `ssize_t`, `pid_t`, `struct pollfd`, `struct winsize`, etc.
- **No TLS**: Multi-threaded code requires manual thread-local storage setup.
- **No math library**, no `errno` (must implement your own); no `strerror`, `exit`, `atexit`.

### 5.3 Syscall Table (aarch64)

| Number | Name | Purpose |
|--------|------|---------|
| 24 | dup3 | Duplicate file descriptor |
| 29 | ioctl | Device control (PTY, terminal) |
| 56 | openat | Open file relative to directory fd |
| 57 | close | Close file descriptor |
| 63 | read | Read from file descriptor |
| 64 | write | Write to file descriptor |
| 73 | ppoll | Monitor multiple file descriptors |
| 93 | exit | Terminate current thread |
| 94 | exit_group | Terminate all threads |
| 172 | getpid | Get process ID |
| 220 | clone | Create child process |
| 221 | execve | Execute program |
| 260 | wait4 | Wait for process termination |

### 5.4 Limitations

- The freestanding binary approach works only if Samsung Knox allows the specific syscalls the application needs. If `clone` (syscall 220) itself is blocked for `untrusted_app`, the binary will still be killed \u2014 but now with output up to the failing syscall, making the problem diagnosable.
- If `clone` is blocked, the architecture must shift to a non-forking design: two `ProcessBuilder` instances connected by Java `PipedInputStream`/`PipedOutputStream`.

---

## 6. Relevance to Other Projects

Any project attempting to run native Linux binaries on Samsung Knox devices should be aware of this trap:

- **PRoot itself**: PRoot linked against glibc and executed from `nativeLibraryDir` works because PRoot's startup does not trigger the blocked syscalls (or PRoot links against glibc in a way that avoids `personality`). This was verified working at v0.0.23 of DevEnv-PRoot.
- **Termux proot (bionic fork)**: Works because bionic's init does not trigger Knox seccomp. The bionic fork is the safe path.
- **Static go binaries**: Go's runtime does not use glibc and uses its own `mmap`-based memory management. Go binaries compiled with `CGO_ENABLED=0` should bypass this trap.
- **Rust binaries**: Rust's `std` links against glibc by default on Linux targets. Rust binaries compiled with `#![no_std]` and raw syscalls would bypass it. Rust binaries with `std` using a musl target (`x86_64-unknown-linux-musl`, `aarch64-unknown-linux-musl`) would not have this issue.
- **Musl-linked binaries**: Musl's startup is significantly simpler than glibc's. It does not call `personality` and minimizes `prctl` usage. Musl-linked static binaries may work on Knox where glibc-linked ones do not.

---

## 7. Diagnosis Checklist

When a binary produces zero output and exits with signal 159 on Samsung Knox:

| Symptom | Likely Cause |
|---------|-------------|
| Zero stdout, zero stderr, exit 159 | glibc static init killed by seccomp |
| Partial stderr output, then exit 159 | A specific syscall blocked after init (check which) |
| stdout works, stderr works, exit 0 | No seccomp issue |
| stdout works, stderr works, exit 159 | clone or fork blocked |

To diagnose further: compile with `-nostdlib` and add `write(2, "point N\n", ...)` at each stage of the application to isolate the first failing syscall.

---

## 8. References

- Linux aarch64 syscall table: https://github.com/torvalds/linux/blob/master/arch/arm64/include/asm/unistd.h
- Glibc start.S for aarch64: sysdeps/aarch64/start.S
- Samsung Knox security whitepaper (DEFEX, RKP, seccomp): samsung_knox_defex
- PRoot documentation: proot_me
- GCC freestanding compilation: `gcc -nostdlib -static` documentation
