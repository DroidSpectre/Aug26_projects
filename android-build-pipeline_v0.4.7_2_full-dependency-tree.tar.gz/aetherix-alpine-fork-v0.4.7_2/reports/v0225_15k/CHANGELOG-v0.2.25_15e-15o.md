# Aetherix-Alpine — Changelog v0.2.25_15e → v0.2.25_15o

Build date: 2026-08-01 · Device: Samsung SM-S166V (Android 16 / API 36, kernel 5.15.189-android13-3-33503169, aarch64)
Latest artifact: `Aetherix-Alpine-v0.2.25_15o.apk` (versionCode 14, v2/v3 signed)

---

## 1. Version map

| Build  | APK versionName | versionCode | Java changes | Native changes | Outcome |
|--------|-----------------|-------------|--------------|----------------|---------|
| 15e    | v0.2.25_15g (stale) | 8 | — (packaging) | rebuilds | Distributed test build |
| 15f    | v0.2.25_15g (stale) | 8 | — (packaging) | rebuilds | Distributed test build |
| 15g    | v0.2.25_15g | 8 | jitter guard present | — | Last build with the ±1 row/col guard in `updateSize()` |
| 15h    | v0.2.25_15g (stale) | 8 | real font metrics wired; jitter guard **removed** | — | The build the user tested for 3h47m; stable but corrupting full-screen apps |
| 15i    | v0.2.25_15g (stale) | 8 | first IME-pan prototype; bash `PROMPT_COMMAND`/`term_size` wiring | `libpty-bridge.so` rebuilt (100 ms poll + 300 ms debounce) | Internal debug build; superseded by 15j |
| 15j    | v0.2.25_15j | 9 | guards/clamps/debounce; corrected insets API; onResume refocus+IME show | — | Corruption eliminated; white-out + invisible prompt introduced |
| **15k** | **v0.2.25_15k** | **10** | **pan removed; grid=viewport; unified sizing; hysteresis; write dedupe; IME gating** | — | **This build** |
| **15l** | **v0.2.25_15l** | **11** | **term_size path fixed into live rootfs; ECHO restored (readline echo); SIGWINCH to foreground job pgroup** | `libpty-bridge.so` rebuilt | **This build** |
| **15m** | **v0.2.25_15m** | **12** | **session-wide SIGWINCH fallback; IME-show focus re-assertion; default font 18→26px** | `libpty-bridge.so` rebuilt (7.6 KB) | **This build** |
| **15n** | **v0.2.25_15n** | **13** | **WINCH debug trap removed from .bashrc; zoom capped 2.0×; faster resize settle (150/200 ms)** | `libpty-bridge.so` rebuilt | **This build** |
| **15o** | **v0.2.25_15o** | **14** | **discrete font sizes 10/12/14/16/18 sp; pinch zoom steps one size at a time; 18sp cap** | — (bridge unchanged) | **This build** |

Note: the "v0.2.25_18" line was abandoned during development and never shipped; 15j superseded 15i, and 15k supersedes 15j.

---

## 2. What changed, per build

### 15e – 15f
Packaging / native-library rebuilds only; no Java source changes between consecutive snapshots. Used to distribute the PTY bridge and PRoot stack for field testing.

### 15g
- Carried a small anti-jitter guard in `TerminalView.updateSize()` (`deltaCols + deltaRows < 2` → early return).

### 15h (the "3h47m" build)
- Wired **real font metrics** from `TerminalView` into `TerminalSession`/`TerminalEmulator` (cell width/height no longer hard-coded to 10×20 px). `TerminalSession` constructor now takes `cellWidth`/`cellHeight`.
- **Removed** the 15g jitter guard (this, combined with no debounce and no clamping, allowed resize storms — the direct cause of the nano/vim corruption seen in 15h).
- User-reported findings during 15h testing:
  - nano/vim full-screen corruption after resize; first digit of typed input sometimes dropped; prompt text invisible when typed; stale cleared screen after app switch.
  - Long-session resize pattern `77×64 ↔ 32` rows (no debounce → two geometry sources raced).
  - `btop` fails with `Failed to parse /proc/stat` — SELinux/`untrusted_app` restriction, environmental (see §4).
  - llama.cpp build notes: `apk add` word-splitting typo, `ssh` package name correction, certificate workaround via `git -c http.sslVerify=false`.

### 15i (user asked for notes — see §3)
- First prototype of the **IME-pan** approach in `TerminalView` (keep grid constant, translate the view up when the keyboard opens) using a deprecated insets read.
- Added `.bashrc` wiring: `unset COLUMNS LINES`, `shopt -s checkwinsize`, `PROMPT_COMMAND` re-reading `/tmp/term_size`, and a `WINCH` debug trap in `StepRunner`.
- Rebuilt `libpty-bridge.so` with the 100 ms file-poll + 300 ms stability debounce and the `TIOCSIG`→`kill(-child, SIGWINCH)` fallback.
- **Not versioned correctly** (still reports `v0.2.25_15g` / code 8), never shipped as a user build; superseded by 15j.

### 15j
- `TerminalView.updateSize()`: guards against transient states (`isShown()`, `fontWidth < 4`, `fontLineSpacing < 12`), hard clamps (500 cols × 300 rows), 300 ms debounce before applying a resize.
- Corrected the IME insets read to the modern `WindowInsets.Type.ime()` API; kept the pan (translation + constant grid).
- `TerminalActivity.onResume()`: force redraw, refocus, and re-show the IME (fixes the stale-frame / first-digit-drop class of bugs).
- Version bump to code 9 / `v0.2.25_15j`; build script no longer swallows errors with `|| true`.
- Result: **corruption eliminated** (no more nano/vim breakage), but three new symptoms:
  1. terminal **whites out when the keyboard is displayed** (the pan translated the view up, revealing the layout background below it),
  2. **prompt text not visible when typed** (bottom rows shifted below the keyboard by the pan),
  3. **nano does not fit the window** (grid kept at full-window size while the visible viewport shrank).
  Root cause: the pan double-compensated for `adjustResize`, and two independent size computations (session constructor vs `attachSession→updateSize`) disagreed, rewriting `term_size` back and forth (79 ↔ 85 rows in the 15j report) and issuing repeated SIGWINCH signals.

### 15k (this build — the fix)
1. **Removed the manual pan.** The activity already uses `windowSoftInputMode="adjustResize"`, so the window (and view) shrink around the keyboard; the grid now tracks the actual visible viewport. No translation → no white strip, prompt always above the keyboard, nano fits.
2. **One authoritative grid size.** `TerminalActivity.startShell()` now uses the exact same formula + clamps as `TerminalView.updateSize()`, so the session constructor and the view can no longer disagree (79 vs 85).
3. **Hysteresis.** `updateSize()` ignores ±1 row/col flaps (transient layout states can no longer trigger a resize).
4. **Write dedupe + clamps** in `PtySession.setWindowSize()`/`writeTermSizeFile()`: the `term_size` file is only rewritten when the grid actually changed, and values are clamped to [4, 9999].
5. **IME gating.** `onResume()` restores the keyboard only if it was actually open before the pause; a fresh shell shows the keyboard once after start. Ends the show/hide + resize churn loop.
6. Version bump to code 10 / `v0.2.25_15k`.

Files touched in 15k: `TerminalActivity.java`, `terminal/TerminalView.java`, `PtySession.java`, `app/build.gradle`.

---


### 15l (this build — the echo/nano-sizing/app-switch fix)

User report (15k): typed text not printing except inside nano; nano still not sized to the window; app switch breaks nano's UI and makes file contents disappear; keyboard no longer whites the screen (15k fix held).

Three root causes were found, all in the PTY/size plumbing:

1. **`term_size` was written outside the live rootfs.** Java and the bridge wrote
   `files/proot/rootfs/tmp/term_size`, but the launcher mounts
   `ROOTFS=files/rootfs/alpine`, so the shell's `/tmp/term_size` — the file read by
   `libfaketty` (`TIOCGWINSZ`) and by bash's `PROMPT_COMMAND` — was a different,
   never-written file. The shell has effectively been stuck at 80×24 since the
   `proot/rootfs` layout was retired: **nano never sized to the window**, and
   `COLUMNS`/`LINES` never updated. Fix: unified every writer/reader on
   `files/rootfs/alpine/tmp/term_size` (Java `PtySession`, `writeTermSizeFile`,
   `readSavedSize`) and pass the exact path to the bridge via a new
   `AETHERIX_TERM_SIZE_PATH` env var instead of the old argv-derived guess.
2. **The bridge forced ECHO off before exec.** GNU readline only self-echoes when the
   tty starts with `ECHO` set; with it cleared, readline silently skipped echoing, so
   typed text was invisible at the bash prompt (nano still worked because it draws its
   own screen). Fix: the bridge now leaves the pty at default `ICANON|ECHO`; readline
   manages echo from then on.
3. **SIGWINCH went to the wrong process group.** Android blocks `TIOCSIG` on the ptm,
   and the fallback `kill(-child, SIGWINCH)` only reached bash's group — under job
   control a foreground app (nano/vim) runs in its own process group, so it never got
   the resize. That is why app switches (which trigger a view/window resize) broke
   nano and left its content garbled or blank. Fix: the bridge now opens the pts and
   tries `TIOCSIG` there, then reads the foreground pgrp with `TIOCGPGRP` and signals
   that group (`kill(-fg, SIGWINCH)`), with the old session-leader fallback last.

Files touched in 15l: `native/pty-bridge.c` (envp access in `_start`, term-size path
override, ECHO policy, foreground-pgrp signalling), `PtySession.java`,
`TerminalActivity.java` (`readSavedSize`), `app/build.gradle` (code 11 / `v0.2.25_15l`).
Native bridge rebuilt (`libpty-bridge.so` 6168 → 6752 bytes) and re-embedded in both
`jniLibs` and `assets`.



### 15m (this build)

User report (15l): typing now echoes (15l fix held); nano didn't auto-size when the keyboard shrank and broke when it returned; first digit typed as the keyboard pops up is ignored; vim vanished when the font was zoomed; question about the default font.

1. **Resize delivery to foreground full-screen apps (nano/vim).** The 15l
   `TIOCGPGRP` path still wasn't bulletproof: if opening the pts or reading the
   foreground pgrp fails, resizes never reached nano/vim. 15m adds a last-resort
   **session-wide `SIGWINCH`** sweep: the bridge scans `/proc` (own-UID children are
   visible under `hidepid=invisible`) for every process whose session equals the
   shell's, and signals each with `SIGWINCH`. This covers nano/vim in any job-control
   process group, so keyboard show/hide/shrink and font zoom all reach the editor.
   Full diagnostics are emitted per step (`TIOCSIG on ptm` → `TIOCSIG on pts` →
   `TIOCGPGRP` → session sweep → `kill(-child)`), visible in the next error report.
2. **First keystroke after the keyboard pops up.** The input connection can detach
   during the IME show relayout, eating the first character. 15m re-asserts focus
   (immediately and again at +120 ms) whenever the IME transitions to visible.
3. **Default font.** `Paint.setTextSize()` is raw pixels, not density-scaled: the
   default was 18 px (≈6.9 sp on this 420 dpi panel), with pinch-zoom re-basing from
   14 px. 15m raises the default to **26 px** (≈10 sp) and makes the zoom base the
   same 26 px, so the text is readable without zooming — and when you do zoom, the
   grid resize is now reliably delivered (no more vanishing vim).

Files touched in 15m: `native/pty-bridge.c` (getdents64 `/proc` scan + session sweep),
`terminal/TerminalView.java` (IME-show focus re-assertion, zoom base 26),
`TerminalActivity.java` (default text size 26), `app/build.gradle` (code 12 /
`v0.2.25_15m`). Bridge rebuilt (`libpty-bridge.so` 6752 → 7608 bytes), re-embedded in
`jniLibs` and `assets`.



### 15n (this build)

User report (15m): keyboard popup shows a stray ":" when the first letter is typed;
nano now resizes cleanly (self-cleans minor corruption on redraw, full-screen when the
keyboard shrinks); vim still corrupts on zoom; first digit can still be eaten.

1. **The stray ":" was the 15i-era debug WINCH trap.** The `.bashrc` shipped a
   `trap 'echo "WINCH_RECEIVED: $LINES $COLUMNS" > /dev/stderr' WINCH` line (added in
   15i to verify signal delivery and never removed). Every resize printed
   `WINCH_RECEIVED: …` straight into the terminal at the cursor — which is the ":" that
   appeared when typing right after the keyboard popped up, and the "cursor flashes
   left" is the prompt redraw racing the trap output. 15n **removes the trap** — both
   for fresh installs and by sanitizing an existing `.bashrc` (the step now strips any
   `WINCH_RECEIVED` line and rewrites the file).
2. **vim-vs-zoom:** the 15m log showed the grid being driven from 67 rows down to
   10 rows (72 px font + keyboard up) and back in seconds — a brutal, rapid
   shrink/expand that vim (unlike nano) does not survive. 15n caps pinch-zoom at
   **2.0×** (26 px default → 52 px max), so the minimum grid stays much larger and
   zoom changes are gentler. If "vim" is actually busybox `vi`, note that busybox vi
   has no real resize support — install real vim with `apk add vim` inside the shell.
3. **Faster resize settle:** the grid debounce is 150 ms (Java) with a 200 ms bridge
   stability window (was 300/300), so resizes land during the keyboard animation
   instead of colliding with the first keystroke. The IME-show focus re-assertion is
   now a no-op unless focus was actually lost (less input-connection disturbance).

Files touched in 15n: `StepRunner.java` (WINCH trap removal/sanitizer),
`terminal/TerminalView.java` (zoom cap 2.0×, debounce 150 ms, guarded focus
re-assertion), `native/pty-bridge.c` (stability window 200 ms), `app/build.gradle`
(code 13 / `v0.2.25_15n`). Bridge rebuilt and re-embedded in `jniLibs` and `assets`.



### 15o (this build)

User report (15n): font was too small to read comfortably; continuous pinch zoom
swung the grid from 135×55 (≈13 px font) to 38×16 (≈47 px) while vim was open, and
vim broke after three zoom steps — shrinking back did not recover it and the user was
stuck in a corrupt editor screen.

1. **Discrete font sizes, capped.** The terminal font is now one of five sp sizes:
   **10 / 12 / 14 / 16 / 18 sp** (10 sp ≈ 26 px on this 420 dpi panel — the previous
   default). Zooming below 10 sp or above 18 sp is impossible, so the grid can no
   longer collapse to 135×55/38×16 extremes.
2. **Pinch zoom steps, it does not stream.** A pinch must cross a 1.4× (in) or 0.72×
   (out) threshold to advance one size; the accumulator resets after each step. Three
   zoom steps now mean exactly three clean grid resizes (each a single `SIGWINCH`),
   not a continuous storm of intermediate sizes — which is what vim could not
   survive.
3. The default stays at the size you have been using (10 sp); the five steps give
   you 12/14/16/18 to grow into. `TerminalView` exposes `setFontSizeSp(int)` /
   `getFontSizeSp()` for a future settings UI or extra-key control.

If a full-screen editor still ever looks corrupt, recovery without vision is:
`ESC ESC : q ! ENTER` (vim) or `Ctrl+X` twice (nano) — and with discrete sizes the
editor should stay coherent across zoom.

Files touched in 15o: `terminal/TerminalView.java` (FONT_SIZES_SP 10-18,
`setFontSizeSp`/`getFontSizeSp`, discrete stepping in `onScale`),
`TerminalActivity.java` (default via `setFontSizeSp(10)`), `app/build.gradle`
(code 14 / `v0.2.25_15o`). No native changes.


## 3. Notes on build `_15i`

- `_15i` is an **internal debug build**: it was the first to prototype the IME-pan grid behavior and the bash `term_size` export chain, and it shipped a rebuilt `libpty-bridge.so` (poll/debounce/SIGWINCH fallback). It was **not** a user release.
- It was packaged with **stale version metadata** — the APK reports `v0.2.25_15g`, versionCode 8 — which is why it looks out of sequence next to `_15h`.
- `_15i` was superseded by `_15j` (which kept the pan idea but added guards, clamps, debounce, and the corrected insets API). The pan idea itself was then reworked in `_15k` (removed in favor of viewport-tracking under `adjustResize`).
- No separate notes file exists for `_15i`; the snapshot lives at `releases/v0.2.25_15i/` in the source tree.

---

## 4. Known environmental limitations (not app-fixable without root)

- `btop` / proc tools: `Failed to parse /proc/stat` — Android's app sandbox (SELinux domain `u:r:untrusted_app`, `hidepid=invisible` proc mount) denies `/proc/stat` and friends. Any PRoot/Chroot-in-an-app approach inherits this.
- `TIOCSWINSZ`/`TIOCSIG` ioctls fail on the PTY (`-25`/`-13`/`-22`) — Android blocks pty resizing ioctls from apps; the bridge's `kill(-child, SIGWINCH)` fallback is the working mechanism (by design).
- `exitCode=143` in the 15j report = deliberate SIGTERM on session close, **not a crash**; all 7 install components reported `tested`.
