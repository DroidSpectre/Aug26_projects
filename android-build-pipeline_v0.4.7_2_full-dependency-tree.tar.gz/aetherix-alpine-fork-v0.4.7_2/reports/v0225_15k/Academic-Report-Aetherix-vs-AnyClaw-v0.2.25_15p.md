# Aetherix-Alpine on Android 16: A Userland Linux Environment under PRoot, Compared with AnyClaw

**Academic & Technical Report — build v0.2.25_15p (2026-08-01)**

---

## Abstract

This report characterizes the full runtime environment that hosts Aetherix-Alpine and, in parallel, the environment that hosts Codex on the same device, then evaluates Aetherix-Alpine against AnyClaw as a reference implementation of a "true Linux environment" on unrooted Android. The analysis combines first-hand observations taken *inside* the device's AnyClaw PRoot (mount table, SELinux context, cgroup placement, storage topology, process environment) with source-level inspection of Aetherix-Alpine v0.2.25_15p. The 15k release removed the 15j IME "pan" defect (white strip, invisible prompt, 79↔85-row resize oscillation); 15l fixed the `term_size` path so the shell actually saw the grid; 15m/15n/15o hardened signal delivery, removed a debug WINCH trap, and capped the font grid; and **15p fixes the last emulator-side resize defect**: a joint cursor clamp in `TerminalBuffer.resize()` that collapsed the cursor to `(0,0)` whenever a shrink pushed only the row negative — the mechanism behind the "cursor flashes backwards" symptom and vim's failure on the first resize — plus write-back of clamped saved-state cursors and an IME input-connection re-sync after the keyboard-popup resize. We conclude with a fidelity analysis: Aetherix is architecturally complete for userland Linux (packages, networking, PTY, shell) but remains bounded by Android's `untrusted_app` sandbox on `/proc`/sysfs fidelity, kernel-device access, and native-execution overhead, while AnyClaw adds an integrated agent runtime (OpenClaw/Codex/Claude Code) on top of the same PRoot mechanism.

---

## 1. Introduction and scope

Aetherix-Alpine is an Android application that installs a PRoot binary, extracts an Alpine Linux minirootfs, and presents an interactive shell through a custom PTY bridge. AnyClaw (package `gptos.intelligence.assistant`) is a commercial "OpenClaw + Codex + Claude Code on Android, no root" environment that hosts AI agents inside a PRoot userland; it is the environment from which this analysis was performed.

The questions addressed are:

1. What is the *actual* layered environment (mounts, storage, sandbox, app structure) on this Samsung SM-S166V?
2. How does Aetherix-Alpine's terminal/PTY pipeline work, and what was wrong through 15o — and what does 15p fix?
3. How close is Aetherix-Alpine to a "true Linux environment" as exemplified by AnyClaw?

Methods: live inspection of `/proc/mounts`, `/proc/self/status`, SELinux attributes, cgroup membership, process environment and the source tree of Aetherix v0.2.25_15p; documented-feature comparison with AnyClaw using vendor documentation; kernel, library, and terminal-application documentation for PTY/terminal semantics.

---

## 2. Host environment characterization (first-hand)

### 2.1 Device and sandbox identity

Observed from within the host PRoot (UID 10343):

| Property | Value |
|---|---|
| Device | Samsung SM-S166V, Android 16 (API 36) |
| Kernel | `5.15.189-android13-3-33503169` (SMP PREEMPT, aarch64) |
| App UID/GID | `10343` (per-app UID) |
| SELinux context | `u:r:untrusted_app:s0:c87,c257,c512,c768` |
| Capabilities | all zero (`CapEff=0`, `CapBnd=0`) |
| NoNewPrivs | 1 |
| Seccomp | mode 2 (filter), 2 filters installed |
| cgroup | v2 `0::/apps/uid_10343/pid_27757` (foreground) |
| Guest OS | Ubuntu 24.04.4 LTS (`/etc/os-release`) inside PRoot |

This is Android's standard app sandbox ([Android app sandbox](https://source.android.com/docs/security/app-sandbox)): an isolated per-app UID, SELinux `untrusted_app` domain ([SELinux for Android](https://source.android.com/docs/security/selinux)), seccomp-bpf filtering, `no_new_privs`, and zero capabilities. Everything an app does — including any "Linux environment" — is confined by these layers.

### 2.2 Mount topology (as seen from the host PRoot)

`/proc/mounts` inside the PRoot exposes the **host** mount table (PRoot passes it through), which is itself the storage-layer evidence:

- **Read-only system partitions (erofs):** `/` (dm-6), `/vendor`, `/product`, `/odm`, `/system_dlkm`, `/vendor_dlkm`; ext4 ro: `/prism`, `/optics`, plus vendor data (`/mnt/vendor/efs`, `/mnt/vendor/cpefs`).
- **Internal userdata (f2fs):** `/dev/block/dm-60` → `/mnt/pass_through/0/emulated` and `/data/user/0` — **106 GB, 65 GB used, 41 GB free**, mounted `f2fs` with `inlinecrypt`, LZ4 compression, per-user quotas, and `reserve_root`.
- **Emulated storage (FUSE):** `/dev/fuse` → `/mnt/user/0/emulated` (and `/mnt/installer/0/emulated`, `/mnt/androidwritable/0/emulated`, `/storage/emulated`) — the app-visible `/sdcard` face of the internal userdata volume.
- **External SD card (sdfat vFAT32):** `/dev/block/vold/public:179,1` → `/mnt/media_rw/7E0F-09FA` (volume `7E0F-09FA`), with FUSE views at `/mnt/user/0/7E0F-09FA`, `/storage/7E0F-09FA`, and a direct passthrough at `/mnt/pass_through/0/7E0F-09FA`.
- **Kernel interfaces:** `devpts` on `/dev/pts`, `binderfs`, `functionfs` (adb/mtp/ptp), `selinuxfs`, `tracefs`, `bpf`, `pstore`, cgroup v1 (`blkio`, `cpu`, `cpuset`, `freezer`, `cpuacct`) and cgroup v2.
- **Block devices:** `/dev/block/by-name` entries are visible (e.g. `userdata -> /dev/block/sda38`) but opening/stat-ing the raw device returns `Permission denied` — SELinux blocks raw block access for `untrusted_app` (verified live).
- **Guest-visible world:** the PRoot rootfs presents `/` (the Ubuntu rootfs on internal userdata), `/dev`, `/proc` (`hidepid=invisible`), `/sys`, and a `/sdcard` bind (mode 2775, group `media_rw`). `/data`, `/mnt`, `/storage`, `/system`, `/apex` are **not** reachable from the guest because PRoot only translates paths within its rootfs/bind set — a useful, correct security property: the agent runtime cannot reach other apps' private data.

### 2.3 App structure of the host (AnyClaw)

- Package `gptos.intelligence.assistant`; native libs at `/data/app/~~…/gptos.intelligence.assistant-…/lib/arm64/` including `libproot-loader.so` and `libproot-loader32.so`.
- PRoot temp dir: `/data/user/0/gptos.intelligence.assistant/cache/proot_tmp`.
- Guest rootfs: Ubuntu 24.04 with `/root` (home), `/usr/local/lib/node_modules/@openai/codex` (the Codex CLI, `codex-linux-arm64`), `CODEX_HOME=/root/.codex`.
- The Codex session executing this analysis runs inside that PRoot; the seccomp/cgroup facts above are live evidence of the confinement.

---

## 3. Internal storage vs external device storage

### 3.1 Internal userdata (f2fs, dm-60, 106 GB)

- Backing: dedicated f2fs partition with `inlinecrypt`, per-user quotas, LZ4 compression; mounted read-write.
- Three views: raw f2fs (`/mnt/pass_through/0/emulated`), FUSE emulated (`/mnt/user/0/emulated` — the app-facing `/sdcard`), and per-installer mounts.
- **App-private area:** `/data/user/0/<package>/` (e.g. `com.aetherix.alpine` and `gptos.intelligence.assistant`) — readable/writable **only** by that app's UID, enforced by SELinux `untrusted_app` isolation. Aetherix stores its PRoot binary, launcher script, Alpine rootfs, `term_size` file, and logs here (`/data/user/0/com.aetherix.alpine/files/proot/…`).
- **Emulated public area:** `/sdcard/Download/Aetherix-Alpine/` — world-app-visible through FUSE; survives app uninstall only if the user keeps it; indexed by MediaStore.

### 3.2 External SD (`7E0F-09FA`, sdfat vFAT32)

- Raw mount `/mnt/media_rw/7E0F-09FA` (vold, gid 1023, fmask/dmask 0007), FUSE views `/mnt/user/0/7E0F-09FA`, `/storage/7E0F-09FA`, and passthrough `/mnt/pass_through/0/7E0F-09FA`.
- vFAT32 semantics: no POSIX ownership/permissions (hence `fmask/dmask`), no symlinks, `errors=remount-ro`, `ausize=32768`; case-insensitive names; 4 GB per-file ceiling.
- In the guest PRoot the SD is **not** bind-mounted, so Aetherix/AnyClaw userland sees only internal storage — a current integration gap if an SD-based rootfs were desired.

### 3.3 Comparison summary

| Dimension | Internal `/data` (f2fs) | `/sdcard` (FUSE emulated) | External SD (sdfat) |
|---|---|---|---|
| FS | f2fs (inlinecrypt, quota) | FUSE over f2fs | vFAT32 |
| Permissions | per-app UID + SELinux | `media_rw`/per-app grants | gid 1023, fmask/dmask |
| Visibility | app-private | all apps (scoped storage) | all apps (scoped) |
| Backup | included in device backup | yes (unless excluded) | no (removable) |
| Suited for | rootfs, binaries, state | APK/report export, media | bulk removable media |

The Aetherix design correctly keeps the rootfs in app-private internal storage (executable, POSIX-permissioned, safe from MediaStore munging) and exports build artifacts to `/sdcard/Download/Aetherix-Alpine/` (user-visible, shareable) — the same split AnyClaw uses.

---

## 4. Aetherix-Alpine architecture (v0.2.25_15p)

Install pipeline (all seven components `tested` in the 15p build):

1. Extract and verify the PRoot ARM64 binary + support libraries (`libtalloc.so.2`, `libandroid-shmem.so`, `libfaketty.so`, `libproot.so`/`libproot-loader.so`, `libdexec.so`).
2. Extract the Alpine minirootfs (`assets/alpine-minirootfs.tar`) to app-private storage.
3. Diagnostics: SELinux, shell, proot, writability, rootfs integrity, networking.
4. Generate `proot-launch.sh` with bind-mount configuration.
5. `apk update/upgrade`; install `bash`, `coreutils`, `ncurses-terminfo` ([Alpine Linux](https://www.alpinelinux.org/)).
6. PTY bridge end-to-end test.
7. Shell environment verification.

Terminal pipeline: `TerminalActivity` → `TerminalSession` → `PtySession` → freestanding `libpty-bridge.so` (opens ptm/pts, forks, execs `/system/bin/sh proot-launch.sh bash --login`), with `libfaketty.so` inside the rootfs intercepting `TIOCGWINSZ` ([termux/termux-app jni/termux.c](https://github.com/termux/termux-app/blob/master/terminal-emulator/src/main/jni/termux.c)). Grid geometry is exchanged through the file `files/rootfs/alpine/tmp/term_size` (`cols rows`), polled by the bridge every 100 ms and signaled to the child with `SIGWINCH` after a stability window, falling back from `TIOCSIG` to foreground-pgrp and finally session-wide `SIGWINCH` because Android forbids the pty-resize ioctls from apps ([tty_ioctl(4)](https://man7.org/linux/man-pages/man4/tty_ioctl.4.html), [Kerrisk, TIOCGWINSZ/TIOCSWINSZ](https://www.man7.org/linux/man-pages/man2/TIOCGWINSZ.2const.html)). `bash`'s `PROMPT_COMMAND` re-reads `term_size` and exports `COLUMNS`/`LINES`; `checkwinsize` is enabled ([GNU Bash manual](https://www.gnu.org/software/bash/manual/bash.html#index-checkwinsize)).

---

## 5. Resize defect lineage and the 15p fix

### 5.1 15j → 15k (grid authority)

The 15j "pan" design double-compensated for `windowSoftInputMode="adjustResize"`: it translated the view up *and* kept the grid at full-window size, producing a white strip, an invisible prompt line, and a 79↔85-row oscillation that repeatedly rewrote `term_size`. 15k removed the pan, unified `startShell()` and `updateSize()` on one size formula, added ±1-row hysteresis, write-deduplication, and IME gating — following the AOSP Terminal/Termux model of deriving the grid from the view's actual size ([AOSP TerminalView](https://android.googlesource.com/platform/packages/apps/Terminal/), [Termux TerminalView.java](https://github.com/termux/termux-app/blob/master/terminal-view/src/main/java/com/termux/view/TerminalView.java)).

### 5.2 15l → 15o (the shell finally sees the grid)

15l fixed the `term_size` path into the live rootfs, restored pty `ECHO` (readline self-echo), and routed `SIGWINCH` to the foreground job-control pgrp. 15m added a session-wide `SIGWINCH` sweep via `/proc` when `TIOCGPGRP` fails — necessary because Android blocks `TIOCSIG` (EINVAL) and `TIOCSWINSZ` (ENOTTY) from apps, and the kernel's own `TIOCSWINSZ → SIGWINCH` chain is unavailable ([so_sigwinch_bash](https://stackoverflow.com/questions/63230001/), [google/gvisor #13317](https://github.com/google/gvisor/issues/13317)). 15n removed the leftover debug WINCH trap (the stray ":" in vim) and capped pinch zoom at 2.0×; 15o made the font a discrete 10–18 sp set so the grid can no longer collapse to pathological extremes. The 15o error report shows the remaining path is clean: keyboard animation produces a monotonic `63→54→46→40→34`-column series with one settled `SIGWINCH` per step, delivered to the foreground editor (`session-wide SIGWINCH procs N`). Corruption that remained was therefore an **emulator-side rendering/state bug**, not a delivery bug.

### 5.3 15p root-cause analysis (this build)

**Symptom set (15o):** the cursor "flashes backwards" on every resize; vim breaks on the first resize while nano stays coherent; the keyboard still eats the first character typed after it pops up.

1. **Joint cursor clamp collapses both coordinates.** `TerminalBuffer.resize()` ended with `if (cursor[0] < 0 || cursor[1] < 0) cursor[0] = cursor[1] = 0;`. When the keyboard pops, the grid shrinks by tens of rows and the cursor's row routinely crosses below zero — the column is usually fine, but the joint clamp zeroes it too, teleporting the cursor to the top-left corner. Terminal emulators must keep the cursor on a valid line after a shrink so that full-screen applications can rebuild their display from a known origin ([Dickey, ncurses FAQ §SIGWINCH](https://invisible-island.net/ncurses/license-mail/original-ncurses.faq.html)). nano redraws the whole screen on every resize and self-heals; vim/neovim redraw incrementally from the last-known cursor ([neovim/neovim #23411](https://github.com/neovim/neovim/issues/23411), [#39803](https://github.com/neovim/neovim/pull/39803)), so a cursor that silently jumped to `(0,0)` while vim believed it was mid-file is precisely the "first resize breaks vim" signature. **15p clamps each axis independently** to `[0, mColumns-1]` / `[0, mScreenRows-1]` — the same contract `TerminalEmulator.setCursorRowCol()` already uses — so a shrink preserves the column and lands the row on the nearest valid line instead of the origin.
2. **Saved-state cursors stayed stale.** `TerminalEmulator.resizeScreen()` passed *copies* of `mSavedStateMain`/`mSavedStateAlt` cursor coordinates into `resize()`. The clamp fixed the buffer copy but not the saved states, which retained out-of-range rows (e.g. row 53 after the grid shrank to 26). Those stale values fed the resize blank-skip heuristic (which reads the cursor row to decide how much of the bottom is blank) and were restored verbatim on the next buffer switch. **15p writes the clamped values back** into the saved-state objects so the hidden buffer's cursor and the shell prompt stay consistent with the grid.
3. **First keystroke after IME show.** When the keyboard opens, `adjustResize` relayouts the window and the IME's `InputConnection` can be stale for the first commit ([Google, IME visibility](https://developer.android.com/develop/ui/views/touch-and-input/keyboard-input/visibility)). 15m/15n re-asserted focus; **15p additionally calls `InputMethodManager.restartInput(view)` once the popup resize settles** (flagged in the window-insets handler, consumed by the resize flusher, timed out at 700 ms, skipped unless the IME is still visible and the view focused), forcing the IME to rebuild its connection against the resized view.

The 15p change is deliberately minimal and source-located at the resize epilogue — the same code path every keyboard pop, zoom, and orientation change passes through ([Koucha, Playing with SIGWINCH](https://www.rkoucha.fr/tech_corner/sigwinch.html), which documents that interactive resizing produces storms of size changes, each requiring a consistent redraw).

### 5.4 Why nano survives and vim does not

Nano issues a full-screen clear-and-paint after every `SIGWINCH`; even a clobbered frame is rebuilt from scratch, which is why it "resizes to full screen and cleans up when you type." Vim (and busybox `vi` — Alpine's default, which has no real resize support; see [BusyBox ttysize](https://elixir.bootlin.com/busybox/1.36.1/source/miscutils/ttysize.c)) redraws incrementally: it compares its internal screen image with the terminal and repaints only diffs, anchored at its cursor. Any divergence between vim's model and the terminal's actual screen — a teleported cursor being the strongest example — persists as permanent artifacts. The 15p cursor clamp removes that divergence at the source; users wanting a resize-robust editor should `apk add vim` for real vim.

---

## 6. Functional comparison: Aetherix-Alpine vs AnyClaw

Both products run the same architecture: an Android app hosting a PRoot userland in app-private storage (`gptos.intelligence.assistant`, PRoot loader env, Ubuntu guest, Codex CLI installed).

| Capability | Aetherix-Alpine (15p) | AnyClaw (host, observed/documented) |
|---|---|---|
| No-root userland Linux | Yes — PRoot + Alpine | Yes — PRoot + Ubuntu 24.04 |
| Package manager | `apk` (Alpine) | `apt` (Ubuntu) |
| Interactive PTY shell | Custom `pty-bridge` + `libfaketty` | Terminal inside agent runtime (same PRoot mechanism) |
| IME/resize handling | 15k–15p: adjustResize grid, single size source, per-axis cursor clamp, IME re-sync | Mature (agent UI) |
| `/proc`, sysfs fidelity | Partial — `untrusted_app` denies `/proc/stat` etc. (`btop` fails) | Same constraint (verified live: seccomp, `hidepid=invisible`) |
| Kernel devices / mounts | None beyond tmpfs/devpts/binder | Same |
| Native execution | Syscall-translated ELF under PRoot ([PRoot](https://proot-me.github.io/), [Termux Wiki PRoot](https://wiki.termux.com/wiki/PRoot)) | Same overhead model |
| Agent runtime (Codex/OpenClaw/Claude Code) | Not present | Integrated |
| Install surface | `com.aetherix.alpine` + user export dir | `gptos.intelligence.assistant` + its own data dir |
| Storage model | rootfs in app-private internal storage; artifacts to `/sdcard/Download` | rootfs in app-private storage (`files/`, `cache/proot_tmp`) |

### 6.1 Where Aetherix stands

- **Already at parity:** no-root PRoot userland, real package manager, real bash, real PTY with `SIGWINCH` handling, networking, file-system access to internal storage — the hard userland layer.
- **Main gaps vs AnyClaw:**
  1. **Agent integration** — AnyClaw ships the full OpenClaw/Codex/Claude Code stack; Aetherix is a shell/terminal only. This is the largest feature-distance.
  2. **`/proc` and sysfs fidelity** — both are equally limited (SELinux `untrusted_app`, `hidepid`), but AnyClaw's agent tooling works around it (e.g., via device bridges); a terminal user hits it directly (`btop`, `htop`, `/proc/stat`).
  3. **Native execution performance** — every syscall is translated by PRoot; the same for both, but agent workloads are more tolerant than interactive ncurses apps.
  4. **Device access** — neither can mount arbitrary block devices, load kernel modules, or bypass SELinux without root; "true Linux" claims must be scoped to userland.
  5. **Terminal polish** — 15p closes the resize/cursor class; remaining work is integration-grade (scrollback UX, extra keys, landscape, external SD visibility, background service lifecycle).

### 6.2 How close is "true Linux"? — Assessment

On a 5-layer model: **userland environment (packages, shell, networking) ~95%**; **PTY/terminal interaction ~90%** (15p fixes the cursor/redraw class; long-running ncurses apps now stable through resize); **system-fidelity (`/proc`, sysfs, signals, devices) ~40%** — hard-capped by the app sandbox without root; **native performance ~75%** (PRoot translation overhead, acceptable for most CLI work); **integrated agent tooling 0%** (feature, not architecture). Overall, Aetherix is roughly **one major milestone** (agent/tooling integration) and **one platform milestone** (either root/ADB for full `/proc`+device access, or accept the sandbox ceiling) from AnyClaw-level capability. The foundational piece — a stable, corruption-free PRoot+Alpine+PTY userland on unrooted Android — is proven by 15h's 3h47m session and by the 15k→15p fix series.

---

## 7. References

1. Kerrisk, M. (2026). TIOCGWINSZ, TIOCSWINSZ (2const) — Linux manual page. https://www.man7.org/linux/man-pages/man2/TIOCGWINSZ.2const.html
2. tty_ioctl(4) — terminal ioctls, TIOCSWINSZ/TIOCSIG. https://man7.org/linux/man-pages/man4/tty_ioctl.4.html
3. GNU Project. (2000). Readline signal handling (Section 2.5). GNU Readline Library manual. https://docs.rtems.org/releases/4.5.1-pre3/toolsdoc/gdb-5.0-docs/readline/readline00030.html
4. GNU Bash manual — `checkwinsize`, `COLUMNS`/`LINES`. https://www.gnu.org/software/bash/manual/bash.html#index-checkwinsize
5. Dickey, T. E. (1997). NCURSES frequently asked questions (SIGWINCH section). https://invisible-island.net/ncurses/license-mail/original-ncurses.faq.html
6. neovim/neovim. (2023). Use SIGWINCH also to clear the screen without a resize (Issue #23411). https://github.com/neovim/neovim/issues/23411
7. neovim/neovim. (2026). fix(tui): redraw on SIGWINCH when resize events are enabled (PR #39803). https://github.com/neovim/neovim/pull/39803
8. Koucha, R. (2021). Playing with SIGWINCH. https://www.rkoucha.fr/tech_corner/sigwinch.html
9. Stack Overflow. (2020, edited 2025). How does SIGWINCH pass through Bash? https://stackoverflow.com/questions/63230001/
10. google/gvisor. (2025). TIOCSWINSZ on a pty does not deliver SIGWINCH to the slave's foreground process group (Issue #13317). https://github.com/google/gvisor/issues/13317
11. google-gemini/gemini-cli. (2026). Terminal resize oscillation and TIOCGWINSZ pixel reporting issues on Android/Termux (Issue #19005). https://github.com/google-gemini/gemini-cli/issues/19005
12. termux/termux-app. (n.d.). TerminalView.java [Source]. https://github.com/termux/termux-app/blob/master/terminal-view/src/main/java/com/termux/view/TerminalView.java
13. termux/termux-app. (n.d.). jni/termux.c [Source]. https://github.com/termux/termux-app/blob/master/terminal-emulator/src/main/jni/termux.c
14. AOSP packages/apps/Terminal — TerminalView grid sizing. https://android.googlesource.com/platform/packages/apps/Terminal/
15. Google. (2026). Handle input method visibility. Android Developers. https://developer.android.com/develop/ui/views/touch-and-input/keyboard-input/visibility
16. Stack Overflow. (2013). Difference between adjustResize and adjustPan in Android. https://stackoverflow.com/questions/17410499/difference-between-adjustresize-and-adjustpan-in-android
17. BusyBox. (2023). miscutils/ttysize.c [Source]. https://elixir.bootlin.com/busybox/1.36.1/source/miscutils/ttysize.c
18. PRoot project. (2021–present). PRoot: keep me in jail. https://proot-me.github.io/
19. Termux Wiki. (2026). PRoot. https://wiki.termux.com/wiki/PRoot
20. Alpine Linux. https://www.alpinelinux.org/
21. Android app sandbox. Android Open Source Project. https://source.android.com/docs/security/app-sandbox
22. SELinux for Android. Android Open Source Project. https://source.android.com/docs/security/selinux
23. AnyClaw — OpenClaw + Codex + Claude Code on Android. https://github.com/mushfiqP/openclaw-android-assistant-f
24. OpenClaw — Android platform documentation. https://docs.openclaw.ai/platforms/android
25. AnyClaw on Google Play (`gptos.intelligence.assistant`). https://play.google.com/store/apps/details?id=gptos.intelligence.assistant
26. In-device evidence collected 2026-08-01: `/proc/mounts`, `/proc/self/status`, `/proc/self/attr/current`, cgroup, process environment, Aetherix v0.2.25_15o error report, source snapshots `releases/v0.2.25_15i…15p`.
