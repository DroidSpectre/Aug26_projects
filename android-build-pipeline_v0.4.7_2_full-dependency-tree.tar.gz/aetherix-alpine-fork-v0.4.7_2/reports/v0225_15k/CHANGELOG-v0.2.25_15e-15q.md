# Aetherix-Alpine — Changelog v0.2.25_15e → v0.2.25_15q

Build date: 2026-08-01 · Device: Samsung SM-S166V (Android 16 / API 36, kernel 5.15.189-android13-3-33503169, aarch64)
Latest artifact: `Aetherix-Alpine-v0.2.25_15q.apk` (versionCode 16, v2/v3 signed)

---

## 1. Version map

| Build  | APK versionName | versionCode | Java changes | Native changes | Outcome |
|--------|-----------------|-------------|--------------|----------------|---------|
| 15e    | v0.2.25_15g (stale) | 8 | — (packaging) | rebuilds | Distributed test build |
| 15f    | v0.2.25_15g (stale) | 8 | — (packaging) | rebuilds | Distributed test build |
| 15g    | v0.2.25_15g | 8 | jitter guard present | — | Last build with the ±1 row/col guard in `updateSize()` |
| 15h    | v0.2.25_15g (stale) | 8 | real font metrics wired; jitter guard **removed** | — | The build the user tested for 3h47m; stable but corrupting full-screen apps |
| 15i    | v0.2.25_15g (stale) | 8 | first IME-pan prototype; bash `PROMPT_COMMAND`/`term_size` wiring | `libpty-bridge.so` rebuilt (100 ms poll + 300 ms debounce) | Internal debug build; superseded by 15j |
| 15j    | v0.2.25_15j | 9 | guards/clamps/debounce; corrected insets API; onResume refocus+IME show | — | Corruption eliminated; white-out + invisible prompt introduced |
| **15k** | **v0.2.25_15k** | **10** | **pan removed; grid=viewport; unified sizing; hysteresis; write dedupe; IME gating** | — | **This build** |
| **15l** | **v0.2.25_15l** | **11** | **term_size path fixed into live rootfs; ECHO restored (readline echo); SIGWINCH to foreground job pgroup** | `libpty-bridge.so` rebuilt | **This build** |
| **15m** | **v0.2.25_15m** | **12** | **session-wide SIGWINCH fallback; IME-show focus re-assertion; default font 18→26px** | `libpty-bridge.so` rebuilt (7.6 KB) | **This build** |
| **15n** | **v0.2.25_15n** | **13** | **WINCH debug trap removed from .bashrc; zoom capped 2.0×; faster resize settle (150/200 ms)** | `libpty-bridge.so` rebuilt | **This build** |
| **15o** | **v0.2.25_15o** | **14** | **discrete font sizes 10/12/14/16/18 sp; pinch zoom steps one size at a time; 18sp cap** | — (bridge unchanged) | **This build** |
| **15p** | **v0.2.25_15p** | **15** | **per-axis cursor clamp in `TerminalBuffer.resize()`; saved-state cursor write-back in `TerminalEmulator.resizeScreen()`; IME re-sync (`restartInput`) after keyboard-popup resize settles** | — (bridge unchanged) | **This build** |
| **15q** | **v0.2.25_15q** | **16** | **launch-time `.bashrc` sanitize (kills the residual 15i-era WINCH trap that caused the stray ":"); IME-visible resize settle 150→350 ms; alt-screen shrink keeps the cursor on-grid** | — (bridge unchanged) | **This build** |

Note: the "v0.2.25_18" line was abandoned during development and never shipped; 15j superseded 15i, and 15k supersedes 15j.

---

## 2. What changed, per build

### 15e – 15f
Packaging / native-library rebuilds only; no Java source changes between consecutive snapshots. Used to distribute the PTY bridge and PRoot stack for field testing.

### 15g
- Carried a small anti-jitter guard in `TerminalView.updateSize()` (`deltaCols + deltaRows < 2` → early return).

### 15h (the "3h47m" build)
- Wired **real font metrics** from `TerminalView` into `TerminalSession`/`TerminalEmulator` (cell width/height no longer hard-coded to 10×20 px). `TerminalSession` constructor now takes `cellWidth`/`cellHeight`.
- **Removed** the 15g jitter guard (this, combined with no debounce and no clamping, allowed resize storms — the direct cause of the nano/vim corruption seen in 15h).
- User-reported findings during 15h testing:
  - nano/vim full-screen corruption after resize; first digit of typed input sometimes dropped; prompt text invisible when typed; stale cleared screen after app switch.
  - Long-session resize pattern `77×64 ↔ 32` rows (no debounce → two geometry sources raced).
  - `btop` fails with `Failed to parse /proc/stat` — SELinux/`untrusted_app` restriction, environmental (see §4).
  - llama.cpp build notes: `apk add` word-splitting typo, `ssh` package name correction, certificate workaround via `git -c http.sslVerify=false`.

### 15i (user asked for notes — see §3)
- First prototype of the **IME-pan** approach in `TerminalView` (keep grid constant, translate the view up when the keyboard opens) using a deprecated insets read.
- Added `.bashrc` wiring: `unset COLUMNS LINES`, `shopt -s checkwinsize`, `PROMPT_COMMAND` re-reading `/tmp/term_size`, and a `WINCH` debug trap in `StepRunner`.
- Rebuilt `libpty-bridge.so` with the 100 ms file-poll + 300 ms stability debounce and the `TIOCSIG`→`kill(-child, SIGWINCH)` fallback.
- **Not versioned correctly** (still reports `v0.2.25_15g` / code 8), never shipped as a user build; superseded by 15j.

### 15j
- `TerminalView.updateSize()`: guards against transient states (`isShown()`, `fontWidth < 4`, `fontLineSpacing < 12`), hard clamps (500 cols × 300 rows), 300 ms debounce before applying a resize.
- Corrected the IME insets read to the modern `WindowInsets.Type.ime()` API; kept the pan (translation + constant grid).
- `TerminalActivity.onResume()`: force redraw, refocus, and re-show the IME (fixes the stale-frame / first-digit-drop class of bugs).
- Version bump to code 9 / `v0.2.25_15j`; build script no longer swallows errors with `|| true`.
- Result: **corruption eliminated** (no more nano/vim breakage), but three new symptoms:
  1. terminal **whites out when the keyboard is displayed** (the pan translated the view up, revealing the layout background below it),
  2. **prompt text not visible when typed** (bottom rows shifted below the keyboard by the pan),
  3. **nano does not fit the window** (grid kept at full-window size while the visible viewport shrank).
  Root cause: the pan double-compensated for `adjustResize`, and two independent size computations (session constructor vs `attachSession→updateSize`) disagreed, rewriting `term_size` back and forth (79 ↔ 85 rows in the 15j report) and issuing repeated SIGWINCH signals.

### 15k (this build — the fix)
1. **Removed the manual pan.** The activity already uses `windowSoftInputMode="adjustResize"`, so the window (and view) shrink around the keyboard; the grid now tracks the actual visible viewport. No translation → no white strip, prompt always above the keyboard, nano fits.
2. **One authoritative grid size.** `TerminalActivity.startShell()` now uses the exact same formula + clamps as `TerminalView.updateSize()`, so the session constructor and the view can no longer disagree (79 vs 85).
3. **Hysteresis.** `updateSize()` ignores ±1 row/col flaps (transient layout states can no longer trigger a resize).
4. **Write dedupe + clamps** in `PtySession.setWindowSize()`/`writeTermSizeFile()`: the `term_size` file is only rewritten when the grid actually changed, and values are clamped to [4, 9999].
5. **IME gating.** `onResume()` restores the keyboard only if it was actually open before the pause; a fresh shell shows the keyboard once after start. Ends the show/hide + resize churn loop.
6. Version bump to code 10 / `v0.2.25_15k`.

Files touched in 15k: `TerminalActivity.java`, `terminal/TerminalView.java`, `PtySession.java`, `app/build.gradle`.

---


### 15l (this build — the echo/nano-sizing/app-switch fix)

User report (15k): typed text not printing except inside nano; nano still not sized to the window; app switch breaks nano's UI and makes file contents disappear; keyboard no longer whites the screen (15k fix held).

Three root causes were found, all in the PTY/size plumbing:

1. **`term_size` was written outside the live rootfs.** Java and the bridge wrote
   `files/proot/rootfs/tmp/term_size`, but the launcher mounts
   `ROOTFS=files/rootfs/alpine`, so the shell's `/tmp/term_size` — the file read by
   `libfaketty` (`TIOCGWINSZ`) and by bash's `PROMPT_COMMAND` — was a different,
   never-written file. The shell has effectively been stuck at 80×24 since the
   `proot/rootfs` layout was retired: **nano never sized to the window**, and
   `COLUMNS`/`LINES` never updated. Fix: unified every writer/reader on
   `files/rootfs/alpine/tmp/term_size` (Java `PtySession`, `writeTermSizeFile`,
   `readSavedSize`) and pass the exact path to the bridge via a new
   `AETHERIX_TERM_SIZE_PATH` env var instead of the old argv-derived guess.
2. **The bridge forced ECHO off before exec.** GNU readline only self-echoes when the
   tty starts with `ECHO` set; with it cleared, readline silently skipped echoing, so
   typed text was invisible at the bash prompt (nano still worked because it draws its
   own screen). Fix: the bridge now leaves the pty at default `ICANON|ECHO`; readline
   manages echo from then on.
3. **SIGWINCH went to the wrong process group.** Android blocks `TIOCSIG` on the ptm,
   and the fallback `kill(-child, SIGWINCH)` only reached bash's group — under job
   control a foreground app (nano/vim) runs in its own process group, so it never got
   the resize. That is why app switches (which trigger a view/window resize) broke
   nano and left its content garbled or blank. Fix: the bridge now opens the pts and
   tries `TIOCSIG` there, then reads the foreground pgrp with `TIOCGPGRP` and signals
   that group (`kill(-fg, SIGWINCH)`), with the old session-leader fallback last.

Files touched in 15l: `native/pty-bridge.c` (envp access in `_start`, term-size path
override, ECHO policy, foreground-pgrp signalling), `PtySession.java`,
`TerminalActivity.java` (`readSavedSize`), `app/build.gradle` (code 11 / `v0.2.25_15l`).
Native bridge rebuilt (`libpty-bridge.so` 6168 → 6752 bytes) and re-embedded in both
`jniLibs` and `assets`.



### 15m (this build)

User report (15l): typing now echoes (15l fix held); nano didn't auto-size when the keyboard shrank and broke when it returned; first digit typed as the keyboard pops up is ignored; vim vanished when the font was zoomed; question about the default font.

1. **Resize delivery to foreground full-screen apps (nano/vim).** The 15l
   `TIOCGPGRP` path still wasn't bulletproof: if opening the pts or reading the
   foreground pgrp fails, resizes never reached nano/vim. 15m adds a last-resort
   **session-wide `SIGWINCH`** sweep: the bridge scans `/proc` (own-UID children are
   visible under `hidepid=invisible`) for every process whose session equals the
   shell's, and signals each with `SIGWINCH`. This covers nano/vim in any job-control
   process group, so keyboard show/hide/shrink and font zoom all reach the editor.
   Full diagnostics are emitted per step (`TIOCSIG on ptm` → `TIOCSIG on pts` →
   `TIOCGPGRP` → session sweep → `kill(-child)`), visible in the next error report.
2. **First keystroke after the keyboard pops up.** The input connection can detach
   during the IME show relayout, eating the first character. 15m re-asserts focus
   (immediately and again at +120 ms) whenever the IME transitions to visible.
3. **Default font.** `Paint.setTextSize()` is raw pixels, not density-scaled: the
   default was 18 px (≈6.9 sp on this 420 dpi panel), with pinch-zoom re-basing from
   14 px. 15m raises the default to **26 px** (≈10 sp) and makes the zoom base the
   same 26 px, so the text is readable without zooming — and when you do zoom, the
   grid resize is now reliably delivered (no more vanishing vim).

Files touched in 15m: `native/pty-bridge.c` (getdents64 `/proc` scan + session sweep),
`terminal/TerminalView.java` (IME-show focus re-assertion, zoom base 26),
`TerminalActivity.java` (default text size 26), `app/build.gradle` (code 12 /
`v0.2.25_15m`). Bridge rebuilt (`libpty-bridge.so` 6752 → 7608 bytes), re-embedded in
`jniLibs` and `assets`.



### 15n (this build)

User report (15m): keyboard popup shows a stray ":" when the first letter is typed;
nano now resizes cleanly (self-cleans minor corruption on redraw, full-screen when the
keyboard shrinks); vim still corrupts on zoom; first digit can still be eaten.

1. **The stray ":" was the 15i-era debug WINCH trap.** The `.bashrc` shipped a
   `trap 'echo "WINCH_RECEIVED: $LINES $COLUMNS" > /dev/stderr' WINCH` line (added in
   15i to verify signal delivery and never removed). Every resize printed
   `WINCH_RECEIVED: …` straight into the terminal at the cursor — which is the ":" that
   appeared when typing right after the keyboard popped up, and the "cursor flashes
   left" is the prompt redraw racing the trap output. 15n **removes the trap** — both
   for fresh installs and by sanitizing an existing `.bashrc` (the step now strips any
   `WINCH_RECEIVED` line and rewrites the file).
2. **vim-vs-zoom:** the 15m log showed the grid being driven from 67 rows down to
   10 rows (72 px font + keyboard up) and back in seconds — a brutal, rapid
   shrink/expand that vim (unlike nano) does not survive. 15n caps pinch-zoom at
   **2.0×** (26 px default → 52 px max), so the minimum grid stays much larger and
   zoom changes are gentler. If "vim" is actually busybox `vi`, note that busybox vi
   has no real resize support — install real vim with `apk add vim` inside the shell.
3. **Faster resize settle:** the grid debounce is 150 ms (Java) with a 200 ms bridge
   stability window (was 300/300), so resizes land during the keyboard animation
   instead of colliding with the first keystroke. The IME-show focus re-assertion is
   now a no-op unless focus was actually lost (less input-connection disturbance).

Files touched in 15n: `StepRunner.java` (WINCH trap removal/sanitizer),
`terminal/TerminalView.java` (zoom cap 2.0×, debounce 150 ms, guarded focus
re-assertion), `native/pty-bridge.c` (stability window 200 ms), `app/build.gradle`
(code 13 / `v0.2.25_15n`). Bridge rebuilt and re-embedded in `jniLibs` and `assets`.



### 15o (this build)

User report (15n): font was too small to read comfortably; continuous pinch zoom
swung the grid from 135×55 (≈13 px font) to 38×16 (≈47 px) while vim was open, and
vim broke after three zoom steps — shrinking back did not recover it and the user was
stuck in a corrupt editor screen.

1. **Discrete font sizes, capped.** The terminal font is now one of five sp sizes:
   **10 / 12 / 14 / 16 / 18 sp** (10 sp ≈ 26 px on this 420 dpi panel — the previous
   default). Zooming below 10 sp or above 18 sp is impossible, so the grid can no
   longer collapse to 135×55/38×16 extremes.
2. **Pinch zoom steps, it does not stream.** A pinch must cross a 1.4× (in) or 0.72×
   (out) threshold to advance one size; the accumulator resets after each step. Three
   zoom steps now mean exactly three clean grid resizes (each a single `SIGWINCH`),
   not a continuous storm of intermediate sizes — which is what vim could not
   survive.
3. The default stays at the size you have been using (10 sp); the five steps give
   you 12/14/16/18 to grow into. `TerminalView` exposes `setFontSizeSp(int)` /
   `getFontSizeSp()` for a future settings UI or extra-key control.

If a full-screen editor still ever looks corrupt, recovery without vision is:
`ESC ESC : q ! ENTER` (vim) or `Ctrl+X` twice (nano) — and with discrete sizes the
editor should stay coherent across zoom.

Files touched in 15o: `terminal/TerminalView.java` (FONT_SIZES_SP 10-18,
`setFontSizeSp`/`getFontSizeSp`, discrete stepping in `onScale`),
`TerminalActivity.java` (default via `setFontSizeSp(10)`), `app/build.gradle`
(code 14 / `v0.2.25_15o`). No native changes.



### 15p (this build)

User report (15o): vim breaks on the first resize (`ESC ESC ESC :q` still exits);
the cursor "flashes backwards" on every resize; the keyboard still loses the first
character typed when it pops up; nano resizes cleanly all the way through. All seven
install components remain `tested`; the session exited with code 143 (deliberate
close, not a crash). The 15o log also confirms the resize path is now clean: the
keyboard animation produces a single monotonic series (`63→54→46→40→34` columns,
`53→26…` rows) with one settled SIGWINCH per step, and `session-wide SIGWINCH procs N`
delivers the signal to the foreground editor — so the remaining corruption is an
emulator-side rendering/state bug, not a signal-delivery bug.

1. **Per-axis cursor clamp (`TerminalBuffer.resize()`).** The resize epilogue was
   `if (cursor[0] < 0 || cursor[1] < 0) cursor[0] = cursor[1] = 0;` — a *joint*
   clamp that collapses **both** coordinates to `(0,0)` whenever **either** goes
   negative. When the keyboard pops, the grid shrinks by tens of rows and the
   cursor's row frequently crosses below zero; the column was usually fine, but the
   joint clamp threw it away too, teleporting the cursor to the top-left corner.
   nano redraws the whole screen on every resize and self-heals; vim redraws
   incrementally and renders from its last-known cursor, so a cursor that jumped to
   `(0,0)` while vim believed it was mid-file is exactly the "first resize breaks
   vim / cursor flashes backwards" signature. 15p clamps each axis independently to
   `[0, mColumns-1]` / `[0, mScreenRows-1]` (the same contract
   `TerminalEmulator.setCursorRowCol()` already uses), so a shrink keeps the column
   and only lands the row on the nearest valid line.
2. **Saved-state cursor write-back (`TerminalEmulator.resizeScreen()`).** The
   shell cursor saved at `smcup` (enter vim) lives in `mSavedStateMain`; the vim
   cursor saved at `rmcup` lives in `mSavedStateAlt`. `resizeScreen()` passed *copies*
   of those values into `resize()`, so the clamp fixed the buffer copy but the saved
   states kept stale out-of-range rows (e.g. row 53 after the grid shrank to 26).
   On the next buffer switch, `setCursorRowCol()` clamped them per-axis and the
   prompt re-appeared at the bottom — mostly harmless — but the stale value also fed
   the resize blank-skip heuristic, which reads `cursor[1]` to decide how much of the
   bottom is blank. 15p writes the clamped values back into the saved-state objects,
   so the hidden buffer's cursor and the shell prompt stay consistent with the grid.
3. **IME re-sync after the keyboard-popup resize (`TerminalView`).** The dropped
   first character is an input-connection artifact: when the IME shows, the window
   relayouts (`adjustResize`) and the IME's `InputConnection` can be stale for the
   first commit. 15m/15n re-asserted focus; 15p additionally sets a
   `mImeJustBecameVisible` flag in the insets handler and, once the resize for the
   popup settles, calls `InputMethodManager.restartInput(view)` so the IME rebuilds
   its connection against the resized view. The flag is consumed by the resize
   flusher (or times out after 700 ms), and the restart is skipped unless the IME is
   still visible and the view still has focus — no interference with normal typing.
4. **No native changes.** The bridge (poll 100 ms, stability 200 ms, session-wide
   SIGWINCH fallback) is unchanged; the 15o log shows it delivering one settled
   resize per animation step, which is the intended behavior.

Files touched in 15p: `terminal/TerminalBuffer.java`, `terminal/TerminalEmulator.java`,
`terminal/TerminalView.java`, `app/build.gradle` (code 15 / `v0.2.25_15p`). No native
changes.

### 15p test checklist

1. Open the terminal; pop the keyboard and type immediately — the first character
   should appear (15p re-syncs the IME connection after the popup resize settles).
2. Run `nano`; pop/hide the keyboard repeatedly — nano must keep fitting the window
   and redraw cleanly (regression guard; was already working in 15o).
3. Run `vim` (or `apk add vim` for real vim — Alpine's default `vi` is busybox vi,
   which has no real resize support); resize with the keyboard and with font zoom —
   the screen must stay coherent and the cursor must not jump to the top-left.
4. Leave vim (`:q`) immediately after a shrink — the shell prompt must be visible at
   the bottom of the grid, not below it.
5. Confirm no cursor flash: resize (keyboard pop / zoom) while the prompt is at the
   bottom — the cursor should stay on the current line, not flash to row 0.


### 15q (this build)

User report (15p): typing `nano` right after the keyboard popped up (following a
shrink + app switch) produced `:ano` — the first character came back as a stray
"`:`"; vim's splash disappeared when the keyboard was minimized but vim stayed
functional through resize and `:q` worked first try; nano re-renders correctly with
each resize. All seven components `tested`; session exit code 143 (deliberate close).

1. **The stray ":" was the 15i-era WINCH debug trap, still resident in the live
   rootfs.** The 15m install log says the fresh `.bashrc` was created with
   "unset, checkwinsize, stty erase, PROMPT_COMMAND, **and WINCH trap**". The 15n
   sanitizer that strips that trap only runs during Step 4 of a fresh install, and
   setup has not re-run since 15m (component statuses persist as `tested`), so the
   trap survived into 15p. Every keyboard popup fires SIGWINCH → the trap echoes
   `WINCH_RECEIVED: …` into the pty at the cursor → readline's redraw over the
   fragment leaves a visible "`:`" and eats the first typed character — exactly the
   15m symptom, and exactly the `:ano` in the 15p report. **15q sanitizes
   `/root/.bashrc` on every `startShell`** (`StepRunner.sanitizeRootBashrc`): strips
   any `WINCH_RECEIVED` / `trap … WINCH` line and re-asserts `checkwinsize`,
   `stty erase ^?`, `unset COLUMNS LINES`, and `PROMPT_COMMAND`, logging
   `startShell: .bashrc sanitized (WINCH trap removed)` into the bridge buffer so
   the next error report confirms it.
2. **Emulator/shell size divergence during the keyboard animation.** The 15p log
   shows the popup emitting three intermediate grids inside one second
   (`46→40→34` cols, `19→16→14` rows): the Java side reflowed the emulator three
   times while the bridge coalesced the `SIGWINCH` to the final `34×14`. The
   emulator and the shell briefly disagree on the grid, and vim's writes land on a
   grid it does not know about. **15q lengthens the resize settle to 350 ms while
   the IME is visible** (150 ms otherwise, e.g. font zoom), so the emulator applies
   the final size once and the shell's single signal matches it.
3. **Alt-screen shrink keeps the cursor on-grid.** When only rows change (the 15p
   log's `63×53 ↔ 63×26` keyboard transitions are exactly this fast path), a big
   shrink shifted content down and left the cursor below the new grid (the 15p
   per-axis clamp then parked it at the last row). Alt-screen apps redraw wholesale
   on SIGWINCH, so **15q caps the shift for `altScreen` so the cursor stays where it
   was, on-grid**; the main screen keeps the bottom-preserving blank-skip behavior.
4. **vim splash on minimize — not app-fixable.** Minimizing the keyboard expands the
   grid (26→53 rows); both resize paths preserve top content (expand blanks only the
   new bottom rows; full-copy re-copies top-aligned), so the disappearing splash is
   vim's own SIGWINCH redraw of its startup buffer, not lost terminal content. Vim is
   functional through resize; test with a real file (`vim file.txt`) rather than the
   splash screen.

Files touched in 15q: `StepRunner.java` (`sanitizeRootBashrc`),
`TerminalActivity.java` (call it at every launch), `terminal/TerminalView.java`
(IME-visible settle 350 ms), `terminal/TerminalBuffer.java` (alt-screen shrink cap),
`app/build.gradle` (code 16 / `v0.2.25_15q`). No native changes.

### 15q test checklist

1. Open the shell; pop the keyboard and type immediately — the first character must
   be the character you typed (no stray "`:`"). Verify with the error report that
   `startShell: .bashrc sanitized (WINCH trap removed)` appears once at startup.
2. Optionally confirm the trap is gone inside the shell: `grep -n WINCH /root/.bashrc`
   should print nothing.
3. `vim file.txt` — pop/hide the keyboard and zoom; the buffer must stay coherent,
   cursor on the current line, `:q` exits first try.
4. `nano` — pop/hide + zoom; must keep fitting and redraw cleanly (regression guard).
5. Leave any full-screen app right after a shrink — the shell prompt must be visible
   at the bottom.

## 3. Notes on build `_15i`

- `_15i` is an **internal debug build**: it was the first to prototype the IME-pan grid behavior and the bash `term_size` export chain, and it shipped a rebuilt `libpty-bridge.so` (poll/debounce/SIGWINCH fallback). It was **not** a user release.
- It was packaged with **stale version metadata** — the APK reports `v0.2.25_15g`, versionCode 8 — which is why it looks out of sequence next to `_15h`.
- `_15i` was superseded by `_15j` (which kept the pan idea but added guards, clamps, debounce, and the corrected insets API). The pan idea itself was then reworked in `_15k` (removed in favor of viewport-tracking under `adjustResize`).
- No separate notes file exists for `_15i`; the snapshot lives at `releases/v0.2.25_15i/` in the source tree.

---

## 4. Known environmental limitations (not app-fixable without root)

- `btop` / proc tools: `Failed to parse /proc/stat` — Android's app sandbox (SELinux domain `u:r:untrusted_app`, `hidepid=invisible` proc mount) denies `/proc/stat` and friends. Any PRoot/Chroot-in-an-app approach inherits this.
- `TIOCSWINSZ`/`TIOCSIG` ioctls fail on the PTY (`-25`/`-13`/`-22`) — Android blocks pty resizing ioctls from apps; the bridge's `kill(-child, SIGWINCH)` fallback is the working mechanism (by design).
- `exitCode=143` in the 15j report = deliberate SIGTERM on session close, **not a crash**; all 7 install components reported `tested`.
