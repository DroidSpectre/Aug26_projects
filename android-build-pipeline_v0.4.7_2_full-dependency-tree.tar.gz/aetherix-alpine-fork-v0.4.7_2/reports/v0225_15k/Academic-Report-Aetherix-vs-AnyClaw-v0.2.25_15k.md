# Aetherix-Alpine on Android 16: A Userland Linux Environment under PRoot, Compared with AnyClaw

**Academic & Technical Report — build v0.2.25_15k (2026-08-01)**

---

## Abstract

This report characterizes the full runtime environment that hosts Aetherix-Alpine and, in parallel, the environment that hosts Codex on the same device, then evaluates Aetherix-Alpine against AnyClaw as a reference implementation of a "true Linux environment" on unrooted Android. The analysis combines first-hand observations taken *inside* the device's AnyClaw PRoot (mount table, SELinux context, cgroup placement, storage topology, process environment) with source-level inspection of Aetherix-Alpine v0.2.25_15j/15k. The 15k release fixes a self-inflicted terminal defect: the 15j IME "pan" design double-compensated for `adjustResize`, translating the terminal view away from its visible viewport and creating a white strip, an invisible prompt line, and a 79↔85 row oscillation that repeatedly rewrote the bridge's `term_size` file and re-signaled the shell. The fix re-unifies grid sizing around a single authoritative computation, removes the pan, adds hysteresis and write-deduplication, and gates IME restore on prior visibility. We conclude with a fidelity analysis: Aetherix is architecturally complete for userland Linux (packages, networking, PTY, shell) but remains bounded by Android's `untrusted_app` sandbox on `/proc`/sysfs fidelity, kernel-device access, and native-execution overhead, while AnyClaw adds an integrated agent runtime (OpenClaw/Codex/Claude Code) on top of the same PRoot mechanism.

---

## 1. Introduction and scope

Aetherix-Alpine is an Android application that installs a PRoot binary, extracts an Alpine Linux minirootfs, and presents an interactive shell through a custom PTY bridge. AnyClaw (package `gptos.intelligence.assistant`) is a commercial "OpenClaw + Codex + Claude Code on Android, no root" environment that hosts AI agents inside a PRoot userland; it is the environment from which this analysis was performed.

The questions addressed are:

1. What is the *actual* layered environment (mounts, storage, sandbox, app structure) on this Samsung SM-S166V?
2. How does Aetherix-Alpine's terminal/PTY pipeline work, and what was wrong in 15j?
3. How close is Aetherix-Alpine to a "true Linux environment" as exemplified by AnyClaw?

Methods: live inspection of `/proc/mounts`, `/proc/self/status`, SELinux attributes, cgroup membership, process environment and the source tree of Aetherix v0.2.25_15j/15k; documented-feature comparison with AnyClaw using the vendor documentation; kernel and library documentation for PTY/terminal semantics.

---

## 2. Host environment characterization (first-hand)

### 2.1 Device and sandbox identity

Observed from within the host PRoot (UID 10343):

| Property | Value |
|---|---|
| Device | Samsung SM-S166V, Android 16 (API 36) |
| Kernel | `5.15.189-android13-3-33503169` (SMP PREEMPT, aarch64) |
| App UID/GID | `10343` (per-app UID) |
| Supplementary groups | `3003` (inet), `9997`, `20343`, `50343` |
| SELinux context | `u:r:untrusted_app:s0:c87,c257,c512,c768` |
| Capabilities | all zero (`CapEff=0`, `CapBnd=0`) |
| Seccomp | mode 2 (filter), 2 filters installed |
| cgroup | `0::/apps/uid_10343/pid_27757` (v2, foreground) |
| Guest OS | Ubuntu 24.04.4 LTS (`/etc/os-release`) inside PRoot |

This is Android's standard app sandbox ([Android app sandbox](https://source.android.com/docs/security/app-sandbox)): an isolated per-app UID, SELinux `untrusted_app` domain ([SELinux for Android](https://source.android.com/docs/security/selinux)), seccomp-bpf filtering, and zero capabilities. Everything an app does — including any "Linux environment" — is confined by these layers.

### 2.2 Mount topology (as seen from the host PRoot)

`/proc/mounts` inside the PRoot exposes the **host** mount table (PRoot passes it through), which is itself the storage-layer evidence:

- **Read-only system partitions (erofs):** `/` (dm-6), `/vendor`, `/product`, `/odm`, `/system_dlkm`, `/vendor_dlkm`; ext4 ro: `/prism`, `/optics`.
- **Internal userdata (f2fs):** `/dev/block/dm-60` → `/mnt/pass_through/0/emulated` — **106 GB, 66 GB used, 41 GB free**, mounted `f2fs` with `inlinecrypt`, LZ4 compression, and per-user quotas.
- **Emulated storage (FUSE):** `/dev/fuse` → `/mnt/user/0/emulated` (and `/mnt/installer/0/emulated`, `/mnt/androidwritable/0/emulated`) — the app-visible `/sdcard` face of the internal userdata volume.
- **External SD card (sdfat vFAT32):** `/dev/block/vold/public:179,1` → `/mnt/media_rw/7E0F-09FA` (volume `7E0F-09FA`), with FUSE views at `/mnt/user/0/7E0F-09FA` and a direct passthrough at `/mnt/pass_through/0/7E0F-09FA`.
- **Kernel interfaces:** `devpts` on `/dev/pts`, `binderfs`, `functionfs` (adb/mtp/ptp), `selinuxfs`, `tracefs`, `bpf`, `pstore`, cgroup v2.
- **Guest-visible world:** the PRoot rootfs presents `/` backed by the internal userdata volume (same 106 GB f2fs), `/dev`, `/proc`, `/sys`, and a `/sdcard` bind (mode 2775, group `media_rw`). `/data`, `/mnt`, `/storage` are **not** reachable from the guest because PRoot only translates paths within its rootfs/bind set — a useful, correct security property: the agent runtime cannot reach other apps' private data.

### 2.3 App structure of the host (AnyClaw)

- Package `gptos.intelligence.assistant`; native libs at `/data/app/~~…/gptos.intelligence.assistant-…/lib/arm64/` including `libproot-loader.so` and `libproot-loader32.so`.
- PRoot temp dir: `/data/user/0/gptos.intelligence.assistant/cache/proot_tmp`.
- Guest rootfs: Ubuntu 24.04 with `/root` (home), `/usr/local/lib/node_modules/@openai/codex` (the Codex CLI, `codex-linux-arm64`), `CODEX_HOME=/root/.codex`.
- The Codex session executing this analysis runs inside that PRoot; `TERM=dumb` and the seccomp/cgroup facts above are live evidence of the confinement.

---

## 3. Internal storage vs external device storage

### 3.1 Internal userdata (f2fs, dm-60, 106 GB)

- Backing: dedicated f2fs partition with `inlinecrypt`, per-user quotas, LZ4 compression; mounted read-write.
- Three views: raw f2fs (`/mnt/pass_through/0/emulated`), FUSE emulated (`/mnt/user/0/emulated` — the app-facing `/sdcard`), and per-installer mounts.
- **App-private area:** `/data/user/0/<package>/` (e.g. `com.aetherix.alpine` and `gptos.intelligence.assistant`) — readable/writable **only** by that app's UID, enforced by SELinux `untrusted_app` isolation. Aetherix stores its PRoot binary, launcher script, Alpine rootfs, `term_size` file, and logs here (`/data/user/0/com.aetherix.alpine/files/proot/…`).
- **Emulated public area:** `/sdcard/Download/Aetherix-Alpine/` — world-app-visible through FUSE; survives app uninstall only if the user keeps it; indexed by MediaStore.

### 3.2 External SD (`7E0F-09FA`, sdfat vFAT32)

- Raw mount `/mnt/media_rw/7E0F-09FA` (vold, gid 1023, fmask 0007), FUSE views `/mnt/user/0/7E0F-09FA` and passthrough `/mnt/pass_through/0/7E0F-09FA`.
- vFAT32 semantics: no POSIX ownership/permissions (hence `fmask/dmask`), no symlinks, `errors=remount-ro`, `ausize=32768`; case-insensitive names; large-file limits at the 4 GB boundary for FAT32.
- In the guest PRoot the SD is not bind-mounted, so Aetherix/AnyClaw userland sees only internal storage — a current integration gap if SD-based rootfs were desired.

### 3.3 Comparison summary

| Dimension | Internal `/data` (f2fs) | `/sdcard` (FUSE emulated) | External SD (sdfat) |
|---|---|---|---|
| FS | f2fs (inlinecrypt, quota) | FUSE over f2fs | vFAT32 |
| Permissions | per-app UID + SELinux | `media_rw`/per-app grants | gid 1023, fmask/dmask |
| Visibility | app-private | all apps (scoped storage) | all apps (scoped) |
| Backup | included in device backup | yes (unless excluded) | no (removable) |
| Suited for | rootfs, binaries, state | APK/report export, media | bulk removable media |

The Aetherix design correctly keeps the rootfs in app-private internal storage (executable, POSIX-permissioned, safe from MediaStore munging) and exports build artifacts to `/sdcard/Download/Aetherix-Alpine/` (user-visible, shareable) — the same split AnyClaw uses.

---

## 4. Aetherix-Alpine architecture (v0.2.25_15k)

Install pipeline (all seven components `tested` in the 15j report):

1. Extract and verify the PRoot ARM64 binary + support libraries (`libtalloc.so.2`, `libandroid-shmem.so`, `libfaketty.so`, `libproot.so`/`libproot-loader.so`, `libdexec.so`).
2. Extract the Alpine minirootfs (`assets/alpine-minirootfs.tar`) to app-private storage.
3. Diagnostics: SELinux, shell, proot, writability, rootfs integrity, networking.
4. Generate `proot-launch.sh` with bind-mount configuration.
5. `apk update/upgrade`; install `bash`, `coreutils` ([Alpine Linux](https://www.alpinelinux.org/)).
6. PTY bridge end-to-end test.
7. Shell environment verification.

Terminal pipeline: `TerminalActivity` → `TerminalSession` → `PtySession` → freestanding `libpty-bridge.so` (opens ptm/pts, forks, execs `/system/bin/sh proot-launch.sh bash --login`), with `libfaketty.so` inside the rootfs intercepting `TIOCGWINSZ`. Grid geometry is exchanged through the file `proot/rootfs/tmp/term_size` (`cols rows`), polled by the bridge every 100 ms and signaled to the child with `SIGWINCH` after 300 ms of stability, falling back from `TIOCSIG` to `kill(-child, SIGWINCH)` because Android forbids the pty-resize ioctls from apps ([tty_ioctl](https://man7.org/linux/man-pages/man4/tty_ioctl.4.html)). `bash`'s `PROMPT_COMMAND` re-reads `term_size` and exports `COLUMNS`/`LINES`; `checkwinsize` is enabled ([GNU Bash manual](https://www.gnu.org/software/bash/manual/bash.html#index-checkwinsize)).

---

## 5. The 15j defect and the 15k fix

### 5.1 Symptom set (user-reported, 15j)

- Terminal **whites out** when the keyboard is displayed.
- **Prompt text not visible** when typed or entered.
- **nano does not fit** the window.
- Corruption eliminated (15j's guards worked); stability of the shell otherwise good.

### 5.2 Root-cause analysis

1. **Double compensation.** The activity declares `windowSoftInputMode="adjustResize"`; when the IME opens, the window shrinks. 15j additionally applied `setTranslationY(-imeHeight)` *and* computed the grid as `viewHeight - mImeOffsetY` (adding the IME height back). Result: the grid stayed at full-window size while the view was translated up, exposing the layout background (white-out) below the terminal and pushing the prompt line below the keyboard (invisible typed text); a full-window grid also cannot fit nano into the shrunken viewport.
2. **Two size authorities.** `TerminalActivity.startShell()` computed the initial grid from the view (79 rows in the 15j log) while `TerminalView.updateSize()` computed 85 rows from the same view once the session attached. Both wrote `term_size`; the bridge saw the file flip 79↔85 and emitted repeated `SIGWINCH`, forcing bash/ncurses into a perpetual reflow (the log shows alternating signals every few seconds for the entire session).
3. **Unconditional IME re-show on every resume** fed a show/hide + relayout cycle, amplifying the oscillation.

### 5.3 Fix (15k)

1. **Remove the pan**; let `adjustResize` do the work: grid = actual viewport height. No translation → no white strip; prompt always above the keyboard; nano fits.
2. **One authoritative size**: `startShell()` uses the identical formula + clamps as `updateSize()` → constructor and view can no longer disagree.
3. **Hysteresis**: ignore ±1 row/col flaps in `updateSize()`.
4. **Write-dedupe + clamps** in `PtySession.setWindowSize()`: `term_size` is rewritten only on a true grid change (values clamped to [4, 9999]).
5. **IME gating**: `onResume()` restores the keyboard only if it was open before the pause; a fresh shell shows it once after start.

The fix follows the pattern used by AOSP's Terminal and Termux — derive the grid from the view's actual size and resize on layout change ([AOSP TerminalView](https://android.googlesource.com/platform/packages/apps/Terminal/), [Termux](https://github.com/termux/termux-app)) — rather than the pan model that double-compensated for the framework's own resize behavior ([IME visibility handling](https://developer.android.com/develop/ui/views/touch-and-input/keyboard-input/visibility)).

---

## 6. Aetherix-Alpine vs AnyClaw: functional comparison

AnyClaw is documented as running OpenClaw + Codex + Claude Code on Android without root ([AnyClaw Android assistant](https://github.com/mushfiqP/openclaw-android-assistant-f), [OpenClaw Android platform docs](https://docs.openclaw.ai/platforms/android)); the live host verified in §2 is that environment (`gptos.intelligence.assistant`, PRoot loader env, Ubuntu guest, Codex CLI installed).

| Capability | Aetherix-Alpine (15k) | AnyClaw (host, observed/documented) |
|---|---|---|
| No-root userland Linux | Yes — PRoot + Alpine | Yes — PRoot + Ubuntu 24.04 |
| Package manager | `apk` (Alpine) | `apt` (Ubuntu) |
| Interactive PTY shell | Custom `pty-bridge` + `libfaketty` | Terminal inside agent runtime (same PRoot mechanism) |
| IME/resize handling | Fixed in 15k (adjustResize + single grid source) | Mature (agent UI) |
| `/proc`, sysfs fidelity | Partial — `untrusted_app` denies `/proc/stat` etc. (`btop` fails) | Same constraint (verified live: seccomp, `hidepid=invisible`) |
| Kernel devices / mounts | None beyond tmpfs/devpts/binder | Same |
| Native execution | Syscall-translated ELF under PRoot ([PRoot](https://proot-me.github.io/), [proot-me/proot](https://github.com/proot-me/proot)) | Same overhead model |
| Agent runtime (Codex/OpenClaw/Claude Code) | Not present | Integrated |
| Install surface | `com.aetherix.alpine` + user export dir | `gptos.intelligence.assistant` + its own data dir |
| Storage model | rootfs in app-private internal storage; artifacts to `/sdcard/Download` | rootfs in app-private storage (`files/`, `cache/proot_tmp`) |

### 6.1 Where Aetherix stands

- **Already at parity:** no-root PRoot userland, real package manager, real bash, real PTY with `SIGWINCH` handling, networking, file-system access to internal storage — the hard userland layer.
- **Main gaps vs AnyClaw:**
  1. **Agent integration** — AnyClaw ships the full OpenClaw/Codex/Claude Code stack; Aetherix is a shell/terminal only. This is the largest feature-distance.
  2. **`/proc` and sysfs fidelity** — both are equally limited (SELinux `untrusted_app`, `hidepid`), but AnyClaw's agent tooling works around it (e.g., via device bridges); a terminal user hits it directly (`btop`, `htop`, `/proc/stat`).
  3. **Native execution performance** — every syscall is translated by PRoot; the same for both, but agent workloads are more tolerant than interactive ncurses apps.
  4. **Device access** — neither can mount arbitrary block devices, load kernel modules, or bypass SELinux without root; "true Linux" claims must be scoped to userland.
  5. **Terminal polish** — 15k closes the IME/resize class; remaining work is integration-grade (scrollback UX, extra keys, landscape, external SD visibility, background service lifecycle).

### 6.2 How close is "true Linux"? — Assessment

On a 5-layer model: **userland environment (packages, shell, networking) ~95%**; **PTY/terminal interaction ~85%** (15k fixes the IME class; long-running ncurses apps now stable); **system-fidelity (`/proc`, sysfs, signals, devices) ~40%** — hard-capped by the app sandbox without root; **native performance ~75%** (PRoot translation overhead, acceptable for most CLI work); **integrated agent tooling 0%** (feature, not architecture). Overall, Aetherix is roughly **one major milestone** (agent/tooling integration) and **one platform milestone** (either root/ADB for full `/proc`+device access, or accept the sandbox ceiling) from AnyClaw-level capability. The foundational piece — a stable, corruption-free PRoot+Alpine+PTY userland on unrooted Android — is proven by 15h's 3h47m session and by 15k's targeted fix.

---

## 7. References

1. PRoot — pseudo rootfs via user-space syscall translation. https://proot-me.github.io/
2. proot-me/proot (source). https://github.com/proot-me/proot
3. Android app sandbox. Android Open Source Project. https://source.android.com/docs/security/app-sandbox
4. SELinux for Android. Android Open Source Project. https://source.android.com/docs/security/selinux
5. AnyClaw — OpenClaw + Codex + Claude Code on Android. https://github.com/mushfiqP/openclaw-android-assistant-f
6. OpenClaw — Android platform documentation. https://docs.openclaw.ai/platforms/android
7. AnyClaw on Google Play (`gptos.intelligence.assistant`). https://play.google.com/store/apps/details?id=gptos.intelligence.assistant
8. AnyClaw Android assistant site. https://openclawandroid.github.io/openclaw-android-assistant/
9. Alpine Linux. https://www.alpinelinux.org/
10. tty_ioctl(4) — terminal ioctls, TIOCSWINSZ/TIOCSIG. https://man7.org/linux/man-pages/man4/tty_ioctl.4.html
11. GNU Bash manual — `checkwinsize`, `COLUMNS`/`LINES`. https://www.gnu.org/software/bash/manual/bash.html#index-checkwinsize
12. AOSP packages/apps/Terminal — TerminalView grid sizing. https://android.googlesource.com/platform/packages/apps/Terminal/
13. Termux — terminal emulator for Android. https://github.com/termux/termux-app
14. Android IME visibility handling. https://developer.android.com/develop/ui/views/touch-and-input/keyboard-input/visibility
15. In-device evidence collected 2026-08-01: `/proc/mounts`, `/proc/self/status`, `/proc/self/attr/current`, process environment, Aetherix v0.2.25_15j error report, source snapshots `releases/v0.2.25_15i…15k`.
