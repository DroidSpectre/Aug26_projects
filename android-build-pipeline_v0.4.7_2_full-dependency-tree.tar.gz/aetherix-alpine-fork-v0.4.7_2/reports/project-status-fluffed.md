# Aetherix-Alpine: Project Status Report v0.2.23–v0.2.25_4

## Overview

Aetherix-Alpine is a native Android application that runs a full Alpine Linux
environment on unmodified, non-rooted Android devices. It achieves this through
a custom freestanding PTY bridge and the PRoot filesystem virtualisation layer,
delivering a terminal experience with job control, window resize, clipboard
integration, and session persistence.

This report covers development iterations v0.2.23 through v0.2.25_4, a sprint
focused on stabilising the PTY bridge, implementing the Close/Exit toolbar with
session persistence, fixing the window-size negotiation chain end-to-end,
adding clipboard support, and improving the dashboard error-reporting
infrastructure.

## Architecture

The application consists of four layers:

1.  **Java/Android Layer** — `TerminalActivity` (terminal UI), `MainActivity`
    (dashboard), `StepRunner` (one-time setup wizard). Manages the
    `TerminalView` renderer, IME input, clipboard, and the toolbar.

2.  **Terminal Emulation Layer** — `TerminalEmulator` (VT100/xterm escape
    sequence parser), `TerminalBuffer` (scrollback buffer), `TerminalSession`
    (bridge between emulator and PTY). Adapted from the Termux open-source
    terminal implementation.

3.  **PTY Bridge Layer** — `PtySession` (Java-side I/O threads) + `libpty-
    bridge.so` (freestanding ARM64 static binary). The bridge forks a child
    process, creates a Unix98 PTY pair, sets up the child as a session leader
    with a controlling terminal, and exec's the target shell. It handles
    window-size negotiation via a custom `\x1B\x1BW` escape protocol.

4.  **Virtualisation Layer** — PRoot (`libproot.so`) translates filesystem
    paths and process identifiers, allowing the Alpine Linux rootfs to run
    inside the Android `/data/data/` directory without root access.

## Version History

### v0.2.23 — PTY Resize + Job Control

The core PTY bridge was overhauled. The bridge child now calls `sys_setsid()`
after fork, enabling POSIX job control (Ctrl+Z, bg, fg). Window resizing was
moved from a `printf("\033[8;%d;%dt")` approach (which echoed to the terminal)
to a silent ioctl-based approach: the app sends a `\x1B\x1BW` + rows + cols
message to the bridge, which the bridge's parent process reads and forwards as
a `TIOCSWINSZ` ioctl on the PTY master file descriptor. ExtraKeysView
styling was matched to the dark theme, and bridge debug logging (`DBG[...]`)
was added for diagnostics.

*What broke*: Existing installations lost their launcher compatibility (old
launcher scripts lacked `PROOT_NO_SECCOMP` and the new bridge binary).

### v0.2.24 — Clipboard, Dashboard, Navigation

Clipboard copy and paste were connected: `onCopyTextToClipboard` and
`onPasteTextFromClipboard` bridge the TerminalSession to Android's
ClipboardManager. Dashboard received an error-report button that gathers
device info, component status, and bridge debug logs into a shareable report.
System bars were set to dark (`#1a1a2e`), activity orientation was locked to
portrait, and the `requestWindowFeature(FEATURE_NO_TITLE)` call removed the
default title bar. The `resizeScreen()` method was fixed to resize both the
main and alternate screen buffers together. A 100ms IME-show delay was added
as a workaround for the first-character-after-resume race.

*What broke*: The alt-buffer cursor position was not preserved across resize
(main buffer displayed when alt buffer was active).

### v0.2.25 — Toolbar + Session Manager

The `TerminalSessionManager` singleton was introduced to hold a single
`TerminalSession` reference across activity recreation. `TerminalSession`
gained `setTerminalView()` and `destroy()` for clean attach/detach. A toolbar
was added to `TerminalActivity` with three elements: Close (saves the session
to the manager and returns to Dashboard), Exit (kills the session and returns),
and an elapsed timer. The `clear` escape sequence (`\033[2J`) was fixed to
clear the transcript via `mMainBuffer.clearTranscript()`. `resizeScreen()` was
fixed to use the saved-state cursor for the inactive buffer. `StepRunner`
added `cleanupProot()` guards and `export HOME=/root` to the launcher script.
A double-resize guard was added to `TerminalEmulator.resize()` to skip no-op
resizes.

*What broke*: The timer field was stored on the Activity and lost on finish.
`TerminalSessionManager.clear()` was calling `session.destroy()` (killing the
very session it was meant to preserve). Updating without reinstalling left the
launcher script without `HOME` and `TERM` environment variables.

### v0.2.25_1 — Bridge Fixes + Terminal Reattachment

`TerminalSessionManager.clear()` was changed to a no-op on the session (the
session survives Close). The bridge winsize handler was fixed to forward
remaining bytes (`n-7`) to the PTY after consuming the `\x1B\x1BW` + 4-byte
winsize message, fixing a first-character truncation bug. Session reattachment
was deferred to `terminalView.post()` to ensure layout was complete before
attach. `TERM=xterm-256color` was added to the launcher script (both generation
and runtime fixup via `ensureLauncherEnvVars`).

### v0.2.25_2 — RC1 / RC2 Stabilisation

No architectural changes. Build testing and binary verification.

### v0.2.25_3 — Full Winsize Chain, POLLHUP, Font Metrics

The `TIOCSWINSZ` ioctl was moved from the Java side to the bridge child side:
rows and cols are now passed as CLI arguments (`argv[1]`/`argv[2]`), and the
child calls `TIOCSWINSZ` on the pts file descriptor after opening it. The
bridge POLLHUP handler was rewritten: only `POLLERR` causes a break; on
`POLLHUP` or `POLLIN`, the parent tries `sys_read()` and checks the child
via `sys_wait4(WNOHANG)` before breaking (handling transient QEMU PTY HUP
events). `HOME=/root` was added to the launcher. Font metrics were moved from
hardcoded 10/20 values to `TerminalView.getFontWidth()` / `getFontLineSpacing()`
/ `getFontLineSpacingAndAscent()`. The IME-show delay was increased from 100ms
to 300ms. A persistent debug signing key was created. The `LogBuffer` was
converted to a singleton to preserve setup logs across activity recreation.
Status bar dark was applied to both `MainActivity` and `TerminalActivity`.

*Bug introduced*: `TIOCSWINSZ` on pts was placed before `sys_setsid()`, which
caused EACCES because the process did not yet own the terminal.

### v0.2.25_4 — TIOCSWINSZ Ordering, Timer Persistence, Input Guard, Banner

The `TIOCSWINSZ` block was moved to after `sys_setsid()` and `TIOCSCTTY`.
Despite the correct ordering, the ioctl still returns EACCES on Android kernel
5.15 (Android 16 API 36), suggesting the slave-side `TIOCSWINSZ` is restricted
by kernel policy. The `sessionStartTime` was moved from `TerminalActivity` into
`TerminalSessionManager` so the elapsed timer survives Close/Reopen. A 500ms
input guard (`blockInputFor`) was added to `TerminalSession`, activated in
`onResume()`, to drop writes during the first 500ms after foregrounding—a
band-aid for the first-byte-lost race. The welcome banner was expanded to
show Aetherix version, Android version, and clarify the kernel as
"(Android/Linux host)". `build-apk.sh` was updated to accept `VERSION_NAME`
and `VERSION_CODE` from environment variables.

## What Worked

- **Freestanding PTY bridge**: The `-nostdlib` approach produces a 4,408-byte
  static binary with zero libc dependencies. It works reliably across Android
  kernel versions.

- **`\x1B\x1BW` winsize protocol**: Consumed by `TerminalEmulator.append()`
  before display data; remaining bytes forwarded to PTY. Correctly silences
  resize echo.

- **setsid() + TIOCSCTTY**: Enables job control (Ctrl+Z, bg, fg) inside the
  proot environment.

- **Session persistence via singleton**: `TerminalSessionManager` preserves
  the PTY session across Close/Reopen. Reattachment deferred to
  `terminalView.post()` works cleanly.

- **PRoot launcher script**: Shell-based launcher with env-var injection is
  reliable and testable. `HOME`, `TERM`, `AETHERIX_VERSION`, and
  `ANDROID_VERSION` are all visible inside Alpine.

- **Error reporting dashboard**: Captures device info, component status, setup
  log, and bridge debug for shareable bug reports.

## What Did Not Work / Needs Fixing

- **TIOCSWINSZ EACCES**: Setting winsize on the slave (pts) file descriptor
  fails with EACCES even after correct `setsid()` + `TIOCSCTTY` sequence on
  Android kernel 5.15. The correct fix is to set `TIOCSWINSZ` on the master
  (ptm) file descriptor instead, which is the standard approach in PTY
  programming.

- **First-byte loss after app switch**: The first `write()` to the PTY after
  foregrounding the app loses one byte. This affects both keyboard input and
  paste. The 500ms guard mitigates but does not resolve the root cause, which
  is likely a kernel-level pipe buffer flush on process backgrounding.

- **Bridge output interleaving**: The parent and child processes both write
  debug output to fd 1 (stdout) without locking, producing garbled debug logs.

- **`\x1B\x1BW` noise at terminal start**: The 7-byte winsize message is
  displayed verbatim when it arrives split across multiple `append()` calls.
  The parser requires all 7 bytes in a single call—no partial-match state
  tracking is implemented.

- **TerminalView RuntimeException**: The dashboard's "Test Terminal" button
  consistently fails with a `RuntimeException`, likely due to missing layout
  context or an asynchronous initialisation race.

- **App killed by Android backgrounding**: Without a foreground service, the
  process is evictable. After ~30 seconds in the background, Android may kill
  it, losing the PTY session.

- **nano display**: The editor renders incorrectly despite
  `TERM=xterm-256color`. Likely missing `terminfo` or `ncurses-term` package.

- **clear content reappears**: After `\033[2J`, switching away and back can
  restore previously cleared content, suggesting `resizeScreen()` or buffer
  backup restores old state.

## Current State

As of v0.2.25_4, the terminal is functional on fresh installations. The
welcome banner correctly displays the Aetherix version, Android version
("16 (API 36)"), Alpine release ("3.19.1"), kernel version
("5.15.189-android13-3-33503169"), architecture ("aarch64"), and installed
package count. bash, git, tmux, and vim are all operational. The PTY bridge
successfully starts the shell, processes output, and handles window resizes.
The Close/Exit toolbar with timer works correctly. The timer persists across
Close/Reopen with the corrected `TerminalSessionManager` integration.

For fresh installs, the terminal is stable across repeated launches and
app switches (observation 4). Updating without reinstalling (observation 2)
can cause a crash, likely due to launcher script incompatibilities between
versions.

## Next Steps (v0.2.25_5)

1.  **Fix TIOCSWINSZ EACCES**: Move the `TIOCSWINSZ` ioctl from the pts slave
    to the ptm master file descriptor before or after the fork.

2.  **Add foreground service**: Start a `ForegroundService` with a persistent
    notification to prevent Android from killing the process in the background.

3.  **Fix `\x1B\x1BW` noise**: Add byte-level state tracking in
    `TerminalEmulator.append()` to match the winsize prefix across partial
    buffer reads.

4.  **Investigate first-byte loss**: Add diagnostic logging around the first
    post-resume write to identify the exact pipe/kernel state.

5.  **Fix TerminalView smoke test**: Debug and resolve the RuntimeException
    in the dashboard's TerminalView test.

6.  **Stabilise update path**: Ensure launcher script patching
    (`ensureLauncherEnvVars`) does not corrupt existing installations.
