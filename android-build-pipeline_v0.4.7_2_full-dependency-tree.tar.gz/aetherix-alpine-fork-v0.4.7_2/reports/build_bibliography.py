# -*- coding: utf-8 -*-
"""Generate standalone bibliography PDF from the same reference data."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refs import REFS

REFS = sorted(REFS, key=lambda r: r[0].lower())
OUT_DIR = "/root/android-dev-env"
VERSION = "v0.2.25_15h"

CSS = """
@page { size: A4; margin: 20mm 15mm 18mm 15mm;
  @bottom-center { content: counter(page); font-size: 8pt; color: #444; } }
body { font-family: 'Liberation Serif', Georgia, serif; font-size: 9.5pt; line-height: 1.35; color: #111; }
h1 { font-size: 16pt; text-align: center; margin: 0 0 8pt 0; }
p { text-align: justify; margin: 0 0 6pt 0; }
.ref { padding-left: 22pt; text-indent: -22pt; text-align: left; }
.ref .annotation { display: block; text-indent: 0; margin-top: 1.5pt; color: #222; }
.stream { margin-top: 10pt; font-weight: bold; color: #333; font-size: 10pt; }
"""

HTML = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Bibliography</title>
<style>{CSS}</style></head><body>
<h1>Aetherix-Alpine Resize Research Bibliography (Build {VERSION})</h1>
<p style="font-size:9pt;color:#333;font-style:italic;text-align:center;margin-bottom:10pt;">
111 sources from six parallel research streams (2026-07-31). All entries appeared in live search results or fetched pages.
</p>
<div class="references">
{chr(10).join(f'<p class="ref" id="ref-{k}">{v} <span class="annotation">{ann}</span></p>' for k, v, ann in REFS)}
</div>
</body></html>"""

import weasyprint
html_path = os.path.join(OUT_DIR, "bibliography.html")
pdf_path = os.path.join(OUT_DIR, f"Aetherix-Alpine-Bibliography-{VERSION}.pdf")
with open(html_path, "w", encoding="utf-8") as f:
    f.write(HTML)
weasyprint.HTML(html_path).write_pdf(pdf_path)
print("Bibliography PDF:", pdf_path, os.path.getsize(pdf_path), "bytes")