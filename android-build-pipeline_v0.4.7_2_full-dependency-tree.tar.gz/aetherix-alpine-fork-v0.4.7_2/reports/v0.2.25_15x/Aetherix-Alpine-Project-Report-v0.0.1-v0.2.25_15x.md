# Aetherix-Alpine Project Report v0.0.1 - v0.2.25_15x

**Date:** 2 August 2026 &nbsp; **Device:** Samsung SM-S166V / Android 16 (API 36) / kernel 5.15.189-android13-3-33503169 / aarch64

## Executive Summary

Aetherix-Alpine runs an Alpine Linux rootfs in a PRoot + freestanding-PTY chain on an unrooted Samsung Android 16 device. The current build finishes Phase 1 (terminal) work: adaptive sizing, cursor clamps, and the readline warm-up that closes the ':ano' first-key corruption. This report audits the build against the v0.2.23-v0.2.30 plan and maps the remaining StepRunner items to v0.2.26-v0.2.30.

## 1. Current state (v0.2.25_15x)

- 7-step setup pipeline (PRoot, rootfs, diagnostics, launcher, packages, shell, verification).
- Freestanding PTY bridge owns the master; term_size file + SIGWINCH propagate size.
- Session manager with persistence, Close (keep-alive) / Exit controls, elapsed timer, clipboard.
- All 7 installer components reported `tested` in the latest field build.

## 2. Timeline

| Range | Milestone |
|---|---|
| v0.0.1-v0.1.6 | breakthrough: PRoot chain on Samsung Knox via PROOT_LOADER (no domain change) |
| v0.1.7-v0.2.0 | Web terminal, HTTPS apk, 6-step pipeline, CA fix |
| v0.2.1-v0.2.5 | 7-step pipeline, freestanding binary, PTY bridge |
| v0.2.23-v0.2.25 | resize, clipboard, session persistence, toolbar |
| v0.2.25_14-18 | abandoned JNI branch; reverted to subprocess bridge |
| v0.2.25_15g-15x | resize/cursor/warm-up fixes; ':ano' resolved |

## 3. Plan conformance

- Phase 1 (terminal): complete in v0.2.25_15x. Divergences: `adjustResize` vs `adjustNothing` and term_size bridge (vs `stty`).
- Phase 2 (StepRunner): pending; mapped to v0.2.26-v0.2.30 (BUG-009..013).

## 4. Bug register

| ID | Area | Status | Version | Summary |
|---|---|---|---|---|
| BUG-001 | Terminal input | fixed | 15w confirmed in 15x | Stray ':' corrupted the first command after a keyboard-popup resize (nano -> ':ano'). |
| BUG-002 | Terminal resize / full-screen | fixed | 15p-15t | nano/vim/htop corrupted after a shrink; cursor could collapse to (0,0). |
| BUG-003 | Terminal setup | fixed | 15q | Residual 15i-era WINCH debug trap printed junk into the shell. |
| BUG-004 | PTY bridge | fixed | v0.2.25_14a | JNI in-process fork() bridge crashed the app (abandoned branch). |
| BUG-005 | PTY noise | fixed | 15e-15h | DBG[] bridge messages and stty echo leaked into the terminal. |
| BUG-006 | Networking | fixed | v0.2.0 | apk over HTTPS failed (outdated CA, missing ISRG Root X2). |
| BUG-007 | Setup pipeline | fixed | v0.1.x / Step 3 | libz.so.1 resolution and rootfs library integrity broke shell startup. |
| BUG-008 | Keyboard/IME | fixed | 15j-15m | Keyboard show/IME handling could fail or leave an invisible/white prompt. |
| BUG-009 | StepRunner (Phase 2) | open | open | Dashboard hard-codes '/6 steps complete' although there are 7 steps. |
| BUG-010 | StepRunner (Phase 2) | open | open | Internal step/method names are not fully aligned to final display names. |
| BUG-011 | StepRunner (Phase 2) | open | open | Final step is 'Verifying...' / no manual 'Test & Verify' step. |
| BUG-012 | StepRunner (Phase 2) | open | open | Setup steps do not write PASS/FAIL lines into the main log. |
| BUG-013 | StepRunner (Phase 2) | open | open | No per-step info popup. |
| ENV-001 | Samsung kernel | open | environmental | pty resize ioctls (TIOCSWINSZ/TIOCSIG) blocked for the app. |
| ENV-002 | Android sandbox | open | environmental | '/proc/stat' and friends are denied; btop-like tools fail. |

### 4.1 Fixed (root causes)
- **BUG-001 (15w confirmed in 15x):** Shell-owned defect: readline deferred its SIG-win redraw to the next read() and consumed the first key. 15w add a guarded space+DEL warm-up, 300ms after each settled resize, to run the redraw early. (Bouynot, F., & Ramey, C, 2026)
- **BUG-002 (15p-15t):** Per-axis cursor clamp (15p), alt-screen cursor-row handling (15q/15s), and cursor-anchor fallback to the last visible text row (15t) removed the flash-back and stale cursor bugs.
- **BUG-003 (15q):** Launch-time .bashrc sanitization (15q) strips any stray WINCH trap.
- **BUG-004 (v0.2.25_14a):** Reverted to the v0.2.25_13 subprocess bridge; the 14-18 branch was renamed a dead end.
- **BUG-005 (15e-15h):** redirectErrorStream(false) and the silent term_size-file path removed the noise.
- **BUG-006 (v0.2.0):** CA-bundle refresh plus writing a Mozilla bundle resolved Let's-Encrypt chain verification.
- **BUG-007 (v0.1.x / Step 3):** Step-3 library diagnostics detect and the fixup replaces the symlink as needed.
- **BUG-008 (15j-15m):** requestFocus() + SHOW_FORCED and insets-aware layout stabilise the keyboard path.

### 4.2 Open / not addressed
- **BUG-009 (open):** Dashboard hard-codes '/6 steps complete' although there are 7 steps. -- Plan v0.2.26 (and the count bug) proposed in the original plan doc.
- **BUG-010 (open):** Internal step/method names are not fully aligned to final display names. -- Plan v0.2.26 label sweep.
- **BUG-011 (open):** Final step is 'Verifying...' / no manual 'Test & Verify' step. -- Plan v0.2.27 reorder + rename.
- **BUG-012 (open):** Setup steps do not write PASS/FAIL lines into the main log. -- Plan v0.2.28 logger integration.
- **BUG-013 (open):** No per-step info popup. -- Plan v0.2.29.
- **ENV-001 (environmental):** pty resize ioctls (TIOCSWINSZ/TIOCSIG) blocked for the app. -- Bypassed by design via term_size file + SIGWINCH bridge; not fixable in-app.
- **ENV-002 (environmental):** '/proc/stat' and friends are denied; btop-like tools fail. -- Android hidepid/untrusted_app limit; inherited by PRoot-in-app.

## 5. Roadmap v0.2.26 - v0.2.30

### v0.2.26 -- Labeling & Step Count
- Fix the '/6 steps complete' hard-code in dashboard.html to '/7'.
- Align StepRunner.executeStep()/method names and STEP_NAMES/STEP_DESCS with the 7-step order.
- Audit getDashboardData() and the JS renderer for the count off-by-one.

### v0.2.27 -- Step Reordering
- Reorder executeStep() so the final step is 'Test & Verify' (manual test then shell verify).
- Rename STEP_NAMES[6]/STEP_DESCS[6] to 'Test & Verify' and update the card.

### v0.2.28 -- Main Logger Integration
- Append 'Step N [PASS/FAIL]: <output>' to the main log panel on each step finish.
- Mirror checkStep() results into the main log.

### v0.2.29 -- Info Popups Per Step
- Add STEP_INFO[] (short description per step).
- Show a single-Continue info popup before each step, reusing the ConfirmDialog latch.
- Style info (blue) vs confirmation (orange) in JS.

### v0.2.30 -- Final Polish
- Fix bugs discovered in v0.2.26-29; UI/UX refinements; prepare the post-v0.2.30 progress report.

## 6. References (APA)

- PRoot project. (2021–present). PRoot: keep me in jail. https://proot-me.github.io/ `[200]`
- proot-me/proot. (2024). src/syscall/enter.c [Source]. GitHub. https://github.com/proot-me/proot/blob/master/src/syscall/enter.c `[200]`
- Termux Wiki. (2026). PRoot. https://wiki.termux.com/wiki/PRoot `[200]`
- Linux kernel. (2018). drivers/tty/pty.c. Google Git mirror. https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/661e5ebbafd26d9d2e3c749f5cf591e55c7364f5/drivers/tty/pty.c `[200]`
- UCLouvain man page mirror. (2008). tty_ioctl(4) — Linux manual page. https://sites.uclouvain.be/SystInfo/manpages/man4/tty_ioctl.4.html `[200]`
- Kerrisk, M. (2026). TIOCGWINSZ, TIOCSWINSZ (2const) — Linux manual page. man7.org, Linux man-pages project. https://www.man7.org/linux/man-pages/man2/TIOCGWINSZ.2const.html `[200]`
- GNU Project. (2000). Readline signal handling (Section 2.5). GNU Readline Library manual (RTEMS mirror). https://docs.rtems.org/releases/4.5.1-pre3/toolsdoc/gdb-5.0-docs/readline/readline00030.html `[200]`
- Bouynot, F., & Ramey, C. (2026, May 15–22). [bug] readline 8.3: cursor mis-positioned after SIGWINCH on wrapped prompt with non-printing region [Mailing list thread]. GNU bug-bash. https://lists.gnu.org/archive/html/bug-bash/2026-05/msg00065.html `[200]`
- Linux man-pages project. (n.d.). resizeterm(3x) — Linux manual page. man7.org. https://man7.org/linux/man-pages/man3/resizeterm.3x.html `[200]`
- openSUSE manpages. (n.d.). resizeterm(3ncurses). https://manpages.opensuse.org/Leap-16.0/ncurses-devel/resizeterm.3ncurses.en.html `[200]`
- Dickey, T. E. (1997). NCURSES frequently asked questions (SIGWINCH section). invisible-island.net. https://invisible-island.net/ncurses/license-mail/original-ncurses.faq.html `[200]`
- Google. (2026). Control and animate the software keyboard. Android Developers. https://developer.android.com/develop/ui/views/layout/sw-keyboard `[200]`
- Google. (2026). Handle input method visibility. Android Developers. https://developer.android.com/develop/ui/views/touch-and-input/keyboard-input/visibility `[200]`
- Google. (n.d.). InputMethodManager API reference. Android Developers. https://developer.android.com/reference/android/view/inputmethod/InputMethodManager `[200]`
- Google. (n.d.). <activity> manifest reference (android:windowSoftInputMode). Android Developers. https://developer.android.com/guide/topics/manifest/activity-element `[200]`
- javatips.net. (n.d.). Termux TerminalSession.java (mirror). https://www.javatips.net/api/termux-app-master/terminal-emulator/src/main/java/com/termux/terminal/TerminalSession.java `[200]`
- termux/termux-app. (n.d.). TerminalView.java [Source]. GitHub. https://github.com/termux/termux-app/blob/master/terminal-view/src/main/java/com/termux/view/TerminalView.java `[200]`
- Android Open Source Project. (n.d.). TerminalView.java (packages/apps/Terminal, commit c8be179). https://android.googlesource.com/platform/packages/apps/Terminal/+/c8be179/src/com/android/terminal/TerminalView.java `[200]`
- GNU Project. (2025). GNU Bash reference manual 5.3: checkwinsize shopt; COLUMNS and LINES variables. https://www.gnu.org/software/bash/manual/bash.html#index-checkwinsize `[200]`
- google-gemini/gemini-cli. (2026). Terminal resize oscillation and TIOCGWINSZ pixel reporting issues on Android/Termux (Issue #19005). GitHub. https://github.com/google-gemini/gemini-cli/issues/19005 `[200]`
