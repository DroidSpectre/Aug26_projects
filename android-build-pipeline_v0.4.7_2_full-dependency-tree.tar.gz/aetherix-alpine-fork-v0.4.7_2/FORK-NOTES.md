# Aetherix-Alpine — Fork Notes

Snapshot source : `/root/android-dev-env` (opencode's live working tree)
Snapshot time   : 2026-08-04 ~16:30 local
Fork location   : this directory

## Purpose
Independent working copy so development can continue WITHOUT mutating the
opencode-owned tree (`/root/android-dev-env`).

## What was copied
- `app/` (full Android app source + assets + jniLibs), `native/`, `scripts/`,
  `rootfs/`, `tools/`, `config/`, Gradle wrapper (`gradle/`, `gradlew*`),
  `build.gradle`, `settings.gradle`, `gradle.properties`, `local.properties`,
  `debug.keystore`, plus `docs/`, `reports/`, `research/`.
- v0.3-series continuity docs added under `docs/v0.3-series/` (VERSIONING,
  CHANGELOG, device-layers plan, progress-v0.3.1-v0.3.2) sourced from the
  verified device archive.
- Excluded (not source / environment): `sdk/` (stray installer zip), `releases/`
  (old snapshots), `.gradle/` cache, `*.apk` build artifacts.
- Android SDK is NOT bundled: `local.properties` and `scripts/build-apk.sh`
  point at the shared `ANDROID_HOME=/root/Android`.

## Compile state at snapshot
The upstream tree is MID-REFACTOR and does not currently compile (opencode is
actively implementing the v0.3.3 telemetry tier). This fork mirrors that state:
(versionCode 27 / v0.3.3 in app/build.gradle)

1. Structural: `StepRunner.java` was missing the declaration for
   `step4Launcher(...)` (called by `executeStep` at line 74) while its body was
   present. FIXED HERE with a header mirroring the sibling step methods.
2. Remaining (opencode in-flight, intentionally NOT fabricated here):
   - `getSystemProperty(String)` — referenced 4x in `StepRunner.writeDeviceConf`
     (~1659-1662), no helper exists yet in the tree.
   - `DevicePayload.java` — new telemetry class; symbol errors vs the build
     android.jar (e.g. `BatteryManager.BATTERY_PROPERTY_TEMPERATURE` + others).
These exist identically in `/root/android-dev-env`; re-sync `StepRunner.java` /
`DevicePayload.java` from opencode after it settles, OR complete the telemetry
tier independently here.

## Build
`bash scripts/build-apk.sh` — NOTE: it exports the APK to
`/sdcard/Download/Aetherix-Alpine/` and deletes stale APKs in the project root;
strip that tail section when building in a fork that shares the device with
opencode.


## Versioning (fork line)
- applicationId: `com.aetherix.alpine.a` (package rename FB-003) — installs side-by-side with upstream.
- This tree is the `v0.3a.x` line: `app/build.gradle` = `versionName "v0.3a.0"`,
  `versionCode 30000` (`30000 + n*10 + k`, patch `_k` for fix builds on a tested
  version — e.g. `v0.3a.14_1` = `30141`; upstream stays ≤ 27).
- From v0.3a.14_13 the core is frozen; v0.3a.14_14 is released as the
  **v0.4.0 core-stable line** (`versionCode 40000 + p`, `versionName "v0.4.<p>"`).
  Modules carry their own versions and are the update vehicle
  (`docs/v0.3-series/core-vs-modules.md`); `bump-version.sh` /
  `release-docs.sh` / `verify-apk.sh` accept both schemes.
- APK artifacts: `Aetherix-Alpine-v0.3a.<n>.apk` (or `…-v0.3a.<n>_<k>.apk`).
- Export tree: `/sdcard/Download/Aetherix-Alpine-Fork/` (build-apk.sh) and module
  drop folder `…/Aetherix-Alpine-Fork/modules/` (StorageTier + modules.html).
  Upstream's `/sdcard/Download/Aetherix-Alpine/` tree is never touched.
- Policy: `docs/v0.3-series/VERSIONING.md` §6.

## License status (fork line)
- Aetherix-Alpine's original code (app logic, PTY bridge, launcher, telemetry,
  module system, storage tier, tier CLIs) is **proprietary / not open source**.
  All rights reserved (DroidSpectre). Only the bundled third-party components
  keep their own open-source licenses; the in-app Dashboard → Licenses page
  states this and cites each component with its upstream source (FB-055).

## Release process (per build)
1. `bash scripts/bump-version.sh` — next patch `v0.3a.<n>_<k>` / `30000+n*10+k` (validates scheme).
2. Author/update `docs/v0.3a.<n>/README.md` (changes + every bug/fix with FB-###),
   then `bash scripts/release-docs.sh v0.3a.<n> -m "summary"` (appends master
   CHANGELOG, creates per-build CHANGELOG.md, runs lossless 5/25/125 consolidation).
3. Update `docs/BUGS.md` statuses.
4. `bash scripts/build-apk.sh` — builds APK, creates
   `archive/v0.3a.<n>/Aetherix-Alpine-v0.3a.<n>-source.zip`, exports APK + zip +
   docs + CHANGELOG/BUGS/FORK-NOTES to `/sdcard/Download/Aetherix-Alpine-Fork/`.
5. `git add -A && git commit -m "v0.3a.<n>: ..." && git tag v0.3a.<n>`.
Guards: never write `/root/Android` or `/root/.gradle`; never run the one-time
env setup scripts (`04-setup-android-sdk.sh`, `wrap-x86-binaries.sh`); if Gradle
is ever used, run with `GRADLE_USER_HOME=$PROJECT_DIR/.gradle-home --no-daemon`.
