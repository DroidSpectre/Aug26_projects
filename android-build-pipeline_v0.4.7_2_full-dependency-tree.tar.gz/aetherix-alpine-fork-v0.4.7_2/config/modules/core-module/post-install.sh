#!/bin/sh
# core-module post-install - install the shared base runtime that every other
# module depends on (hello/llm/help). The llama.cpp build toolchain belongs to
# llm-module (installed lazily by 'llm setup' inside need_llama). Idempotent.
MODULE_DIR=$(dirname "$0")
mkdir -p /etc/aetherix /etc/ssl/certs

# Hard dependencies: base runtime shared by every module. findutils/gawk lock
# GNU find/awk semantics for the awk-heavy llm tier (tavily_extract, json_val,
# docs ranking) - busybox awk/find are not behaviorally identical.
PKGS="bash coreutils ncurses-terminfo ca-certificates-bundle findutils gawk"
echo "installing core packages (needs internet, ~1-2 min)..."
apk add $PKGS || {
  echo "ERROR: apk add core packages failed (check internet/repo; retry 'module install core-module' or 'core setup')" >&2
  exit 1
}

# Optional dependencies - best effort; a failure here must not block the module.
echo "installing optional packages (best-effort): libomp..."
if apk add libomp >/dev/null 2>&1; then
  echo "  optional libomp OK"
else
  echo "  optional libomp skipped (OpenMP not available)"
fi

# FB-043: git/curl default their CA file to /etc/ssl/cert.pem; make it point at
# the installed bundle so TLS works even if SSL_CERT_FILE is not honored.
ln -sfn /etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem

# Deploy the core tier CLI (status/help) alongside the other module tiers.
mkdir -p /usr/local/bin
for f in "$MODULE_DIR"/tier/*; do
  [ -f "$f" ] || continue
  cp -f "$f" "/usr/local/bin/$(basename "$f")"
  chmod +x "/usr/local/bin/$(basename "$f")"
done
# v0.4.7: the CRT dropdown ships as tier/menu.sh; the Android category bar and
# System-menu items call `aetherix-menu <cat>`, so expose that name too.
ln -sfn menu.sh /usr/local/bin/aetherix-menu

echo "installed $(date -u +%Y-%m-%dT%H:%M:%SZ)" > /etc/aetherix/core-module.installed
GCCV=$(gcc --version 2>/dev/null | head -1 | awk '{print $3}')
CMV=$(cmake --version 2>/dev/null | head -1 | awk '{print $3}')
CLV=$(clang --version 2>/dev/null | head -1 | awk '{print $3}')
echo "core-module OK: shared base ready (gcc $GCCV, clang $CLV, cmake $CMV - toolchain owned by llm-module)"
