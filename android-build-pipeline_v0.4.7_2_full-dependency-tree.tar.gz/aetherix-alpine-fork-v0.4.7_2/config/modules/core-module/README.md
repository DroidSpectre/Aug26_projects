# core-module — shared base runtime (dependency module)

Ships inside the APK as `assets/modules/core-module.bundle` (gzip tar).
Regenerate all bundles with `scripts/build-modules.sh`.

Every other bundled module (`hello-module`, `llm-module`, `help-module`)
declares `requires: core-module` and is **not installable** until core-module
is installed. core-module's post-install installs the shared runtime via
Alpine:

- **Base:** `bash coreutils ncurses-terminfo ca-certificates-bundle`
- **GNU tools:** `findutils gawk` (the llm tier's awk/find parsing relies on
  GNU behavior; busybox applets are not identical)
- **Optional:** none — the llama.cpp build toolchain belongs to **llm-module**
  and is installed lazily by `llm setup` (via `need_llama`)

`linux-headers`, `build-base`, `cmake`, `clang`, `git`, `curl`,
`openssl-dev`, `ccache`, `ninja` are llm-module's dependencies, not this
module's. Keep module ownership one-to-one: each module installs what it
needs.

`aetherix-menu` (the CRT menu system) is deployed from this module's `tier/`
directory so every module install has the menu available.

## Install & use
- Dashboard > Modules & Storage -> Install `core-module` (first module to install)
- `core status` — verify the shared base
- `core setup` — reinstall the package set if it was removed
- `core help` — what this module provides

## Uninstall
Uninstall is refused while hello/llm/help modules are installed. Uninstall those
first, then core-module (Full Erase also removes the `core` CLI).
