#!/bin/sh
# core-module self-test - check the shared base runtime (run in terminal).
# The llama.cpp build toolchain is owned by llm-module and checked by
# llm-selftest; this module only asserts what core itself installs.
FAIL=0
pass() { echo "PASS  $1"; }
fail() { echo "FAIL  $1"; FAIL=$((FAIL+1)); }

echo "== core-module self-test =="
[ -f /etc/aetherix/core-module.installed ] && pass "core-module marker" || fail "core-module marker missing"
for c in bash coreutils find gawk awk; do
  command -v "$c" >/dev/null 2>&1 && pass "$c present" || fail "$c missing"
done
[ -r /etc/ssl/cert.pem ] && pass "TLS CA cert (/etc/ssl/cert.pem)" || fail "TLS CA cert missing"
command -v core >/dev/null 2>&1 && pass "core CLI" || fail "core CLI missing"
core status >/dev/null 2>&1 && pass "core status runs" || fail "core status failed"

echo ""
if [ "$FAIL" -eq 0 ]; then echo "ALL CHECKS PASSED"; exit 0; fi
echo "$FAIL CHECK(S) FAILED"; exit 1
