# core-module TESTPLAN

## Purpose
Bundles the shared dependency set every other module relies on: base runtime
packages plus the build toolchain (including `linux-headers`, which llama.cpp
requires to compile at all). Installed first; hello/llm modules declare
`requires: core-module` and are not installable until it is present.

## Depends on
- Alpine rootfs initialized (Steps 1-5 pass) - enforced by the app install path.

## Install check
1. Modules & Storage page: core-module shows as **Available**; hello/llm show
   **Blocked (requires: core-module)** until it is installed.
2. Install core-module - post-install runs `apk add` for the package set with
   progress, then optional libomp best-effort.
3. After install: `core status` reports OK; `module status` lists core-module.

## Package assertions (`core-selftest.sh`)
- `bash`, `coreutils`, `cmake`, `git`, `curl`, `gcc`, `ccache`, `ninja` on PATH
- `/usr/include/linux/limits.h` exists (linux-headers)
- `/etc/ssl/cert.pem` readable
- `openssl-dev` headers present
- `libomp` optional (NOTE not FAIL when absent)

## Regression checks
- Uninstall of core-module is refused by the app while hello/llm are
  installed (reverse-dependency guard).
- Reinstalling core-module is idempotent and fast (apk add already-satisfied).
