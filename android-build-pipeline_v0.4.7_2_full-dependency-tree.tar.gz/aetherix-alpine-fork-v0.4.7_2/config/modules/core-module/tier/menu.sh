#!/bin/sh
CAT="${1:-llm}"
# aetherix-menu - Aetherix-Alpine CRT dropdown menus (pure ANSI, ash-safe).
# Renders an adaptive item list for a category (llm|modules|files|system|help)
# as a boxed, top-docked menu on the alternate screen. Arrow keys move, Enter
# runs the highlighted command, Esc/q closes without running anything.
#
#   aetherix-menu [category]     interactive menu
#   aetherix-menu --items <cat>  non-interactive print: idx|label|command
#   aetherix-menu --selftest     sanity check (exit 0)
set -u

AMBER='\033[38;5;214m'
GREEN='\033[38;5;82m'
DIM='\033[38;5;239m'
INV='\033[7m'
RST='\033[0m'
ESC=$(printf '\033')

# ---- adaptive state (shared by --items and interactive mode) ----

server_running() { pgrep -f llama-server >/dev/null 2>&1; }
build_running()  { pgrep -f 'llm-build' >/dev/null 2>&1 || pgrep -f 'cmake --build' >/dev/null 2>&1; }
module_installed() { [ -f "/etc/aetherix/$1-module.installed" ]; }
tavily_key_set()  { [ -s /etc/aetherix/tavily.key ]; }

MODS=""
for _m in core hello llm help; do
  if module_installed "$_m"; then MODS="$MODS $_m"; fi
done
[ -n "$MODS" ] || MODS=" none"

# app request channel: the Android app polls /etc/aetherix/app.request; write
# one of close|exit|copy|clear to trigger the matching terminal action.
app_req() { printf '%s\n' "$1" > /etc/aetherix/app.request 2>/dev/null; }

# ---- item lists: one 'idx|label|command' per line, re-evaluated per draw ----

items_llm() {
  if server_running; then
    echo "1|Stop the AI server|llm stop"
  else
    echo "1|Start the AI server|llm start"
  fi
  echo "2|Chat (interactive)|llm chat"
  echo "3|Ask one question|llm chat --once"
  echo "4|AI status + profile|llm status"
  echo "5|AI capabilities|llm capabilities"
  echo "6|AI context snapshot|llm context"
  if tavily_key_set; then
    echo "7|Web search test (key set)|llm chat --web --test"
  else
    echo "7|Web search (no Tavily key)|llm chat --web status"
  fi
  echo "8|Download a model (hf)|llm hf"
  echo "9|Recent replies / export|llm replies"
  echo "10|LLM help|llm help"
}

items_modules() {
  echo "1|Shared base status|core status"
  echo "2|Module system help|module help"
  echo "3|Reinstall core packages|core setup"
  echo "4|Installed modules:$MODS|module list"
  echo "5|LLM module help|llm help"
  echo "6|Help module cards|llm context"
}

items_files() {
  echo "1|I/O dropbox env|io env"
  echo "2|INPUT dropbox (user files)|io in"
  echo "3|OUTPUT dropbox (exports)|io out /root/storage/output"
  echo "4|Map device storage|sd mount"
  echo "5|Storage map / paths|sd env"
  echo "6|Prune old exports (30d)|io clean"
}

items_system() {
  if server_running; then
    echo "1|AI server: RUNNING (llm status)|llm status"
  else
    echo "1|AI server: stopped (llm start)|llm start"
  fi
  if build_running; then
    echo "2|Build: RUNNING (llm build-status)|llm build-status"
  else
    echo "2|Build: idle (llm build-status)|llm build-status"
  fi
  echo "3|Environment self-test|aetherix-selftest"
  echo "4|Quick smoke test|aetherix-smoke"
  echo "5|ADB elevation (shell)|elv setup && elv shell"
  echo "6|Copy terminal screen|appreq copy"
  echo "7|Clear terminal screen|appreq clear"
  echo "8|Close terminal (keep running)|appreq close"
  echo "9|Exit terminal (end session)|appreq exit"
}

items_help() {
  echo "1|Module system help|module help"
  echo "2|LLM help|llm help"
  echo "3|LLM context + card map|llm context"
  echo "4|Find a help doc|llm docs find"
  echo "5|Version / changelog|cat /etc/aetherix/core-module.installed"
  echo "6|Full help corpus|llm docs find help"
}

items() { # $1 = category
  case "$1" in
    llm) items_llm ;;
    modules) items_modules ;;
    files) items_files ;;
    system) items_system ;;
    help) items_help ;;
    *) echo "1|Menu help (categories: llm modules files system help)|aetherix-menu help" ;;
  esac
}

# ---- non-interactive modes (used by tests and scripts) ----

if [ "${1:-}" = "--items" ]; then
  items "${2:-llm}"
  exit 0
fi
if [ "${1:-}" = "--selftest" ]; then
  for c in stty dd pgrep printf; do
    command -v "$c" >/dev/null 2>&1 || { echo "missing: $c" >&2; exit 1; }
  done
  n=$(items "${2:-llm}" | wc -l | tr -d ' ')
  [ "$n" -ge 1 ] || { echo "no items for ${2:-llm}" >&2; exit 1; }
  echo "aetherix-menu selftest OK ($n items for ${2:-llm})"
  exit 0
fi

# ---- interactive mode ----

TTY=/dev/tty
[ -r "$TTY" ] || TTY=/dev/stdin
[ -e "$TTY" ] || { echo "aetherix-menu: no tty (use --items for listings)" >&2; exit 1; }

trap 'printf "%b" "${RST}${ESC}[?25h${ESC}[?1049l"; stty sane 2>/dev/null; exit 1' INT TERM HUP

read_key() {
  b=$(dd bs=1 count=1 < "$TTY" 2>/dev/null)
  case "$b" in
    "$ESC")
      r1=$(dd bs=1 count=1 < "$TTY" 2>/dev/null)
      [ "$r1" = "[" ] || { echo esc; return; }
      r2=$(dd bs=1 count=1 < "$TTY" 2>/dev/null)
      case "$r2" in
        A) echo up ;;
        B) echo down ;;
        C) echo right ;;
        D) echo left ;;
        *) echo other ;;
      esac
      ;;
    "$(printf '\n')"|"$(printf '\r')") echo enter ;;
    q|Q) echo q ;;
    *) echo "$b" ;;
  esac
}

items "$CAT" > /tmp/aetherix-menu.items 2>/dev/null || exit 2
total=$(wc -l < /tmp/aetherix-menu.items | tr -d ' ')
[ "${total:-0}" -ge 1 ] || { echo "aetherix-menu: no items for '$CAT'" >&2; exit 2; }

sel=1
printf '%b' "${ESC}[?1049h"
stty raw -echo min 1 time 0 < "$TTY" 2>/dev/null
printf '%b' "${ESC}[?25l"

while :; do
  printf '%b' "${ESC}[2J${ESC}[H"
  printf '%b' "${AMBER}AETHERIX-ALPINE  ${GREEN}menu / ${CAT}${RST}\n"
  printf '%b' "${DIM}modules:${MODS}${RST}\n"
  i=1
  while IFS='|' read -r idx label cmd; do
    [ -n "$idx" ] || continue
    if [ "$i" -eq "$sel" ]; then
      printf '%b' "${INV}${AMBER}  ${label}  ${RST}\n"
    else
      printf '%b' "${GREEN}  ${label}${RST}\n"
    fi
    i=$((i+1))
  done < /tmp/aetherix-menu.items
  printf '%b' "${DIM}up/down move -- enter run -- esc/q close${RST}\n"

  k=$(read_key)
  case "$k" in
    up) [ "$sel" -gt 1 ] && sel=$((sel-1)) ;;
    down) [ "$sel" -lt "$total" ] && sel=$((sel+1)) ;;
    enter)
      line=$(sed -n "${sel}p" /tmp/aetherix-menu.items 2>/dev/null)
      cmd=$(printf '%s' "$line" | cut -d'|' -f3-)
      printf '%b' "${RST}${ESC}[?25h${ESC}[?1049l"
      stty sane < "$TTY" 2>/dev/null
      case "$cmd" in
        appreq\ *) app_req "$(printf '%s' "$cmd" | cut -d' ' -f2)" ;;
        *) sh -c "$cmd" ;;
      esac
      exit 0
      ;;
    esc|q) break ;;
    *) : ;;
  esac
done

printf '%b' "${RST}${ESC}[?25h${ESC}[?1049l"
stty sane < "$TTY" 2>/dev/null
exit 0
