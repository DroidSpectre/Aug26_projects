# help-module

Curated help + project documentation corpus for the llm tier.

## What it ships

- `/etc/aetherix/help/*.md` - condensed corpus: welcome, terminal, modules,
  package inventory, llm usage, help system, Alpine-under-PRoot caveats,
  version history, bug register, troubleshooting.
- A keyword index (`/etc/aetherix/help/.index`) rebuilt on install.

## Usage (commands live in the llm tier)

- `llm docs find <terms>` - search the corpus (top 5 docs, matched lines)
- `llm docs add <dir>` - copy your own `.md`/`.txt` docs into
  `/etc/aetherix/help/user/<name>/`; they become searchable immediately
- `llm chat --docs <question>` - one-shot answer from the corpus (citations)

The universal router uses this corpus for option B (docs) on every `llm chat` turn.

## Install order

## Knowledge cards (v1.2.0)

The module also ships a set of tool-tip style **data cards**
(`docs/cards/`, 59 cards) designed for the on-device model: a small-world
network of interlinked summaries (start at `00 HOME`, follow `RELATED`,
answers within 6 hops, `DEEP:` lines point at the full docs). Post-install
deploys them to `/etc/aetherix/help/cards/`; the llm tier's `llm docs find`
scans them automatically and `llm context` advertises them.

core-module -> llm-module -> help-module
