# Help system (help-module)

'help-module' ships a curated corpus to /etc/aetherix/help/ that the llm uses
to answer help questions with citations - no more hunting through individual
help commands.

## Commands
- llm docs find <terms>   top 5 matching corpus docs + matched lines
- llm docs add <dir>      copy your .md/.txt files into
                          /etc/aetherix/help/user/<name>/ (searchable at once)
- llm chat --docs <question>  one-shot answer from the corpus with source
                          citations; the interactive chat can also pick
                          option B (docs) on any turn

## Auto-routing (v0.4.6)
Every llm chat turn runs the universal router: one letter per hop
(A web / B docs / C file / D knowledge / E terminal / F final). The docs
hop pulls the top corpus snippets (capped ~6KB) into the prompt together
with the terminal context snapshot and recent chat history; web hops run
Tavily searches and synthesize with numbered citations [n].

## Context awareness
The app writes the last ~40 terminal lines to /etc/aetherix/term.context on
resume/resize; 'llm context' shows it plus pwd, tty size, core/mods/jobs
state, storage map, and server state. Chat prompts inject this so replies
fit what the user is actually doing.
