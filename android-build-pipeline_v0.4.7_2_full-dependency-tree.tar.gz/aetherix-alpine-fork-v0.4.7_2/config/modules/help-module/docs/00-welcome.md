# Welcome

Aetherix-Alpine runs a real Alpine Linux userland on your Android phone
inside PRoot - no root required. The app provides the 7-step setup, the
terminal (PTY bridge), storage access, and a module system.

## First steps after install
- `sd mount`        expose device storage at ~/storage (needs All-files access)
- `module status`   list installed modules
- `aetherix-selftest`  run environment checks (hello-module)
- `core status`     shared base + toolchain state
- install modules: Dashboard > Modules & Storage (install order matters)

## Storage model
The app binds storage under /mnt (internal = /mnt/sdcard, removable =
/mnt/sd-extN, USB = labelled "usb" when detected) and mirrors it into
~/storage/{shared,downloads,dcim,documents,music,movies,pictures} plus
external/externalN/usb links. "sd mount" refreshes the tree; the app rebuilds
it on every start.

## Versions
Version scheme: the fork line is v0.4.x (core-stable). Modules carry their own
versions and update separately from the app. gui-module was archived at
v0.3a.14_13 and is no longer bundled.
