# CARD 46 · TROUBLE-TERMINAL — Terminal/app problem solver
TAG: troubleshooting
WHAT: Symptom → fix for terminal and app-level quirks.
WHY: These look scary but are mostly benign or fixed.
KEYS:
- Rendering lag on start → initial device profiling; wait a few seconds.
- Screen blackout during deep processing → CPU-only by design; wake lock keeps it alive; lower LLM_JOBS if thermal.
- First typed digit eaten (BT keyboard) → prompt warmup; wait for the cursor.
- App killed → relaunch notice + fresh shell reopen (marker-based recovery).
- Session "lost" after switching apps → normally it's preserved; if closed to dashboard it ends.
USE:
- Still broken? → Dashboard → Report (41 REPORTING).
RELATED: 43 TROUBLESHOOTING, 13 TERMINAL-TIPS, 41 REPORTING, 47 ENV-LIMITS
DEEP: config/modules/help-module/docs/90-troubleshooting.md (Terminal / app)


