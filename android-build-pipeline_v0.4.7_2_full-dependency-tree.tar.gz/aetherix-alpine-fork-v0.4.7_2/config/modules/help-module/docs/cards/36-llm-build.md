# CARD 36 · LLM-BUILD — Build logs and status
- The toolchain is installed by llm-module on first `llm setup` (core-module is base-only since v0.4.7 - 21 CORE-MODULE).
TAG: llm
WHAT: Tools to watch and recover the llama-server build.
WHY: Builds are long; knowing state and logs prevents panic.
KEYS:
- llm build-log [n] → tail of the build log (/var/log/llm-build.log).
- llm build-status → state (idle/building), STALE detection (dead build), thermal zones + cgroup hint.
- llm build-restart → resume from where it stopped (stale state auto-restarts on setup).
- llm build-log export → copies the log into the OUTPUT dropbox (v0.4.3; 3rd arg overrides target).
- llm build-status also prints the compiler, OpenMP state, resolved -march (+fp16 when the CPU advertises fphp/asimdhp) and the cmake probe results (v0.4.4).
- Detached build survives screen-off/resizes; ccache makes restarts fast.
USE:
- build state: building (STALE) → llm build-restart.
RELATED: 25 LLM, 27 LLM-SETUP, 18 JOBS, 17 IO-DROPBOX, 44 TROUBLE-LLM
DEEP: docs/BUGS.md (FB-060, FB-064, FB-065), docs/v0.4.3/README.md (FB-111), docs/v0.4.4/README.md (FB-117/118), docs/v0.4.7/REPORT.md (FB-126)


