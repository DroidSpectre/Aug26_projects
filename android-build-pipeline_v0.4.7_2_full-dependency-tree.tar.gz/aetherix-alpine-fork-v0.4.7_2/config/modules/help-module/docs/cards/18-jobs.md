# CARD 18 · JOBS — Background tasks with progress
TAG: storage
WHAT: A job runner that detaches long tasks (installs, builds, downloads) so the prompt returns immediately.
WHY: Long tasks used to flood the terminal; now they run in the dock with progress bars.
KEYS:
- job run <id> <command...> | job list | job stop <id> | job log <id> [lines].
- State files: /etc/aetherix/jobs/<id>.state (id/status/task/cur/tot/pct/pid).
- The dock stacks up to 5 jobs; apk (N/M) and cmake [N/M] markers become progress bars.
- Model downloads (llm hf get) and AI builds route through the job runner.
USE:
- job run my-download sh /opt/aetherix/llm-hf-dl.sh <repo> <file>
RELATED: 14 DOCK, 25 LLM, 28 LLM-MODELS, 36 LLM-BUILD
DEEP: docs/BUGS.md (FB-088), docs/v0.4.0/README.md


