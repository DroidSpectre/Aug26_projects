# CARD 07 · INSTALL — Getting the app onto the phone
TAG: setup
WHAT: The APK is self-signed, so Samsung only allows install via ADB from a computer.
WHY: This is Samsung policy, not an app limitation — worth explaining calmly.
KEYS:
- Requirements: Samsung phone, Developer Mode, USB debugging on, a computer with adb.
- Command: adb install Aetherix-Alpine-v0.4.3.apk
- Package id: com.aetherix.alpine.a (installs side-by-side with the original app).
- After install: open the app, then run the wizard (08 WIZARD).
USE:
- adb install path/to/Aetherix-Alpine-v0.4.3.apk
CAUTION:
- "Install blocked by Play Protect" — use "Install anyway" / allow unknown sources for this session.
RELATED: 06 SETUP, 08 WIZARD, 52 LICENSE
DEEP: research/Atherix-Alpine_explained/Atherix-Alpine_explained.md (How to Get It), FORK-NOTES.md


