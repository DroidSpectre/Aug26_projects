# Aetherix-Alpine — Data Cards (small-world knowledge set)

A compact, interlinked card set designed for the **on-device in-app model**.
Every card is a self-contained "tool tip" the model can read in seconds and
reason from. The set is deliberately built as a **small-world network** so the
model can answer almost any project question by following links — in **six hops
or fewer**.

## Why cards instead of raw docs

Raw documentation is long, redundant, and inconsistently structured — small
phone models lose accuracy when prompted from it. Cards fix that:

- One idea per card, capped at ~25 lines.
- A rigid schema the model can parse reliably (WHAT/WHY/KEYS/USE/CAUTION).
- Explicit links (`RELATED:`) instead of prose cross-references.
- Hubs (`TAG: hub`) that keep average path length tiny.

## Small-world design

The graph has 59 nodes. **Twelve hubs** (00 HOME, 06 SETUP, 11 TERMINAL,
15 STORAGE, 19 MODULES, 25 LLM, 38 APP, 43 TROUBLESHOOTING, 48 RESEARCH,
56 CAPABILITIES, 57 TERM-TOOLS, 58 MENU) anchor 12 clusters. Properties:

- **High clustering** — every card links to its hub and 3–5 neighbors.
- **Short paths** — leaf → hub → hub → leaf is at most 3 hops; cross-cluster
  questions route through 00 HOME for a worst case of ~4–5 hops. The 6-hop
  guarantee always holds.
- **Hub-and-spoke** — hubs carry the navigation, leaves carry facts.

## Card schema

```
# CARD <NN> · <NAME> — <title>
TAG: hub|<cluster>        # which cluster it anchors
WHAT: one-line definition
WHY: why it exists / when to reach for it
KEYS: 3-6 bullet facts (ground truth)
USE:  commands / steps (only on actionable cards)
CAUTION: watch-outs (only where they exist)
RELATED: <NN> <NAME>, <NN> <NAME>   # navigation links
DEEP: path/to/raw-doc.md  # where to fetch full detail
```

## How the model should use the set

1. Start at **00 HOME** (or the most obviously-matching hub).
2. Read the card; if it doesn't answer, follow one `RELATED` link.
3. Prefer the card's `KEYS` as ground truth over memory; never invent CLI
   flags or versions that aren't in a card.
4. If the question spans clusters, jump via the hub (e.g., 25 LLM ↔ 17
   IO-DROPBOX happens through 15 STORAGE or 35 LLM-REPLIES).
5. Depth: cards summarize — for exact bug IDs and versions, defer to
   `docs/BUGS.md` and 50 VERSIONING (the source of truth).
6. **`DEEP:`** tells you where the raw source lives. Fetch it when a question
   needs exact detail (full bug rows, package lists, research methodology).
   Cards are the index; raw docs are the pages.

## Card index (59)

| ID | Card | Cluster |
|----|------|---------|
| 00 | HOME | hub |
| 01 | WHAT-IS | overview |
| 02 | WHY-KNOX | overview |
| 03 | HOW-IT-WORKS | overview |
| 04 | HISTORY | overview |
| 05 | LIMITATIONS | overview |
| 06 | SETUP | hub |
| 07 | INSTALL | setup |
| 08 | WIZARD | setup |
| 09 | PERMISSIONS | setup |
| 10 | FACTORY-RESET | setup |
| 11 | TERMINAL | hub |
| 12 | TERMINAL-BASICS | terminal |
| 13 | TERMINAL-TIPS | terminal |
| 14 | DOCK | terminal |
| 15 | STORAGE | hub |
| 16 | STORAGE-TIER | storage |
| 17 | IO-DROPBOX | storage |
| 18 | JOBS | storage |
| 19 | MODULES | hub |
| 20 | MODULE-SYSTEM | modules |
| 21 | CORE-MODULE | modules |
| 22 | HELLO-MODULE | modules |
| 23 | LLM-MODULE | modules |
| 24 | HELP-MODULE | modules |
| 25 | LLM | hub |
| 26 | LLM-OVERVIEW | llm |
| 27 | LLM-SETUP | llm |
| 28 | LLM-MODELS | llm |
| 29 | LLM-ASK | llm |
| 30 | LLM-CHAT | llm |
| 31 | LLM-WEB | llm |
| 32 | LLM-TASK | llm |
| 33 | LLM-CONTEXT | llm |
| 34 | LLM-DOCS | llm |
| 35 | LLM-REPLIES | llm |
| 36 | LLM-BUILD | llm |
| 37 | MODEL-PROFILES | llm |
| 38 | APP | hub |
| 39 | DASHBOARD | app |
| 40 | HARDWARE-CARD | app |
| 41 | REPORTING | app |
| 42 | ELEVATION | app |
| 43 | TROUBLESHOOTING | hub |
| 44 | TROUBLE-LLM | troubleshooting |
| 45 | TROUBLE-STORAGE | troubleshooting |
| 46 | TROUBLE-TERMINAL | troubleshooting |
| 47 | ENV-LIMITS | troubleshooting |
| 48 | RESEARCH | hub |
| 49 | ARCHITECTURE | research |
| 50 | VERSIONING | research |
| 51 | BUG-REGISTER | research |
| 52 | LICENSE | research |
| 53 | PACKAGE-INVENTORY | research |
| 54 | FORK-PROVENANCE | research |
| 55 | BREAKTHROUGH-METHOD | research |
| 56 | CAPABILITIES | llm |
| 57 | TERM-TOOLS | hub |
| 58 | MENU | hub |

## Deployment note

The cards live under `config/modules/help-module/docs/cards/`. Wiring them into
the help-module is **done**: post-install deploys them to
`/etc/aetherix/help/cards/`, the llm tier's `llm docs find` scans them
recursively, the router's file hop can fetch them (help-corpus allow-list),
and `llm context` advertises the hubs. Help-module v1.6.0 ships this (v0.4.7: module cleanup, CRT menus, 8k clamp).
