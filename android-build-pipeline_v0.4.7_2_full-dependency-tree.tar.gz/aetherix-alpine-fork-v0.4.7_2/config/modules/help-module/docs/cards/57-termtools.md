# CARD 57 · TERM-TOOLS — Gated terminal bridge (term_run)
TAG: hub
WHAT: Lets the AI run safe terminal commands itself: read/status commands auto-run, everything else asks the user first.
WHY: Small models can answer "how full is the disk?", "what processes are running?", or "list this folder" by checking the device directly instead of guessing — without giving the AI free rein over the phone.
KEYS:
- Offered as router option E in every llm chat turn and llm chat --task (56 CAPABILITIES). LLM_TERM=0 disables it.
- Auto-run (read-only/status allowlist): ls cat pwd df du ps free uname uptime echo printf grep wc stat file head tail find mount date id whoami env readlink which basename dirname realpath sha256sum; plus git status, git log, llm status, llm context, llm docs find.
- Everything else shows: "Run ...? [y/N]" — answered on-device; with no terminal (a prompt) it is declined instead.
- Refused outright: shell metacharacters (; | & ` $( ) > < * ? ~ { } [ ]), redirection, and destructive targets (rm -rf /, mkfs, dd to /dev, chmod -R /, reboot/poweroff, writes outside $HOME or OUTPUT).
- Output capped at 60 lines / 4 KB; commands run with a 30s timeout in $HOME.
USE:
- llm chat --task "how full is the disk?" → the router picks E, runs df, synthesizes the answer.
CAUTION:
- Read-only trust boundary: confirmation is per-command, never a blanket yes.
- Live scrollback is still not readable — only the ~40-line snapshot (33 LLM-CONTEXT).
RELATED: 25 LLM, 11 TERMINAL, 32 LLM-TASK, 56 CAPABILITIES, 33 LLM-CONTEXT
DEEP: docs/v0.4.5/README.md (FB-120), docs/v0.4.5/RESEARCH.md (Q5 terminal bridge)
