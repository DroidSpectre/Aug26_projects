# CARD 49 · ARCHITECTURE — How the pieces fit
TAG: research
WHAT: The app's layered design: Android app → launcher → PRoot → Alpine Linux → tiers.
WHY: Explains why things behave the way they do and where each feature lives.
KEYS:
- App (Java): dashboard, terminal, modules, storage seeder, PTY bridge (libpty-jni).
- Launcher: builds the PRoot command with bind mounts + env (AETHERIX_* vars).
- PRoot (libproot.so from nativeLibraryDir): translates Linux syscalls; PROOT_LOADER bridges musl binaries — never changes SELinux label.
- Alpine rootfs: real Linux userland (bash/apk/tools); /etc/aetherix holds app state.
- Tiers (CLIs in /usr/local/bin): sd, job, io, module, elv, llm, core, hello.
- Modules ship inside the APK as bundles; the core app is frozen.
USE:
- Trace a feature: terminal → tier CLI → module post-install → package.
RELATED: 48 RESEARCH, 03 HOW-IT-WORKS, 20 MODULE-SYSTEM, 15 STORAGE, 25 LLM, 55 BREAKTHROUGH-METHOD
DEEP: research/breakthrough-v0.1.0.md, docs/v0.3-series/aetherix-v0.3-series-device-layers-plan.md


