# CARD 02 · WHY-KNOX — Why normal Linux apps fail on Samsung
TAG: overview
WHAT: Samsung Knox adds stricter security checks that block the usual Linux-on-Android tricks used by apps like Termux.
WHY: Understanding this explains the app's core design and why it can run where others cannot.
KEYS:
- Android tags every running program with a security label (SELinux domain); Samsung Knox adds DEFEX + RKP guard layers.
- Termux changes its label (through the linker) to run Linux binaries — Knox catches this and kills the program.
- Corporate/GOV phones with Knox are common; that locked market is this app's home turf.
- The app never changes its label, so Knox's checks always pass (see 03 HOW-IT-WORKS).
USE:
- "Why doesn't Termux work on my Samsung?" → this card + 03 HOW-IT-WORKS.
RELATED: 01 WHAT-IS, 03 HOW-IT-WORKS, 49 ARCHITECTURE, 47 ENV-LIMITS, 55 BREAKTHROUGH-METHOD
DEEP: research/breakthrough-v0.1.0.md §2


