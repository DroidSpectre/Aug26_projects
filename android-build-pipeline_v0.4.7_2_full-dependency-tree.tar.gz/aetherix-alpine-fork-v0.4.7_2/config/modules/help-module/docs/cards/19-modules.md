# CARD 19 · MODULES — Modules cluster hub
TAG: hub
WHAT: Hub for the module system and each feature pack.
WHY: Modules are how the app ships features; install order and versions matter.
KEYS:
- Modules ship INSIDE the APK (assets/modules/*.bundle); nothing to sideload.
- Install order: core → hello → llm → help (dependency-aware).
- Each module has its own version and updates independently of the app.
- Commands: module available/install/reinstall/uninstall/help/deps/status.
- Current versions: core 1.2.0, hello 1.2.0, llm 1.5.0, help 1.1.0.
USE:
- "Why is X blocked?" → 20 MODULE-SYSTEM; "what does core do?" → 21 CORE-MODULE.
RELATED: 00 HOME, 20 MODULE-SYSTEM, 21 CORE-MODULE, 22 HELLO-MODULE, 23 LLM-MODULE, 24 HELP-MODULE
DEEP: docs/v0.3-series/core-vs-modules.md


