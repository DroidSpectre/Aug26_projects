# CARD 20 · MODULE-SYSTEM — How modules work
TAG: modules
WHAT: Optional feature packs that install into the Linux side, bundled in the APK and managed by the app.
WHY: Features ship as modules so the frozen core never changes.
KEYS:
- Bundle = gzip tar with module.yml (name/version/requires) + post-install.sh + tier CLIs.
- The app writes a bundled manifest (/etc/aetherix/bundled-modules.txt); module available lists only those.
- Install = validate → extract → bookkeeping → run post-install (async, progress streamed).
- Requires metadata gates installs (e.g., help requires llm; llm requires core).
- Reinstall overwrites; uninstall cleans both trees.
- The retired gui-module stays archived in config/archive/ (never listed).
USE:
- module available → shows ready/blocked/installed per module.
RELATED: 19 MODULES, 21 CORE-MODULE, 23 LLM-MODULE, 24 HELP-MODULE, 50 VERSIONING
DEEP: docs/v0.3-series/core-vs-modules.md, docs/BUGS.md (FB-057..FB-059)


