# CARD 55 · BREAKTHROUGH-METHOD — The technical trick, deeper
TAG: research
WHAT: The precise mechanism that lets Linux run on locked Knox: three SELinux blockers and the PROOT_LOADER answer.
WHY: For technical "how does it actually work" questions beyond the plain-language story.
KEYS:
- Blocker A: app data dirs cannot execute binaries (execute_no_trans removed since Android 10).
- Blocker B: the linker domain cannot execute outside /system (neverallow rule 76, amplified by Knox).
- Blocker C: Knox DEFEX blocks a ptrace'd execve that changes the security domain.
- Answer: run PRoot from nativeLibraryDir (apk_data_file → execute_no_trans) and STAY in untrusted_app.
- Alpine binaries are musl-linked (their interpreter is missing on Android) → PRoot routes them through PROOT_LOADER, also from nativeLibraryDir — no domain change.
- No domain transition → Knox's cross-domain check never fires.
- Reached after 24 build iterations (v0.0.1 → v0.1.0); v0.0.10–v0.0.22 document each failed path.
USE:
- Cite the chain: App Java → /system/bin/sh → libproot.so → PROOT_LOADER → Alpine /bin/sh.
RELATED: 48 RESEARCH, 49 ARCHITECTURE, 03 HOW-IT-WORKS, 02 WHY-KNOX, 47 ENV-LIMITS
DEEP: research/breakthrough-v0.1.0.md, research/project-report-v0.0.1-v0.2.0/project-report-v0.0.1-v0.2.0.md
