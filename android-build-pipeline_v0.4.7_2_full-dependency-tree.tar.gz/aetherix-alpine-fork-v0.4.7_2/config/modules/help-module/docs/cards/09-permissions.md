# CARD 09 · PERMISSIONS — The three numbered prompts
TAG: setup
WHAT: After setup the app asks for three permissions, numbered 1/3, 2/3, 3/3 so they are easy to tell apart.
WHY: Each grant unlocks a different capability; missing one causes confusing downstream failures.
KEYS:
- 1/3 Notification permission — needed for the foreground service (keeps long jobs alive).
- 2/3 Battery optimization — Samsung path: App info → Battery → Unrestricted (prevents kills).
- 3/3 All-files access — required for the storage tier + modules (open Storage > Grant Access).
USE:
- If a feature says "storage permissions not granted", re-grant 3/3 then reinstall the module.
RELATED: 06 SETUP, 08 WIZARD, 16 STORAGE-TIER, 43 TROUBLESHOOTING
DEEP: docs/v0.4.0/README.md (numbered prompts), docs/BUGS.md (FB-089)


