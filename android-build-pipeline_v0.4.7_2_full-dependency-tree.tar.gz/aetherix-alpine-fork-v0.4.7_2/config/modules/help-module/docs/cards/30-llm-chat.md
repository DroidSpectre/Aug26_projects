# CARD 30 · LLM-CHAT — Multi-turn conversation
TAG: llm
WHAT: An interactive back-and-forth chat; every turn routes itself through the universal letter menu.
WHY: Follow-up questions need the model to remember earlier turns - the router carries that history.
KEYS:
- Command: llm chat; exit with the word Exit or Ctrl-D (Exit-only convention).
- Keeps the last ~8 turns as compacted follow-up context for the router.
- Each turn gets its own hop budget (<=6 hops, small-world); the budget resets every turn.
- Same model/profile rules as --once; the profile reply cap applies.
USE:
- llm chat → type messages → Exit to end.
RELATED: 25 LLM, 29 LLM-ASK, 32 LLM-TASK, 14 DOCK, 35 LLM-REPLIES
DEEP: docs/BUGS.md (FB-082, FB-085, FB-101, FB-123)
