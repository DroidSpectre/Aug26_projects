# CARD 51 · BUG-REGISTER — Reading FB-### IDs
TAG: research
WHAT: Every fix has an ID (FB-###) recorded in docs/BUGS.md.
WHY: Support conversations cite IDs; knowing the pattern helps answer "was this fixed?"
KEYS:
- Format: FB-<n> | version | status | title | root cause | fix.
- Latest cluster: FB-109..FB-114 (v0.4.3): sparkle key, detached downloads, build speed, build-log export, replies/export/dock, I/O dropbox.
- v0.4.2: FB-103..FB-108 (profiles, context, router, agent, help corpus, ranking).
- v0.4.1: FB-098..FB-102 (apk add dup, download spam, sparkle label, Exit-only chat, Tavily).
- v0.4.0: FB-087..FB-097 (CPU probe, job dock, permissions, dashboard, modules).
- Environmental: ENV-001/ENV-002 (kernel limits, no fix).
USE:
- Search docs/BUGS.md for an ID to get the full root cause + fix.
RELATED: 48 RESEARCH, 04 HISTORY, 50 VERSIONING, 41 REPORTING
DEEP: docs/BUGS.md


