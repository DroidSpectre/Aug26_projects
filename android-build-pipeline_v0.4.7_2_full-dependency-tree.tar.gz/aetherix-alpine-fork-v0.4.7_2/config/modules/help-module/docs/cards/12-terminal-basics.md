# CARD 12 · TERMINAL-BASICS — Everyday terminal use
TAG: terminal
WHAT: A real bash shell inside Alpine Linux; type commands, get output, run long jobs safely.
WHY: The terminal is the interface to everything: packages, files, the AI, modules.
KEYS:
- Prompt is a normal Linux shell (bash); ctrl keys, tab completion, history work.
- Package manager: apk add/update/upgrade (Alpine).
- Useful first commands: sd (storage), module status, aetherix-selftest, llm status.
- Long-running commands can be detached with job (18 JOBS) so the prompt returns.
- Welcome banner shows installed modules + a cheatsheet.
USE:
- "how do I install python?" → apk add python3
RELATED: 11 TERMINAL, 13 TERMINAL-TIPS, 16 STORAGE-TIER, 19 MODULES, 25 LLM
DEEP: docs/v0.3-series/CHANGELOG.md, research/Atherix-Alpine_explained/Atherix-Alpine_explained.md


