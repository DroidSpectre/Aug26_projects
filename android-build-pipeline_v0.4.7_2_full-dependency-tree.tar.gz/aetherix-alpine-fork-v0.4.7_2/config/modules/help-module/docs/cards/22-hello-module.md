# CARD 22 · HELLO-MODULE — Self-test + storage/job helpers
TAG: modules
WHAT: Environment health checks and the shared helper CLIs (sd, job, io, module).
WHY: It keeps the system honest (selftest) and provides the everyday tooling.
KEYS:
- aetherix-selftest → exit 0 = all checks pass (18 checks incl. TLS, tty, binds).
- aetherix-smoke → quick SMOKE_OK of core flows.
- Tier CLIs: sd, job, io, module, elv are deployed here (post-install copies tier/* to /usr/local/bin).
- v1.2.0 added the io dropbox helper + sd env/input-output links.
- Self-heals helpers, ~/storage links, aliases, storage.state, device.conf from the bundle.
USE:
- Run aetherix-selftest when something feels broken.
RELATED: 19 MODULES, 16 STORAGE-TIER, 17 IO-DROPBOX, 18 JOBS, 43 TROUBLESHOOTING, 53 PACKAGE-INVENTORY
DEEP: docs/v0.3-series/package-inventory.md §E, docs/BUGS.md (FB-027)


