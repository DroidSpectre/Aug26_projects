# CARD 54 · FORK-PROVENANCE — Where this code came from
TAG: research
WHAT: The fork's origin, identity, and why it exists alongside the upstream project.
WHY: Explains the com.aetherix.alpine.a package and the two Aetherix apps a phone can show.
KEYS:
- Forked 2026-08-04 from the opencode-owned upstream tree (/root/android-dev-env) so work could continue without mutating it.
- Side-by-side install: applicationId com.aetherix.alpine.a (upstream uses com.aetherix.alpine) — both can be installed together.
- Own version line (v0.3a.x, then v0.4.x) and own export trees: /sdcard/Download/Aetherix-Alpine-Fork/ + per-version folders.
- The fork never touches the upstream /sdcard/Download/Aetherix-Alpine/ tree.
- Full origin story, compile state at snapshot, and policy: FORK-NOTES.md.
USE:
- "Why do I have two Aetherix apps?" → this card.
RELATED: 48 RESEARCH, 50 VERSIONING, 52 LICENSE, 04 HISTORY, 39 DASHBOARD
DEEP: FORK-NOTES.md
