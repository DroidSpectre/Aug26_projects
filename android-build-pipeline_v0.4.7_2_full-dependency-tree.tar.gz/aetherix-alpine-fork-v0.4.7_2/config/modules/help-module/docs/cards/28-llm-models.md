# CARD 28 · LLM-MODELS — Getting and selecting models
TAG: llm
WHAT: Small GGUF models downloaded from HuggingFace into ~/models/ and set active.
WHY: The right model is the difference between useful answers and nonsense on phone hardware.
KEYS:
- llm hf → curated menu of verified phone-friendly Q4 models (e.g., Qwen3-0.6B, Qwen2.5-0.5B/1.5B, SmolLM2-360M, Llama-3.2-1B, Gemma-3-1B).
- llm hf list <owner/repo> → list quant files; llm hf get <owner/repo> <file> → download.
- Downloads run DETACHED through the job dock (v0.4.3) — the prompt returns immediately.
- llm model ~/models/<file>.gguf → set active (idempotent re-link; no re-download if present).
- Profile mapping (ctx/batch/router-hops) is automatic per model name (37 MODEL-PROFILES); the floor is 8192 (16384 for 13B+), clamped down to the model's GGUF native window when smaller (37 MODEL-PROFILES).
USE:
- llm hf → pick a number → wait for the dock bar → llm start.
CAUTION:
- File size matters on low RAM; the menu models are tuned for this phone.
RELATED: 25 LLM, 26 LLM-OVERVIEW, 37 MODEL-PROFILES, 18 JOBS
DEEP: docs/BUGS.md (FB-068..FB-077), docs/v0.4.3/README.md, docs/v0.4.7/REPORT.md


