# CARD 13 · TERMINAL-TIPS — Quirks and workarounds
TAG: terminal
WHAT: Small behaviors that surprise users, and the fixes built in.
WHY: Most terminal "bugs" are known and mitigated — knowing them avoids dead ends.
KEYS:
- First typed digit with a BT keyboard can be eaten: the warm-up guard cancels its prime once you type — wait for the cursor.
- Toolbar: Copy All / Clear All; Clear wipes scrollback too.
- Switching apps returns to the live terminal (session is preserved); close to dashboard if you want to leave it.
- Screen blackout during deep AI processing: the wake lock keeps it alive; lower LLM_JOBS if thermal pressure.
- Resize storms / IME are handled; occasional stray spaces are cosmetic, not breaking.
RELATED: 11 TERMINAL, 14 DOCK, 27 LLM-SETUP, 46 TROUBLE-TERMINAL
DEEP: docs/BUGS.md (FB-036, FB-052, FB-067), docs/v0.4.0/REPORT.md §5


