# CARD 14 · DOCK — Reply window + job progress
TAG: terminal
WHAT: The panel above the keyboard that shows AI answers and background-job progress.
WHY: It keeps the terminal clean while the AI works and long jobs run.
KEYS:
- AI replies render in the dock (transcript), not the scrollback; sparkle ✨ toggles it.
- The dock auto-opens when the AI writes /etc/aetherix/dock.request (v0.4.3).
- Job rows stack up to 5: progress bar + [N/M] task + spinner; finished rows fade after ~20 s.
- Legacy states (build/download) render as dock rows too.
USE:
- ✨ key opens/closes the reply window; job list shows running jobs.
RELATED: 11 TERMINAL, 18 JOBS, 35 LLM-REPLIES, 29 LLM-ASK
DEEP: docs/BUGS.md (FB-081, FB-084, FB-086, FB-088)


