# CARD 11 · TERMINAL — Terminal cluster hub
TAG: hub
WHAT: Hub for everything about the terminal: using it, its quirks, and the dock.
WHY: The terminal is the app's main surface; most "how do I…" questions touch it.
KEYS:
- Native terminal view with a PTY bridge; resize-safe; scrollback; toolbar.
- Keys row: TAB ESC CTRL ALT arrows PASTE + sparkle ✨ (reply window).
- The dock shows AI replies and job progress (14 DOCK).
- Warm-up guard fixes the eaten-first-digit bug (13 TERMINAL-TIPS).
USE:
- Command questions: 12 TERMINAL-BASICS.
- Quirks/fixes: 13 TERMINAL-TIPS + 46 TROUBLE-TERMINAL.
RELATED: 00 HOME, 12 TERMINAL-BASICS, 13 TERMINAL-TIPS, 14 DOCK, 46 TROUBLE-TERMINAL
DEEP: docs/v0.4.0/REPORT.md §4, research/v0.2.11-revision-report.md


