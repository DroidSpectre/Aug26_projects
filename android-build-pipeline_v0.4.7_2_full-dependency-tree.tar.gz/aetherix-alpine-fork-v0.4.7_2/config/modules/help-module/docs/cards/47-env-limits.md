# CARD 47 · ENV-LIMITS — Environmental/Android limits
TAG: troubleshooting
WHAT: Limits imposed by the phone/kernel that the app works around or accepts.
WHY: Some "bugs" are environmental; knowing them prevents wasted fixes.
KEYS:
- ENV-001: Samsung kernel blocks TIOCSWINSZ/TIOCSIG → userspace resize bypass in place.
- ENV-002: /proc/stat denied for untrusted_app → some stats unavailable (no fix).
- Phantom process killer: background processes trimmed after ~30 s → wake lock + foreground service during long jobs.
- Loopback adb (elv) may be kernel-blocked → degrades gracefully.
- SELinux untrusted_app: no root paths; the app works WITHIN the sandbox by design.
USE:
- Explain "why can't it do X" with these when nothing is broken.
RELATED: 43 TROUBLESHOOTING, 05 LIMITATIONS, 02 WHY-KNOX, 42 ELEVATION
DEEP: docs/BUGS.md (ENV-001, ENV-002), research/breakthrough-v0.1.0.md §2


