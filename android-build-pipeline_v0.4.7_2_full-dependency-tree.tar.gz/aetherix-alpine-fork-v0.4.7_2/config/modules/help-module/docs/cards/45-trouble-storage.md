# CARD 45 · TROUBLE-STORAGE — Storage/permission problem solver
TAG: troubleshooting
WHAT: Symptom → fix for storage and module-install issues.
WHY: These usually trace back to permission or link state.
KEYS:
- "storage permissions not granted" / modules not listed → grant All-files (Dashboard → Storage → Grant Access), then reinstall.
- module blocked "install first: core-module" → install order: core → hello → llm → help.
- helpers missing in shell (sd/core/llm/io...) → reinstall the module (post-install re-deploys tier CLIs).
- exported file "not found" → exports go to Download/Aetherix-Alpine_OUTPUT; io env prints exact paths.
- INPUT file not in context → drop into Download/Aetherix-Alpine_INPUT or io in <path>; then llm context.
- Link drift → sd mount re-derives the ~/storage tree (single source of truth).
RELATED: 43 TROUBLESHOOTING, 16 STORAGE-TIER, 17 IO-DROPBOX, 19 MODULES, 09 PERMISSIONS
DEEP: config/modules/help-module/docs/90-troubleshooting.md (Modules)


