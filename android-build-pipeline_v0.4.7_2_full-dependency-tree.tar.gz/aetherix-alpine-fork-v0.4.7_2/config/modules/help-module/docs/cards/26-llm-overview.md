# CARD 26 · LLM-OVERVIEW — What the AI is
TAG: llm
WHAT: A small AI model (llama.cpp) that runs entirely on the phone, answering about your system, files, and the web.
WHY: Privacy: nothing leaves the device; the model is chosen to fit phone RAM/CPU.
KEYS:
- Server: llama-server, OpenAI-compatible, listens ONLY on 127.0.0.1:8080.
- Models: GGUF files in ~/models/ (download with llm hf; select with llm model).
- Replies appear in the dock; every reply is also saved (35 LLM-REPLIES).
- Universal router (v0.4.6): EVERY model uses the same hardwired letter menu (A web / B docs / C file / D knowledge / E terminal / F final); bigger models get bigger context windows (37 MODEL-PROFILES).
- Default reply cap: 512 tokens (LLM_MAX_TOKENS override).
- Speed: roughly a few words/second on the recommended Q4 models.
USE:
- llm status → server state + active model + profile (ctx/batch/hops).
RELATED: 25 LLM, 23 LLM-MODULE, 28 LLM-MODELS, 29 LLM-ASK, 05 LIMITATIONS
DEEP: docs/v0.4.0/REPORT.md §4, docs/v0.4.3/README.md, docs/v0.4.4/README.md


