# CARD 10 · FACTORY-RESET — Start over cleanly
TAG: setup
WHAT: A true reset that wipes the Linux system, PRoot files, markers, prefs, and logs.
WHY: Use it when setup is broken beyond repair or you want a fresh environment.
KEYS:
- Kills proot, wipes rootfs/proot/sdk + the setup marker, clears prefs/logs.
- Dashboard: Reset & Reinstall — always the bottom-most button; it asks for confirmation.
- After reset you re-run the full wizard (08 WIZARD).
CAUTION:
- This removes installed modules and models too — export what you need first (17 IO-DROPBOX).
RELATED: 06 SETUP, 08 WIZARD, 17 IO-DROPBOX, 43 TROUBLESHOOTING
DEEP: docs/BUGS.md (FB-024)


