# CARD 40 · HARDWARE-CARD — Device info at a glance
TAG: app
WHAT: Shows phone model, RAM (with free/cached breakdown), battery, GPU make/model, storage.
WHY: Useful for support and for explaining what the AI can run.
KEYS:
- GPU: make + model from cached EGL identity (no polling; vendor fallbacks).
- RAM: availMem + free/cached sub-line from /proc/meminfo.
- Battery: Samsung-aware path; optimization prompt wording matches App info → Battery → Unrestricted.
- Card is collapsible; stays collapsed across refreshes.
CAUTION:
- Some device props report unknown under PRoot (guest can't read Android props) — device.conf bridges what it can.
RELATED: 38 APP, 41 REPORTING, 05 LIMITATIONS, 47 ENV-LIMITS
DEEP: docs/BUGS.md (FB-031), docs/v0.4.0/REPORT.md §1


