# CARD 38 · APP — App/dashboard cluster hub
TAG: hub
WHAT: Hub for the Android app itself: dashboard, hardware info, reporting, elevation.
WHY: Questions about buttons, settings, and app behavior live here.
KEYS:
- Dashboard (39 DASHBOARD): install-first, then actions once verified.
- Hardware card (40 HARDWARE-CARD): phone model, RAM, battery, GPU.
- Error reporting + logs (41 REPORTING).
- Elevation tier (42 ELEVATION): optional loopback adb (foundation).
USE:
- "Where is X button?" → 39 DASHBOARD.
- "How do I report a bug?" → 41 REPORTING.
RELATED: 00 HOME, 39 DASHBOARD, 40 HARDWARE-CARD, 41 REPORTING, 42 ELEVATION
DEEP: docs/v0.4.0/README.md, docs/v0.4.1/README.md


