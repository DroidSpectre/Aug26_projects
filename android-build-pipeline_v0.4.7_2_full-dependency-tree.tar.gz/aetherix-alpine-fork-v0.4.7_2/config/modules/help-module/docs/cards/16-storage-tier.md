# CARD 16 · STORAGE-TIER — The sd helper and ~/storage tree
TAG: storage
WHAT: A CLI (sd) plus symlinks that connect the Linux side to your phone's real folders.
WHY: Without it, Linux can't see your Downloads, photos, or USB drives.
KEYS:
- ~/storage/shared = main shared storage; ~/storage/downloads; removable volumes as external*/usb.
- sd list | sd ext | sd ls <path> | sd cp <src> <dst> | sd mount (re-derives links).
- Bash aliases: storage, shared, external, usb → cd shortcuts.
- sd is the single source of truth for the storage map (no drifting links).
- Requires All-files access granted (09 PERMISSIONS).
USE:
- sd cp /sdcard/Download/foo.txt ~/storage/input/   (see 17 IO-DROPBOX)
RELATED: 15 STORAGE, 09 PERMISSIONS, 17 IO-DROPBOX, 22 HELLO-MODULE, 45 TROUBLE-STORAGE
DEEP: docs/BUGS.md (FB-062), docs/v0.3-series/CHANGELOG.md (v0.3.2)


