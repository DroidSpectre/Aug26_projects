# CARD 01 · WHAT-IS — The project in one tool-tip
TAG: overview
WHAT: Aetherix-Alpine is an Android app giving you a real Linux terminal and a private, on-device AI assistant on a locked Samsung phone — no root.
WHY: Built because normal Linux-on-phone apps (Termux) are blocked by Samsung Knox on most corporate/government devices.
KEYS:
- Install like any app (via ADB, because it is self-signed); run a 7-step setup; get a full Linux environment.
- Alpine Linux provides bash, a package manager (apk), and hundreds of installable tools.
- The AI (llama.cpp) runs entirely on the phone's CPU; nothing leaves the device.
- The app creates an INPUT/OUTPUT dropbox in Downloads so you can hand files to the AI and export reports.
USE:
- First-time questions about the project start here.
RELATED: 02 WHY-KNOX, 03 HOW-IT-WORKS, 05 LIMITATIONS, 06 SETUP, 25 LLM
DEEP: README.md, research/Atherix-Alpine_explained/Atherix-Alpine_explained.md


