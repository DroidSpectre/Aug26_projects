# CARD 03 · HOW-IT-WORKS — The "back door" explained
TAG: overview
WHAT: The app runs Linux through a door every app is allowed to use, so Samsung's guards never see anything suspicious.
WHY: This one insight — proven after 24 failed experiments — is what makes the whole project possible.
KEYS:
- PRoot is a translator: it converts Linux file/process requests into Android-allowed operations.
- PRoot runs from the app's native-library folder (apk_data_file label), keeping the SAME security label the whole time.
- Alpine's Linux programs use a different C library (musl), so PRoot routes them through its loader — also from the same allowed folder.
- The process never changes security label → Samsung Knox's cross-label check never triggers.
- Result: full Linux + on-device AI, no root, no bootloader unlock.
USE:
- Explain it simply: "the app never changes its badge, so the guards let it pass."
RELATED: 01 WHAT-IS, 02 WHY-KNOX, 49 ARCHITECTURE, 52 LICENSE, 55 BREAKTHROUGH-METHOD
DEEP: research/breakthrough-v0.1.0.md §4, research/Atherix-Alpine_explained/Atherix-Alpine_explained.md


