# CARD 21 · CORE-MODULE — The shared base
TAG: modules
WHAT: Installs the shared base every other module depends on (shell, TLS, text tools) — no heavy build toolchain.
WHY: Modules stay single-purpose: core is the base, llm-module owns the llama.cpp build tools.
KEYS:
- Packages (v0.4.7): bash, coreutils, ncurses-terminfo, ca-certificates-bundle, findutils, gawk (+ best-effort libomp).
- findutils/gawk lock GNU find/awk semantics for the llm tier (busybox versions differ).
- The llama.cpp toolchain lives in llm-module (27 LLM-SETUP): build-base, clang, cmake, git, curl, linux-headers, openssl-dev, ccache, ninja.
- Installs /etc/ssl/cert.pem symlink so git/curl TLS works.
- Post-install is idempotent and re-run safe.
USE:
- core status → prints toolchain versions (gcc, clang, cmake).
RELATED: 19 MODULES, 20 MODULE-SYSTEM, 27 LLM-SETUP, 23 LLM-MODULE, 53 PACKAGE-INVENTORY
DEEP: docs/v0.4.7/REPORT.md (module cleanup), docs/v0.3-series/package-inventory.md §C


