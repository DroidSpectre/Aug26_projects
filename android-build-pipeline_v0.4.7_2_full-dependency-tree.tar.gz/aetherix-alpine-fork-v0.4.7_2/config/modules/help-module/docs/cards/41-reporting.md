# CARD 41 · REPORTING — Error reports and logs
TAG: app
WHAT: Built-in way to capture app/terminal problems and share them for support.
WHY: Structured reports (last-100-lines log + component status) beat screenshots.
KEYS:
- Dashboard → Settings → Report (or Share) → exports an Error Report.
- Report includes: app version, device/Android/kernel, component status table, module readiness, last 100 log lines.
- BridgeLogBuffer captures deploy/tier failures (visible in the report).
- View Log button toggles the log section (View Log / Hide Log).
USE:
- "App not responding / APK problem" → screenshot + Error Report, share it.
RELATED: 38 APP, 40 HARDWARE-CARD, 44 TROUBLE-LLM, 46 TROUBLE-TERMINAL
DEEP: docs/v0.4.0/REPORT.md §3, docs/BUGS.md


