# CARD 08 · WIZARD — The 7-step first-time setup
TAG: setup
WHAT: A one-time wizard that extracts the Linux system and verifies everything works (needs internet).
WHY: Steps run in order and each must pass before the next; the dashboard shows live progress.
KEYS:
- 1 Install PRoot binary + support libraries (seconds).
- 2 Extract the Alpine Linux rootfs + CA certificates (~5 s).
- 3 Run diagnostics: SELinux, shell, proot, writability, rootfs integrity, networking.
- 4 Create the PRoot launcher script (bind mounts config).
- 5 apk update/upgrade + base packages (~1–2 min, internet).
- 6 Test the PTY bridge (fork/PTY/exec pipeline).
- 7 Test & verify: full shell test + version self-test.
USE:
- All 7 steps must show "tested" before the terminal unlocks.
CAUTION:
- Step 5 needs internet; failure → check network, retry (idempotent).
RELATED: 06 SETUP, 07 INSTALL, 09 PERMISSIONS, 10 FACTORY-RESET, 43 TROUBLESHOOTING
DEEP: docs/v0.4.0/REPORT.md §3, research/Atherix-Alpine_explained/Atherix-Alpine_explained.md


