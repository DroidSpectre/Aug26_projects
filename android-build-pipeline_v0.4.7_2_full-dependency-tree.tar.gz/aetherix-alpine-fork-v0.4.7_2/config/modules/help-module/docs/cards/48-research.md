# CARD 48 · RESEARCH — Deep-dive cluster hub
TAG: hub
WHAT: Hub for architecture, versioning, bug history, and licensing.
WHY: For questions about HOW it works internally or historical records.
KEYS:
- Architecture: 49 ARCHITECTURE (app layers + PRoot chain).
- Versions: 50 VERSIONING (schemes + export folders).
- Bug IDs: 51 BUG-REGISTER (FB-### map).
- License: 52 LICENSE (proprietary + bundled OSS).
USE:
- "Why does the app do it this way?" → 49 ARCHITECTURE.
- "Was this bug fixed?" → 51 BUG-REGISTER.
RELATED: 00 HOME, 49 ARCHITECTURE, 50 VERSIONING, 51 BUG-REGISTER, 52 LICENSE, 53 PACKAGE-INVENTORY, 54 FORK-PROVENANCE, 55 BREAKTHROUGH-METHOD
DEEP: research/, reports/, docs/v0.3-series/


