# CARD 37 · MODEL-PROFILES — Per-model tuning
TAG: llm
WHAT: Automatic settings (context size, batch, router hops) per model, from /etc/aetherix/model-profiles.conf.
WHY: One size doesn't fit all: tiny models need smaller windows; bigger models deserve more room.
KEYS:
- File: /etc/aetherix/model-profiles.conf; first-match glob on the .gguf name; '*' = default.
- Fields: ctx, batch, router hops. Example: *smollm2* 8192 256 6 ; *3b* 8192 1024 6.
- v0.4.7 floor: 8192 ctx for every model (16384 for 13B+), clamped down to the model's GGUF native window when smaller (e.g. SmolLM2 = 2048) - read from the model file itself, cached in /etc/aetherix/llm.gguf.ctx.
- Max response stays 512 tokens per reply (LLM_MAX_TOKENS overrides); exports keep the full text.
- LLM_CTX always wins - a forced size skips the native clamp.
- Overrides: LLM_CTX=<n>, LLM_BATCH=<n>, LLM_ROUTER_MAX=<n> win over the file; LLM_ROUTER=0 disables tools.
- Router hops 0 = tools disabled for that model; every model uses the universal router (32 LLM-TASK).
- llm status prints the active profile so you can see what applies.
USE:
- LLM_CTX=8192 llm start → force a bigger window for one session.
RELATED: 25 LLM, 28 LLM-MODELS, 32 LLM-TASK, 26 LLM-OVERVIEW
DEEP: docs/v0.4.2/README.md (FB-103), docs/v0.4.6/README.md (FB-122), docs/v0.4.7/REPORT.md (FB-129)
