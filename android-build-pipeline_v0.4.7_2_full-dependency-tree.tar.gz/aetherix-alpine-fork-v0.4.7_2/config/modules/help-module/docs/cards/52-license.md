# CARD 52 · LICENSE — Ownership + open-source parts
TAG: research
WHAT: The app's own code is proprietary; bundled third-party components keep their open-source licenses.
WHY: Answers "can I reuse this?" and explains the in-app Licenses page.
KEYS:
- Aetherix-Alpine original code (app logic, PTY bridge, launcher, telemetry, modules, tiers) — proprietary, all rights reserved (DroidSpectre).
- Bundled OSS components (e.g., PRoot, Alpine, llama.cpp, Tavily SDK usage) keep their own licenses, cited with upstream sources.
- In-app: Dashboard → Licenses page states this and cites each component (FB-055).
- This repo (the fork) follows the same policy; FORK-NOTES.md documents it.
USE:
- Point users to the Licenses page; do NOT claim the project is open source.
RELATED: 48 RESEARCH, 49 ARCHITECTURE, 03 HOW-IT-WORKS, 05 LIMITATIONS, 54 FORK-PROVENANCE
DEEP: FORK-NOTES.md (License status), docs/BUGS.md (FB-055)


