# CARD 58 · MENU — In-terminal CRT dropdowns
TAG: hub
WHAT: A bottom keybar + top category bar that open command menus inside the terminal — LLM / Modules / Files / System / Help.
WHY: The raw shell is intimidating; the menus make every workflow discoverable without learning Linux paths.
KEYS:
- Top bar (amber): LLM │ MODULES │ FILES │ SYSTEM │ HELP + status dot (green = AI server up, amber = build running).
- Keybar: MENU opens the LLM menu, ▶ toggles the reply dock, arrows/TAB/ESC/CTRL/ALT stay.
- `aetherix-menu <cat>` renders a boxed dropdown: ↑/↓ move, Enter runs, Esc/q closes; items adapt to live state (start vs stop, key set/missing, modules installed).
- System menu holds the old toolbar actions: Close (keep running), Exit (end session), Copy screen, Clear — via /etc/aetherix/app.request.
- Files menu wraps the I/O dropbox (io in/out/env, sd mount); Help wraps the cards/docs; Modules wraps core status + module help.
USE:
- Tap LLM → "Start the AI server" → "Chat (interactive)" — no command typing needed.
- Long-press nothing: MENU key = the old ✨ sparkle slot, now a real menu.
RELATED: 11 TERMINAL, 25 LLM, 19 MODULES, 15 STORAGE, 38 APP, 26 LLM-OVERVIEW
DEEP: docs/v0.4.7/REPORT.md (CRT UI), docs/v0.4.7/README.md
