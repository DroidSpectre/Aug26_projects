# CARD 31 · LLM-WEB — Web search with citations (--web)
TAG: llm
WHAT: Answers questions using live web search (Tavily) with numbered citations.
WHY: The small local model doesn't know current facts; web grounding fixes that.
KEYS:
- Requires a Tavily API key: Dashboard → Tavily Key (stored encrypted in Android Keystore; synced to /etc/aetherix/tavily.key, 0600).
- llm chat --web "<q>" → 1–2 generated queries → cited synthesis. Tavily's short `answer` summary is shown first; result snippets are compact (~200 chars) and merged material is capped at 3000 chars so a 6-hop router prompt stays inside 8k (v0.4.7).
- A second query only runs when the first returns no answer summary — fewer tokens, faster replies.
- Every routed chat turn also offers web as option A (router).
- llm chat --web status → key state; llm chat --web --test → live check (HTTP 200).
- No key → --web explains how to add one; the router falls back to knowledge.
CAUTION:
- If Tavily returns 401/403, the saved key was rejected — re-add it.
RELATED: 25 LLM, 29 LLM-ASK, 30 LLM-CHAT, 39 DASHBOARD, 44 TROUBLE-LLM
DEEP: docs/v0.4.1/ANALYSIS.md §8, docs/v0.4.1/README.md, docs/v0.4.7/REPORT.md (Tavily answers)
