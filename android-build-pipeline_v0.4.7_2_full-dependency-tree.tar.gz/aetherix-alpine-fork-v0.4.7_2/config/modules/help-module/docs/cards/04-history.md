# CARD 04 · HISTORY — The journey, version by version
TAG: overview
WHAT: The project went from a research experiment (v0.0.1) to a stable product (v0.4.3) in about three weeks of intense iteration.
WHY: Knowing the eras helps answer "when was X added" and why old features (GUI) disappeared.
KEYS:
- v0.0.1–v0.1.6 (DevEnv-PRoot): 24 experiments; Knox breakthrough at v0.1.0 ("echo OK" works).
- v0.1.7–v0.2.0: terminal, internet package manager, 6-step wizard.
- v0.2.1–v0.2.25: renamed Aetherix-Alpine; native terminal (4th rewrite); 7-step setup.
- v0.3.0–v0.3.3: setup UX, storage tier, module system, telemetry.
- v0.3a.0–v0.3a.14_13 (fork line, 28 builds): modules, elv/gui/llm tiers, docked AI window, reliability.
- v0.4.0: core frozen; modules bundled in-app; job dock.
- v0.4.1: web search (Tavily). v0.4.2: model-aware AI + agent + help corpus. v0.4.3: sparkle key fix, background downloads, faster builds, INPUT/OUTPUT dropbox, AI export.
USE:
- "Which version added X?" → scan this map, then 50 VERSIONING for exact codes.
RELATED: 50 VERSIONING, 51 BUG-REGISTER, 49 ARCHITECTURE, 01 WHAT-IS, 54 FORK-PROVENANCE
DEEP: docs/v0.3-series/CHANGELOG.md, docs/v0.4.0/README.md, docs/v0.4.3/README.md


