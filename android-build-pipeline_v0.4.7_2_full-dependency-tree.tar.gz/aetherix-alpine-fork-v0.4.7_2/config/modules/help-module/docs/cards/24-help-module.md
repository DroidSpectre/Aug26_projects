# CARD 24 · HELP-MODULE — The curated knowledge corpus
TAG: modules
WHAT: A curated library of short docs the AI reads to answer help questions.
WHY: Gives the small on-device model reliable facts instead of guesswork.
KEYS:
- Corpus deployed to /etc/aetherix/help/*.md (welcome, terminal, modules, llm, versions, bugs, troubleshooting).
- llm docs find <terms> → ranked search (exact-phrase first).
- llm docs add <dir> → add your own docs to /etc/aetherix/help/user/<name>/.
- llm chat --docs <q> → one-shot answer from the corpus with citations.
- v1.1.0 added the v0.4.3 verbs (io, export/replies, build speed, dropbox).
USE:
- "How do I..." questions → llm chat --docs or llm docs find.
RELATED: 19 MODULES, 34 LLM-DOCS, 29 LLM-ASK, 51 BUG-REGISTER, 53 PACKAGE-INVENTORY
DEEP: docs/v0.3-series/package-inventory.md §E, docs/v0.4.2/README.md


