# CARD 56 · CAPABILITIES — What the on-device AI can and cannot do
TAG: hub
WHAT: Honest can/cannot manifest for the local LLM tier; `llm capabilities` prints the same list on-device.
WHY: Knowing the boundaries prevents wasted prompts — no shell access beyond the gate, no vision, no keyless web.
KEYS:
- CAN: llm chat (135M-10B GGUF), Tavily web answers (--web, key from Dashboard), universal guided router for every model, docs corpus (--docs, docs find), replies + OUTPUT export, read-only file access (help corpus, home, ~/storage, INPUT).
- CANNOT: write to the prompt/scrollback, live terminal reads (only a ~40-line snapshot), keyless web search (SearXNG deferred), vision/multimodal, cloud sync.
- Router (v0.4.6): ONE letter menu per hop for every model — A web / B docs / C file / D knowledge / E terminal / F final, <=6 hops (small-world); no native tool-calling required; LLM_ROUTER=0 disables.
- Terminal bridge (v0.4.5): term_run is gated — read/status commands auto-run, else per-command yes/no; LLM_TERM=0 disables it (57 TERM-TOOLS).
- Context (v0.4.7): floor 8192 (16384 for 13B+), clamped to the model's GGUF native window when smaller; max response 512 tokens per reply, exports keep full text (37 MODEL-PROFILES).
- Web (v0.4.7): Tavily answers-first with compact snippets and a 3000-char merged cap - less context, faster replies (31 LLM-WEB).
- CRT UI (v0.4.7): category bar + keybar MENU open in-terminal dropdowns (llm/modules/files/system/help); the System menu holds close/exit/copy/clear (58 MENU).
- Build readout: llm build-status shows compiler, OpenMP, -march (+fp16) and cmake probe results.
USE:
- "Can it read my file / search the web / run this command?" — read KEYS, then 32 LLM-TASK or 17 IO-DROPBOX.
- "Why is it slow / truncating?" — check build-status first (FP16/OpenMP on?), then the profile ctx (37 MODEL-PROFILES).
RELATED: 25 LLM, 32 LLM-TASK, 29 LLM-ASK, 33 LLM-CONTEXT, 37 MODEL-PROFILES, 36 LLM-BUILD, 17 IO-DROPBOX, 57 TERM-TOOLS, 58 MENU
DEEP: docs/v0.4.6/README.md, docs/v0.4.6/RESEARCH.md (universal router), docs/v0.4.7/REPORT.md
