# CARD 34 · LLM-DOCS — Built-in help library
TAG: llm
WHAT: Searchable docs the model uses to answer "how do I..." questions accurately.
WHY: Small models hallucinate; grounding answers in the corpus fixes that.
KEYS:
- llm docs find <terms> → top 5 docs, matched lines (exact-phrase ranking first).
- llm docs add <dir> → copies your .md/.txt docs into /etc/aetherix/help/user/<name>/ (instantly searchable).
- llm chat --docs <q> → one-shot answer from the corpus with citations.
- Corpus files: welcome, terminal, modules, packages, llm, help, alpine, versions, bugs, troubleshooting.
USE:
- "how do modules install?" → llm chat --docs or llm docs find modules.
RELATED: 25 LLM, 24 HELP-MODULE, 29 LLM-ASK, 32 LLM-TASK
DEEP: docs/v0.4.2/README.md (FB-107, FB-108)


