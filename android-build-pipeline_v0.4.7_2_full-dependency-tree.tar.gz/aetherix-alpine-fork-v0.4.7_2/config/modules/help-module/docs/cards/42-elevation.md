# CARD 42 · ELEVATION — The elv tier (foundation)
TAG: app
WHAT: Optional deeper control by connecting to the phone's own wireless debugging (adb) over loopback.
WHY: Provides a shell with extra privileges without rooting; still sandboxed.
KEYS:
- Commands: elv setup (installs android-tools), elv pair <port> <pin>, elv connect, elv shell <cmd> (uid 2000), elv status, elv disconnect.
- Dashboard card with Wireless Debugging shortcut + pairing form.
- Foundation status: shipped; on-device verification pending — the kernel may block loopback pairing.
- Degrades gracefully to the normal sandbox if blocked.
USE:
- elv status → see if the connection is available.
RELATED: 38 APP, 05 LIMITATIONS, 47 ENV-LIMITS, 49 ARCHITECTURE
DEEP: docs/v0.3-series/aetherix-v0.3-series-device-layers-plan.md (Part 5), docs/BUGS.md (FB-018)


