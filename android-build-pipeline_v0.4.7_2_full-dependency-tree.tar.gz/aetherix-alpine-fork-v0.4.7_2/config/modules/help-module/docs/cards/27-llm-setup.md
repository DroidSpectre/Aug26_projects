# CARD 27 · LLM-SETUP — Building the AI server
TAG: llm
WHAT: Compiles llama-server from source inside Alpine (no package exists for it).
WHY: This is the long step users ask about; it runs detached with progress.
KEYS:
- Command: llm wizard (guided: build + model + first-run tour) or llm setup (plain build; build-restart resumes a stale build; build-status checks).
- Compiler: gcc by default (OpenMP via libgomp; clang only when libomp is installed; LLM_USE_CLANG=1 forces) + -DCMAKE_BUILD_TYPE=Release + PRoot-safe -march probe → Termux-parity speed (llm build-status prints the active compiler/OpenMP).
- jobs = min(cores, 4); drops to 2 only below 3 GiB RAM; LLM_JOBS overrides.
- PRoot-safe CPU probe: derives -march from /proc/cpuinfo (GGML_NATIVE=OFF).
- Build runs DETACHED (survives screen-off); ccache + ninja resume quickly.
- Toolchain is owned by llm-module (installed lazily by `llm setup`): build-base, clang, cmake, git, curl, linux-headers, openssl-dev, ccache, ninja. core-module provides the shared base only (21 CORE-MODULE).
USE:
- llm setup → wait for the dock job → llm build-status → llm start.
CAUTION:
- Do not let the phone overheat; watch thermal zones in build-status.
RELATED: 25 LLM, 23 LLM-MODULE, 21 CORE-MODULE, 36 LLM-BUILD, 18 JOBS, 44 TROUBLE-LLM
DEEP: docs/BUGS.md (FB-087), docs/v0.4.0/REPORT.md §2, docs/v0.4.3/README.md, docs/v0.4.7/REPORT.md


