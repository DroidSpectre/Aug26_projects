# CARD 39 · DASHBOARD — The main screen
TAG: app
WHAT: The app's home screen: setup status, hardware/system cards, module management, settings.
WHY: It is the control center; buttons appear as the system verifies.
KEYS:
- Fresh install → only the Install button until all 7 steps report tested.
- After verification: Open Terminal, Modules & Storage, Log view, Share, Licenses, Tavily Key, Reset & Reinstall (bottom-most, always).
- Cards: Hardware + System (collapsible, default-minimized) refreshed every ~5 s.
- Modules page: one card per module (Installed green / Available blue / Uninstall blue).
- Grant All-files access lives under Storage > Grant Access.
USE:
- Dashboard → Modules & Storage → install core → hello → llm → help.
RELATED: 38 APP, 40 HARDWARE-CARD, 41 REPORTING, 19 MODULES, 31 LLM-WEB
DEEP: docs/v0.4.0/README.md, docs/v0.4.1/README.md


