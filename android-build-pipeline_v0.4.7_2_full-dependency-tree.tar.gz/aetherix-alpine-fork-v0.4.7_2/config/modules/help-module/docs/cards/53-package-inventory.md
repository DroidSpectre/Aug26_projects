# CARD 53 · PACKAGE-INVENTORY — What's installed where
TAG: research
WHAT: The exact package lists for each layer: OS base, core-module, llm fallback, and the pure-content modules.
WHY: Answers "which package provides X" and "what does setup actually install".
KEYS:
- Step-5 OS base (v0.4.7): alpine-base, alpine-conf, openrc, tzdata, util-linux, shadow, procps (+ bash, coreutils, ncurses-terminfo, ca-certificates-bundle). Conveniences dropped: openssh, nano, htop, bash-completion, iproute2.
- core-module (21): bash, coreutils, ncurses-terminfo, ca-certificates-bundle, findutils, gawk (+ best-effort libomp) - shared base only.
- llm-module toolchain (installed lazily by `llm setup`): build-base, clang, cmake, git, curl, ca-certificates-bundle, linux-headers, openssl-dev, ccache, ninja (+ best-effort libomp).
- hello-module and help-module: no packages — pure content bundles.
- gui-module (archived): was xvfb/x11vnc/openbox/xterm (~86 pkgs) — no longer built.
USE:
- "Is nano installed?" → apk list --installed | grep nano
RELATED: 48 RESEARCH, 21 CORE-MODULE, 22 HELLO-MODULE, 24 HELP-MODULE, 08 WIZARD
DEEP: docs/v0.3-series/package-inventory.md, docs/v0.4.7/REPORT.md (FB-126)
