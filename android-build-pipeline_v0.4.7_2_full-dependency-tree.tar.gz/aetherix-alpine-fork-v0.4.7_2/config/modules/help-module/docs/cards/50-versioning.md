# CARD 50 · VERSIONING — Version schemes + artifacts
TAG: research
WHAT: How versions are numbered and where release files go.
WHY: "Which version am I on / where's the APK" answers live here.
KEYS:
- App (current line): v0.4.<p> → versionCode 40000+p (e.g., v0.4.5 = 40005).
- Legacy fork line: v0.3a.<n>(_<k>) → 30000+n*10+k (historical).
- Modules: independent semantic versions (core 1.2.0, hello 1.2.0, llm 1.7.0, help 1.4.0).
- Single source of truth: app/build.gradle (versionName/versionCode).
- Per-version export folder on device: /sdcard/Download/Aetherix-Alpine_v<version>/ (APK + source + docs) + fork tree.
- Build/verify: scripts/build-apk.sh + config/modules/hello-module/tests/verify-apk.sh (16 checks).
USE:
- "What changed in v0.4.2?" → docs/v0.4.2/ or 04 HISTORY.
RELATED: 48 RESEARCH, 04 HISTORY, 51 BUG-REGISTER, 19 MODULES, 54 FORK-PROVENANCE
DEEP: docs/v0.3-series/VERSIONING.md


