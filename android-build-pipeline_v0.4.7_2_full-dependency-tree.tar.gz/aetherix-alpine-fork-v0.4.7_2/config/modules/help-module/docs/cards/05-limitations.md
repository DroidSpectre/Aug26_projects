# CARD 05 · LIMITATIONS — Honest boundaries
TAG: overview
WHAT: What the app intentionally cannot do, and why.
WHY: Setting expectations prevents wrong answers and frustration.
KEYS:
- No root / no jailbreak by design — the app stays inside Android's normal app sandbox.
- Self-signed APK: first install requires ADB from a computer (Samsung policy).
- Background work is limited by Android's "phantom process killer"; the app uses a wake lock during long builds/downloads to protect them.
- AI is CPU-only: a few words per second; small models can occasionally make things up.
- GUI apps (VNC) were retired as out of scope; terminal + storage + AI are the product.
- Some kernel interfaces are blocked on this phone (see 47 ENV-LIMITS).
USE:
- Answer "can it do X?" honestly; if it is here, it cannot.
RELATED: 01 WHAT-IS, 47 ENV-LIMITS, 43 TROUBLESHOOTING, 52 LICENSE
DEEP: docs/v0.4.0/REPORT.md §5, research/Atherix-Alpine_explained/Atherix-Alpine_explained.md


