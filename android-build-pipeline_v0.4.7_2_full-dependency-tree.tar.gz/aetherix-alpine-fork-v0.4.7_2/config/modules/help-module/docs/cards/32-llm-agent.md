# CARD 32 · LLM-TASK — Routed multi-hop tasks (--task)
TAG: llm
WHAT: Give the AI a task and it works through it with tools: web, docs, files, terminal.
WHY: Multi-step tasks (research, analyze a file, check the device) need tools, not one-shot answers.
KEYS:
- Command: llm chat --task "<task>"; every interactive chat turn can route the same way.
- Universal router (v0.4.6): one letter per hop — A web / B docs / C file / D knowledge / E terminal / F final.
- Works on EVERY model, 135M up - a hardwired menu needs no native tool-calling training.
- Hops capped per turn: LLM_ROUTER_MAX (default 6, small-world); LLM_ROUTER=0 disables tools.
- Material accumulates across hops; final answers cite web sources [n].
USE:
- llm chat --task "check the docs for llm setup, then summarize the terminal"
RELATED: 25 LLM, 37 MODEL-PROFILES, 30 LLM-CHAT, 34 LLM-DOCS, 17 IO-DROPBOX, 57 TERM-TOOLS
DEEP: docs/v0.4.6/README.md (FB-124), docs/v0.4.6/RESEARCH.md
