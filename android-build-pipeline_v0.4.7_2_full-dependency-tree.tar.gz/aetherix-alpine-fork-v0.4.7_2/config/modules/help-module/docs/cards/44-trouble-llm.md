# CARD 44 · TROUBLE-LLM — AI problem solver
TAG: troubleshooting
WHAT: Symptom → fix for the most common AI failures.
WHY: Most AI issues are a small set of known states.
KEYS:
- "build state: building (STALE)" → the build died; run llm build-restart (or llm setup).
- "linux/limits.h" errors → missing linux-headers; install core-module or rerun llm setup.
- "TLS CA file missing" → apk add ca-certificates (or core-module).
- "no model set" → drop a .gguf in ~/models/, llm model <file>, llm start.
- "no response - is the server running?" → llm start / llm status.
- "web 401/403" → Tavily key rejected; re-add in Dashboard → Tavily Key.
- Slow/thermal → build-status shows zones; lower LLM_JOBS and let the phone cool.
USE:
- Read the exact error line, then match it here.
RELATED: 43 TROUBLESHOOTING, 27 LLM-SETUP, 36 LLM-BUILD, 31 LLM-WEB, 28 LLM-MODELS
DEEP: config/modules/help-module/docs/90-troubleshooting.md (llm)


