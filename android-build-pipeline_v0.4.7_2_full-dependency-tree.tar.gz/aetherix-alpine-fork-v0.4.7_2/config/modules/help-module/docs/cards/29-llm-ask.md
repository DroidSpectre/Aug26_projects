# CARD 29 · LLM-ASK — One-shot questions (llm chat --once/--plain)
TAG: llm
WHAT: Ask the AI one question, non-interactively - the router picks the best source of truth per question.
WHY: One command handles most needs; the router chooses web/docs/file/terminal/knowledge for you.
KEYS:
- llm chat --once "<q>" auto-routes the question the same way a chat turn does.
- llm chat --plain "<q>" forces a direct completion (no routing, no tools).
- llm chat --docs "<q>" forces the bundled docs corpus; llm chat --web "<q>" forces Tavily.
- Prompts include terminal/system context (33 LLM-CONTEXT) + INPUT dropbox file list.
- Answers render in the dock and are saved to disk (35 LLM-REPLIES).
USE:
- llm chat --once "review INPUT/code.py for bugs"   /   llm chat --plain "summarize: <text>"
RELATED: 25 LLM, 30 LLM-CHAT, 34 LLM-DOCS, 31 LLM-WEB, 33 LLM-CONTEXT, 35 LLM-REPLIES
DEEP: docs/v0.4.6/README.md (FB-123)
