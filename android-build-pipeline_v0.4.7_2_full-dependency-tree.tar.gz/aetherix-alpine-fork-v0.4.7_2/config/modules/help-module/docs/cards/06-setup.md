# CARD 06 · SETUP — Setup cluster hub
TAG: hub
WHAT: Hub for everything about installing and first-time setup.
WHY: Most questions about "how do I get started" or "why is setup failing" live in this cluster.
KEYS:
- Install via ADB (07 INSTALL), then run the 7-step wizard (08 WIZARD).
- Three permission prompts appear after setup: 09 PERMISSIONS.
- Reset wipes everything: 10 FACTORY-RESET.
- Health checks: 22 HELLO-MODULE (aetherix-selftest / smoke).
USE:
- "Stuck at step N?" → 08 WIZARD, then 43 TROUBLESHOOTING.
- "Permission prompt 2/3?" → 09 PERMISSIONS.
RELATED: 00 HOME, 07 INSTALL, 08 WIZARD, 09 PERMISSIONS, 10 FACTORY-RESET, 43 TROUBLESHOOTING
DEEP: docs/v0.3-series/aetherix-v0.3-series-device-layers-plan.md, FORK-NOTES.md


