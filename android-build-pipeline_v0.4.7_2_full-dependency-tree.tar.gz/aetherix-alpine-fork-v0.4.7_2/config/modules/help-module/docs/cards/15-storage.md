# CARD 15 · STORAGE — Storage cluster hub
TAG: hub
WHAT: Hub for how the app reads your phone's files and exchanges files with the Linux side and the AI.
WHY: Storage questions ("where is my file", "why can't the AI see it") live here.
KEYS:
- The app can access All-files storage with permission (3/3) and binds it into Linux.
- sd CLI maps Android volumes into ~/storage (16 STORAGE-TIER).
- The AI dropbox: Downloads/Aetherix-Alpine_INPUT + _OUTPUT (17 IO-DROPBOX).
- Exports from builds/AI land in OUTPUT; logs export there too.
USE:
- "Where did my export go?" → 17 IO-DROPBOX.
- "How do I copy from Downloads into Linux?" → 16 STORAGE-TIER.
RELATED: 00 HOME, 16 STORAGE-TIER, 17 IO-DROPBOX, 18 JOBS, 45 TROUBLE-STORAGE
DEEP: docs/v0.3-series/package-inventory.md, docs/v0.3-series/core-vs-modules.md


