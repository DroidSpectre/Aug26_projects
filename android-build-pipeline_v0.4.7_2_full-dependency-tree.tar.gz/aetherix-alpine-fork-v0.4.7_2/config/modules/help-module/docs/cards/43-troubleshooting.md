# CARD 43 · TROUBLESHOOTING — Problems cluster hub
TAG: hub
WHAT: Hub for diagnosing failures: setup, AI, storage, terminal.
WHY: Symptom → likely cause → fix, in the fewest steps.
KEYS:
- AI problems: 44 TROUBLE-LLM (build, model, server, key).
- Storage/permissions: 45 TROUBLE-STORAGE.
- Terminal/app quirks: 46 TROUBLE-TERMINAL.
- Kernel/Android-wide limits: 47 ENV-LIMITS.
- Golden rule: check state first (llm status, job list, module available, aetherix-selftest).
USE:
- Match the symptom to a cluster, then to the specific card.
RELATED: 00 HOME, 44 TROUBLE-LLM, 45 TROUBLE-STORAGE, 46 TROUBLE-TERMINAL, 47 ENV-LIMITS
DEEP: config/modules/help-module/docs/90-troubleshooting.md


