# Package inventory

What gets installed, and where in the process.

## App-bundled (APK assets / native libs - no apk)
- alpine-minirootfs.tar: bootstrap Alpine 3.19 rootfs (Step 2)
- proot-arm64 / libproot.so: PRoot user-mode sandbox (Step 3)
- libpty-bridge.so: fork/PTY/exec bridge proof (Step 6)
- libpty-jni.so: TIOCSWINSZ ioctl shim
- libfaketty.so: isatty shim (LD_PRELOAD)
- libandroid-shmem.so, libtalloc.so.2, ca-certificates.crt

## Step 5 init (StepRunner.java)
apk update/upgrade, ca-certificates-bundle, bash coreutils ncurses-terminfo,
alpine-base alpine-conf openrc tzdata util-linux shadow procps
(v0.4.7: conveniences nano/htop/bash-completion/openssh/iproute2 dropped -
the rootfs keeps them preinstalled by minirootfs expansion, but Step 5 no
longer re-asserts them.)

## core-module (post-install)
Shared base only (v0.4.7): bash coreutils ncurses-terminfo
ca-certificates-bundle findutils gawk (+ optional libomp best-effort).
The llama.cpp build toolchain is NOT installed here anymore.

## llm-module toolchain (lazy, via 'llm setup')
The toolchain now belongs to llm-module: build-base clang cmake git curl
ca-certificates-bundle linux-headers openssl-dev ccache ninja (+ best-effort
libomp). core-module is only a dependency for the shared base.

## hello-module / help-module
No packages - pure shell scripts + the docs corpus.
