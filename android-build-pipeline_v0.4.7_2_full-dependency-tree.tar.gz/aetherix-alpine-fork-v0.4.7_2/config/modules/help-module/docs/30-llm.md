# LLM module (llama.cpp)

Local AI chat via llama.cpp's OpenAI-compatible server, loopback only
(127.0.0.1:8080 - it never listens on the network).

## Verbs
- llm wizard / llm setup / build-log / build-status / build-restart
  Guided wizard (splash -> build -> curated model pick -> first-run tour) or
  plain setup. Builds llama-server from source (Alpine has no llama.cpp
  package); gcc by default (OpenMP via libgomp; clang when libomp is
  installed; LLM_USE_CLANG=1/0 forces) + Release + jobs=min(cores,4),
  PRoot-safe -march derived from
  /proc/cpuinfo (GGML_NATIVE=OFF). Build runs DETACHED (survives
  screen-off/resizes); ccache resumes; build-status adds thermal zones.
- llm hf | llm hf list <repo> | llm hf get <repo> <file>
  HuggingFace Hub downloads into ~/models/ + sets active model.
  Downloads run DETACHED through the job dock (prompt returns asap).
- llm model ~/models/<file>.gguf   select a model (idempotent re-link)
- llm start / stop / status
- llm chat                      interactive chat; every turn routes itself
- llm chat --once "<q>"          one-shot routed question
- llm chat --plain "<q>"         direct completion (no routing)
- llm chat --web "<q>"           Tavily search (answers-first, compact snippets;
                                  needs key)
- llm chat --web status|--test   backend + Tavily key check
- llm chat --docs "<q>"          answer from the bundled docs corpus
- llm chat --task "<task>"       routed multi-hop task (tools)
- llm context                    print the terminal + system snapshot
- llm replies [n]                print the last n saved replies (default 1)
- llm export [path]              save a reply into the OUTPUT folder
- llm chat-log [n]               show the last n chat turns
- llm docs find/add              help-corpus search (help-module)
- io env|in|out|clean            INPUT/OUTPUT dropbox helper (below)
- llm-selftest                   exit 0 = pass

## Universal router (v0.4.6)
Every model - 135M up - drives the same one-token letter menu per hop:
A web / B docs / C file / D knowledge / E terminal / F final (<=6 hops,
small-world). No native tool-calling training required. The old llm ask /
llm web / llm agent / llm ask-help commands were removed in v0.4.6;
everything funnels through llm chat.

## Input / Output dropbox
The app creates two folders in Downloads, kept in sync on every volume:
  Download/Aetherix-Alpine_INPUT   place files here for the llm to read
  Download/Aetherix-Alpine_OUTPUT  exports (reports, logs) land here
`io in <path>` copies a file into INPUT (or lists INPUT with `io in`),
`io out <src> [name]` copies a file from INPUT into OUTPUT (or from any
path), `io clean` empties both. ~/storage/input and ~/storage/output are
symlinks to the same folders. Files in INPUT are listed with sizes in the
llm context block, so "llm chat --once 'review INPUT/foo.py for bugs'"
works with no extra setup; the analysis report can be exported with
`llm export`.

## Responses
Every reply is saved to /etc/aetherix/replies/<n>.md and shown in the
docked response window, which also auto-opens after a reply. From the
terminal, `llm replies`, `llm chat-log`, and `llm export` (writes into
the OUTPUT folder) give you the same content back as files.

## Model profiles (auto)
/etc/aetherix/model-profiles.conf maps the active .gguf name to
ctx/batch/router-hops (first-match glob; '*' = default). Overrides:
LLM_CTX=<n>, LLM_BATCH=<n>, LLM_ROUTER_MAX=<n>, LLM_ROUTER=<0|1>.
Context (v0.4.7): floor 8192 (16384 for 13B+), clamped down to the model's
GGUF native window when smaller (e.g. SmolLM2 = 2048) - read from the model
file itself and cached. A forced LLM_CTX always wins. Every model uses the
universal router. Max response: 512 tokens per reply (LLM_MAX_TOKENS).

## Recommended phone models
Qwen3-0.6B | Qwen2.5-0.5B/1.5B | SmolLM2-360M | Llama-3.2-1B | Gemma-3-1B
(recommended Q4 variants via 'llm hf' menu)

## Web search (v0.4.7)
Tavily is asked for its short `answer` summary (`include_answer: true`),
shown first; result snippets are compact (~200 chars) and merged web
material is capped at 3000 chars. A second query runs only when the first
returns no answer summary - less context, faster replies.

## CRT menus (v0.4.7)
The top category bar (LLM | MODULES | FILES | SYSTEM | HELP) and the keybar
MENU key write `aetherix-menu <cat>` into the terminal; `aetherix-menu`
(core-module tier, /usr/local/bin) renders an in-terminal dropdown with
arrows/Enter/Esc. The System menu holds close/exit/copy/clear (via
/etc/aetherix/app.request), so the old toolbar buttons are gone.

## Limits

## Knowledge cards (help-module v1.2.0)

The model can answer from a set of tool-tip data cards deployed to
/etc/aetherix/help/cards/ (small-world: start at 00 HOME, follow RELATED,
any answer within 6 hops; DEEP: lines point to the full docs). `llm docs
find <topic>` returns them like any other corpus doc, and `llm context`
lists the hubs.
LLM_MAX_TOKENS (default 512) caps completion length. Replies go to the
docked response window in-app (AETHERIX_DOCK=1).
