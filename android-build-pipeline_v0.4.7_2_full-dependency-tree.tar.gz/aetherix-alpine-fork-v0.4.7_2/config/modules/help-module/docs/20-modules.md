# Modules

Modules add feature tiers to the Alpine sandbox. They ship INSIDE the APK as
assets/modules/<name>.bundle (gzip tar). The app writes the bundled manifest,
so nothing is discovered from the device's Download folder.

## Install order (dependency-aware)
1. core-module   shared base + build toolchain (bash, cmake, clang, git,
                 curl, gcc, ccache, ninja, linux-headers, openssl-dev)
2. hello-module  environment self-test + smoke scripts + io dropbox helper
3. llm-module    local AI chat via llama.cpp (llm setup && llm chat)
4. help-module   curated help corpus for llm docs / llm chat --docs

`module available` shows ready/blocked/installed per module; install from the
Dashboard > Modules & Storage page (All-files access required).

## Versioning
Each module carries its own version in module.yml and bumps independently of
the app. Convention: one version bump per bundle content change.

## Testing modules as updates
Build the app core separately (bit-identical for module-only changes), then
iterate on one module at a time: edit config/modules/<name>/, run
`bash scripts/build-modules.sh`, rebuild the APK, install, verify.

## Retired
gui-module is archived in config/archive/ (out of project scope as of
v0.3a.14_13). The RVNC/desktop path is intentionally removed from builds.
