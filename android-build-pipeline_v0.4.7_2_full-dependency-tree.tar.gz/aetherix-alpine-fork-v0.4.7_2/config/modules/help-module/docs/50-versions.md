# Version history (condensed)

## v0.3a series (0-14)
Established the fork: side-by-side app id (com.aetherix.alpine.a), 7-step
setup hardening, storage tier, module system, terminal PTY stability
(exit/back handling, resize debounce), hardware card, battery/permission
flows, llama.cpp tier, docked reply window + chat, archived gui-module,
detached job runner, numbered permissions, install-only dashboard, per-module
cards, APK-only modules with own versions.

## v0.4.0 (core-stable)
v0.3a.14_14 renamed v0.4.0. Core (app + Alpine + terminal) frozen as the
base; modules become the update vehicle. Per-version source snapshots +
academic reports in docs/v0.4.x. PRoot-safe CPU probe fixed llama.cpp builds.

## v0.4.1
Tavily web search: Dashboard Tavily Key entry (keystore-encrypted), guest key
sync, llm web/status/--test, dashboard spacing fixes.

## v0.4.2
Model-aware llm: per-model profiles (ctx/batch/agent), terminal context
snapshot (llm context), auto-router llm ask (plain/help/docs/web), llm agent
tool loop, help-module corpus + llm docs find/add + llm ask-help, reply-dock
sparkles key already shipped in 0.4.1. Bug IDs for this release: FB-103..FB-108.

## v0.4.3
Sparkles key fix (opens the reply window instead of typing the emoji),
detached model downloads (job dock), clang + Release build with
jobs=min(cores,4) (Termux-parity speed), unified INPUT/OUTPUT dropbox +
io helper, llm export/replies/chat-log + auto-opening reply dock,
build-status thermal/cgroup readout. Bug IDs: FB-109..FB-114.

## v0.4.4
Capability split (one monolithic llm tier -> tier/lib/*.sh), small-model
guided router (hardwired letter menu), FP16 + OpenMP build fixes
(cpu_march +fp16, gcc when libomp is missing), capabilities manifest
(llm capabilities + card 56).

## v0.4.5
llm wizard (guided setup flow), gated terminal bridge (term_run - router
option E), card 57 TERM-TOOLS.

## v0.4.6
Unified AI command: llm chat replaces llm ask / web / agent / ask-help.
Universal router on every model (A web / B docs / C file / D knowledge /
E terminal / F final, <=6 hops). Context floor fixed: 4096 for tiny models,
8192 for 1-8B, 16384 for 13B+ (was 1024/2048 - answer truncation resolved).

## v0.4.7
Module cleanup + CRT terminal UI in one release. Steps 5/core are now lean
(no toolchain in core-module; llm-module owns build tools; Step-5 drops
convenience packages). Context floor raised to 8192 and clamped to each
model's GGUF native window (SmolLM2 = 2048); max response is 512 tokens.
Tavily answers-first + compact snippets (3000-char merge cap). New top
category bar + keybar MENU open in-terminal dropdowns (aetherix-menu);
System menu holds close/exit/copy/clear. New card 58 MENU. Bug IDs:
FB-126..FB-130.

## v0.4.7_1
Correctness re-cut: wizard tour + `llm help` no longer emit "can't open
task/q/question" redirection errors (FB-131 - unquoted <placeholder> samples).
App versionCode 40071 (monotonic above v0.4.6_1); llm-module 1.9.1.

## v0.4.7_2
Device UX re-cut (FB-132): the `llm wizard` wait no longer re-prints the five
data cards every 30s - cards show once, then a live progress line (build-log
tail + elapsed minutes). Terminal scrollback raised 2000 -> 10000 rows. Every
menu/help/tour/status/capabilities line now wraps cleanly at the device's 63
columns (`say()` at word boundaries); model-pick lists were shortened to fit.
Replies no longer leak the `"},"finish_reason"...` JSON tail (parse_reply).
App versionCode 40072 (monotonic above 40071); llm-module 1.9.2. Sandbox
suite: 133 checks.

## Versioning scheme
- App: v0.4.<p> -> versionCode 40000 + p (sub-releases v0.4.<p>_<k> use
  versionCode 40000 + p*10 + k, e.g. v0.4.6_1 = 40061, v0.4.7_1 = 40071)
- Modules: own versions, bumped per content change (core 1.4.0, hello 1.2.0,
  llm 1.9.2, help 1.6.0)
- Each released app version gets its own folder in the device download tree:
  APK + source snapshot + docs
