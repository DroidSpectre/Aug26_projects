# Troubleshooting

## llm
- "build state: building (STALE)" - the app was killed mid-build; run
  'llm build-restart' (or llm setup) - cmake/ccache resume
- "linux/limits.h" errors - toolchain headers missing; install core-module
  or rerun llm setup (installs linux-headers)
- "TLS CA file missing" - apk add ca-certificates (or core-module)
- "no model set" - drop a .gguf in ~/models/, 'llm model <file>', llm start
- build slow / OOM - the build adapts to RAM/cores (clang + Release +
  jobs=min(cores,4)); force safer: LLM_JOBS=1 llm setup
- build-status shows hot thermal zones - let the phone cool before
  'llm build-restart'; lower LLM_JOBS if it throttles again
- reply window did not auto-open - replies still save to
  /etc/aetherix/replies/; use 'llm replies' + 'llm export' in the terminal
- "exported file not found" - exports go to
  Download/Aetherix-Alpine_OUTPUT (io env prints the exact paths)
- file not in llm context - INPUT files are listed by 'llm context'; drop
  files into Download/Aetherix-Alpine_INPUT or use 'io in <path>'
- Tavily 401/403 - the saved key was rejected; re-add from the app Dashboard
  > Tavily Key (stored encrypted in Android Keystore)
- "no response - is the server running?" - server not up; 'llm start' or
  'llm status'

## Modules
- "storage permissions not granted" / modules not listed - grant All-files
  access from the Dashboard (Storage > Grant Access), then reinstall
- module blocked "install first: core-module" - modules install in order
  core -> hello -> llm -> help
- helpers missing in shell (sd/core/llm/io...): reinstall the module - post
  install re-deploys the tier CLIs

## Terminal / app
- Major rendering lag on app start - initial device profiling; give it a few
  seconds; lag when switching out of terminal is under instrumentation
- Screen blackout during deep processing - the app is CPU-only by design;
  the wake lock keeps it alive; lower LLM_JOBS if thermal pressure
- First typed digit eaten (BT keyboard) - prompt warmup; wait for cursor
- Register: app not responding / APK problems - screenshot + Error Report
  from the Dashboard (Settings > Report) and share the last-100-lines log
