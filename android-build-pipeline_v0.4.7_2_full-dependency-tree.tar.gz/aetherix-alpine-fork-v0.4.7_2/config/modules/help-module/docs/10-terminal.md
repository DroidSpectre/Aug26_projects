# Terminal

The terminal is a PTY bridge (libpty-bridge.so) + PRoot session; it is the
main interface. It is considered stable; known quirks are cosmetic.

## Controls
- Keybar row: TAB ESC CTRL ALT arrows + REPLY toggle (docked response window)
- Toolbar: Copy All / Clear All (16k+ scrollback), timer, session close
- Exit types `exit` and closes the shell; app switching keeps the session
  running (TerminalActivity restores to front on resume)
- Ctrl-D ends interactive modes (chat/help)
- Long-press special keys still carries the legacy menu

## Docked windows
- REPLY: llm replies render in a docked scroll (5 lines keyboard-open,
  10 lines keyboard-closed) instead of flooding the terminal
- Jobs: up to 5 stacked job rows (progress bar + current task + spinner)
  for apk adds, builds, and downloads; 'job list' shows state
- Spinner overlay appears after 2s of silence on long commands

## Known quirks
- Samsung kernels block TIOCSWINSZ/TIOCSIG (ENV-001); the app ships a
  userspace SIGWINCH chain + libfaketty shim instead
- First digit of fast typing can be eaten on BT keyboards (FB-052,
  mitigated by prompt warmup guards); wait for the prompt cursor
- Resizes around the IME are debounced; the prompt line stays above the
  keyboard
