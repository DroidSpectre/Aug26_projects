# Alpine under PRoot

Aetherix-Alpine is Alpine 3.19 in a PRoot user-space sandbox - no root,
no kernel modules, no init system in the normal sense.

## What works differently
- Package manager: apk (not apt/dnf). `apk add <pkg>`, `apk search`, etc.
- No systemd: services are openrc scripts; most GUI services won't run
- No /dev access beyond what the launcher binds (/dev/urandom, /dev/random,
  ptmx); use /dev/shm? No - use tmp paths like /tmp
- GPU accel is unavailable: everything (including llama.cpp inference) is
  CPU-only by design; deep processing keeps the screen on via wake lock but
  stays on CPU
- /proc/stat is denied for untrusted_app (ENV-002); /proc/cpuinfo passes
- TLS: /etc/ssl/cert.pem is symlinked to the ca-certificates bundle;
  missing cert.pem = install ca-certificates-bundle (or core-module)
- bash is the interactive shell (busybox ash is /bin/sh)

## Gotchas
- `apk add` with a wrong name shows "unable to select packages"; check the
  world file with `apk list --installed` / `apk search`
- Large metapackages (e.g. gnome) pull hundreds of packages and take a long
  time - run them detached: apk add is auto-detached by the app ('job list',
  'job log <id>')
- Storage lives under /mnt/sdcard (internal) + /mnt/sd-extN (removable);
  ~/storage links mirror them (sd mount)
- long jobs survive screen-off (wake lock + detached setsid runner); the app
  being killed mid-build leaves a STALE build state - 'llm build-restart'
  resumes from ccache/cmake
