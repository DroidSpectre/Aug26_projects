# hello-module — bundled Aetherix test module

Ships inside the APK as `assets/modules/hello-module.bundle`
(gzip tar; `.bundle` because aapt strips `.tar.gz` from asset names).
Regenerate with `scripts/build-hello-module.sh`.

Installs the on-device test suite into the Alpine guest so you can verify the
environment without extra files.

## Requires
- **core-module** — install it first (Modules & Storage page). This module is
  **Blocked** until core-module is installed.

## What it installs
- `/opt/aetherix-tests/` — full suite scripts + TESTPLAN
- `/usr/local/bin/aetherix-selftest` — all smoke checks (exit 0 = pass)
- `/usr/local/bin/aetherix-smoke` — quick environment/telemetry dump
- `/etc/aetherix/hello-module.installed` — install marker
- `/usr/local/bin/{sd,device-info,elv,llm,module}` — tier helpers
  (FB-027 guest-side self-heal: reinstalled from the bundle's `tier/` dir so
  the environment works even if the app-side deploy could not run)
- `~/storage/` links + `shared`/`external`/`usb` aliases + `storage.state` /
  `device.conf` fallbacks

## Usage (inside the terminal)
- `aetherix-selftest` — run all checks; exit code 0 = pass
- `aetherix-smoke` — one-shot info dump
- `cat /etc/aetherix/hello-module.installed`

## Uninstall
Modules & Storage -> Uninstall. Removes the module tree + bookkeeping; files
copied to `/opt/aetherix-tests/` remain (remove with `rm -rf /opt/aetherix-tests`).
