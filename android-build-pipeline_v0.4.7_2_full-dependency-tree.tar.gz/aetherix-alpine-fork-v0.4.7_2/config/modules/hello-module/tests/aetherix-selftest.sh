#!/bin/sh
# Aetherix-Alpine self-test — smoke checks for the installed environment.
# Run inside the terminal:  aetherix-selftest   (exit 0 = all pass)
FAIL=0
pass() { echo "PASS  $1"; }
fail() { echo "FAIL  $1"; FAIL=$((FAIL+1)); }

echo "== Aetherix-Alpine self-test =="
[ -n "$AETHERIX_VERSION" ] && pass "AETHERIX_VERSION=$AETHERIX_VERSION" || fail "AETHERIX_VERSION not set"
ALP=$(cat /etc/alpine-release 2>/dev/null)
[ -n "$ALP" ] && pass "alpine-release: $ALP" || fail "alpine-release unreadable"
[ "$(id -u)" = "0" ] && pass "uid 0 (proot root)" || fail "uid is $(id -u), expected 0"
[ "$(pwd)" = "/root" ] && pass "cwd /root" || fail "cwd is $(pwd)"
for c in bash apk coreutils uname; do
  command -v "$c" >/dev/null 2>&1 && pass "$c present" || fail "$c missing"
done
N=$(apk list --installed 2>/dev/null | wc -l)
[ "$N" -gt 0 ] && pass "packages: $N" || fail "apk list returned 0 packages"
uname -m | grep -q aarch64 && pass "arch aarch64" || fail "arch is $(uname -m)"
command -v sd >/dev/null 2>&1 && pass "sd helper" || fail "sd helper missing"
command -v device-info >/dev/null 2>&1 && pass "device-info helper" || fail "device-info helper missing"
for c in elv module; do
  command -v "$c" >/dev/null 2>&1 && pass "$c tier helper" || fail "$c tier helper missing"
done
for c in llm; do
  if [ -f "/etc/aetherix/$c-module.installed" ]; then
    command -v "$c" >/dev/null 2>&1 && pass "$c tier helper" || fail "$c tier helper missing (module installed)"
  else
    pass "$c tier helper (module not installed - skipped)"
  fi
done
[ -f /etc/aetherix/device.conf ] && pass "device.conf" || fail "device.conf missing"
[ -f /etc/aetherix/hello-module.installed ] && pass "hello-module marker" || fail "hello-module marker missing"
[ -r /etc/ssl/cert.pem ] && pass "TLS CA cert (/etc/ssl/cert.pem)" || fail "TLS CA cert missing (/etc/ssl/cert.pem)"
stty size >/dev/null 2>&1 && pass "stty size" || fail "stty size failed"
echo ""
if [ "$FAIL" -eq 0 ]; then echo "ALL CHECKS PASSED"; exit 0; fi
echo "$FAIL CHECK(S) FAILED"; exit 1
