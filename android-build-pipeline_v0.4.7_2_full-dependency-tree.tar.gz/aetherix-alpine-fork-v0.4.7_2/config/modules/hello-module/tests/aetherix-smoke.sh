#!/bin/sh
# One-shot environment + telemetry dump (covers the T3/T4/T6/T8/T9 smoke tests).
echo "== T3 =="; uname -a; cat /etc/alpine-release; echo "VER=$AETHERIX_VERSION"; id -u; pwd; which bash apk coreutils
echo "== T4 =="; apk list --installed 2>/dev/null | wc -l
echo "== T6 =="; sd list 2>/dev/null; sd ls / 2>/dev/null | head -5
echo "== T8 =="; device-info 2>/dev/null
echo "== T9 =="; stty size
echo "SMOKE_OK"
