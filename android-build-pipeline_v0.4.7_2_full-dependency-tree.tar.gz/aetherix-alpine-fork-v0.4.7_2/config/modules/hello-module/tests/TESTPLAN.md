# Aetherix-Alpine on-device test plan (v0.3a.x)

Run after a fresh install. Host-side APK checks: `tests/verify-apk.sh` (on a PC
with aapt/apksigner; it reads the built APK and prints PASS/FAIL).

1. **T1 — Boot to Dashboard** — fresh install opens the dashboard (Setup
   required, Initiate Install button), not the manual step list.
2. **T2 — Walkthrough + auto-install** — 9 walkthrough pages; Start runs steps
   1-7 (one install + one test each); log shows `Step 1..7 [PASS]`,
   `SELF_TEST_PASS`, `All steps complete!`; Step 3 shows internet + notification
   + battery + All-files prompts.
3. **T3 — Shell sanity** — `uname -a`, `cat /etc/alpine-release`, `echo
   $AETHERIX_VERSION`, `id -u` = 0, `pwd` = /root, bash/apk/coreutils present.
4. **T4 — Live package counter** — dashboard Packages installed matches
   `apk list --installed | wc -l`; after `apk add <pkg>` it increments within
   ~5s; `apk del` decrements.
5. **T5 — Exit without false kill popup** — ✕ Exit -> reopen: no "killed by the
   system" popup; same after typing `exit`. Genuine kill: background session +
   force-stop the app -> heartbeat-stale popup on reopen.
6. **T6 — Storage tier** — after Step 3 grant: `sd mount`, `sd list`, `ls
   ~/storage/shared` (Termux-style mapping), `sd ls /`, `sd cp /etc/hostname
   ~/storage/shared/aetherix-test.txt`; file visible in Android file
   manager; dashboard Storage Access = Granted. With an SD card or USB
   drive attached, `sd mount` creates `~/storage/external` / `~/storage/usb`
   (adaptive per-volume mapping).
7. **T7 — Module system** — Modules & Storage shows `hello-module` as
   Available with version 1.0.0 and an installed count; install it;
   `ls /var/lib/aetherix-modules/hello-module/`,
   `cat /etc/aetherix/hello-module.installed`, `aetherix-selftest` run;
   then Reinstall/Uninstall.
8. **T8 — Telemetry** — dashboard Hardware card (battery % + charging,
   temp, voltage, RAM avail/total, storage avail/total, app data/apk size,
   CPU cores/model, GPU vendor/busy, NPU, network transport) matches
   `cat /etc/aetherix/device.conf` and `device-info`.
9. **T9 — PTY/resize/keys** — `nano`/`vim` resize cleanly; `stty size` tracks
   the window; first keystroke after the keyboard popup is preserved.
10. **T10 — Error report + resume** — report header shows version/device/kernel,
    all components tested, Step 7 PASS; background Close -> reopen resumes the
    same session.
11. **T11 — Elevation tier** — dashboard Elevation card (shown after setup):
    Install adb -> `elv setup`; enable Wireless debugging, `elv pair <port>
    <pin>` -> status becomes paired, `elv connect` -> connected, then
    `elv shell id` returns `uid=2000(shell)`. `elv disconnect` returns to
    idle. If the kernel blocks loopback adb, the card shows error and the
    app stays sandboxed (degrade gracefully).
12. **T12 — LLM tier** — `llm setup` installs llama.cpp; drop a `.gguf` in
    `~/models/` (recommended light models: `Qwen3.5-0.8B-IQ4_XS.gguf` or
    `SmolLM2-360M-IQ4_XS.gguf`), `llm model ~/models/<file>.gguf`,
    `llm start` -> status running (127.0.0.1:8080); `llm chat --plain "hello"` returns
    a completion; `llm stop` stops it.
13. **T13 — Tier helper self-heal** — after hello-module install, all tier
    helpers exist without app restarts: `command -v sd device-info elv llm
    module` all resolve; `ls ~/storage/shared` works; `shared` alias cd's;
    `module status` prints module list; `cat /etc/aetherix/device.conf` and
    `cat /etc/aetherix/storage.state` exist.
