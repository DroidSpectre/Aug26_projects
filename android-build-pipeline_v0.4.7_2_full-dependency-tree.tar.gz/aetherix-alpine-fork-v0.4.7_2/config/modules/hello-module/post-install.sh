#!/bin/sh
# hello-module post-install — deploy the Aetherix test suite + tier helpers.
MODULE_DIR=$(dirname "$0")
mkdir -p /opt/aetherix-tests
cp -f "$MODULE_DIR"/tests/* /opt/aetherix-tests/ 2>/dev/null || true
chmod +x /opt/aetherix-tests/*.sh 2>/dev/null || true
ln -sf /opt/aetherix-tests/aetherix-selftest.sh /usr/local/bin/aetherix-selftest
ln -sf /opt/aetherix-tests/aetherix-smoke.sh /usr/local/bin/aetherix-smoke

# FB-027: self-heal the tier helpers + storage mapping from inside the guest,
# so the environment works even if the app-side StorageTier.deploy() could not
# run on this device. Idempotent; app-side deploy overwrites the same files.
mkdir -p /usr/local/bin /etc/aetherix /etc/ssl/certs
# FB-043: git/curl default to /etc/ssl/cert.pem; self-heal the symlink so TLS
# works even if the app-side Step 2 never ran on this rootfs.
ln -sfn /etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem
for f in "$MODULE_DIR"/tier/*; do
  [ -f "$f" ] || continue
  cp -f "$f" "/usr/local/bin/$(basename "$f")"
  chmod +x "/usr/local/bin/$(basename "$f")"
done

# storage.state fallback: granted matches the common All-files grant; the
# app-side writeState overwrites this with the real grant on the next poll.
if [ ! -f /etc/aetherix/storage.state ]; then
  echo "granted" > /etc/aetherix/storage.state
fi

# device.conf fallback (the app-side Step 3 writes the full capture)
if [ ! -f /etc/aetherix/device.conf ]; then
  {
    echo "board: $(getprop ro.board.platform 2>/dev/null || echo unknown)"
    echo "model: $(getprop ro.product.model 2>/dev/null || echo unknown)"
    echo "cpu_abi: $(getprop ro.product.cpu.abi 2>/dev/null || echo unknown)"
    echo "manufacturer: $(getprop ro.product.manufacturer 2>/dev/null || echo unknown)"
    echo "gpu_vendor: unknown"
  } > /etc/aetherix/device.conf
fi

# Termux-style ~/storage links: the 'sd' helper (copied to /usr/local/bin
# above) is the single source of truth - it clears stale removable links and
# re-derives the whole tree, so the app-side seed and this module never drift.
if [ -f /etc/aetherix/storage.state ] && [ "$(cat /etc/aetherix/storage.state)" = "granted" ]; then
  sd mount >/dev/null 2>&1 || true
else
  mkdir -p /root/storage
  ln -sfn /mnt/sdcard /root/storage/shared
  ln -sfn /mnt/sdcard/Download /root/storage/downloads
fi

# bash aliases
touch /root/.bashrc
grep -q "alias shared=" /root/.bashrc || cat >> /root/.bashrc <<'BASH'
# Aetherix storage aliases (v0.3a.7)
alias storage='cd ~/storage'
alias shared='cd ~/storage/shared'
alias external='cd ~/storage/external'
alias usb='cd ~/storage/usb'
BASH

echo "installed $(date -u +%Y-%m-%dT%H:%M:%SZ)" > /etc/aetherix/hello-module.installed
echo "hello-module OK: run 'aetherix-selftest' in the terminal"
