#!/bin/sh
# llm-module post-install — deploy the LLM tier CLI into the guest.
MODULE_DIR=$(dirname "$0")
mkdir -p /usr/local/bin /usr/local/bin/lib /etc/aetherix /root/models
for f in "$MODULE_DIR"/tier/*; do
  [ -f "$f" ] || continue
  cp -f "$f" "/usr/local/bin/$(basename "$f")"
  chmod +x "/usr/local/bin/$(basename "$f")"
done
# v0.4.4 (Q6): capability libraries live next to the 'llm' dispatcher (tier/lib
# is a subdirectory, so the loop above skips it; install it explicitly).
for f in "$MODULE_DIR"/tier/lib/*.sh; do
  [ -f "$f" ] || continue
  cp -f "$f" "/usr/local/bin/lib/$(basename "$f")"
done
# model profiles: ship defaults, never overwrite user edits
if [ ! -f /etc/aetherix/model-profiles.conf ]; then
  if [ -f "$MODULE_DIR/profiles/model-profiles.conf" ]; then
    cp -f "$MODULE_DIR/profiles/model-profiles.conf" /etc/aetherix/model-profiles.conf
  fi
fi
[ -f /etc/aetherix/llm.state ] || echo stopped > /etc/aetherix/llm.state
[ -f /etc/aetherix/llm.conf ] || touch /etc/aetherix/llm.conf
echo "installed $(date -u +%Y-%m-%dT%H:%M:%SZ)" > /etc/aetherix/llm-module.installed
echo "llm-module OK: run 'llm setup', drop a .gguf in ~/models/, 'llm model', 'llm start'"
