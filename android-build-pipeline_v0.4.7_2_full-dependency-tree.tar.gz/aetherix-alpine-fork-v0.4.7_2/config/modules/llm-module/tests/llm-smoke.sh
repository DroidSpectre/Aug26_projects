#!/bin/sh
# llm-module smoke — quick environment + status dump.
echo "== llm-module smoke =="
echo "llm: $(command -v llm || echo missing)"
echo "llama-server: $(command -v llama-server || echo missing)"
echo "curl: $(command -v curl || echo missing)"
echo "models dir: /root/models"
llm status
