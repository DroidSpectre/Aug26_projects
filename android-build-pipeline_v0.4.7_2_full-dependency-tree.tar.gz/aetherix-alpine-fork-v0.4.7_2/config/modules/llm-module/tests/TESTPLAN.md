# llm-module on-device test plan (v0.4.6)

Install via Modules & Storage. Run `llm-selftest` inside the terminal after
`llm setup` and setting a model.

1. **L1 — Install** — Modules & Storage shows `llm-module` (bundled, v1.8.0);
   Install succeeds; `/etc/aetherix/llm-module.installed` exists.
2. **L2 — CLI present** — `command -v llm` resolves; `llm status` prints
   `state: stopped` before first run; `llm help` shows the new unified
   `llm chat` command and no legacy `llm ask / web / agent / ask-help`.
3. **L3 — Setup** — `llm setup` installs llama.cpp + curl (large download,
   needs internet); `llama-server --version` works; `~/models/` exists.
   (Or run the guided `llm wizard` once.)
4. **L4 — Model** — `llm model ~/models/<file>.gguf` persists to
   `/etc/aetherix/llm.conf`; `llm status` shows the model path.
5. **L5 — Chat (single surface)** — with a light `.gguf` in `~/models/`
   (e.g. `Qwen3-0.6B-Q4_0.gguf` or `SmolLM2-360M-Instruct-Q4_K_M.gguf`):
   - `llm start`; `curl http://127.0.0.1:8080/v1/models` responds.
   - `llm chat --plain "hello"` returns a direct completion.
   - `llm chat --once "what is Aetherix-Alpine?"` runs the router and
     returns a routed answer.
   - `llm chat` interactive: type a question, get an answer, `Exit` leaves.
   - Context check: `llm status` prints the profile (expect ctx 4096 for
     tiny models, 8192 for 1-8B) — answers should no longer truncate at
     1k context.
6. **L6 — Routed task + dropbox** — `printf 'def bug():\n    return 1/0\n' >
   ~/storage/input/bug.py`; `llm chat --task "find the bug in bug.py"` →
   router option C reads the file and reports division by zero;
   `llm export` copies the reply into Downloads/Aetherix-Alpine_OUTPUT.
7. **L7 — Web** — with a Tavily key in the Dashboard: `llm chat --web
   "latest qwen news"` returns a cited [n] answer; `llm chat --web --test`
   prints `tavily: OK (HTTP 200)`.
8. **L8 — Selftest** — `llm-selftest` exits 0 with all checks passed.
