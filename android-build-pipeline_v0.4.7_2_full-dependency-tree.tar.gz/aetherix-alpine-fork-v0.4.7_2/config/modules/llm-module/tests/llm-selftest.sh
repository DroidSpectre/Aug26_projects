#!/bin/sh

# v0.4.7: llm-module owns its build toolchain (core-module provides only the
# shared base). Assert the tools once a build exists; before the first build
# they are a NOTE (llm setup installs them when the build starts).
if [ -d /opt/llama.cpp/.git ]; then
  for c in cmake gcc clang git curl ccache ninja; do
    command -v "$c" >/dev/null 2>&1 && pass "toolchain: $c" || fail "toolchain: $c missing (run 'llm setup')"
  done
  [ -f /usr/include/linux/limits.h ] && pass "toolchain: linux-headers" || fail "toolchain: linux-headers missing"
  grep -q OpenSSL /usr/include/openssl/opensslv.h 2>/dev/null && pass "toolchain: openssl-dev" || fail "toolchain: openssl-dev missing"
else
  echo "NOTE: build toolchain not yet installed - 'llm setup' installs it on first build"
fi
# llm-module self-test — full functionality check (run inside the terminal).
FAIL=0
pass() { echo "PASS  $1"; }
fail() { echo "FAIL  $1"; FAIL=$((FAIL+1)); }

echo "== llm-module self-test =="
command -v llm >/dev/null 2>&1 && pass "llm CLI installed" || fail "llm CLI missing"
llm status >/dev/null 2>&1 && pass "llm status runs" || fail "llm status failed"
command -v llama-server >/dev/null 2>&1 && pass "llama.cpp installed" || fail "llama.cpp missing (run 'llm setup' with internet)"
command -v curl >/dev/null 2>&1 && pass "curl installed" || fail "curl missing"

MODEL=$(grep -m1 '^model=' /etc/aetherix/llm.conf 2>/dev/null | cut -d= -f2)
if [ -n "$MODEL" ]; then
  [ -f "$MODEL" ] && pass "model file exists: $MODEL" || fail "model file not found: $MODEL"
  llm start >/dev/null 2>&1
  sleep 3
  curl -s http://127.0.0.1:8080/v1/models >/dev/null 2>&1 && pass "server responding on 127.0.0.1:8080" || fail "server not responding"
  llm chat --plain "Reply with OK" >/dev/null 2>&1 && pass "llm chat --plain returns a completion" || fail "llm chat --plain failed"
  llm stop >/dev/null 2>&1
  sleep 1
  pgrep -f llama-server >/dev/null 2>&1 && fail "llama-server still running after stop" || pass "llm stop clean"
else
  echo "NOTE: no model set - set one with 'llm model ~/models/<file>.gguf' to test start/ask"
fi

echo ""
if [ "$FAIL" -eq 0 ]; then echo "ALL CHECKS PASSED"; exit 0; fi
echo "$FAIL CHECK(S) FAILED"; exit 1
