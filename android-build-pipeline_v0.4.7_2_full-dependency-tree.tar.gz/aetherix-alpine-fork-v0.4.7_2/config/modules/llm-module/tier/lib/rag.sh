# Aetherix-Alpine LLM tier - RAG capability library (sourced). Help-corpus
# search/ranking (docs_top) and docs_add ingestion.

docs_top() { # $1 = max docs  $2 = match lines/doc  $* = terms
  maxn="$1"; ml="$2"; shift 2
  terms=$(printf '%s' "$*" | tr -s ' ' | sed 's/[^A-Za-z0-9 ]//g; s/^ *//; s/ *$//')
  pat=$(printf '%s' "$terms" | tr ' ' '|')
  [ -z "$pat" ] && pat="aetherix"
  files=$(find "$HELP" -type f \( -name '*.md' -o -name '*.txt' \) 2>/dev/null)
  [ -z "$files" ] && return 0
  list=""
  for f in $files; do
    [ -f "$f" ] || continue
    matched=0; total=0; phrase=0
    for t in $terms; do
      case "$t" in ''|*[!A-Za-z0-9]*) continue;; esac
      h=$(grep -Eic "$t" "$f" 2>/dev/null | tr -d ' ')
      case "$h" in ''|*[!0-9]*) h=0;; esac
      if [ "$h" -gt 0 ]; then matched=$((matched+1)); fi
      total=$((total+h))
    done
    if [ "$matched" -eq 0 ]; then
      h=$(grep -Eic "aetherix" "$f" 2>/dev/null | tr -d ' ')
      case "$h" in ''|*[!0-9]*) h=0;; esac
      [ "$h" -gt 0 ] || continue
      matched=1; total=$h
    fi
    if [ "$(printf '%s' "$terms" | wc -w)" -gt 1 ]; then
      ph=$(grep -Eic "$terms" "$f" 2>/dev/null | tr -d ' ')
      case "$ph" in ''|*[!0-9]*) ph=0;; esac
      [ "$ph" -gt 0 ] && phrase=1
    fi
    # rank: exact-phrase match first, then distinct terms, then total hits
    score=$((phrase * 1000000 + matched * 10000 + total))
    list="$list
$score $f"
  done
  printf '%s\n' "$list" | sed '/^$/d' | sort -rn | head -n "$maxn" | while read -r score f; do
    [ -f "$f" ] || continue
    echo ""
    echo "## ${f#$HELP/}"
    grep -n '^#' "$f" 2>/dev/null | head -6 | sed 's/^/  /'
    if [ "$ml" -gt 0 ]; then
      grep -E -m "$ml" "$pat" "$f" 2>/dev/null | sed 's/^/  - /'
    fi
  done
}

docs_find()    { docs_top 5 3 "$@"; }

docs_snippets() { docs_top 4 8 "$@"; }

docs_add() { # $1 = source dir of .md/.txt files
  src="$1"
  if [ -z "$src" ]; then echo "usage: llm docs add <dir>  (copies .md/.txt into the help corpus)" >&2; return 2; fi
  if [ ! -d "$src" ]; then echo "docs: not a directory: $src" >&2; return 2; fi
  if [ ! -d "$HELP" ]; then echo "docs: help corpus missing - install help-module first" >&2; return 2; fi
  name=$(basename "$src" | sed 's/[^A-Za-z0-9._-]//g')
  [ -n "$name" ] || name=user
  dst="$HELP/user/$name"
  mkdir -p "$dst"
  n=0
  for f in "$src"/*.md "$src"/*.txt; do
    [ -f "$f" ] || continue
    cp -f "$f" "$dst/"
    n=$((n+1))
  done
  say "added $n doc(s) to $dst - searchable via 'llm docs find' / 'llm chat --docs'"
}

# JSON value by key (BusyBox-safe; same scanner as tavily_extract).
