# Aetherix-Alpine LLM tier - chat capability library (sourced). v0.4.6: the
# unified conversational surface. `llm chat` is the ONLY AI command:
# interactive multi-turn chat where every turn routes itself through the
# universal letter-menu router (web / docs / file / terminal / knowledge).
# One-shot flags: --once <q> (routed), --plain <q> (direct), --web <q|status|
# --test>, --docs <q>, --task <task>. The old llm ask / web / agent /
# ask-help commands are gone - everything funnels through here.

# Compact the interactive transcript to the last ~8 turns (16 lines), each
# capped so a long answer cannot blow the prompt window on a tiny model.

chat_hist_read() { # $1 = hist file -> plain-text recent context
  [ -s "$1" ] || return 0
  tail -n 16 "$1" 2>/dev/null | sed 's/\(.\{600\}\).*/\1.../'
}

chat_hist_write() { # $1 = hist file  $2 = user text  $3 = llm text
  { printf '[you] %s\n' "$2"
    printf '[llm] %s\n' "$3"; } >> "$1" 2>/dev/null
  tail -n 200 "$1" > "$1.tmp" 2>/dev/null && mv -f "$1.tmp" "$1" 2>/dev/null
}

# One routed turn: the universal router gathers material (0..N hops) and
# returns the final answer; llm_out saves/docks/prints it exactly like every
# other reply. $2 = recent chat history text (interactive mode).

chat_turn() { # $1 = user text  $2 = history text
  final=$(route_hops "$1" "$2")
  llm_out "$1" "$final"
}

# Interactive chat loop (exit: Exit or Ctrl-D). Each turn keeps its own hop
# budget and the transcript feeds the next turn as follow-up context.

chat_loop() {
  ensure_server
  HIST=/tmp/llm-chat.hist
  rm -f "$HIST"; touch "$HIST"
  say "chat mode: every question routes itself (web / docs / file / terminal / knowledge); type Exit or Ctrl-D to leave"
  while :; do
    printf 'chat> '
    IFS= read -r line || { echo ""; break; }
    line=$(printf '%s' "$line" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
    case "$line" in
      Exit) break ;;
      "") continue ;;
    esac
    hist=$(chat_hist_read "$HIST")
    final=$(route_hops "$line" "$hist")
    llm_out "$line" "$final"
    chat_hist_write "$HIST" "$line" "$final"
    echo ""
  done
  echo "chat ended"
}

# Docs completion over the help corpus (used by --docs and the docs route's
# synthesis). Persona + corpus snippets + history + terminal context.

docs_completion() { # $1 = q  $2 = system persona  $3 = history (optional)
  q="$1"; persona="$2"; hist="${3:-}"
  snips=$(docs_snippets "$q")
  ctx=$(ctx_block)
  escq=$(printf '%s' "$q" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escsnips=$(printf '%s' "$snips" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escctx=$(printf '%s' "$ctx" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escpers=$(printf '%s' "$persona" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  eschist=$(printf '%s' "$hist" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escpers\"},{\"role\":\"user\",\"content\":\"HELP CORPUS (from llm docs):\\n$escsnips\\n\\nRECENT CHAT HISTORY:\\n$eschist\\n\\nSYSTEM CONTEXT:\\n$escctx\\n\\nQUESTION: $escq\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  llm_reply "$q" "$resp"
}

answer_docs() { # $1 = question - project-doc persona over the corpus
  if [ ! -d "$HELP" ]; then
    say "docs corpus not installed - install help-module; direct answer instead:"
    plain_answer "$1"
    return 0
  fi
  docs_completion "$1" "You are the Aetherix-Alpine project assistant. Answer from the bundled project docs (versions, changelog, bug register) and help corpus. Cite the source file name in parentheses. If the docs do not cover it, say so."
}

# Dispatcher entry: llm chat [flags]

chat_cli() { # flags: --once | --plain | --web | --docs | --task | (interactive)
  case "$1" in
    --once)
      shift
      q="$*"
      if [ -z "$q" ]; then
        echo "usage: llm chat --once \"<question>\"" >&2
        return 2
      fi
      ensure_server
      final=$(route_hops "$q" "")
      llm_out "$q" "$final"
      echo ""
      ;;
    --plain)
      shift
      q="$*"
      if [ -z "$q" ]; then
        echo "usage: llm chat --plain \"<question>\"" >&2
        return 2
      fi
      ensure_server
      plain_answer "$q"
      ;;
    --web)
      shift
      sub="$1"
      if [ "$sub" = "status" ]; then
        web_status
        return 0
      fi
      if [ "$sub" = "--test" ]; then
        web_test
        return $?
      fi
      q="$*"
      if [ -z "$q" ]; then
        echo "usage: llm chat --web \"<question>\" | llm chat --web status | llm chat --web --test" >&2
        return 2
      fi
      if ! tavily_key_ok; then
        echo "llm chat --web needs a Tavily API key."
        echo "Add one in the Aetherix app: Dashboard > Tavily Key."
        return 2
      fi
      ensure_server
      web_answer "$q"
      ;;
    --docs)
      shift
      q="$*"
      if [ -z "$q" ]; then
        echo "usage: llm chat --docs \"<question>\"" >&2
        return 2
      fi
      ensure_server
      answer_docs "$q"
      ;;
    --task)
      shift
      t="$*"
      if [ -z "$t" ]; then
        echo "usage: llm chat --task \"<task>\"" >&2
        return 2
      fi
      ensure_server
      echo "task: routed tool loop (universal router, every model)"
      final=$(route_hops "$t" "")
      llm_out "$t" "$final"
      echo ""
      ;;
    '')
      chat_loop
      ;;
    *)
      echo "usage: llm chat [--once \"<q>\" | --plain \"<q>\" | --web \"<q>\" | --docs \"<q>\" | --task \"<task>\"]" >&2
      echo "       (no flags = interactive multi-turn chat; exit: Exit or Ctrl-D)" >&2
      return 2
      ;;
  esac
}
