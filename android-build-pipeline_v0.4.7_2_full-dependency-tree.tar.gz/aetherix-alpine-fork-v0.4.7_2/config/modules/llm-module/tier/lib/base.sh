# Aetherix-Alpine LLM tier - base capability library (sourced by the
# v0.4.7_2 (FB-132): say() folds long help/tour/status text at the terminal
# width - device terminals are often only 63 cols, and unwrapped lines hard-
# wrap ragged mid-word, scattering menus and the wizard tour. Uses tput cols
# (fallback 80), clamped 40..120 so piped output never explodes; wraps at
# word boundaries and hard-cuts only overlong tokens (URLs, paths).
say() {
  say_w=${SAY_WIDTH:-$(tput cols 2>/dev/null | tr -dc '0-9')}
  case "$say_w" in ''|*[!0-9]*) say_w=80;; esac
  [ "$say_w" -lt 40 ] && say_w=40
  [ "$say_w" -gt 120 ] && say_w=120
  printf '%s\n' "$*" | awk -v W="$say_w" '
    {
      s = $0
      while (length(s) > W) {
        cut = W
        i = W
        while (i > 1 && substr(s, i, 1) != " ") i--
        if (i > 1) cut = i - 1
        print substr(s, 1, cut)
        s = substr(s, cut + 1)
        sub(/^ /, "", s)
      }
      print s
    }
  '
  unset say_w
}

# v0.4.7: read the native context length (llama.context_length) straight from
# the GGUF header - no jq/python. od + awk walk the metadata KV section of the
# first 256 KiB (metadata is tiny; tensor data lives after). Echoes the value
# when found; exits 1 silently on any parse failure so callers fall back to
# the profile window. Values are 8-byte aligned in the GGUF spec.
gguf_n_ctx() { # $1 = .gguf file
  f="$1"
  [ -n "$f" ] && [ -f "$f" ] && [ -r "$f" ] || return 1
  # v0.4.7: cache the parse per (path, mtime, size) - llama.context_length sits
  # after the tokenizer vocab, which can be several MB of strings; streaming
  # skip makes this a one-time cost per model, never per chat turn.
  cache=/etc/aetherix/llm.gguf.ctx
  mtime=$(stat -c %Y "$f" 2>/dev/null | tr -dc '0-9')
  fsize=$(stat -c %s "$f" 2>/dev/null | tr -dc '0-9')
  if [ -n "$mtime" ] && [ -n "$fsize" ] && [ -f "$cache" ]; then
    read -r cp cm cs cv < "$cache" 2>/dev/null
    if [ "$cp" = "$f" ] && [ "$cm" = "$mtime" ] && [ "$cs" = "$fsize" ]; then
      case "$cv" in
        [0-9]*) echo "$cv"; return 0 ;;
      esac
    fi
  fi
  # Streaming GGUF v1-3 metadata walker: od emits 16 decimal bytes per line;
  # the tokenizer vocab is skipped in line-sized chunks instead of buffered.
  v=$(od -An -v -t u1 "$f" 2>/dev/null | LC_ALL=C awk '
    function loadline(   i) {
      if (getline <= 0) return 0
      if (++nlines > 4194304) return 0   # 64 MiB safety cap on metadata
      nf = NF
      for (i = 1; i <= NF; i++) L[i-1] = $i + 0
      c = 0
      return 1
    }
    function byte(   b) {
      if (c >= nf) { if (!loadline()) return -1 }
      b = L[c]; c++
      return b
    }
    function skipb(k,   rem) {
      while (k > 0) {
        rem = nf - c
        if (rem >= k) { c += k; return 1 }
        k -= rem
        if (!loadline()) return 0
      }
      return 1
    }
    function u32(   i, b, v, m) {
      v = 0; m = 1
      for (i = 0; i < 4; i++) { b = byte(); if (b < 0) return -1; v += b*m; m *= 256 }
      return v
    }
    function u64(   i, b, v, m) {
      v = 0; m = 1
      for (i = 0; i < 8; i++) { b = byte(); if (b < 0) return -1; v += b*m; m *= 256 }
      return v
    }
    function keyname(   len, s, i, b) {
      len = u64(); if (len < 0 || len > 4096) return ""
      s = ""
      for (i = 0; i < len; i++) { b = byte(); if (b < 0) return ""; s = s sprintf("%c", b) }
      return s
    }
    function skipstr(   len) { len = u64(); if (len < 0) return 0; return skipb(len) }
    function skipv(vt,   at, al, i) {
      if (vt == 0 || vt == 1 || vt == 7) return skipb(1)
      if (vt == 2 || vt == 3) return skipb(2)
      if (vt == 4 || vt == 5 || vt == 6) return skipb(4)
      if (vt == 10 || vt == 11 || vt == 12) return skipb(8)
      if (vt == 8) return skipstr()
      if (vt == 9) {
        at = u32(); if (at < 0) return 0
        al = u64(); if (al < 0) return 0
        for (i = 0; i < al; i++) {
          if (at == 8) { if (!skipstr()) return 0 }
          else if (at == 0 || at == 1 || at == 7) { if (!skipb(1)) return 0 }
          else if (at == 2 || at == 3) { if (!skipb(2)) return 0 }
          else if (at == 4 || at == 5 || at == 6) { if (!skipb(4)) return 0 }
          else if (at == 10 || at == 11 || at == 12) { if (!skipb(8)) return 0 }
          else return 0
        }
        return 1
      }
      return 0
    }
    BEGIN {
      if (!loadline()) exit 1
      if (byte() != 71 || byte() != 71 || byte() != 85 || byte() != 70) exit 1
      if (u32() < 0) exit 1          # version
      if (u64() < 0) exit 1          # tensor count
      nkv = u64(); if (nkv < 0 || nkv > 100000) exit 1
      for (k = 0; k < nkv; k++) {
        key = keyname(); if (key == "") exit 1
        vt = u32(); if (vt < 0) exit 1
        if (key == "llama.context_length") {
          if (vt == 4 || vt == 5) { v = u32(); if (v >= 0) print v; exit }
          if (vt == 10 || vt == 11) { v = u64(); if (v >= 0) print v; exit }
          if (vt == 0 || vt == 1 || vt == 2 || vt == 3) { b = byte(); if (b >= 0) print b; exit }
          exit 1
        }
        if (!skipv(vt)) exit 1
      }
      exit 1
    }
  ')
  case "$v" in
    ''|*[!0-9]*) return 1 ;;
  esac
  if [ -n "$mtime" ] && [ -n "$fsize" ]; then
    printf '%s %s %s %s\n' "$f" "$mtime" "$fsize" "$v" > "$cache" 2>/dev/null
  fi
  echo "$v"
}
# llm dispatcher; never run standalone). Server/model lifecycle, context,
# profiles, chat routing, reply plumbing, capabilities manifest.

# Shared config. Guarded so the dispatcher header wins when present (same
# values); the defaults keep the libs usable standalone, e.g. under tests.
: "${STATE:=/etc/aetherix/llm.state}"
: "${CONF:=/etc/aetherix/llm.conf}"
: "${BSTATE:=/etc/aetherix/llm.build.state}"
: "${BLOG:=/var/log/llm-build.log}"
: "${CHATLOG:=/etc/aetherix/llm-chat.log}"
: "${RESPDIR:=/etc/aetherix/responses}"
: "${LPORT:=8080}"
: "${MODELS:=/root/models}"
: "${LLM_MAX_TOKENS:=512}"
: "${PROFILES:=/etc/aetherix/model-profiles.conf}"
: "${TCONTEXT:=/etc/aetherix/term.context}"
: "${HELP:=/etc/aetherix/help}"
: "${INPUT_DIR:=${AETHERIX_INPUT_DIR:-$HOME/storage/input}}"
: "${OUTPUT_DIR:=${AETHERIX_OUTPUT_DIR:-$HOME/storage/output}}"
: "${TERM_ENABLED:=1}"


model() { grep -m1 '^model=' "$CONF" 2>/dev/null | cut -d= -f2; }

running() { pgrep -f llama-server >/dev/null 2>&1; }

# FB-064: a build counts as live only while the detached script (or its
# cmake --build child) actually exists. Android can kill the app's process
# group even though the state file still says 'building'.

parse_reply() { # $1 = raw response body
  if printf '%s' "$1" | grep -q '"content":"'; then
    printf '%s' "$1" \
      | sed -n 's/.*"content":"//p' \
      | sed 's/"},"refusal".*//; s/"},"finish_reason".*//; s/"},"index".*//; s/"}}],"created".*//' \
      | sed 's/\\n/\n/g; s/\\t/\t/g; s/\\"/"/g'
  elif [ -z "$1" ]; then
    echo "no response - is the server running? (llm start)"
  else
    printf '%s' "$1" | head -c 2000
  fi
}

# FB-102: turn a Tavily JSON body into numbered result lines for the model.
# BusyBox-safe (no jq): a quote/escape-aware scanner walks the flat results
# array, so titles/URLs/content with escaped quotes, ] or }, inside them parse
# correctly. Tavily is asked for basic depth (flat result objects only).

transcript() { # $1 = speaker (you|llm)  $2 = text
  mkdir -p /etc/aetherix 2>/dev/null
  ts=$(date +%H:%M:%S 2>/dev/null || echo --:--:--)
  printf '[%s] %s: %s\n' "$ts" "$1" "$2" >> "$CHATLOG" 2>/dev/null
  lines=$(wc -l < "$CHATLOG" 2>/dev/null | tr -d ' ')
  case "$lines" in ''|*[!0-9]*) return 0;; esac
  if [ "$lines" -gt 200 ]; then
    tail -n 200 "$CHATLOG" > "$CHATLOG.tmp" 2>/dev/null \
      && mv -f "$CHATLOG.tmp" "$CHATLOG" 2>/dev/null
  fi
}

# v0.4.3 (FB-113): keep one file per reply so 'llm replies' and 'llm export'
# work outside the app, and ask the app to open the response dock whenever a
# reply lands (the app polls + clears /etc/aetherix/dock.request).

save_reply() { # $1 = question  $2 = reply text
  mkdir -p "$RESPDIR" 2>/dev/null || return 0
  ts=$(date +%Y%m%d-%H%M%S 2>/dev/null || echo unknown)
  { printf '# Q: %s\n\n' "$1"; printf '%s\n' "$2"; } > "$RESPDIR/$ts.md" 2>/dev/null
  n=0
  for f in $(ls -1t "$RESPDIR"/*.md 2>/dev/null); do
    n=$((n+1))
    [ "$n" -gt 50 ] && rm -f "$f"
  done
  if [ "$AETHERIX_DOCK" = "1" ]; then
    printf 'show\n' > /etc/aetherix/dock.request 2>/dev/null
  fi
}

# FB-081: when the launcher exports AETHERIX_DOCK=1 the app shows replies in
# the docked response window (transcript only, no terminal output); otherwise
# print the reply inline exactly like 14_11.

llm_reply() { # $1 = question  $2 = raw response body
  out=$(parse_reply "$2")
  save_reply "$1" "$out"
  if [ "$AETHERIX_DOCK" = "1" ]; then
    transcript you "$1"
    transcript llm "$out"
  else
    printf '%s\n' "$out"
  fi
}

# v0.4.4 (Q8): OpenMP-aware compiler. clang needs the LLVM OpenMP runtime
# (libomp); when libomp is unavailable (the best-effort 'apk add libomp' fails)
# gcc is used so -DGGML_OPENMP=ON links via gcc's bundled libgomp. Otherwise
# cmake silently falls back to GGML_OPENMP=OFF and inference loses parallel
# kernels. LLM_USE_CLANG=1 forces clang (accepting the OpenMP-OFF fallback),
# =0 forces gcc.

capabilities() {
  model_profile
  march=$(cpu_march)
  echo "== Aetherix-Alpine LLM capabilities =="
  echo ""
  echo "Base:"
  say "  - one AI command: llm chat (interactive, routed, multi-hop per turn)"
  say "  - 135M-10B GGUF models (llama.cpp, loopback only); start/stop/status"
  say "  - per-model profiles (ctx/batch/router hops), replies, export"
  echo "  - build llama-server from source; hf browse/download"
  echo "Context (llm context):"
  say "  - terminal tail snapshot (~40 lines), system/module/job state"
  echo "  - INPUT dropbox listing, storage map, knowledge-card map"
  echo "Web:"
  say "  - Tavily search + cited synthesis (needs Dashboard > Tavily Key)"
  echo "  - no keyless web fallback (SearXNG deferred)"
  echo "RAG/docs:"
  echo "  - llm docs find/add over the help-module corpus and cards"
  echo "Router (v0.4.6, universal - every model):"
  if [ "$ROUTER_ENABLED" -eq 1 ]; then
    say "  - guided router: ON - one-token A/B/C/D/E/F menu per hop, <=6 hops"
    say "    (small-world); the tier executes web/docs/file/terminal tools"
    echo "    (profile hops = $ROUTER_HOPS, LLM_ROUTER_MAX overrides)"
  else
    echo "  - guided router: OFF (LLM_ROUTER=0 or profile hop limit 0)"
  fi
  echo "Profile & responses:"
  if [ -n "$CLAMP_NATIVE" ]; then
    say "  - active profile: ctx $CTX_SIZE (clamped from native $CLAMP_NATIVE), batch $BATCH_SIZE, hops $ROUTER_HOPS"
  else
    say "  - active profile: ctx $CTX_SIZE, batch $BATCH_SIZE, hops $ROUTER_HOPS"
  fi
  say "  - context: 8192 floor, clamped to the model's GGUF native window when smaller"
  say "  - max response: $LLM_MAX_TOKENS tokens per reply (LLM_MAX_TOKENS overrides; export keeps full text)"
  echo "Terminal bridge (v0.4.5):"
  if [ "$TERM_ENABLED" -eq 1 ]; then
    say "  - term_run: ON - read/status commands auto-run; everything else asks the user first"
  else
    echo "  - term_run: OFF (LLM_TERM=0)"
  fi
  echo "File access:"
  say "  - read-only: help corpus, home, ~/storage, INPUT dropbox (<=60 lines/4KB)"
  echo "Cannot:"
  say "  - write to the prompt/scrollback, live scrollback reads (only the ~40-line snapshot)"
  echo "  - keyless web search, vision/multimodal, cloud sync"
  echo "Build (device):"
  say "  - compiler: $(pick_compiler) (LLM_USE_CLANG=${LLM_USE_CLANG:-auto})"
  echo "  - openmp: $(openmp_state)   march: ${march:-none}"
  if [ -s "$BLOG" ]; then
    grep -o 'Performing Test HAVE_[A-Z0-9_]* - Success\|Performing Test HAVE_[A-Z0-9_]* - Failed' "$BLOG" 2>/dev/null | sort -u | sed 's/^/  probes: /'
  fi
}

# ---- v0.4.2: model profiles, terminal context, routing, help ----

model_profile() {
  f=$(model)
  [ -n "$f" ] || f="$LLM_MODEL"
  mfile=$f
  f=$(basename "$f" 2>/dev/null | tr 'A-Z' 'a-z')
  ctx=8192; batch=512; hops=6
  if [ -f "$PROFILES" ]; then
    while IFS= read -r line; do
      case "$line" in ''|\#*) continue;; esac
      pat=$(printf '%s' "$line" | awk '{print $1; exit}')
      vctx=$(printf '%s' "$line" | awk '{print $2; exit}')
      vbatch=$(printf '%s' "$line" | awk '{print $3; exit}')
      vhops=$(printf '%s' "$line" | awk '{print $4; exit}')
      case "$pat" in ''|*[!a-z0-9*?]*) continue;; esac
      case "$vctx" in ''|*[!0-9]*) continue;; esac
      case "$vbatch" in ''|*[!0-9]*) continue;; esac
      case "$vhops" in ''|*[!0-9]*) continue;; esac
      case "$f" in
        $pat) ctx=$vctx; batch=$vbatch; hops=$vhops; break ;;
      esac
    done < "$PROFILES"
  fi
  forced=0
  case "$LLM_CTX" in ''|*[!0-9]*) ;; *) ctx=$LLM_CTX; forced=1 ;; esac
  # v0.4.7: clamp the window down to the model's trained context when the
  # GGUF says the model supports less than the profile row (e.g. SmolLM2 is
  # 2048). CLAMP_NATIVE lets status/capabilities show what happened. A forced
  # LLM_CTX always wins (no clamp). When the native window is larger we keep
  # the profile / 8192 floor size.
  CLAMP_NATIVE=""
  if [ "$forced" -ne 1 ]; then
    native=$(gguf_n_ctx "$mfile" 2>/dev/null)
    case "$native" in ''|*[!0-9]*) native="" ;; esac
    if [ -n "$native" ] && [ "$native" -gt 0 ] && [ "$native" -lt "$ctx" ]; then
      ctx=$native
      CLAMP_NATIVE=$native
    fi
  fi
  case "$LLM_BATCH" in ''|*[!0-9]*) ;; *) batch=$LLM_BATCH ;; esac
  case "$LLM_ROUTER_MAX" in ''|*[!0-9]*) ;; *) hops=$LLM_ROUTER_MAX ;; esac
  [ "$batch" -gt "$ctx" ] && batch=$ctx
  [ "$hops" -gt 0 ] || hops=0
  CTX_SIZE=$ctx
  BATCH_SIZE=$batch
  ROUTER_HOPS=$hops
  # v0.4.6: the guided router is universal - every model uses it; it never
  # depends on native tool-calling training. LLM_ROUTER=0 disables tools,
  # and a 0-hop profile row does the same.
  case "$LLM_ROUTER" in
    0) ROUTER_ENABLED=0 ;;
    *) ROUTER_ENABLED=1 ;;
  esac
  # v0.4.5: the terminal bridge is a user gate, not a model capability.
  case "$LLM_TERM" in
    0) TERM_ENABLED=0 ;;
    *) TERM_ENABLED=1 ;;
  esac
  export CTX_SIZE BATCH_SIZE ROUTER_HOPS ROUTER_ENABLED TERM_ENABLED CLAMP_NATIVE
}

# Spawn llama-server with the active model's profile (ctx/batch from
# model_profiles.conf). Caller checks the model file first.

spawn_server() {
  model_profile
  nohup llama-server --host 127.0.0.1 --port $LPORT -m "$m" \
    --ctx-size $CTX_SIZE --batch-size $BATCH_SIZE >/var/log/llama-server.log 2>&1 &
  echo running > "$STATE"
  sleep 1
  say "llama-server starting on 127.0.0.1:$LPORT (OpenAI-compatible API)"
}

# Start the server if needed (model must be set and present).

ensure_server() {
  need_llama
  m=$(model)
  if [ -z "$m" ]; then
    echo "no model set - run 'llm model ~/models/<file>.gguf' first" >&2; exit 2; fi
  if [ ! -f "$m" ]; then echo "model file not found: $m" >&2; exit 2; fi
  if ! running; then
    spawn_server
  fi
}

# FB-104: terminal + system snapshot. The app writes the last ~40 terminal
# lines to $TCONTEXT on resume/resize (TerminalActivity); chat/router prompts inject
# this block so the model is aware of what the user is doing.

term_tail() {
  if [ -s "$TCONTEXT" ]; then
    tail -n 40 "$TCONTEXT" 2>/dev/null
  else
    echo "(no terminal context yet - open the terminal session)"
  fi
}

core_line() {
  if command -v core >/dev/null 2>&1; then
    out=$(core status 2>/dev/null | head -1)
    [ -n "$out" ] && echo "$out"
  fi
}

modules_line() {
  out=""
  for d in /etc/aetherix/modules.d/*/; do
    [ -d "$d" ] || continue
    nm=$(basename "$d")
    ver=$(grep -m1 '^version:' "$d/info" 2>/dev/null | cut -d: -f2 | tr -d ' ')
    [ -n "$ver" ] || ver="?"
    out="$out $nm($ver)"
  done
  [ -n "$out" ] || out=" none"
  echo "installed modules:$out"
}

jobs_line() {
  n=0
  for sf in /etc/aetherix/jobs/*.state; do
    [ -f "$sf" ] || continue
    id=$(sed -n 's/^id=//p' "$sf" | head -1)
    st=$(sed -n 's/^status=//p' "$sf" | head -1)
    pct=$(sed -n 's/^pct=//p' "$sf" | head -1)
    case "$pct" in ''|*[!0-9]*) pct=0;; esac
    if [ "$st" = "running" ]; then
      printf '  %s: running %s%%\n' "$id" "$pct"
      n=$((n+1))
    fi
  done
  [ "$n" -eq 0 ] && echo "  (no running jobs)"
}

storage_line() {
  if [ -s /etc/aetherix/storage.map ]; then
    sed 's/^/  /' /etc/aetherix/storage.map 2>/dev/null
  else
    echo "  (no storage map - run 'sd mount')"
  fi
}

ctx_block() {
  echo "=== terminal (last visible lines) ==="
  term_tail
  echo ""
  echo "=== environment ==="
  echo "pwd: $(pwd 2>/dev/null)"
  echo "tty size: $(stty size 2>/dev/null || echo unknown)"
  core_line
  modules_line
  jobs_line
  if running; then echo "llm server: running (model: $(model))"; else echo "llm server: stopped"; fi
  if tavily_key_ok; then echo "web search: tavily (key set)"; else echo "web search: tavily (no key)"; fi
  echo ""
  echo "=== user input dropbox (Aetherix-Alpine_INPUT) ==="
  say "=== knowledge cards (small-world, /etc/aetherix/help/cards) ==="
  if [ -d "$HELP/cards" ]; then
    say "  Tool-tip cards: start at 00 HOME and follow RELATED links (any answer within 6 hops)."
    say "  Hubs: 06 SETUP, 11 TERMINAL, 15 STORAGE, 19 MODULES, 25 LLM, 38 APP, 43 TROUBLESHOOTING, 48 RESEARCH, 56 CAPABILITIES, 57 TERM-TOOLS, 58 MENU."
    say "  Fetch a card via 'llm docs find <topic>' or the router's file hop; DEEP: lines name the full docs."
  else
    echo "  (cards not deployed - reinstall help-module)"
  fi
  echo ""
  if [ -d "$INPUT_DIR" ]; then
    ls -1 "$INPUT_DIR" 2>/dev/null | head -20 | while read -r f; do
      [ -z "$f" ] && continue
      sz=$(wc -c < "$INPUT_DIR/$f" 2>/dev/null | tr -d ' ')
      case "$sz" in ''|*[!0-9]*) sz=0;; esac
      printf '  %s (%s bytes)\n' "$f" "$sz"
    done
  else
    say "  (input dropbox not mounted - put files in Downloads/Aetherix-Alpine_INPUT)"
  fi
  echo ""
  echo "=== storage map ==="
  storage_line
}

# ---- help corpus (help-module) ----

json_val() { # $1 = key; reads a JSON object on stdin
  awk -v key="$1" '
    function val(s, k,   klen, i, n, p, c, v) {
      n = length(s); klen = length(k) + 3
      for (i = 1; i + klen - 1 <= n; i++) {
        if (substr(s, i, klen) == "\"" k "\":") break
      }
      if (i + klen - 1 > n) return ""
      p = i + klen
      while (p <= n && (substr(s, p, 1) == " " || substr(s, p, 1) == "\t")) p++
      if (p > n || substr(s, p, 1) != "\"") return ""
      p++; v = ""
      while (p <= n) {
        c = substr(s, p, 1)
        if (c == "\\") {
          p++
          if (p <= n) {
            c = substr(s, p, 1)
            if (c == "n") v = v " "; else v = v c
          }
          p++
          continue
        }
        if (c == "\"") break
        v = v c
        p++
      }
      return v
    }
    { print val($0, key); exit }
  '
}

# Parse an OpenAI chat.completions body for "tool_calls": emit for each call
#   ID:<id>
#   NAME:<function name>
#   ARGS:<unescaped arguments JSON>

llm_out() { # $1 = user text  $2 = plain assistant text
  save_reply "$1" "$2"
  if [ "$AETHERIX_DOCK" = "1" ]; then
    transcript you "$1"
    transcript llm "$2"
  else
    printf '%s\n' "$2"
  fi
}

plain_answer() { # $1 = question - direct completion with system persona + ctx
  q="$1"
  ctx=$(ctx_block)
  system="You are the Aetherix-Alpine assistant on an Android phone (Alpine Linux inside PRoot). Be concise and practical. The terminal context below is what the user is currently doing - answer with it in mind."
  escq=$(printf '%s' "$q" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escsys=$(printf '%s' "$system" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  esctx=$(printf '%s' "$ctx" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escsys\"},{\"role\":\"user\",\"content\":\"$escq\\n\\nTerminal context:\\n$esctx\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  llm_reply "$q" "$resp"
}
