# Aetherix-Alpine LLM tier - document/output capability library (sourced).
# Reply capture printing, dock transcript, and OUTPUT-dropbox export.
export_cli() { # $1 = optional source path
  src="${1:-}"
  if [ -z "$src" ]; then
    src=$(ls -1t "$RESPDIR"/*.md 2>/dev/null | head -1)
    if [ -n "$src" ]; then
      kind="llm-response"
    else
      echo "no replies yet - run 'llm chat' first (or pass a file path)" >&2
      return 1
    fi
  else
    kind="$(basename "$src")"
  fi
  [ -f "$src" ] || { echo "no such file: $src" >&2; return 1; }
  mkdir -p "$OUTPUT_DIR" 2>/dev/null
  if [ ! -d "$OUTPUT_DIR" ] || [ ! -w "$OUTPUT_DIR" ]; then
    echo "output folder not writable - the app creates Downloads/Aetherix-Alpine_OUTPUT on next start" >&2
    return 1
  fi
  ts=$(date +%Y%m%d-%H%M%S 2>/dev/null || echo unknown)
  name=$(printf '%s' "$kind" | sed "s/^\(.*\)\.\([^.]*\)$/\1-$ts.\2/")
  [ "$name" = "$kind" ] && name="$kind-$ts"
  cp -f "$src" "$OUTPUT_DIR/$name"
  echo "exported: $OUTPUT_DIR/$name ($(wc -c < "$OUTPUT_DIR/$name") bytes)"
}
replies_cli() { # $1 = n
  n="${1:-5}"
  case "$n" in ''|*[!0-9]*) n=5;; esac
  if [ -d "$RESPDIR" ] && ls -1 "$RESPDIR"/*.md >/dev/null 2>&1; then
    for f in $(ls -1t "$RESPDIR"/*.md 2>/dev/null | head -n "$n"); do
      [ -f "$f" ] || continue
      echo ""
      echo "===== $(basename "$f") ====="
      cat "$f" 2>/dev/null
    done
  else
    echo "no replies yet - run 'llm chat' first"
  fi
}
chat_log_cli() { # $1 = n
  n="${1:-40}"
  case "$n" in ''|*[!0-9]*) n=40;; esac
  if [ -s "$CHATLOG" ]; then tail -n "$n" "$CHATLOG"; else echo "no chat transcript yet"; fi
}
