# Aetherix-Alpine LLM tier - agent capability library (sourced). Universal
# guided router (v0.4.6): every model - 135M up - drives the same single-
# token letter menu per hop. No native tool-calling training required
# (binary decision tree + small-world reasoning through the data cards).
# The native OpenAI tool_calls loop was DELETED in v0.4.6 (see
# docs/v0.4.6/RESEARCH.md): free-form JSON tool calls are unreliable under
# 2B params, so the tier executes tools and the model only picks letters.

# Agent tool: read a text file / list a dir, read-only, restricted to the help
# corpus, the home dir, and ~/storage.

safe_file_read() { # $1 = path
  p="$1"
  case "$p" in
    '') echo "ERROR: empty path"; return 0 ;;
    *'..'*) echo "ERROR: path traversal not allowed"; return 0 ;;
  esac
  case "$p" in
    /*) : ;;
    *) p="$HOME/$p" ;;
  esac
  rp=$(command -v readlink >/dev/null 2>&1 && readlink -f "$p" 2>/dev/null || echo "$p")
  ok=0
  case "$rp" in
    /etc/aetherix/help|/etc/aetherix/help/*) ok=1 ;;
  esac
  h=$(command -v readlink >/dev/null 2>&1 && readlink -f "$HOME" 2>/dev/null || echo "$HOME")
  case "$rp" in
    "$h"|"$h"/*) ok=1 ;;
  esac
  # v0.4.4: the app's INPUT dropbox is an explicit read target (context lists
  # it), even when it is not under $HOME.
  ir=$(command -v readlink >/dev/null 2>&1 && readlink -f "$INPUT_DIR" 2>/dev/null || echo "$INPUT_DIR")
  case "$rp" in
    "$ir"|"$ir"/*) ok=1 ;;
  esac
  if [ "$ok" != "1" ]; then
    say "ERROR: file_read is limited to the help corpus, your home dir, and ~/storage"
    return 0
  fi
  if [ -d "$rp" ]; then
    ls -1 "$rp" 2>/dev/null | head -30 | sed 's/^/  /'
  elif [ -f "$rp" ]; then
    sed -n '1,60p' "$rp" 2>/dev/null | head -c 4000
  else
    echo "ERROR: not found: $rp"
  fi
}

# v0.4.5: gated terminal bridge (Q5). Read-only/status commands auto-run;
# everything else asks the user first (declined when no TTY, e.g. a strapped
# prompt). Metacharacters, redirection, globs and destructive targets are
# refused outright. Output is capped (60 lines / 4 KB) so a runaway command
# cannot flood the agent context. LLM_TERM=0 disables the bridge entirely.

TERM_ALLOW='ls cat pwd df du ps free uname uptime echo printf grep wc stat file head tail find mount date id whoami env readlink which basename dirname realpath sha256sum'

term_allowlisted() { # $1 = command line -> 0 if on the read-only/status allowlist
  for a in "git status" "git log" "llm status" "llm context" "llm docs find"; do
    case "$1" in
      "$a "*) return 0 ;;
      "$a") return 0 ;;
    esac
  done
  first=$(printf '%s' "$1" | awk '{print $1}')
  for c in $TERM_ALLOW; do
    [ "$first" = "$c" ] && return 0
  done
  return 1
}

term_has_meta() { # $1 = command line -> 0 if it contains shell metacharacters
  case "$1" in
    *';'*|*'|'*|*'&'*|*'$('*|*')'*|*'`'*|*'>'*|*'<'*|*'*'*|*'?'*|*'~'*|*'{'*|*'}'*|*'['*|*']'*)
      return 0
      ;;
  esac
  return 1
}

term_denied() { # $1 = command line -> 0 if destructive / out of bounds
  case "$1" in
    *"rm -rf /"*|*"rm -fr /"*|*"rm -rf -- "*|*"rm -r /"*) return 0 ;;
    *"mkfs"*|*"fdisk"*|*"partition"*) return 0 ;;
    *"dd "*"of=/dev/"*) return 0 ;;
    *"chmod -R"*" /"*|*"chown -R"*" /"*) return 0 ;;
    reboot|poweroff|halt|shutdown*) return 0 ;;
    *" > /"*|*" >> /"*|*" >/etc/"*|*" > /etc/"*) return 0 ;;
  esac
  return 1
}

term_run() { # $1 = command line (single command; hybrid allowlist + confirm)
  if [ "${TERM_ENABLED:-1}" != "1" ]; then
    echo "term_run: OFF - terminal bridge disabled (LLM_TERM=0)" >&2
    return 1
  fi
  cmd="$1"
  if term_denied "$cmd"; then
    echo "term_run: refused - destructive command (security denylist)" >&2
    return 1
  fi
  if term_has_meta "$cmd"; then
    echo "term_run: refused - shell metacharacters not allowed (single command only)" >&2
    return 1
  fi
  if ! term_allowlisted "$cmd"; then
    if [ -t 0 ]; then
      printf 'term_run: run "%s"? [y/N] ' "$cmd"
      IFS= read -r ans
      case "$ans" in
        y|Y|yes|YES) : ;;
        *)
          echo "term_run: declined by user" >&2
          return 1
          ;;
      esac
    else
      echo "term_run: declined - non-allowlist command needs interactive confirmation" >&2
      return 1
    fi
  fi
  (cd "$HOME" 2>/dev/null || true
   timeout 30 sh -c "$cmd" 2>&1 | head -60 | head -c 4000)
  return 0
}

router_complete() { # $1 = system  $2 = payload  -> full reply text
  escsys=$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  # the ROUTER FINAL marker stays visible to the payload so logs/tests can key it
  escpl=$(printf '%s' "$2\n\nROUTER FINAL" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions     -H 'Content-Type: application/json'     -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escsys\"},{\"role\":\"user\",\"content\":\"$escpl\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  parse_reply "$resp"
}

router_pick() { # $1 = marker  $2 = system  $3 = payload -> first token, lowercased
  escsys=$(printf '%s' "$2" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  # the marker (ROUTER STEP n / ROUTER FILE) rides in the payload so logs and
  # the test fixtures can key on the decision hop
  escpl=$(printf '%s' "$3\n\nROUTER CHOICE: $1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions     -H 'Content-Type: application/json'     -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escsys\"},{\"role\":\"user\",\"content\":\"$escpl\"}],\"max_tokens\":16}")
  parse_reply "$resp" | tr -c 'a-zA-Z0-9' ' ' | awk '{print $1}' | tr 'A-Z' 'a-z'
}

# ---- v0.4.6: universal multi-hop router (every model, every chat turn) ----
# OODA framing: each turn Observes (terminal context + chat history + material
# gathered so far), Orients (one-letter menu), Acts (the tier runs the chosen
# tool), then Decides (F = final answer). Small-world: any task resolves in
# <= LLM_ROUTER_MAX hops (default 6). LLM_ROUTER=0 (or a 0-hop profile)
# disables tools entirely -> direct knowledge answer.

router_enabled() {
  model_profile
  [ "$ROUTER_ENABLED" = "1" ] && [ "$ROUTER_HOPS" -gt 0 ]
}

route_menu_payload() { # $1 = hop  $2 = task  $3 = history  $4 = gathered  $5 = src tags
  hop="$1"; task="$2"; hist="$3"; gathered="$4"; srcs="$5"
  echo "TASK: $task"
  if [ -n "$hist" ]; then
    echo ""
    echo "RECENT CHAT HISTORY (follow-up context, earlier turns):"
    printf '%s\n' "$hist"
  fi
  echo ""
  echo "MATERIAL GATHERED SO FAR:$srcs"
  if [ -n "$gathered" ]; then
    printf '%s\n' "$gathered"
  else
    echo "(nothing yet)"
  fi
  echo ""
  echo "What does the task still need? Reply with a single letter."
  echo "A) current or external information only the web knows"
  echo "B) Aetherix-Alpine help or project docs"
  echo "C) a file on this phone (INPUT dropbox, home, or storage)"
  echo "D) answer from what you already know (no new tool)"
  if [ "${TERM_ENABLED:-1}" = "1" ]; then
    say "E) run a terminal command (read/status auto-run; others confirm first)"
  fi
  echo "F) I have enough - write the final answer now"
}

route_hops() { # $1 = task  $2 = history text  -> final answer on stdout
  task="$1"; hist="$2"
  model_profile
  if [ "$ROUTER_ENABLED" != "1" ] || [ "$ROUTER_HOPS" -lt 1 ]; then
    say "chat: tools disabled (LLM_ROUTER=0 or profile hop limit 0) - answering from knowledge"
    router_complete "You are the Aetherix-Alpine assistant on an Android phone. Answer the question concisely from your own knowledge, with the terminal context and chat history in mind. If the material is not enough, say exactly what is missing." "KNOWLEDGE:
(no tools used)

TASK: $task

Final answer:"
    return 0
  fi
  maxhops=$ROUTER_HOPS
  ctx=$(ctx_block)
  gathered=""; srcs=""; hop=0
  while [ "$hop" -lt "$maxhops" ]; do
    hop=$((hop+1))
    payload=$(route_menu_payload "$hop" "$task" "$hist" "$gathered" "$srcs")
    if [ "$hop" -eq 1 ]; then
      payload="$payload

TERMINAL CONTEXT:
$ctx"
    fi
    choice=$(router_pick "ROUTER STEP $hop" "You are the Aetherix-Alpine tiny assistant on Android (Alpine Linux inside PRoot). Reply with a single letter only - no explanation." "$payload")
    case "$choice" in
      a) # web (Tavily, Vane-style: search -> cite [n] -> synthesize)
        srcs="$srcs

[hop $hop: web]"
        if ! tavily_key_ok; then
          say "chat: hop $hop - web needs a Tavily key (Dashboard > Tavily Key) - answering from knowledge"
          choice=d
        else
          # v0.4.7: answer-first gather (Tavily include_answer) - short context
          # keeps the cumulative 6-hop prompt inside the 8k window.
          web_gather "$task" ""
          got=$(cat /tmp/web-gather.txt 2>/dev/null)
          if [ -n "$got" ]; then
            gathered="$gathered

WEB RESULTS (hop $hop):
$got"
            echo "chat: hop $hop - web results gathered"
            continue
          fi
          say "chat: hop $hop - web search failed - answering from knowledge"
          choice=d
        fi
        ;;
      b) # local help/docs corpus
        srcs="$srcs

[hop $hop: docs]"
        if [ ! -d "$HELP" ]; then
          say "chat: hop $hop - help corpus missing (install help-module) - answering from knowledge"
          choice=d
        else
          got=$(docs_snippets "$task")
          if [ -n "$got" ]; then
            gathered="$gathered

LOCAL DOCS (hop $hop):
$got"
            echo "chat: hop $hop - docs gathered"
            continue
          fi
          echo "chat: hop $hop - no matching docs - answering from knowledge"
          choice=d
        fi
        ;;
      c) # INPUT dropbox / home file
        srcs="$srcs

[hop $hop: file]"
        if [ ! -d "$INPUT_DIR" ]; then
          say "chat: hop $hop - INPUT dropbox not mounted - answering from knowledge"
          choice=d
        else
          i=0; files=""
          for f in "$INPUT_DIR"/*; do
            [ -f "$f" ] || continue
            i=$((i+1))
            [ "$i" -gt 10 ] && break
            files="$files
  $i) $(basename "$f") ($(wc -c < "$f" 2>/dev/null) bytes)"
          done
          if [ -z "$files" ]; then
            say "chat: hop $hop - INPUT dropbox is empty - answering from knowledge"
            choice=d
          else
            pick=$(router_pick "ROUTER FILE" "Reply with a single file number, or 0 if none of these files can help. Nothing else." "TASK: $task

FILES IN Aetherix-Alpine_INPUT:$files

Which file should I read? Reply with its number, or 0 to skip.")
            case "$pick" in
              0|''|none|skip)
                echo "chat: hop $hop - no file chosen - answering from knowledge"
                choice=d
                ;;
              *)
                n=$(printf '%s' "$pick" | tr -cd '0-9')
                case "$n" in
                  ''|0) choice=d ;;
                  *)
                    tgt=$(ls -1 "$INPUT_DIR" 2>/dev/null | sed -n "${n}p")
                    if [ -n "$tgt" ]; then
                      got=$(safe_file_read "$INPUT_DIR/$tgt")
                      case "$got" in
                        ERROR:*) echo "chat: hop $hop - cannot read '$tgt' - answering from knowledge"; choice=d ;;
                        *)
                          gathered="$gathered

FILE CONTENTS ($tgt, hop $hop):
$got"
                          echo "chat: hop $hop - file '$tgt' read"
                          continue
                          ;;
                      esac
                    else
                      echo "chat: hop $hop - no file #$n - answering from knowledge"
                      choice=d
                    fi
                    ;;
                esac
                ;;
            esac
          fi
        fi
        ;;
      e) # gated terminal bridge
        srcs="$srcs

[hop $hop: terminal]"
        if [ "${TERM_ENABLED:-1}" != "1" ]; then
          say "chat: hop $hop - terminal bridge disabled (LLM_TERM=0) - answering from knowledge"
          choice=d
        else
          chk=$(router_pick "ROUTER CMD" "You are the Aetherix-Alpine tiny assistant. Terminal commands are gated: read/status commands auto-run, everything else asks the user first. Reply with a single letter." "TASK: $task

Run a terminal command to gather the answer?
A) yes - the exact command comes next
B) no - answer from knowledge instead

Reply with a single letter.")
          if [ "$chk" != "a" ]; then
            say "chat: hop $hop - no terminal command - answering from knowledge"
            choice=d
          else
            cmd=$(router_pick "ROUTER CMD TEXT" "You are the Aetherix-Alpine tiny assistant. Write the exact single terminal command (no shell metacharacters, no redirection, no destructive commands) that answers the task. Reply with just the command." "TASK: $task

Terminal command:")
            cmd=$(printf '%s' "$cmd" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
            case "$cmd" in
              ''|none|skip|no)
                echo "chat: hop $hop - no command given - answering from knowledge"
                choice=d
                ;;
              *)
                if got=$(term_run "$cmd") && [ -n "$got" ]; then
                  gathered="$gathered

TERMINAL OUTPUT (hop $hop, cmd: $cmd):
$got"
                  echo "chat: hop $hop - terminal output captured"
                  continue
                else
                  say "chat: hop $hop - command unavailable ('$cmd') - answering from knowledge"
                  choice=d
                fi
                ;;
            esac
          fi
        fi
        ;;
      d|f) : ;; # final synthesis below with what we have
      *)
        say "chat: hop $hop - unrecognized choice '$choice' - answering from knowledge"
        choice=d
        ;;
    esac
    break
  done
  if [ -n "$gathered" ]; then
    srcblock="MATERIAL GATHERED"
    final=$(router_complete "You are the Aetherix-Alpine tiny assistant. Answer the task concisely using ONLY the material and chat history provided. Cite web sources as [n]. If the material is not enough, say exactly what is missing." "$srcblock:
$gathered

TASK: $task

Final answer:")
  else
    final=$(router_complete "You are the Aetherix-Alpine assistant on an Android phone. Answer the question concisely from your own knowledge, with the terminal context in mind. If the material is not enough, say exactly what is missing." "KNOWLEDGE:
(no tools used)

TASK: $task

Final answer:")
  fi
  printf '%s' "$final"
}
