# Aetherix-Alpine LLM tier - web capability library (sourced). Tavily
# pipeline: search -> Vane-style cited synthesis. No SearXNG dependency.

# v0.4.7: answer-first extraction. The short top-level Tavily `answer` summary
# (when returned) is the primary context for tiny models; result snippets are
# compact (content ~200 chars) so a 6-hop router prompt stays inside 8k.
tavily_extract() { # stdin: Tavily JSON -> "ANSWER: ...\n[n] title\n    url\n    content\n"
  awk '
    function val(s, key,   klen, i, n, p, c, v) {
      n = length(s)
      klen = length(key) + 3
      for (i = 1; i + klen - 1 <= n; i++) {
        if (substr(s, i, klen) == "\"" key "\":") break
      }
      if (i + klen - 1 > n) return ""
      p = i + klen
      while (p <= n && (substr(s, p, 1) == " " || substr(s, p, 1) == "\t")) p++
      if (p > n || substr(s, p, 1) != "\"") return ""
      p++
      v = ""
      while (p <= n) {
        c = substr(s, p, 1)
        if (c == "\\") {
          p++
          if (p <= n) {
            c = substr(s, p, 1)
            if (c == "n") v = v " "; else v = v c
          }
          p++
          continue
        }
        if (c == "\"") break
        v = v c
        p++
      }
      return v
    }
    BEGIN { RS = "" }
    {
      line = $0
      ap = index(line, "\"answer\":")
      if (ap > 0) {
        av = val(line, "answer")
        if (av != "") printf "ANSWER: %s\n", av
      }
      p = index(line, "\"results\":[")
      if (p == 0) exit 0
      rest = substr(line, p + 11)
      n = length(rest)
      seg = ""; inside = 0; esc = 0; count = 0
      for (i = 1; i <= n; i++) {
        c = substr(rest, i, 1)
        if (inside) {
          if (esc) esc = 0
          else if (c == "\\") esc = 1
          else if (c == "\"") inside = 0
          seg = seg c
          continue
        }
        if (c == "\"") { inside = 1; seg = seg c; continue }
        if (c == "}") {
          seg = seg c
          nx = substr(rest, i + 1, 1)
          if (nx == "," || nx == "]") {
            count++
            t = val(seg, "title"); u = val(seg, "url"); co = val(seg, "content")
            if (length(co) > 200) co = substr(co, 1, 200) "..."
            printf "[%d] %s\n    %s\n    %s\n", count, t, u, co
            seg = ""
            if (nx == "]") exit 0
            i++
          }
          continue
        }
        if (c == "]") exit 0
        seg = seg c
      }
    }
  '
}

# FB-081: append one speaker line to the docked transcript and cap the file
# at the last 200 lines so it can never grow unbounded.

tavily_key_ok() { [ -s /etc/aetherix/tavily.key ]; }

# Shared Tavily search: writes the JSON body to $3 and echoes the HTTP code.

tavily_search() { # $1 = query  $2 = max results  $3 = output file
  escq=$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  # v0.4.7: include_answer:true asks Tavily for its short summary so the model
  # gets clean, already-synthesized context instead of raw page snippets.
  curl -s -o "$3" -w '%{http_code}' --max-time 30 -X POST \
    https://api.tavily.com/search \
    -H "Authorization: Bearer $(cat /etc/aetherix/tavily.key 2>/dev/null)" \
    -H 'Content-Type: application/json' \
    -d "{\"query\":\"$escq\",\"search_depth\":\"basic\",\"max_results\":${2:-3},\"include_answer\":true}"
}

# FB-103: per-model profiles drive llama-server ctx/batch and the agent tool
# loop. The active model's file name is matched (case-insensitive, first-match
# glob) against /etc/aetherix/model-profiles.conf; LLM_CTX / LLM_BATCH /
# LLM_AGENT env overrides always win (pi-agent lesson: fit context/batch to
# the model, user override wins).

# v0.4.6: backend readouts moved into the library (llm chat --web status /
# --web --test). No-key guard lives in chat_cli; these are the facts.

web_status() {
  if [ -s /etc/aetherix/tavily.key ]; then
    echo "web backend: tavily (key set)"
  else
    say "web backend: tavily (NO KEY - add one from the app Dashboard > Tavily Key)"
  fi
  if running; then echo "llm server: running (model: $(model))"; else echo "llm server: stopped"; fi
}

web_test() {
  if [ ! -s /etc/aetherix/tavily.key ]; then
    echo "ERROR: no Tavily key saved - add one from the app Dashboard > Tavily Key" >&2
    return 2
  fi
  code=$(curl -s -o /tmp/tavily-test.json -w '%{http_code}' --max-time 20 -X POST \
    https://api.tavily.com/search \
    -H "Authorization: Bearer $(cat /etc/aetherix/tavily.key)" \
    -H 'Content-Type: application/json' \
    -d '{"query":"test","search_depth":"basic","max_results":1}')
  if [ "$code" = "200" ]; then
    echo "tavily: OK (HTTP 200)"
  else
    say "tavily: FAILED (HTTP $code) - $(head -c 200 /tmp/tavily-test.json 2>/dev/null)"
  fi
  rm -f /tmp/tavily-test.json
  return 0
}

# v0.4.7: shared Tavily gather - queries 1 (and 2 only when the first returns
# no Tavily answer summary), writes ANSWER: + compact [n] snippets to
# /tmp/web-gather.txt capped at ~3000 chars, echoes the [n] result count.
web_gather() { # $1 = query  $2 = optional second query
  : > /tmp/web-gather-raw.txt
  i=0
  for qq in "$1" "$2"; do
    [ -z "$qq" ] && continue
    i=$((i+1))
    echo "web: searching Tavily: $qq"
    code=$(tavily_search "$qq" 3 "/tmp/web-gather-$i.json")
    if [ "$code" = "200" ]; then
      got=$(tavily_extract < "/tmp/web-gather-$i.json")
      if [ -n "$got" ]; then
        printf '%s\n' "$got" >> /tmp/web-gather-raw.txt
        if printf '%s\n' "$got" | grep -q '^ANSWER:'; then
          break
        fi
      fi
    else
      say "web: search $i failed (HTTP $code) - see llm chat --web --test"
    fi
  done
  rm -f /tmp/web-gather-*.json
  : > /tmp/web-gather.txt
  if [ -s /tmp/web-gather-raw.txt ]; then
    awk '/^\[[0-9]+\]/{n++; sub(/^\[[0-9]+\]/, "[" n "]")} {print}' /tmp/web-gather-raw.txt > /tmp/web-gather.txt
    if [ "$(wc -c < /tmp/web-gather.txt | tr -d ' ')" -gt 3000 ]; then
      head -c 3000 /tmp/web-gather.txt > /tmp/web-gather.txt.tmp && mv -f /tmp/web-gather.txt.tmp /tmp/web-gather.txt
    fi
  fi
  rm -f /tmp/web-gather-raw.txt
  grep -c '^\[' /tmp/web-gather.txt 2>/dev/null | tr -d ' '
}

web_answer() { # $1 = question; Tavily key required (router checks first)
  q="$1"
  ensure_server
  ctx=$(ctx_block)
  escq=$(printf '%s' "$q" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escctx=$(printf '%s' "$ctx" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  qr=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"You generate web search queries. Write 1-2 short web search queries that best answer the question. One query per line, nothing else.\"},{\"role\":\"user\",\"content\":\"Question: $escq\\n\\nTerminal context:\\n$escctx\"}],\"max_tokens\":80}")
  queries=$(parse_reply "$qr" | sed 's/".*//' | grep -v '^[[:space:]]*$' | head -2)
  if [ -z "$queries" ]; then queries="$q"; fi
  q1=$(printf '%s\n' "$queries" | sed '/^[[:space:]]*$/d' | head -1)
  q2=$(printf '%s\n' "$queries" | sed '/^[[:space:]]*$/d' | sed -n '2p')
  [ -n "$q1" ] || q1="$q"
  nres=$(web_gather "$q1" "$q2")
  results=$(cat /tmp/web-gather.txt 2>/dev/null)
  if [ -z "$results" ]; then
    echo "web: no results found - nothing to synthesize"
    return 0
  fi
  echo "web: $nres results - synthesizing..."
  prompt="Search results:
$results

Question: $q

Answer the question using ONLY the search results above. Cite each source as [n] next to the claim it supports. If the results do not contain the answer, say so."
  escprompt=$(printf '%s' "$prompt" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"You are the Aetherix assistant. Answer concisely in a few sentences using only the provided search results; cite [n].\"},{\"role\":\"user\",\"content\":\"$escprompt\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  llm_reply "$q" "$resp"
}
