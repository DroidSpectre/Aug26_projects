#!/bin/sh
# gui-module self-test — full functionality check (run inside the terminal).
FAIL=0
pass() { echo "PASS  $1"; }
fail() { echo "FAIL  $1"; FAIL=$((FAIL+1)); }

echo "== gui-module self-test =="
command -v gui >/dev/null 2>&1 && pass "gui CLI installed" || fail "gui CLI missing"
gui status >/dev/null 2>&1 && pass "gui status runs" || fail "gui status failed"
gui vnc 2>/dev/null | grep -q "127.0.0.1:5901" && pass "gui vnc prints client instructions" || fail "gui vnc missing/incomplete"
for p in Xvfb x11vnc openbox xterm; do
  command -v "$p" >/dev/null 2>&1 && pass "$p installed" || fail "$p missing (run 'gui setup' first)"
done

if command -v Xvfb >/dev/null 2>&1; then
  gui start >/dev/null 2>&1
  sleep 2
  pgrep -f "Xvfb :1" >/dev/null 2>&1 && pass "Xvfb running" || fail "Xvfb not running after start"
  gui status | grep -q running && pass "gui status shows running" || fail "gui status not running"
  DISPLAY=:1 xterm -e true >/dev/null 2>&1 && pass "xterm launches on display" || fail "xterm launch failed"
  gui stop >/dev/null 2>&1
  sleep 1
  pgrep -f "Xvfb :1" >/dev/null 2>&1 && fail "Xvfb still running after stop" || pass "gui stop clean"
else
  fail "gui start skipped (Xvfb unavailable - run 'gui setup' with internet)"
fi

echo ""
if [ "$FAIL" -eq 0 ]; then echo "ALL CHECKS PASSED"; exit 0; fi
echo "$FAIL CHECK(S) FAILED"; exit 1
