# gui-module on-device test plan

Install via Modules & Storage (or `module install gui-module` once the CLI
supports it). Run `gui-selftest` inside the terminal after `gui setup`.

1. **G1 — Install** — Modules & Storage shows `gui-module` (bundled, v1.0.0);
   Install succeeds; `/etc/aetherix/gui-module.installed` exists.
2. **G2 — CLI present** — `command -v gui` resolves; `gui status` prints
   `state: stopped` before first run.
3. **G3 — Setup** — `gui setup` installs xvfb/x11vnc/openbox/xterm (needs
   internet); re-run is a no-op; all four binaries resolve.
4. **G4 — Start/stop** — `gui start` prints VNC ready on 127.0.0.1:5901;
   `pgrep -f 'Xvfb :1'` shows the server; `gui status` shows running;
   `gui stop` cleans up and status returns to stopped.
5. **G5 — App launch** — `gui app xterm` launches on display :1 (verify with
   `DISPLAY=:1 xterm -e true` exit 0).
6. **G6 — VNC from PC** — `adb forward tcp:5901 tcp:5901`; a VNC client shows
   the openbox desktop; window manager responds.
7. **G7 — Selftest** — `gui-selftest` exits 0 with all checks passed.
8. **G8 — VNC help** — `gui vnc` prints phone + PC client instructions and
   mentions `127.0.0.1:5901`; bare `x11vnc` outside `gui start` is documented
   as having no display.
