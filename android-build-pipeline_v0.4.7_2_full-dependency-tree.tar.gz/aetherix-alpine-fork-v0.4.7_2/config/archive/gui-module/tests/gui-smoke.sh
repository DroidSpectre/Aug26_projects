#!/bin/sh
# gui-module smoke — quick environment + status dump.
echo "== gui-module smoke =="
echo "gui: $(command -v gui || echo missing)"
echo "xvfb: $(command -v Xvfb || echo missing)"
echo "x11vnc: $(command -v x11vnc || echo missing)"
echo "openbox: $(command -v openbox || echo missing)"
gui status
