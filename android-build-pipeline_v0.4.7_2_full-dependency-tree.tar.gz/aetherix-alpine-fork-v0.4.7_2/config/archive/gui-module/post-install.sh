#!/bin/sh
# gui-module post-install — deploy the GUI tier CLI into the guest.
MODULE_DIR=$(dirname "$0")
mkdir -p /usr/local/bin /etc/aetherix
for f in "$MODULE_DIR"/tier/*; do
  [ -f "$f" ] || continue
  cp -f "$f" "/usr/local/bin/$(basename "$f")"
  chmod +x "/usr/local/bin/$(basename "$f")"
done
[ -f /etc/aetherix/gui.state ] || echo stopped > /etc/aetherix/gui.state
echo "installed $(date -u +%Y-%m-%dT%H:%M:%SZ)" > /etc/aetherix/gui-module.installed
echo "gui-module OK: run 'gui setup' then 'gui start'"
