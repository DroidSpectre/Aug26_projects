#!/bin/bash
# build-hello-module.sh — convenience wrapper: rebuilds all bundled modules
# (hello-module + llm-module). See build-modules.sh.
set -e
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
exec "$PROJECT_DIR/scripts/build-modules.sh"
