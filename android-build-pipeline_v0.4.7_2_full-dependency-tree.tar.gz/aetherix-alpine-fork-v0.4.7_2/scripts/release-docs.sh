#!/bin/bash
# release-docs.sh — scaffold per-build docs + lossless consolidation.
#   usage: release-docs.sh [v0.3a.<n>] [-m "one-line summary"]
# Defaults version to current app/build.gradle versionName.
set -e
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SUMMARY=""
VERSION="${1:-$(grep -oP 'versionName "\K[^"]+' "$PROJECT_DIR/app/build.gradle" | head -1)}"
[ "$2" = "-m" ] && SUMMARY="$3"

if [[ "$VERSION" =~ ^v0\.3a\.([0-9]+)(_([0-9]+))?$ ]]; then
    n=${BASH_REMATCH[1]}
elif [[ "$VERSION" =~ ^v0\.4\.([0-9]+)$ ]]; then
    n=${BASH_REMATCH[1]}
else
    echo "ERROR: version must match v0.3a.<n>(_<k>) or v0.4.<p> (got $VERSION)" >&2
    exit 1
fi

DOCS_DIR="$PROJECT_DIR/docs/$VERSION"
mkdir -p "$DOCS_DIR"

if [ ! -f "$DOCS_DIR/README.md" ]; then
    DATE=$(date -u +%Y-%m-%d)
    cat > "$DOCS_DIR/README.md" << MD
# Aetherix-Alpine Fork — Build $VERSION

- **Date:** $DATE
- **VersionName:** $VERSION
- **versionCode:** $(grep -oP 'versionCode \K[0-9]+' "$PROJECT_DIR/app/build.gradle" | head -1)
- **Summary:** $SUMMARY

## Changes
(TODO: fill)

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| (none) | | | | |

## Build & Verification Notes
(TODO: fill)
MD
    echo "Scaffolded $DOCS_DIR/README.md"
else
    echo "README exists: $DOCS_DIR/README.md (not overwritten)"
fi

# Master changelog entry (append if absent)
MASTER="$PROJECT_DIR/docs/v0.3-series/CHANGELOG.md"
if [ ! -f "$MASTER" ] || ! grep -q "^## $VERSION " "$MASTER"; then
    mkdir -p "$(dirname "$MASTER")"
    [ -f "$MASTER" ] || printf '# Aetherix-Alpine — Changelog (fork line)\n\n' > "$MASTER"
    printf '\n## %s (fork)\n\n%s\n' "$VERSION" "${SUMMARY:-No summary provided.}" >> "$MASTER"
    echo "Appended $MASTER"
fi

# Per-build changelog copy
printf '# Aetherix-Alpine Fork — Changelog\n\n## %s (fork)\n\n%s\n' "$VERSION" "${SUMMARY:-No summary provided.}" > "$DOCS_DIR/CHANGELOG.md"

# ---- Consolidation: level-1 every 5 builds; level-2 every 25 ----
consolidate() {
    local start=$1 end=$2 level=$3 base=$4
    local dir="$DOCS_DIR/consolidation/level$level"
    mkdir -p "$dir"
    local synth="$dir/v0.3a.$start-v0.3a.$end-synthesis.md"
    { echo "# Fork Consolidation (level $level): v0.3a.$start - v0.3a.$end"
      echo ""
      echo "Synthesized at build $VERSION. Originals retained; nothing deleted."
      echo ""
    } > "$synth"
    for i in $(seq "$start" "$end"); do
        local src="$PROJECT_DIR/docs/$base$i/README.md"
        if [ -f "$src" ]; then
            cp "$src" "$dir/v0.3a.$i.README.md"
            { echo ""; echo "---"; echo ""; echo "## v0.3a.$i"; echo ""; cat "$src"; } >> "$synth"
        fi
    done
    echo "Level-$level consolidation for v0.3a.$start-v0.3a.$end -> $dir"
}

if [ "$n" -ge 5 ] && [ $((n % 5)) -eq 0 ]; then
    consolidate $((n - 5)) $((n - 1)) 1 "v0.3a."
fi
if [ "$n" -ge 25 ] && [ $((n % 25)) -eq 0 ]; then
    # level-2: synthesize from the five level-1 syntheses
    dir="$DOCS_DIR/consolidation/level2"
    mkdir -p "$dir"
    synth="$dir/v0.3a.$((n-25))-v0.3a.$((n-1))-synthesis.md"
    { echo "# Fork Consolidation (level 2): v0.3a.$((n-25)) - v0.3a.$((n-1))"
      echo ""
      echo "Synthesized at build $VERSION from the five level-1 reports. Originals retained."
      echo ""
    } > "$synth"
    for i in 0 5 10 15 20; do
        s="$((n - i))"
        l1="$PROJECT_DIR/docs/v0.3a.$s/consolidation/level1"
        if [ -d "$l1" ]; then
            f="$l1/v0.3a.$((s-5))-v0.3a.$((s-1))-synthesis.md"
            [ -f "$f" ] && cp "$f" "$dir/" && { echo ""; echo "---"; echo ""; cat "$f"; } >> "$synth"
        fi
    done
    echo "Level-2 consolidation -> $dir"
fi
echo "Done: $DOCS_DIR"
