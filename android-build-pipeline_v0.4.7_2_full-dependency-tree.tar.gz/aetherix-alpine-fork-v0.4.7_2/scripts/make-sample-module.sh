#!/bin/sh
# Build the fork sample module and export it to the fork phone tree.
# Usage: scripts/make-sample-module.sh

set -e
work=$(mktemp -d)
mkdir -p "$work/hello-module"

cat > "$work/hello-module/module.yml" <<'YAML'
name: hello-module
version: 0.1.0
YAML

cat > "$work/hello-module/post-install.sh" <<'SH'
#!/bin/sh
# Aetherix-Alpine sample module post-install
mkdir -p /etc/aetherix
echo "hello-module installed $(date -u)" > /etc/aetherix/hello-module.installed
echo "HELLO_MODULE_INSTALLED v0.1.0"
SH
chmod +x "$work/hello-module/post-install.sh"

mkdir -p /sdcard/Download/Aetherix-Alpine-Fork/modules
tar -czf /sdcard/Download/Aetherix-Alpine-Fork/modules/hello-module.tar.gz \
  -C "$work" hello-module

rm -rf "$work"
echo "OK: /sdcard/Download/Aetherix-Alpine-Fork/modules/hello-module.tar.gz"
tar -tzf /sdcard/Download/Aetherix-Alpine-Fork/modules/hello-module.tar.gz
cat /etc/os-release >/dev/null 2>&1 || true