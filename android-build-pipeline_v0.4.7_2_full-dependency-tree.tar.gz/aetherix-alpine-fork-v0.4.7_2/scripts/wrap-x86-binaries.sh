#!/bin/bash
# Find and wrap all x86-64 ELF binaries in Android SDK and Gradle cache
BT=/root/Android/build-tools/35.0.0
WRAPPER_SCRIPT='#!/bin/bash
QEMU_LD_PREFIX=/opt/amd64-rootfs exec /usr/bin/qemu-x86_64 "$0.real" "$@"
'

wrap_binary() {
    local path="$1"
    if [ -f "$path" ] && [ ! -f "${path}.real" ]; then
        local filetype=$(file -b "$path" 2>/dev/null)
        if [[ "$filetype" == *"x86-64"* ]]; then
            echo "Wrapping: $path"
            mv "$path" "${path}.real"
            echo "$WRAPPER_SCRIPT" > "$path"
            chmod +x "$path"
            return 0
        fi
    fi
    return 1
}

# Wrap SDK build tools
for tool in "$BT"/aapt "$BT"/aapt2 "$BT"/zipalign; do
    wrap_binary "$tool"
done

# Wrap all aapt2 in Gradle cache
find /root/.gradle/caches -name "aapt2" -type f 2>/dev/null | while read f; do
    wrap_binary "$f"
done

echo "Done wrapping x86-64 binaries"
