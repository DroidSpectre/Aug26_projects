#!/system/bin/sh
# 03-setup-rootfs.sh - Configure Alpine packages and base environment
set -e

PROOT_DIR="$1"
if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

ROOTFS_DIR="$PROOT_DIR/rootfs/alpine"
PROOT_BIN="$PROOT_DIR/proot/proot-arm64"
LAUNCH_PROOT="$PROOT_DIR/proot/proot-launch.sh"

echo "[*] Configuring Alpine rootfs..."

# Create PRoot launch script for internal use
cat > "$LAUNCH_PROOT" << 'LAUNCH_EOF'
#!/system/bin/sh
PROOT_DIR="$(dirname "$0")/.."
ROOTFS="$PROOT_DIR/rootfs/alpine"
PROOT_BIN="$PROOT_DIR/proot/proot-arm64"

export PROOT_NO_SECCOMP=1
export PROOT_LINK2SYMLINK=1

exec "$PROOT_BIN" \
    -0 \
    -r "$ROOTFS" \
    -b /dev \
    -b /proc \
    -b /sys \
    -b "$PROOT_DIR/sdk:/opt/android-sdk" \
    -b /sdcard:/mnt/sdcard \
    -w /root \
    --link2symlink \
    /bin/sh --login "$@"
LAUNCH_EOF

chmod 755 "$LAUNCH_PROOT"

# Initialize Alpine packages
echo "[*] Initializing Alpine package manager..."
"$LAUNCH_PROOT" -c "apk update && apk upgrade"

# Install essential packages
echo "[*] Installing essential packages..."
"$LAUNCH_PROOT" -c "apk add bash coreutils findutils grep sed gawk"

# Install download tools
echo "[*] Installing download tools..."
"$LAUNCH_PROOT" -c "apk add curl wget git openssh"

# Install archive tools
echo "[*] Installing archive tools..."
"$LAUNCH_PROOT" -c "apk add zip unzip tar xz"

# Install build essentials
echo "[*] Installing build essentials..."
"$LAUNCH_PROOT" -c "apk add linux-headers build-base"

# Install Java dependencies
echo "[*] Installing Java dependencies..."
"$LAUNCH_PROOT" -c "apk add fontconfig tzdata"

# Configure timezone
echo "[*] Configuring timezone..."
"$LAUNCH_PROOT" -c "ln -sf /usr/share/zoneinfo/UTC /etc/localtime"

# Create SDK directory
"$LAUNCH_PROOT" -c "mkdir -p /opt/android-sdk"

# Create Gradle cache directory
"$LAUNCH_PROOT" -c "mkdir -p /root/.gradle"

echo "[+] Alpine rootfs configuration complete"
echo "[*] You can now run: 04-setup-android-sdk.sh"
