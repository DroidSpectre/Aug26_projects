#!/system/bin/sh
# 05-setup-jdk.sh - Install OpenJDK 17
set -e

PROOT_DIR="$1"
if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

LAUNCH_PROOT="$PROOT_DIR/proot/proot-launch.sh"

echo "[*] Installing OpenJDK 17..."

# Install OpenJDK 17 via Alpine package manager
"$LAUNCH_PROOT" -c "apk add openjdk17"

# Verify installation
echo "[*] Verifying JDK installation..."
"$LAUNCH_PROOT" -c "java -version"

# Set up environment variables
"$LAUNCH_PROOT" -c "
    cat > /etc/profile.d/java.sh << 'EOF'
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
export PATH=\$PATH:\$JAVA_HOME/bin
EOF
"

echo "[+] OpenJDK 17 installation complete"
echo "[*] JAVA_HOME=/usr/lib/jvm/java-17-openjdk"
