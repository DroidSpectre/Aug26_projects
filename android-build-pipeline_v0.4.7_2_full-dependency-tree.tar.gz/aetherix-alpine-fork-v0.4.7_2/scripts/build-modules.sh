#!/bin/bash
# build-modules.sh — regenerate every bundled module in config/modules/* into
# app/src/main/assets/modules/<name>.bundle (gzip tar, ".bundle" because aapt
# strips ".tar.gz" from asset names). hello-module additionally syncs its tier
# dir from app/src/main/assets/tier so shared CLIs stay in one place.
set -e
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$PROJECT_DIR/app/src/main/assets/modules"
mkdir -p "$OUT"

# hello-module: sync shared tier CLIs from app assets (single source of truth)
HELLO="$PROJECT_DIR/config/modules/hello-module"
mkdir -p "$HELLO/tier"
for f in "$PROJECT_DIR"/app/src/main/assets/tier/*.sh; do
  [ -f "$f" ] || continue
  stem=$(basename "$f" .sh)
  cp -f "$f" "$HELLO/tier/$stem"
done
# prune stale tier CLIs that became standalone modules (gui/llm) so they never
# leak back into the hello bundle; sd + device-info intentionally live only here
for f in "$HELLO"/tier/*; do
  [ -f "$f" ] || continue
  case "$(basename "$f")" in
    gui|llm) rm -f "$f" ;;
  esac
done

for SRC in "$PROJECT_DIR"/config/modules/*/; do
  name=$(basename "$SRC")
  [ -f "$SRC/module.yml" ] || continue
  tar -czf "$OUT/$name.bundle" -C "$SRC" .
  echo "wrote $OUT/$name.bundle ($(du -h "$OUT/$name.bundle" | cut -f1))"
done
