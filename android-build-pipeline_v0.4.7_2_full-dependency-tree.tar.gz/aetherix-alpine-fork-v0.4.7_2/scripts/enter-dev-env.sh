#!/system/bin/sh
# enter-dev-env.sh - Quick entry into development environment
# This is a convenience wrapper for the full launcher

PROOT_DIR="/data/data/com.devenv.prootbuild/files"
LAUNCHER="$PROOT_DIR/proot/enter-dev-env.sh"

if [ ! -f "$LAUNCHER" ]; then
    echo "[!] Development environment not set up yet."
    echo "[*] Please run the setup scripts in order:"
    echo "    01-setup-proot.sh"
    echo "    02-setup-alpine.sh"
    echo "    03-setup-rootfs.sh"
    echo "    04-setup-android-sdk.sh"
    echo "    05-setup-jdk.sh"
    echo "    06-setup-gradle.sh"
    echo "    07-create-launcher.sh"
    exit 1
fi

exec "$LAUNCHER" "$@"
