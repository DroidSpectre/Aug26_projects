#!/system/bin/sh
# 02-setup-alpine.sh - Download and extract Alpine Linux rootfs
set -e

PROOT_DIR="$1"
if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

ROOTFS_DIR="$PROOT_DIR/rootfs/alpine"
ALPINE_VERSION="3.19.1"
ALPINE_ARCH="aarch64"
ALPINE_URL="https://dl-cdn.alpinelinux.org/alpine/v3.19/releases/${ALPINE_ARCH}/alpine-minirootfs-${ALPINE_VERSION}-${ALPINE_ARCH}.tar.gz"
ALPINE_ARCHIVE="$PROOT_DIR/rootfs/alpine-minirootfs.tar.gz"

echo "[*] Setting up Alpine Linux rootfs..."
echo "[*] Version: ${ALPINE_VERSION}"
echo "[*] Architecture: ${ALPINE_ARCH}"

# Create directories
mkdir -p "$ROOTFS_DIR"
mkdir -p "$PROOT_DIR/rootfs"

# Download Alpine rootfs if not present
if [ ! -f "$ALPINE_ARCHIVE" ]; then
    echo "[*] Downloading Alpine minirootfs..."
    if command -v wget > /dev/null 2>&1; then
        wget -O "$ALPINE_ARCHIVE" "$ALPINE_URL"
    elif command -v curl > /dev/null 2>&1; then
        curl -L -o "$ALPINE_ARCHIVE" "$ALPINE_URL"
    else
        echo "[!] Neither wget nor curl found. Please install one."
        exit 1
    fi
else
    echo "[*] Alpine archive already downloaded"
fi

# Extract rootfs
echo "[*] Extracting Alpine rootfs..."
if command -v tar > /dev/null 2>&1; then
    # Android's toybox tar may not support all options
    tar -xzf "$ALPINE_ARCHIVE" -C "$ROOTFS_DIR" 2>/dev/null || \
    tar -xzf "$ALPINE_ARCHIVE" -C "$ROOTFS_DIR" --no-same-owner 2>/dev/null || \
    tar -xzf "$ALPINE_ARCHIVE" -C "$ROOTFS_DIR" --no-same-permissions 2>/dev/null
else
    echo "[!] tar not found. Cannot extract rootfs."
    exit 1
fi

# Verify extraction
if [ -d "$ROOTFS_DIR/bin" ] && [ -d "$ROOTFS_DIR/etc" ]; then
    echo "[+] Alpine rootfs extracted successfully"
    echo "[*] Rootfs location: $ROOTFS_DIR"
else
    echo "[!] Rootfs extraction may have failed - /bin or /etc not found"
    exit 1
fi

# Create basic mount points
mkdir -p "$ROOTFS_DIR/dev"
mkdir -p "$ROOTFS_DIR/proc"
mkdir -p "$ROOTFS_DIR/sys"
mkdir -p "$ROOTFS_DIR/mnt/sdcard"

echo "[+] Alpine Linux rootfs setup complete"
