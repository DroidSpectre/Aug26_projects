#!/bin/bash
# bump-version.sh — bump app/build.gradle to the next build in the fork scheme.
#   v0.3a.<n>(_<k>)  -> versionCode 30000 + n*10 + k   (v0.3a.14_1 -> 30141)
#   v0.4.<p>         -> versionCode 40000 + p          (v0.4.0 -> 40000)
#   v0.4.<p>_<k>     -> versionCode 40000 + p*10 + k   (v0.4.6_1 -> 40061)
# v0.4.x is the core-stable line: modules carry their own versions and are not
# reflected in the app version. A bump from v0.4.6_1 to v0.4.7 is a manual
# gradle edit (per the fork convention); this script validates any version and
# can then increment the patch.
set -e
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
GRADLE="$PROJECT_DIR/app/build.gradle"

VN=$(grep -oP 'versionName "\K[^"]+' "$GRADLE" | head -1)
VC=$(grep -oP 'versionCode \K[0-9]+' "$GRADLE" | head -1)

if [[ "$VN" =~ ^v0\.4\.([0-9]+)(_([0-9]+))?$ ]]; then
    p=${BASH_REMATCH[1]}
    k=${BASH_REMATCH[3]:-}
    if [ -n "$k" ]; then expected=$((40000 + p * 10 + k)); else expected=$((40000 + p)); fi
elif [[ "$VN" =~ ^v0\.3a\.([0-9]+)(_([0-9]+))?$ ]]; then
    n=${BASH_REMATCH[1]}
    k=${BASH_REMATCH[3]:-0}
    expected=$((30000 + n * 10 + k))
else
    echo "ERROR: versionName must match v0.4.<p>(_<k>) or v0.3a.<n>(_<k>) (got $VN)" >&2
    exit 1
fi
if ! [[ "$VC" =~ ^[0-9]+$ ]] || [ "$expected" -ne "$VC" ]; then
    echo "ERROR: versionCode must match the scheme (got $VC, expected $expected)" >&2
    exit 1
fi

if [[ "$VN" =~ ^v0\.4\. ]]; then
    next_p=$((p + 1))
    next_vn="v0.4.$next_p"
    next_vc=$((40000 + next_p))
else
    if [ "$k" -eq 0 ]; then next_k=1; else next_k=$((k + 1)); fi
    next_vn="v0.3a.$n_$next_k"
    next_vc=$((30000 + n * 10 + next_k))
fi
python3 - "$GRADLE" "$next_vn" "$next_vc" << 'PY'
import io, re, sys
p, vn, vc = sys.argv[1], sys.argv[2], str(sys.argv[3])
s = io.open(p, encoding='utf-8').read()
s, c1 = re.subn(r'versionCode \d+', f'versionCode {vc}', s, count=1)
s, c2 = re.subn(r'versionName "[^"]+"', f'versionName "{vn}"', s, count=1)
assert c1 == 1 and c2 == 1
io.open(p, 'w', encoding='utf-8').write(s)
print(f"Bumped to {vn} (versionCode {vc})")
PY
