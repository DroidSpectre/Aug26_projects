#!/system/bin/sh
# setup-all.sh - Master setup script
# Runs all setup scripts in sequence

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROOT_DIR="$1"

if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

echo "========================================="
echo "  Development Environment Setup"
echo "========================================="
echo ""
echo "This will install:"
echo "  1. PRoot binary"
echo "  2. Alpine Linux rootfs"
echo "  3. Base packages"
echo "  4. Android SDK"
echo "  5. OpenJDK 17"
echo "  6. Gradle 8.x"
echo ""
echo "Target directory: $PROOT_DIR"
echo ""

read -p "Continue? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Setup cancelled."
    exit 0
fi

echo ""

# Run each script
for script in \
    01-setup-proot.sh \
    02-setup-alpine.sh \
    03-setup-rootfs.sh \
    04-setup-android-sdk.sh \
    05-setup-jdk.sh \
    06-setup-gradle.sh \
    07-create-launcher.sh; do

    echo "-----------------------------------------"
    echo "Running: $script"
    echo "-----------------------------------------"

    if [ -f "$SCRIPT_DIR/$script" ]; then
        sh "$SCRIPT_DIR/$script" "$PROOT_DIR"
        if [ $? -ne 0 ]; then
            echo ""
            echo "[!] Error running $script"
            echo "[*] Check the output above for details"
            exit 1
        fi
    else
        echo "[!] Script not found: $SCRIPT_DIR/$script"
        exit 1
    fi

    echo ""
done

echo "========================================="
echo "  Setup Complete!"
echo "========================================="
echo ""
echo "To enter the development environment:"
echo "  $SCRIPT_DIR/enter-dev-env.sh"
echo ""
echo "Or run diagnostics:"
echo "  $SCRIPT_DIR/diagnose.sh"
echo ""
