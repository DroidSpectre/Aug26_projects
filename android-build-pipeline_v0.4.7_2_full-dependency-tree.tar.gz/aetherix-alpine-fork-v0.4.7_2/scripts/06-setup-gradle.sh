#!/system/bin/sh
# 06-setup-gradle.sh - Install Gradle 8.x
set -e

PROOT_DIR="$1"
if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

LAUNCH_PROOT="$PROOT_DIR/proot/proot-launch.sh"
GRADLE_VERSION="8.5"
GRADLE_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
GRADLE_ARCHIVE="/opt/gradle-${GRADLE_VERSION}-bin.zip"

echo "[*] Installing Gradle ${GRADLE_VERSION}..."

# Download Gradle
"$LAUNCH_PROOT" -c "
    if [ ! -f '$GRADLE_ARCHIVE' ]; then
        wget -O '$GRADLE_URL' '$GRADLE_ARCHIVE' || \
        curl -L -o '$GRADLE_ARCHIVE' '$GRADLE_URL'
    fi
"

# Extract Gradle
echo "[*] Extracting Gradle..."
"$LAUNCH_PROOT" -c "
    cd /opt && \
    unzip -q gradle-${GRADLE_VERSION}-bin.zip && \
    ln -sf gradle-${GRADLE_VERSION} gradle
"

# Set up environment variables
"$LAUNCH_PROOT" -c "
    cat > /etc/profile.d/gradle.sh << 'EOF'
export GRADLE_HOME=/opt/gradle
export PATH=\$PATH:\$GRADLE_HOME/bin
EOF
"

# Verify installation
echo "[*] Verifying Gradle installation..."
"$LAUNCH_PROOT" -c "gradle --version"

echo "[+] Gradle ${GRADLE_VERSION} installation complete"
