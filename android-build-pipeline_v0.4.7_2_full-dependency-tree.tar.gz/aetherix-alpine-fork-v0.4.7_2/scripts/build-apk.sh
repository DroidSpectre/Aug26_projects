#!/bin/bash
set -e

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="/tmp/build-aetherix-$(date +%s)"
ANDROID_HOME="${ANDROID_HOME:-/root/Android}"
PLATFORM="${ANDROID_HOME}/platforms/android-34"
BUILD_TOOLS="${ANDROID_HOME}/build-tools/35.0.0"

APP_NAME="Aetherix-Alpine"
GRADLE_VERSION_NAME="$(grep -oP 'versionName "\K[^"]+' "$PROJECT_DIR/app/build.gradle" | head -1)"
GRADLE_VERSION_CODE="$(grep -oP 'versionCode \K[0-9]+' "$PROJECT_DIR/app/build.gradle" | head -1)"
VERSION_NAME="${VERSION_NAME:-$GRADLE_VERSION_NAME}"
VERSION_CODE="${VERSION_CODE:-$GRADLE_VERSION_CODE}"

echo "=== Aetherix-Alpine APK Builder === (fork line v0.3a.x)"
echo "Version: $VERSION_NAME ($VERSION_CODE)"
echo ""

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"/{classes,dex,res/values,res/drawable,gen}

cat > "$BUILD_DIR/res/values/strings.xml" << 'STRXML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Aetherix-Alpine</string>
    <string name="copy_text">Copy</string>
    <string name="paste_text">Paste</string>
    <string name="text_selection_more">More…</string>
</resources>
STRXML

echo "[0/5] Building native components..."
CROSS_GCC="aarch64-linux-gnu-gcc"
JNILIB_DIR="$PROJECT_DIR/app/src/main/jniLibs/arm64-v8a"
JAVA_INCLUDE="/usr/lib/jvm/java-1.17.0-openjdk-arm64/include"

# 0a. Build JNI library (libpty-jni.so) - loaded into app process, provides TIOCSWINSZ
JNI_SRC="$PROJECT_DIR/native/pty-jni.c"
JNI_OUT="$PROJECT_DIR/native/libpty-jni.so"
if [ -x "$(command -v $CROSS_GCC)" ] && [ -f "$JNI_SRC" ]; then
    $CROSS_GCC -shared -fPIC -Os -s \
        -I"$JAVA_INCLUDE" -I"$JAVA_INCLUDE/linux" \
        -o "$JNI_OUT" "$JNI_SRC"
    cp "$JNI_OUT" "$JNILIB_DIR/libpty-jni.so"
    echo "  JNI lib: $(ls -lh $JNI_OUT | awk '{print $5}')"
fi

# 0b. Build freestanding bridge (libpty-bridge.so) - for setup step 5 PTY test
BRIDGE_SRC="$PROJECT_DIR/native/pty-bridge.c"
BRIDGE_OUT="$PROJECT_DIR/native/libpty-bridge.so"
if [ -x "$(command -v $CROSS_GCC)" ] && [ -f "$BRIDGE_SRC" ]; then
    $CROSS_GCC -static -nostdlib -ffreestanding -Os -s -o "$BRIDGE_OUT" "$BRIDGE_SRC"
    cp "$BRIDGE_OUT" "$JNILIB_DIR/libpty-bridge.so"
    echo "  Bridge: $(ls -lh $BRIDGE_OUT | awk '{print $5}')"
fi
echo "[0/5] Terminal uses native View + JNI PTY I/O"

echo "[1/5] Packaging resources + assets..."

# Create drawable resources for text selection handles
cat > "$BUILD_DIR/res/drawable/text_select_handle_left_material.xml" << 'DRL'
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="#ff2196f3" />
    <size android:width="24dp" android:height="24dp" />
    <corners android:radius="12dp" />
</shape>
DRL
cat > "$BUILD_DIR/res/drawable/text_select_handle_right_material.xml" << 'DRR'
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="#ff2196f3" />
    <size android:width="24dp" android:height="24dp" />
    <corners android:radius="12dp" />
</shape>
DRR

# Generate R.java
aapt package -f \
    --min-sdk-version 26 --target-sdk-version 35 \
    --version-code "$VERSION_CODE" --version-name "$VERSION_NAME" \
    -M "$PROJECT_DIR/app/src/main/AndroidManifest.xml" \
    -I "$PLATFORM/android.jar" \
    -A "$PROJECT_DIR/app/src/main/assets" \
    -S "$BUILD_DIR/res" \
    -J "$BUILD_DIR/gen" \
    -F "$BUILD_DIR/resources.apk" 2>&1

echo "[2/5] Compiling Java..."
find "$PROJECT_DIR/app/src/main/java" -name "*.java" > "$BUILD_DIR/sources.txt"
find "$BUILD_DIR/gen" -name "*.java" >> "$BUILD_DIR/sources.txt"
javac -source 8 -target 8 \
    -classpath "$PLATFORM/android.jar" \
    -d "$BUILD_DIR/classes" @$BUILD_DIR/sources.txt 2>&1

echo "[3/5] Converting to DEX..."
java -cp "$BUILD_TOOLS/lib/d8.jar" com.android.tools.r8.D8 \
    --min-api 26 --output "$BUILD_DIR/dex" \
    $(find "$BUILD_DIR/classes" -name "*.class")

echo "[4/5] Assembling clean APK..."
python3 -c "
import os, zipfile
apk_path = '$BUILD_DIR/app-unsigned.apk'
src_path = '$BUILD_DIR/resources.apk'
dex_path = '$BUILD_DIR/dex/classes.dex'
entries = []
with zipfile.ZipFile(src_path, 'r') as src:
    for info in src.infolist():
        if info.filename.startswith('META-INF/'):
            continue
        data = src.read(info.filename)
        info.external_attr = 0
        entries.append((info, data))
with open(dex_path, 'rb') as f:
    dex_data = f.read()
dex_info = zipfile.ZipInfo('classes.dex')
dex_info.compress_type = zipfile.ZIP_DEFLATED
dex_info.external_attr = 0
entries.insert(0, (dex_info, dex_data))
jni_libs = '$PROJECT_DIR/app/src/main/jniLibs/arm64-v8a'
for fname in sorted(os.listdir(jni_libs)):
    if fname.endswith('.so'):
        fpath = os.path.join(jni_libs, fname)
        with open(fpath, 'rb') as f:
            lib_data = f.read()
        lib_info = zipfile.ZipInfo('lib/arm64-v8a/' + fname)
        lib_info.compress_type = zipfile.ZIP_STORED
        lib_info.external_attr = 0o100755 << 16
        entries.append((lib_info, lib_data))
        print(f'  Added native lib: {fname} ({len(lib_data)} bytes)')
with zipfile.ZipFile(apk_path, 'w', zipfile.ZIP_DEFLATED) as dst:
    for info, data in entries:
        dst.writestr(info, data)
print(f'  Created APK with {len(entries)} entries')
"

echo "[5/5] Aligning and signing..."
zipalign -f 4 "$BUILD_DIR/app-unsigned.apk" "$BUILD_DIR/app-aligned.apk"

KEYSTORE="$PROJECT_DIR/debug.keystore"
if [ ! -f "$KEYSTORE" ]; then
    keytool -genkey -v -keystore "$KEYSTORE" \
        -storepass android -alias androiddebugkey -keypass android \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -dname "CN=Android Debug,O=Android,C=US" 2>/dev/null
fi

java -jar "$BUILD_TOOLS/lib/apksigner.jar" sign \
    --ks "$KEYSTORE" \
    --ks-pass pass:android \
    --key-pass pass:android \
    --ks-key-alias androiddebugkey \
    "$BUILD_DIR/app-aligned.apk" 2>/dev/null

cp "$BUILD_DIR/app-aligned.apk" "$PROJECT_DIR/${APP_NAME}-${VERSION_NAME}.apk"

echo ""
echo "=== Verify ==="
java -jar "$BUILD_TOOLS/lib/apksigner.jar" verify --verbose \
    "$PROJECT_DIR/${APP_NAME}-${VERSION_NAME}.apk" 2>&1 | grep -E "(Verifies|v[1234])"
echo ""
aapt dump badging "$PROJECT_DIR/${APP_NAME}-${VERSION_NAME}.apk" 2>&1 \
    | grep -E "(package:|sdkVersion:|application-label:)"
echo ""
ls -lh "$PROJECT_DIR/${APP_NAME}-${VERSION_NAME}.apk"

echo ""
echo "=== Snapshot (source zip, no build artifacts) ==="
ARCHIVE_DIR="$PROJECT_DIR/archive/${VERSION_NAME}"
SNAP_ZIP="$ARCHIVE_DIR/${APP_NAME}-${VERSION_NAME}-source.zip"
mkdir -p "$ARCHIVE_DIR"
python3 - "$PROJECT_DIR" "$SNAP_ZIP" << 'PY'
import os, sys, zipfile
root, out = sys.argv[1], sys.argv[2]
excl_dirs = {'.git', '.gradle', '.gradle-home', 'archive', 'sdk', 'releases', 'build'}
excl_suffix = ('.apk', '.zip', '.pdf', '.class')
count = 0
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in excl_dirs]
        for fn in sorted(filenames):
            if fn.endswith(excl_suffix):
                continue
            full = os.path.join(dirpath, fn)
            z.write(full, os.path.relpath(full, root))
            count += 1
print(f"  snapshot entries: {count}")
PY
ls -lh "$SNAP_ZIP"

echo ""
echo "=== Device Export (fork tree) ==="
DEV_DIR="/sdcard/Download/Aetherix-Alpine-Fork"
mkdir -p "$DEV_DIR/snapshots" "$DEV_DIR/docs/${VERSION_NAME}"
cp "$PROJECT_DIR/${APP_NAME}-${VERSION_NAME}.apk" "$DEV_DIR/"
cp "$SNAP_ZIP" "$DEV_DIR/snapshots/"
if [ -d "$PROJECT_DIR/docs/${VERSION_NAME}" ]; then
    cp -r "$PROJECT_DIR/docs/${VERSION_NAME}/." "$DEV_DIR/docs/${VERSION_NAME}/"
fi
for m in docs/v0.3-series/CHANGELOG.md docs/BUGS.md FORK-NOTES.md README.md; do
    [ -f "$PROJECT_DIR/$m" ] && cp "$PROJECT_DIR/$m" "$DEV_DIR/$(basename "$m")"
done
echo "Device: $DEV_DIR/${APP_NAME}-${VERSION_NAME}.apk"
echo "Device: $DEV_DIR/snapshots/${APP_NAME}-${VERSION_NAME}-source.zip"
echo "Device: $DEV_DIR/docs/${VERSION_NAME}/"

echo ""
echo "=== Device Export (per-version folder) ==="
# v0.4.0 convention: every released version gets its own folder in the download
# tree with the source snapshot AND its APK (not just change logs), plus the
# version docs + cumulative register. Folder: Aetherix-Alpine_v<version>.
# VERSION_NAME already carries the leading "v" (e.g. v0.4.0) - strip it.
V_SHORT="${VERSION_NAME#v}"
V_DIR="/sdcard/Download/Aetherix-Alpine_v${V_SHORT}"
mkdir -p "$V_DIR"
cp "$PROJECT_DIR/${APP_NAME}-${VERSION_NAME}.apk" "$V_DIR/"
cp "$SNAP_ZIP" "$V_DIR/${APP_NAME}_${VERSION_NAME}-source.zip"
if [ -d "$PROJECT_DIR/docs/${VERSION_NAME}" ]; then
    cp -r "$PROJECT_DIR/docs/${VERSION_NAME}/." "$V_DIR/docs/"
fi
for m in docs/v0.3-series/CHANGELOG.md docs/BUGS.md FORK-NOTES.md README.md; do
    [ -f "$PROJECT_DIR/$m" ] && cp "$PROJECT_DIR/$m" "$V_DIR/$(basename "$m")"
done
echo "Device: $V_DIR/ (APK + source snapshot + docs)"

echo ""
echo "=== Stale Cleanup (fork root only) ==="
find "$PROJECT_DIR" -maxdepth 1 -name "${APP_NAME}-*.apk" \
     ! -name "${APP_NAME}-${VERSION_NAME}.apk" -delete
echo "Done."
