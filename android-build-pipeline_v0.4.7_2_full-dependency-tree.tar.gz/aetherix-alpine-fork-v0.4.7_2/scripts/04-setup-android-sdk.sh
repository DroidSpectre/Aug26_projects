#!/system/bin/sh
# 04-setup-android-sdk.sh - Install Android SDK components
set -e

PROOT_DIR="$1"
if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

ROOTFS_DIR="$PROOT_DIR/rootfs/alpine"
SDK_DIR="$PROOT_DIR/sdk"
PROOT_BIN="$PROOT_DIR/proot/proot-arm64"
LAUNCH_PROOT="$PROOT_DIR/proot/proot-launch.sh"

echo "[*] Setting up Android SDK..."

# Create SDK directories
mkdir -p "$SDK_DIR/cmdline-tools"
mkdir -p "$SDK_DIR/platforms"
mkdir -p "$SDK_DIR/build-tools"
mkdir -p "$SDK_DIR/platform-tools"

# Download Android SDK command-line tools
CMDLINE_TOOLS_VERSION="11076708"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_TOOLS_VERSION}_latest.zip"
CMDLINE_TOOLS_ARCHIVE="$SDK_DIR/cmdline-tools/commandlinetools.zip"

if [ ! -f "$CMDLINE_TOOLS_ARCHIVE" ]; then
    echo "[*] Downloading Android SDK command-line tools..."
    "$LAUNCH_PROOT" -c "wget -O /opt/android-sdk/cmdline-tools/commandlinetools.zip '$CMDLINE_TOOLS_URL'"
else
    echo "[*] Command-line tools archive already downloaded"
fi

# Extract and organize
echo "[*] Extracting command-line tools..."
"$LAUNCH_PROOT" -c "
    cd /opt/android-sdk/cmdline-tools && \
    unzip -q commandlinetools.zip && \
    mkdir -p latest && \
    mv cmdline-tools/* latest/ 2>/dev/null || true && \
    mv latest cmdline-tools/ 2>/dev/null || true
"

# Set up environment variables in Alpine
echo "[*] Configuring SDK environment variables..."
"$LAUNCH_PROOT" -c "
    cat > /etc/profile.d/android-sdk.sh << 'EOF'
export ANDROID_HOME=/opt/android-sdk
export ANDROID_SDK_ROOT=/opt/android-sdk
export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$ANDROID_HOME/build-tools/35.0.0
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
EOF
"

# Accept licenses
echo "[*] Accepting SDK licenses..."
"$LAUNCH_PROOT" -c "
    yes | /opt/android-sdk/cmdline-tools/latest/bin/sdkmanager --licenses 2>/dev/null || true
"

# Install SDK components
echo "[*] Installing SDK platforms and build-tools..."
"$LAUNCH_PROOT" -c "
    /opt/android-sdk/cmdline-tools/latest/bin/sdkmanager \
        'platforms;android-35' \
        'build-tools;35.0.0' \
        'platform-tools'
"

echo "[+] Android SDK setup complete"
echo "[*] SDK location: $SDK_DIR"
echo "[*] Installed components:"
"$LAUNCH_PROOT" -c "/opt/android-sdk/cmdline-tools/latest/bin/sdkmanager --list_installed" 2>/dev/null || true
