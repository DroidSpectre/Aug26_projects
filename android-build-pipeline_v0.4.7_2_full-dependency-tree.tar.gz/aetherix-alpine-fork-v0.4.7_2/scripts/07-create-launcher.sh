#!/system/bin/sh
# 07-create-launcher.sh - Create interactive PRoot launcher script
set -e

PROOT_DIR="$1"
if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

LAUNCHER="$PROOT_DIR/proot/enter-dev-env.sh"

echo "[*] Creating development environment launcher..."

cat > "$LAUNCHER" << 'LAUNCHER_EOF'
#!/system/bin/sh
# Development Environment Launcher
# Usage: ./enter-dev-env.sh [command]

PROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ROOTFS="$PROOT_DIR/rootfs/alpine"
PROOT_BIN="$PROOT_DIR/proot/proot-arm64"

# Verify PRoot exists
if [ ! -f "$PROOT_BIN" ]; then
    echo "[!] PRoot binary not found at: $PROOT_BIN"
    echo "[*] Run 01-setup-proot.sh first"
    exit 1
fi

# Verify rootfs exists
if [ ! -d "$ROOTFS/bin" ]; then
    echo "[!] Alpine rootfs not found at: $ROOTFS"
    echo "[*] Run 02-setup-alpine.sh first"
    exit 1
fi

# Set PRoot environment
export PROOT_NO_SECCOMP=1
export PROOT_LINK2SYMLINK=1

# Build PRoot arguments
PROOT_ARGS="
    -0
    -r $ROOTFS
    -b /dev
    -b /proc
    -b /sys
    -b $PROOT_DIR/sdk:/opt/android-sdk
    -b /sdcard:/mnt/sdcard
    -w /root
    --link2symlink
"

# Source environment if running interactively
if [ -z "$1" ]; then
    # Interactive shell
    exec $PROOT_BIN $PROOT_ARGS \
        /bin/bash -c "
            source /etc/profile.d/android-sdk.sh 2>/dev/null
            source /etc/profile.d/java.sh 2>/dev/null
            source /etc/profile.d/gradle.sh 2>/dev/null
            echo '========================================='
            echo '  Android Dev Environment (Alpine Linux)'
            echo '========================================='
            echo '  Android SDK: /opt/android-sdk'
            echo '  JDK:         /usr/lib/jvm/java-17-openjdk'
            echo '  Gradle:      /opt/gradle'
            echo '  SD Card:     /mnt/sdcard'
            echo '========================================='
            echo ''
            exec /bin/bash --login
        "
else
    # Execute command
    exec $PROOT_BIN $PROOT_ARGS \
        /bin/bash -c "
            source /etc/profile.d/android-sdk.sh 2>/dev/null
            source /etc/profile.d/java.sh 2>/dev/null
            source /etc/profile.d/gradle.sh 2>/dev/null
            $*
        "
fi
LAUNCHER_EOF

chmod 755 "$LAUNCHER"

echo "[+] Launcher created at: $LAUNCHER"
echo "[*] Usage:"
echo "    Interactive: $LAUNCHER"
echo "    Command:     $LAUNCHER 'gradle --version'"
