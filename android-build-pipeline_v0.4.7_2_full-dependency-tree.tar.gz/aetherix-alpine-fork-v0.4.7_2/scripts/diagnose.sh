#!/system/bin/sh
# diagnose.sh - Diagnostic tool for the development environment
# Run this script to check for common issues

PROOT_DIR="/data/data/com.devenv.prootbuild/files"

echo "========================================="
echo "  Development Environment Diagnostics"
echo "========================================="
echo ""

# Check Android version
echo "[System Information]"
if [ -n "$ANDROID_VERSION" ]; then
    echo "  Android Version: $ANDROID_VERSION"
else
    echo "  Android Version: Unable to detect"
fi

if [ -n "$SERIALNO" ]; then
    echo "  Device: $SERIALNO"
fi

echo "  Architecture: $(uname -m 2>/dev/null || echo 'unknown')"
echo ""

# Check PRoot
echo "[PRoot Check]"
PROOT_BIN="$PROOT_DIR/proot/proot-arm64"
if [ -f "$PROOT_BIN" ]; then
    echo "  PRoot binary: Found at $PROOT_BIN"
    if [ -x "$PROOT_BIN" ]; then
        echo "  Permissions: Executable"
    else
        echo "  Permissions: NOT executable"
        echo "  Fix: chmod 755 $PROOT_BIN"
    fi
else
    echo "  PRoot binary: NOT FOUND"
    echo "  Fix: Run 01-setup-proot.sh"
fi
echo ""

# Check rootfs
echo "[Alpine Rootfs Check]"
ROOTFS="$PROOT_DIR/rootfs/alpine"
if [ -d "$ROOTFS" ]; then
    echo "  Rootfs directory: Found"
    if [ -d "$ROOTFS/bin" ]; then
        echo "  /bin directory: Present"
    else
        echo "  /bin directory: MISSING"
        echo "  Fix: Run 02-setup-alpine.sh"
    fi
    if [ -d "$ROOTFS/etc" ]; then
        echo "  /etc directory: Present"
    else
        echo "  /etc directory: MISSING"
        echo "  Fix: Run 02-setup-alpine.sh"
    fi
else
    echo "  Rootfs directory: NOT FOUND"
    echo "  Fix: Run 02-setup-alpine.sh"
fi
echo ""

# Check SDK
echo "[Android SDK Check]"
SDK_DIR="$PROOT_DIR/sdk"
if [ -d "$SDK_DIR" ]; then
    echo "  SDK directory: Found"
    if [ -f "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
        echo "  Command-line tools: Installed"
    else
        echo "  Command-line tools: NOT FOUND"
        echo "  Fix: Run 04-setup-android-sdk.sh"
    fi
else
    echo "  SDK directory: NOT FOUND"
    echo "  Fix: Run 04-setup-android-sdk.sh"
fi
echo ""

# Check storage permissions
echo "[Storage Check]"
if [ -d "/sdcard" ]; then
    echo "  /sdcard: Accessible"
else
    echo "  /sdcard: NOT ACCESSIBLE"
fi
echo ""

# Check for noexec issues
echo "[Filesystem Check]"
if [ -f "$PROOT_BIN" ]; then
    MOUNT_INFO=$(mount 2>/dev/null | grep "$(dirname $PROOT_BIN)" || true)
    if echo "$MOUNT_INFO" | grep -q "noexec"; then
        echo "  WARNING: PRoot directory has noexec flag"
        echo "  Fix: Move PRoot to app private directory"
    else
        echo "  PRoot location: OK"
    fi
fi
echo ""

# Summary
echo "========================================="
echo "  Summary"
echo "========================================="

ISSUES=0

if [ ! -f "$PROOT_BIN" ]; then
    echo "  [!] PRoot not installed"
    ISSUES=$((ISSUES + 1))
fi

if [ ! -d "$ROOTFS/bin" ]; then
    echo "  [!] Alpine rootfs not installed"
    ISSUES=$((ISSUES + 1))
fi

if [ ! -f "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
    echo "  [!] Android SDK not installed"
    ISSUES=$((ISSUES + 1))
fi

if [ $ISSUES -eq 0 ]; then
    echo "  [+] All checks passed!"
else
    echo "  [-] $ISSUES issue(s) found"
fi

echo ""
echo "========================================="
