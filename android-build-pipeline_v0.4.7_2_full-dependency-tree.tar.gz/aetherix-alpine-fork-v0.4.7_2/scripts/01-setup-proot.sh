#!/system/bin/sh
# 01-setup-proot.sh - Install PRoot binary for ARM64
set -e

PROOT_DIR="$1"
if [ -z "$PROOT_DIR" ]; then
    PROOT_DIR="/data/data/com.devenv.prootbuild/files"
fi

PROOT_BIN="$PROOT_DIR/proot/proot-arm64"

# Multiple fallback URLs for PRoot static binary
PROOT_URLS="
    https://proot.me/bin/proot
    https://raw.githubusercontent.com/nicman23/proot-static/master/proot
    https://github.com/nicman23/proot-static/releases/download/v5.4.0/proot-static-aarch64
"

echo "[*] Setting up PRoot..."
echo "[*] Target directory: $PROOT_DIR"

# Create directories
mkdir -p "$PROOT_DIR/proot"

# Download PRoot if not present
if [ ! -f "$PROOT_BIN" ]; then
    echo "[*] Downloading PRoot binary..."

    DOWNLOADED=0
    for URL in $PROOT_URLS; do
        echo "[*] Trying: $URL"
        if command -v wget > /dev/null 2>&1; then
            wget -q -O "$PROOT_BIN" "$URL" 2>/dev/null && DOWNLOADED=1 && break
        elif command -v curl > /dev/null 2>&1; then
            curl -sL -o "$PROOT_BIN" "$URL" 2>/dev/null && DOWNLOADED=1 && break
        fi
    done

    if [ "$DOWNLOADED" -eq 0 ]; then
        echo "[!] Failed to download PRoot from all sources."
        echo "[*] Please manually download a static PRoot binary for aarch64"
        echo "    and place it at: $PROOT_BIN"
        exit 1
    fi
else
    echo "[*] PRoot binary already exists at $PROOT_BIN"
fi

# Set permissions
chmod 755 "$PROOT_BIN"

# Verify
if [ -x "$PROOT_BIN" ]; then
    echo "[+] PRoot installed successfully at $PROOT_BIN"
    "$PROOT_BIN" --version 2>/dev/null || echo "[*] PRoot binary present (version check may fail in non-root context)"
else
    echo "[!] Failed to set executable permissions on PRoot"
    exit 1
fi
