package com.aetherix.alpine.terminal;

public class WarmUpGuardTest {
    private static int fails;

    private static void check(boolean got, boolean expect, String name) {
        System.out.println((got == expect ? "PASS " : "FAIL ") + name + " got=" + got);
        if (got != expect) fails++;
    }

    public static void main(String[] args) {
        check(TerminalPromptGuard.hasTypedContent(""), false, "empty line");
        check(TerminalPromptGuard.hasTypedContent("   "), false, "whitespace only");
        check(TerminalPromptGuard.hasTypedContent("root@A16:"), false, "prompt terminus ':'");
        check(TerminalPromptGuard.hasTypedContent("root@A16:~#"), false, "prompt terminus '#'");
        check(TerminalPromptGuard.hasTypedContent(">>>  "), false, "python repl prompt");
        check(TerminalPromptGuard.hasTypedContent("root@A16:~# l"), true, "typed letter");
        check(TerminalPromptGuard.hasTypedContent("ls -la /"), true, "typed command");
        check(TerminalPromptGuard.hasTypedContent("rm -rf ~/.cach" + "e"), true, "trailing non-terminator");
        check(TerminalPromptGuard.hasTypedContent(null), true, "null -> skip (fail safe)");
        System.exit(fails == 0 ? 0 : 1);
    }
}