#include <jni.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>

extern char **environ;

static jintArray createResultInt(JNIEnv *env, const jint *data, int len) {
    jintArray result = (*env)->NewIntArray(env, len);
    if (result) (*env)->SetIntArrayRegion(env, result, 0, len, data);
    return result;
}

static jintArray errorResultInt(JNIEnv *env, int err) {
    jint data = (jint)err;
    return createResultInt(env, &data, 1);
}

static char **buildArgv(JNIEnv *env, jobjectArray args) {
    jsize len = args ? (*env)->GetArrayLength(env, args) : 0;
    if (len == 0) return NULL;

    char **argv = calloc((size_t)(len + 1), sizeof(char *));
    if (!argv) return NULL;

    for (jsize i = 0; i < len; i++) {
        jstring js = (jstring)(*env)->GetObjectArrayElement(env, args, i);
        if (!js) { argv[i] = NULL; continue; }
        const char *s = (*env)->GetStringUTFChars(env, js, NULL);
        if (s) {
            argv[i] = strdup(s);
            (*env)->ReleaseStringUTFChars(env, js, s);
        }
        (*env)->DeleteLocalRef(env, js);
    }
    argv[len] = NULL;
    return argv;
}

static void freeArgv(char **argv) {
    if (!argv) return;
    for (int i = 0; argv[i]; i++) free(argv[i]);
    free(argv);
}

JNIEXPORT jintArray JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeOpenPtm(
    JNIEnv *env, jclass cls,
    jint rows, jint cols,
    jobjectArray args)
{
    int ptm;
    pid_t pid;

    if (!args || (*env)->GetArrayLength(env, args) == 0) {
        return errorResultInt(env, -EINVAL);
    }

    ptm = open("/dev/ptmx", O_RDWR);
    if (ptm < 0) return errorResultInt(env, -errno);

    unsigned int ptyno = 0;
    if (ioctl(ptm, TIOCGPTN, &ptyno) < 0) {
        int saved = errno;
        close(ptm);
        return errorResultInt(env, -saved);
    }

    int lock = 0;
    ioctl(ptm, TIOCSPTLCK, &lock);

    {
        struct winsize ws;
        ws.ws_row = (unsigned short)rows;
        ws.ws_col = (unsigned short)cols;
        ws.ws_xpixel = 0;
        ws.ws_ypixel = 0;
        int ret = ioctl(ptm, TIOCSWINSZ, &ws);
        write(2, "JNI: TIOCSWINSZ on ptm ", 23);
        if (ret == 0) {
            write(2, "OK\n", 3);
        } else {
            char buf[64];
            int n = snprintf(buf, sizeof(buf), "FAIL errno=%d\n", errno);
            write(2, buf, n);
        }
    }

    char pts_path[64];
    int pn = snprintf(pts_path, sizeof(pts_path), "/dev/pts/%u", ptyno);
    if (pn < 0 || (size_t)pn >= sizeof(pts_path)) {
        close(ptm);
        return errorResultInt(env, -ENAMETOOLONG);
    }

    char **argv = buildArgv(env, args);
    if (!argv) {
        close(ptm);
        return errorResultInt(env, -ENOMEM);
    }

    pid = fork();
    if (pid < 0) {
        int saved = errno;
        freeArgv(argv);
        close(ptm);
        return errorResultInt(env, -saved);
    }

    if (pid == 0) {
        close(ptm);
        int pts = open(pts_path, O_RDWR);
        if (pts < 0) _exit(1);
        setsid();
        ioctl(pts, TIOCSCTTY, 0);
        dup2(pts, 0);
        dup2(pts, 1);
        dup2(pts, 2);
        if (pts > 2) close(pts);
        execve(argv[0], argv, environ);
        _exit(127);
    }

    freeArgv(argv);

    jint result[2] = { (jint)ptm, (jint)pid };
    return createResultInt(env, result, 2);
}

JNIEXPORT jint JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeWriteToPtm(
    JNIEnv *env, jclass cls, jint fd, jbyteArray data)
{
    jsize len = (*env)->GetArrayLength(env, data);
    jbyte *buf = (*env)->GetByteArrayElements(env, data, NULL);
    if (!buf) return -EIO;

    ssize_t written = 0;
    while (written < len) {
        ssize_t r = write((int)fd, buf + written, (size_t)(len - written));
        if (r < 0) {
            int err = errno;
            (*env)->ReleaseByteArrayElements(env, data, buf, JNI_ABORT);
            return -err;
        }
        written += r;
    }

    (*env)->ReleaseByteArrayElements(env, data, buf, JNI_ABORT);
    return (jint)written;
}

JNIEXPORT jbyteArray JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeReadFromPtm(
    JNIEnv *env, jclass cls, jint fd, jint maxLen)
{
    char *buf = (char *)malloc((size_t)maxLen);
    if (!buf) return NULL;

    ssize_t n = read((int)fd, buf, (size_t)maxLen);
    if (n <= 0) {
        free(buf);
        return NULL;
    }

    jbyteArray result = (*env)->NewByteArray(env, (jsize)n);
    if (result) {
        (*env)->SetByteArrayRegion(env, result, 0, (jsize)n, (jbyte *)buf);
    }
    free(buf);
    return result;
}

JNIEXPORT jint JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeSetWindowSize(
    JNIEnv *env, jclass cls, jint fd, jint rows, jint cols)
{
    struct winsize ws;
    ws.ws_row = (unsigned short)rows;
    ws.ws_col = (unsigned short)cols;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;

    int ret = ioctl((int)fd, TIOCSWINSZ, &ws);
    if (ret < 0) return -errno;
    return 0;
}

JNIEXPORT void JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeClosePtm(
    JNIEnv *env, jclass cls, jint fd, jint childPid)
{
    close((int)fd);
    if (childPid > 0) {
        kill((pid_t)childPid, SIGTERM);
        usleep(50000);
        kill((pid_t)childPid, SIGKILL);
        waitpid((pid_t)childPid, NULL, WNOHANG);
    }
}
