#define _GNU_SOURCE

typedef long long ssize_t;
typedef unsigned long long size_t;
typedef long long off_t;
typedef long long pid_t;
typedef unsigned int uid_t;
typedef unsigned int gid_t;
#define NULL ((void*)0)

struct pollfd { int fd; unsigned short events; unsigned short revents; };
struct timespec { long long tv_sec; long long tv_nsec; };
struct winsize { unsigned short ws_row; unsigned short ws_col; unsigned short ws_xpixel; unsigned short ws_ypixel; };

#define AT_FDCWD (-100)
#define O_RDWR 2
#define SIGCHLD 17
#define POLLIN 1
#define POLLHUP 16
#define POLLERR 8
#define TIOCGPTN 0x80045430
#define TIOCSPTLCK 0x40045431
#define TIOCSWINSZ 0x40087467
#define TIOCSIG 0x40045436
#define TIOCGPGRP 0x540F
#define TIOCSCTTY 0x540E
#define SIGWINCH 28
#define WNOHANG 1

static long syscall6(long n, long a1, long a2, long a3, long a4, long a5, long a6) {
    register long x8 asm("x8") = n;
    register long x0 asm("x0") = a1;
    register long x1 asm("x1") = a2;
    register long x2 asm("x2") = a3;
    register long x3 asm("x3") = a4;
    register long x4 asm("x4") = a5;
    register long x5 asm("x5") = a6;
    asm volatile("svc #0" : "=r"(x0) : "r"(x0), "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5), "r"(x8) : "memory");
    return x0;
}

static long syscall5(long n, long a1, long a2, long a3, long a4, long a5) { return syscall6(n, a1, a2, a3, a4, a5, 0); }
static long syscall4(long n, long a1, long a2, long a3, long a4) { return syscall5(n, a1, a2, a3, a4, 0); }
static long syscall3(long n, long a1, long a2, long a3) { return syscall4(n, a1, a2, a3, 0); }
static long syscall2(long n, long a1, long a2) { return syscall3(n, a1, a2, 0); }
static long syscall1(long n, long a1) { return syscall2(n, a1, 0); }

static ssize_t sys_write(int fd, const void *buf, size_t count) { return syscall3(64, fd, (long)buf, count); }
static ssize_t sys_read(int fd, void *buf, size_t count) { return syscall3(63, fd, (long)buf, count); }
static long sys_openat(int dfd, const char *path, int flags, int mode) { return syscall4(56, dfd, (long)path, flags, mode); }
static long sys_close(int fd) { return syscall1(57, fd); }
static long sys_ioctl(int fd, unsigned long req, void *arg) { return syscall3(29, fd, req, (long)arg); }
static long sys_clone(unsigned long flags, void *stack, int *ptid, int *ctid, unsigned long tls) { return syscall5(220, flags, (long)stack, (long)ptid, (long)ctid, tls); }
static long sys_dup3(int oldfd, int newfd, int flags) { return syscall3(24, oldfd, newfd, flags); }
static long sys_execve(const char *path, char *const argv[], char *const envp[]) { return syscall3(221, (long)path, (long)argv, (long)envp); }
static long sys_exit(int code) { return syscall1(93, code); }
static long sys_exit_group(int code) { return syscall1(94, code); }
static long sys_ppoll(struct pollfd *fds, int nfds, const struct timespec *timeout, const unsigned long long *sigmask, size_t sigsize) { return syscall5(73, (long)fds, nfds, (long)timeout, (long)sigmask, sigsize); }
static long sys_wait4(pid_t pid, int *wstatus, int options, void *rusage) { return syscall4(260, pid, (long)wstatus, options, (long)rusage); }
static pid_t sys_getpid(void) { return syscall1(172, 0); }
static long sys_setsid(void) { return syscall1(157, 0); }
static long sys_kill(pid_t pid, int sig) { return syscall2(129, pid, sig); }
static long sys_clock_gettime(int clk_id, void *tp) { return syscall2(113, clk_id, (long)tp); }

static void write_num_buf(char *buf, int *pos, unsigned long n) {
    if (n == 0) { buf[(*pos)++] = '0'; return; }
    char rev[24];
    int r = 0;
    while (n > 0 && r < 23) { rev[r++] = '0' + (n % 10); n /= 10; }
    while (r > 0) buf[(*pos)++] = rev[--r];
}

static void write_str(int fd, const char *s) {
    while (*s) {
        ssize_t r = sys_write(fd, s, 1);
        if (r <= 0) break;
        s++;
    }
}

static void write_num(int fd, long n) {
    char buf[24];
    int i = 23;
    buf[23] = 0;
    if (n == 0) { write_str(fd, "0"); return; }
    if (n < 0) { write_str(fd, "-"); n = -n; }
    while (n > 0 && i > 0) {
        buf[--i] = '0' + (n % 10);
        n /= 10;
    }
    write_str(fd, buf + i);
}

static void diag(const char *msg, long val) {
    write_str(2, "DBG[");
    write_num(2, sys_getpid());
    write_str(2, "]: ");
    write_str(2, msg);
    write_str(2, " ");
    write_num(2, val);
    write_str(2, "\n");
}

static void diag_str(const char *msg, const char *val) {
    write_str(2, "DBG[");
    write_num(2, sys_getpid());
    write_str(2, "]: ");
    write_str(2, msg);
    write_str(2, " ");
    write_str(2, val ? val : "(null)");
    write_str(2, "\n");
}

static void write_term_size_file(const char *path, unsigned short col, unsigned short row) {
    long fd = sys_openat(AT_FDCWD, path, 2 | 0x40 | 0x200, 0666);
    if (fd < 0) return;
    char buf[32];
    int p = 0;
    write_num_buf(buf, &p, col);
    buf[p++] = ' ';
    write_num_buf(buf, &p, row);
    buf[p++] = '\n';
    sys_write(fd, buf, p);
    sys_close(fd);
}

struct linux_dirent64 {
    unsigned long long d_ino;
    long long d_off;
    unsigned short d_reclen;
    unsigned char d_type;
    char d_name[256];
};

/* 15m: last-resort resize delivery. Under bash job control the foreground app
   (nano/vim) lives in its own process group; if TIOCSIG/TIOCGPGRP are blocked we
   scan /proc (same-uid children are visible) for every process in the child's
   session and signal each with SIGWINCH. */
static long signal_session(int session_leader_pid) {
    long d = sys_openat(AT_FDCWD, "/proc", 0, 0);
    if (d < 0) return -1;
    char buf[2048];
    long signaled = 0;
    while (1) {
        long n = syscall3(61, d, (long)buf, (long)sizeof(buf)); /* getdents64 */
        if (n <= 0) break;
        for (long off = 0; off < n; ) {
            struct linux_dirent64 *de = (struct linux_dirent64 *)(buf + off);
            off += de->d_reclen;
            char *name = de->d_name;
            if (name[0] == 0) continue;
            int is_num = 1;
            for (int i = 0; name[i]; i++) {
                if (name[i] < '0' || name[i] > '9') { is_num = 0; break; }
            }
            if (!is_num) continue;
            char stat_path[64];
            int sp = 0;
            char prefix[] = "/proc/";
            for (int i = 0; prefix[i]; i++) stat_path[sp++] = prefix[i];
            for (int i = 0; name[i]; i++) stat_path[sp++] = name[i];
            char suffix[] = "/stat";
            for (int i = 0; suffix[i]; i++) stat_path[sp++] = suffix[i];
            stat_path[sp] = 0;
            long fd = sys_openat(AT_FDCWD, stat_path, 0, 0);
            if (fd < 0) continue;
            char sb[512];
            long rn = sys_read(fd, sb, sizeof(sb) - 1);
            sys_close(fd);
            if (rn <= 0) continue;
            sb[rn] = 0;
            char *rp = sb;
            long pid_num = 0;
            while (*rp >= '0' && *rp <= '9') { pid_num = pid_num * 10 + (*rp - '0'); rp++; }
            char *paren = 0;
            for (char *q = rp; *q; q++) if (*q == ')') paren = q;
            if (!paren) continue;
            char *f = paren + 1;
            while (*f == ' ') f++;
            while (*f && *f != ' ') f++;       /* state */
            while (*f == ' ') f++;
            long ppid = 0, pgrp = 0, sess = 0;
            while (*f >= '0' && *f <= '9') { ppid = ppid * 10 + (*f - '0'); f++; }
            while (*f == ' ') f++;
            while (*f >= '0' && *f <= '9') { pgrp = pgrp * 10 + (*f - '0'); f++; }
            while (*f == ' ') f++;
            while (*f >= '0' && *f <= '9') { sess = sess * 10 + (*f - '0'); f++; }
            if (sess == (long)session_leader_pid && pid_num > 1) {
                long kr = sys_kill(pid_num, SIGWINCH);
                if (kr == 0) signaled++;
            }
        }
    }
    sys_close(d);
    return signaled;
}

static void diag_errno(const char *msg, long err) {
    write_str(2, "DBG[");
    write_num(2, sys_getpid());
    write_str(2, "]: ");
    write_str(2, msg);
    write_str(2, " errno=");
    write_num(2, -err);
    write_str(2, "\n");
}

static long parse_num(const char *s) {
    long n = 0;
    while (*s >= '0' && *s <= '9') {
        n = n * 10 + (*s - '0');
        s++;
    }
    return n;
}

static long sys_errno(long ret) {
    if (ret >= -4095 && ret < 0) return -ret;
    return 0;
}

asm(
    ".globl _start\n"
    "_start:\n"
    "    ldr w0, [sp]\n"
    "    add x1, sp, #8\n"
    "    add x2, x1, w0, uxtw #3\n"
    "    add x2, x2, #8\n"
    "    bl main\n"
    "    mov x8, #93\n"
    "    svc #0\n"
);

int main(int argc, char *argv[], char *envp[]) {
    long ret;
    int ptm, pts;
    pid_t pid;

    write_str(2, "DBG[");
    write_num(2, sys_getpid());
    write_str(2, "]: pty-bridge freestanding v1 starting\n");

    if (argc < 4) {
        write_str(2, "pty-bridge: usage: pty-bridge <rows> <cols> <command> [args...]\n");
        sys_exit(1);
    }

    unsigned short init_rows = (unsigned short)parse_num(argv[1]);
    unsigned short init_cols = (unsigned short)parse_num(argv[2]);

    diag("argc", argc);
    diag_str("command", argv[3]);

    char term_size_path[260];
    char pts_path_copy[32];
    term_size_path[0] = 0;
    pts_path_copy[0] = 0;
    if (argc > 4 && argv[4]) {
        int i = 0, slash_count = 0, last_slash = -1;
        while (argv[4][i]) {
            if (argv[4][i] == '/') { last_slash = i; slash_count++; }
            i++;
        }
        if (slash_count >= 2) {
            int pos = 0;
            for (int j = 0; j < last_slash; j++) {
                term_size_path[pos++] = argv[4][j];
            }
            char suffix[] = "/rootfs/tmp/term_size";
            for (int j = 0; suffix[j]; j++) term_size_path[pos++] = suffix[j];
            term_size_path[pos] = 0;
        }
    }
    /* 15l: Java passes the authoritative term_size path via the environment.
       The legacy argv[4]-derived path resolved to files/proot/rootfs/tmp, which is
       OUTSIDE the live PRoot rootfs (files/rootfs/alpine), so the shell's
       /tmp/term_size was never written - bash and libfaketty saw no size updates. */
    if (envp) {
        const char *prefix = "AETHERIX_TERM_SIZE_PATH=";
        for (int i = 0; envp[i]; i++) {
            int j = 0;
            while (prefix[j] && envp[i][j] == prefix[j]) j++;
            if (prefix[j] == 0) {
                int k = 0;
                while (envp[i][j + k] && k < 259) {
                    term_size_path[k] = envp[i][j + k];
                    k++;
                }
                term_size_path[k] = 0;
                break;
            }
        }
    }
    diag_str("term_size_path", term_size_path);

    ptm = sys_openat(AT_FDCWD, "/dev/ptmx", O_RDWR, 0);
    if (ptm < 0) {
        diag_errno("open /dev/ptmx", sys_errno(ptm));
        sys_exit(1);
    }
    diag("opened ptm fd", ptm);

    {
        unsigned int ptyno = 0;
        ret = sys_ioctl(ptm, TIOCGPTN, &ptyno);
        if (ret < 0) {
            diag_errno("TIOCGPTN", sys_errno(ret));
            sys_close(ptm);
            sys_exit(1);
        }
        diag("pty number", ptyno);

        int zero = 0;
        ret = sys_ioctl(ptm, TIOCSPTLCK, &zero);
        if (ret < 0) {
            diag_errno("TIOCSPTLCK (non-fatal)", sys_errno(ret));
        }
        diag("unlocked", 0);

        char pts_path[32];
        int npos = 0;
        char pts_prefix[] = "/dev/pts/";
        for (int i = 0; pts_prefix[i]; i++) pts_path[npos++] = pts_prefix[i];
        unsigned int pn = ptyno;
        if (pn == 0) {
            pts_path[npos++] = '0';
        } else {
            char rev[16];
            int r = 0;
            while (pn > 0) { rev[r++] = '0' + (pn % 10); pn /= 10; }
            while (r > 0) { pts_path[npos++] = rev[--r]; }
        }
        pts_path[npos] = 0;
        diag_str("pts path", pts_path);
        {
            int k = 0;
            while (pts_path[k] && k < 31) {
                pts_path_copy[k] = pts_path[k];
                k++;
            }
            pts_path_copy[k] = 0;
        }

        {
            struct winsize ws;
            ws.ws_row = init_rows;
            ws.ws_col = init_cols;
            ws.ws_xpixel = 0;
            ws.ws_ypixel = 0;
            ret = sys_ioctl(ptm, TIOCSWINSZ, &ws);
            if (ret < 0) {
                diag_errno("parent: TIOCSWINSZ on ptm", sys_errno(ret));
            } else {
                diag("parent: TIOCSWINSZ on ptm ok", 0);
            }
        }

        diag("cloning", SIGCHLD);
        pid = sys_clone(SIGCHLD, NULL, NULL, NULL, 0);
        if (pid < 0) {
            diag_errno("clone", sys_errno(pid));
            sys_close(ptm);
            sys_exit(1);
        }

        if (pid == 0) {
            diag("child: starting", 0);
            sys_close(ptm);
            diag("child: closed ptm", 0);

            pts = sys_openat(AT_FDCWD, pts_path, O_RDWR, 0);
            if (pts < 0) {
                diag_errno("child: open pts", sys_errno(pts));
                sys_exit_group(1);
            }
            diag("child: opened pts", pts);

            sys_setsid();
            ret = sys_ioctl(pts, TIOCSCTTY, 0);
            if (ret < 0) {
                diag_errno("child: TIOCSCTTY (non-fatal)", sys_errno(ret));
            }

            {
                struct winsize ws;
                if (init_rows < 4) init_rows = 4;
                if (init_cols < 4) init_cols = 4;
                ws.ws_row = init_rows;
                ws.ws_col = init_cols;
                ws.ws_xpixel = 0;
                ws.ws_ypixel = 0;
                ret = sys_ioctl(pts, TIOCSWINSZ, &ws);
                if (ret < 0) {
                    diag_errno("child: TIOCSWINSZ on pts", sys_errno(ret));
                }
            }

            sys_dup3(pts, 0, 0);
            sys_dup3(pts, 1, 0);
            sys_dup3(pts, 2, 0);
            if (pts > 2) sys_close(pts);

            /* 15l: intentionally leave the pty in its default termios (ICANON|ECHO).
               Clearing ECHO here made GNU readline skip its own echoing (readline
               only self-echoes when the tty starts with ECHO set), so typed text was
               invisible at the bash prompt while raw-mode apps like nano still drew
               it themselves. The shell/readline manage termios from here on. */

            /* Do not set COLUMNS/LINES in env - let shell query via TIOCGWINSZ from libfaketty */
            char *envp[] = { NULL };
            sys_execve(argv[3], argv + 3, envp);
            diag_errno("child: execve failed", 0);
            sys_exit_group(127);
        }

        diag("parent: child pid", pid);

        {
            struct timespec ts;
            ts.tv_sec = 0; ts.tv_nsec = 100000000;
            sys_ppoll(NULL, 0, &ts, NULL, 0);
        }
        {
            long kill_ret = sys_kill(-pid, SIGWINCH);
            if (kill_ret == 0) {
                diag("parent: initial kill(-child, SIGWINCH) ok", 0);
            } else {
                diag_errno("parent: initial kill(-child, SIGWINCH)", sys_errno(kill_ret));
            }
        }

        int stdin_done = 0;
        int child_done = 0;
        char buf[65536];
        long last_file_check_ms = 0;
        long last_activity_ms = 0;
        long last_resize_sig_ms = 0;
        unsigned long winsize_fail_count = 0;
        unsigned short last_file_col = init_cols;
        unsigned short last_file_row = init_rows;
        // Debounce state for resize signals
        unsigned short last_signaled_col = init_cols;
        unsigned short last_signaled_row = init_rows;
        unsigned short pending_col = 0;
        unsigned short pending_row = 0;
        long last_size_change_ms = 0;

        {
            struct timespec mono;
            if (sys_clock_gettime(1, &mono) == 0) {
                last_activity_ms = mono.tv_sec * 1000 + mono.tv_nsec / 1000000;
            }
        }

        while (1) {
            struct pollfd fds[2];
            int nfds = 0;
            struct timespec ts;
            long now_ms = 0;
            {
                struct timespec mono;
                if (sys_clock_gettime(1, &mono) == 0) {
                    now_ms = mono.tv_sec * 1000 + mono.tv_nsec / 1000000;
                }
            }

            /* Poll the term_size file (written by Java) for resize requests. */
            if (now_ms - last_file_check_ms >= 100 && term_size_path[0]) {
                last_file_check_ms = now_ms;
                long tfd = sys_openat(AT_FDCWD, term_size_path, 0, 0);
                if (tfd >= 0) {
                    char tbuf[32];
                    ssize_t tn = sys_read(tfd, tbuf, sizeof(tbuf));
                    sys_close(tfd);
                    if (tn > 0) {
                        unsigned short fcol = init_cols, frow = init_rows;
                        char *p = tbuf, *end = tbuf + tn;
                        long c = 0, r = 0;
                        while (p < end && *p >= '0' && *p <= '9') { c = c * 10 + (*p - '0'); p++; }
                        if (p < end && (*p == ' ' || *p == '\t' || *p == '\n')) p++;
                        while (p < end && *p >= '0' && *p <= '9') { r = r * 10 + (*p - '0'); p++; }
                        if (c > 0 && c < 10000) fcol = (unsigned short)c;
                        if (r > 0 && r < 10000) frow = (unsigned short)r;
                        if (fcol != last_file_col || frow != last_file_row) {
                            last_file_col = fcol;
                            last_file_row = frow;
                            diag("parent: resize from file:", fcol);
                            diag("parent: rows from file:", frow);
                        }

                        // Debounce: only signal when size has been stable for 300ms
                        // and differs from last signaled size
                        if (fcol != last_signaled_col || frow != last_signaled_row) {
                            if (fcol != pending_col || frow != pending_row) {
                                // New pending size - reset debounce timer
                                pending_col = fcol;
                                pending_row = frow;
                                last_size_change_ms = now_ms;
                            } else if (now_ms - last_size_change_ms >= 200) {
                                // Size stable for 300ms - send signal
                                if (pending_row < 4) pending_row = 4;
                                if (pending_col < 4) pending_col = 4;
                                struct winsize ws;
                                ws.ws_row = pending_row;
                                ws.ws_col = pending_col;
                                ws.ws_xpixel = 0;
                                ws.ws_ypixel = 0;
                                long io_ret = sys_ioctl(ptm, TIOCSWINSZ, &ws);
                                if (io_ret < 0 && winsize_fail_count == 0) {
                                    diag_errno("parent: runtime TIOCSWINSZ on ptm", sys_errno(io_ret));
                                }
                                if (io_ret >= 0) {
                                    winsize_fail_count = 0;
                                } else {
                                    winsize_fail_count++;
                                    diag("parent: trying TIOCSIG SIGWINCH", 0);
                                    long sig_ret = sys_ioctl(ptm, TIOCSIG, (void*)(long)SIGWINCH);
                                    if (sig_ret < 0) {
                                        diag_errno("parent: TIOCSIG on ptm", sys_errno(sig_ret));
                                        /* 15l: Android blocks TIOCSIG on the ptm. Under bash
                                           job control a foreground app (nano/vim) runs in its
                                           own process group, so kill(-child) misses it. Open
                                           the pts, try TIOCSIG there, then read the foreground
                                           pgrp via TIOCGPGRP and signal that group instead. */
                                        long pts_fd = -1;
                                        if (pts_path_copy[0]) {
                                            pts_fd = sys_openat(AT_FDCWD, pts_path_copy, O_RDWR | 0x100, 0);
                                            if (pts_fd >= 0) {
                                                sig_ret = sys_ioctl(pts_fd, TIOCSIG, (void*)(long)SIGWINCH);
                                                if (sig_ret >= 0) {
                                                    diag("parent: TIOCSIG on pts ok", 0);
                                                } else {
                                                    unsigned int fg = 0;
                                                    long grp_ret = sys_ioctl(pts_fd, TIOCGPGRP, &fg);
                                                    if (grp_ret >= 0 && fg > 1) {
                                                        diag("parent: TIOCGPGRP fg pgrp", fg);
                                                        long fg_ret = sys_kill(-(long)fg, SIGWINCH);
                                                        if (fg_ret == 0) {
                                                            diag("parent: kill(-fg, SIGWINCH) ok", 0);
                                                            sig_ret = 0;
                                                        } else {
                                                            diag_errno("parent: kill(-fg, SIGWINCH)", sys_errno(fg_ret));
                                                        }
                                                    } else {
                                                        diag_errno("parent: TIOCGPGRP", sys_errno(grp_ret));
                                                    }
                                                }
                                                sys_close(pts_fd);
                                            } else {
                                                diag_errno("parent: open pts", sys_errno(pts_fd));
                                            }
                                        }
                                        if (sig_ret < 0) {
                                            diag("parent: trying session-wide SIGWINCH", 0);
                                            long nsignaled = signal_session((int)pid);
                                            if (nsignaled > 0) {
                                                diag("parent: session-wide SIGWINCH procs", nsignaled);
                                                sig_ret = 0;
                                            } else {
                                                diag("parent: trying kill(-child, SIGWINCH)", 0);
                                                long kill_ret = sys_kill(-pid, SIGWINCH);
                                                if (kill_ret == 0) {
                                                    diag("parent: kill(-child, SIGWINCH) ok", 0);
                                                } else {
                                                    diag_errno("parent: kill(-child, SIGWINCH)", sys_errno(kill_ret));
                                                }
                                            }
                                        }
                                    } else {
                                        diag("parent: TIOCSIG SIGWINCH ok", 0);
                                    }
                                }
                                last_signaled_col = pending_col;
                                last_signaled_row = pending_row;
                                last_resize_sig_ms = now_ms;
                                pending_col = 0;
                                pending_row = 0;
                                diag("parent: debounced resize signal sent:", last_signaled_col);
                                diag("parent: debounced resize rows sent:", last_signaled_row);
                            }
                        } else {
                            // Size reverted to last signaled - clear pending
                            pending_col = 0;
                            pending_row = 0;
                        }
                    }
                }
            }

            ts.tv_sec = 0;
            ts.tv_nsec = 100000000;

            fds[nfds].fd = ptm;
            fds[nfds].events = POLLIN;
            fds[nfds].revents = 0;
            nfds++;

            if (!stdin_done) {
                fds[nfds].fd = 0;
                fds[nfds].events = POLLIN;
                fds[nfds].revents = 0;
                nfds++;
            }

            ret = sys_ppoll(fds, nfds, &ts, NULL, 0);
            if (ret < 0) {
                if (sys_errno(ret) == 4) continue;
                break;
            }

            if (fds[0].revents & POLLERR) {
                diag("parent: ptm ERR", 0);
                break;
            }
            if (fds[0].revents & (POLLIN | POLLHUP)) {
                ssize_t n = sys_read(ptm, buf, sizeof(buf));
                if (n > 0) {
                    last_activity_ms = now_ms;
                    ssize_t off = 0;
                    while (off < n) {
                        ssize_t w = sys_write(1, buf + off, n - off);
                        if (w < 0) { off = n; break; }
                        off += w;
                    }
                } else {
                    int ws;
                    pid_t r = sys_wait4(pid, &ws, WNOHANG, NULL);
                    if (r == pid) {
                        child_done = 1;
                        diag("parent: child exited", 0);
                        break;
                    }
                    diag("parent: ptm transient HUP", 0);
                }
            }

            if (!stdin_done && nfds > 1 && (fds[1].revents & (POLLIN | POLLHUP | POLLERR))) {
                if (fds[1].revents & POLLIN) {
                    ssize_t n = sys_read(0, buf, sizeof(buf));
                    if (n <= 0) {
                        stdin_done = 1;
                        sys_close(0);
                    } else {
                        last_activity_ms = now_ms;
                        // 15r/15u: diagnostic - dump the bytes the app sends shortly
                        // after a resize signal, to trace the first-keystroke
                        // mangling ("nano" -> ":ano") at the pipe boundary. Widened
                        // to 10000ms in 15u because the first "nano" arrives >2s
                        // after the keyboard-popup reflow (15t: no INPUT or stdin
                        // bytes captured for the first attempt at all).
                        if (now_ms - last_resize_sig_ms < 10000) {
                            diag("parent: stdin burst after resize", n);
                            char hexbuf[40];
                            int hp = 0;
                            int dump = n < 16 ? (int)n : 16;
                            static const char hexdig[] = "0123456789abcdef";
                            for (int i = 0; i < dump; i++) {
                                hexbuf[hp++] = hexdig[(buf[i] >> 4) & 0xf];
                                hexbuf[hp++] = hexdig[buf[i] & 0xf];
                            }
                            hexbuf[hp] = 0;
                            diag_str("parent: stdin hex", hexbuf);
                        }
                        ssize_t off = 0;
                        while (off < n) {
                            ssize_t w = sys_write(ptm, buf + off, n - off);
                            if (w < 0) break;
                            off += w;
                        }
                    }
                } else {
                    stdin_done = 1;
                    sys_close(0);
                }
            }

            if (ret == 0) {
                if (!child_done) {
                    int ws;
                    pid_t r = sys_wait4(pid, &ws, WNOHANG, NULL);
                    if (r == pid) {
                        child_done = 1;
                        diag("parent: child exited silently", 0);
                        break;
                    }
                }
                if (now_ms - last_activity_ms > 86400000) {
                    diag("parent: idle timeout 86400s", 0);
                    break;
                }
            }
        }

        diag("parent: ptm closed, reaping child", 0);
        int status = 0;
        sys_wait4(pid, &status, 0, NULL);

        int exit_code;
        if (status < 0) {
            exit_code = 1;
        } else if ((status & 0x7f) == 0) {
            exit_code = (status >> 8) & 0xff;
        } else {
            exit_code = 128 + (status & 0x7f);
        }
        diag("parent: exit code", exit_code);
        return exit_code;
    }

    return 0;
}
