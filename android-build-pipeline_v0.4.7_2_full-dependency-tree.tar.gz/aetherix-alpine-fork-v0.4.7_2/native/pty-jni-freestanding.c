#define NULL ((void*)0)

typedef int jint;
typedef signed char jbyte;
typedef unsigned char jboolean;
typedef int jsize;

struct _jobject;
typedef struct _jobject *jobject;
typedef jobject jclass;
typedef jobject jstring;
typedef jobject jarray;
typedef jarray jbyteArray;
typedef jarray jintArray;
typedef jarray jobjectArray;

struct JNINativeInterface_ {
    void *reserved[4];
    void *reserved4;
    void *reserved5_22[18];
    void (*DeleteLocalRef)(void *, void *);
    void *reserved24_168[145];
    const char *(*GetStringUTFChars)(void *, void *, jboolean *);
    void (*ReleaseStringUTFChars)(void *, void *, const char *);
    jsize (*GetArrayLength)(void *, void *);
    void *reserved172;
    jobject (*GetObjectArrayElement)(void *, void *, jsize);
    void *reserved174_175[2];
    void *(*NewByteArray)(void *, jsize);
    void *reserved177_178[2];
    void *(*NewIntArray)(void *, jsize);
    void *reserved180_183[4];
    jbyte *(*GetByteArrayElements)(void *, void *, jboolean *);
    void *reserved185_191[7];
    void (*ReleaseByteArrayElements)(void *, void *, jbyte *, jint);
    void *reserved193_207[15];
    void (*SetByteArrayRegion)(void *, void *, jsize, jsize, const jbyte *);
    void *reserved209_210[2];
    void (*SetIntArrayRegion)(void *, void *, jsize, jsize, const jint *);
};

typedef const struct JNINativeInterface_ *JNIEnv;

#define JNI_FALSE 0
#define JNI_TRUE 1
#define JNI_OK 0
#define JNI_ERR (-1)

#ifndef JNIEXPORT
#define JNIEXPORT __attribute__((visibility("default")))
#endif
#ifndef JNICALL
#define JNICALL
#endif

static long sys_call(long n, long a0, long a1, long a2, long a3, long a4, long a5) {
    register long x0 asm("x0") = a0;
    register long x1 asm("x1") = a1;
    register long x2 asm("x2") = a2;
    register long x3 asm("x3") = a3;
    register long x4 asm("x4") = a4;
    register long x5 asm("x5") = a5;
    register long x8 asm("x8") = n;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5), "r"(x8) : "memory", "cc");
    return x0;
}

static long sys_openat(int dirfd, const char *path, int flags, int mode) {
    return sys_call(56, (long)dirfd, (long)path, (long)flags, (long)mode, 0, 0);
}

static long sys_open(const char *path, int flags) {
    return sys_openat(-100, path, flags, 0);
}

static long sys_read(int fd, void *buf, unsigned long count) {
    return sys_call(63, (long)fd, (long)buf, (long)count, 0, 0, 0);
}

static long sys_write(int fd, const void *buf, unsigned long count) {
    return sys_call(64, (long)fd, (long)buf, (long)count, 0, 0, 0);
}

static long sys_close(int fd) {
    return sys_call(57, (long)fd, 0, 0, 0, 0, 0);
}

static long sys_ioctl(int fd, unsigned long cmd, void *arg) {
    return sys_call(29, (long)fd, (long)cmd, (long)arg, 0, 0, 0);
}

static long sys_dup3(int oldfd, int newfd, int flags) {
    return sys_call(24, (long)oldfd, (long)newfd, (long)flags, 0, 0, 0);
}

static long sys_setsid(void) {
    return sys_call(112, 0, 0, 0, 0, 0, 0);
}

static long sys_execve(const char *path, char *const *argv, char *const *envp) {
    return sys_call(221, (long)path, (long)argv, (long)envp, 0, 0, 0);
}

static long sys_clone(unsigned long flags, void *stack, long *ptid, long *ctid, unsigned long tls) {
    return sys_call(220, (long)flags, (long)stack, (long)ptid, (long)ctid, (long)tls, 0);
}

static long sys_kill(int pid, int sig) {
    return sys_call(129, (long)pid, (long)sig, 0, 0, 0, 0);
}

static long sys_wait4(int pid, int *wstatus, int options, void *rusage) {
    return sys_call(260, (long)pid, (long)wstatus, (long)options, (long)rusage, 0, 0);
}

static long sys_mmap(void *addr, unsigned long len, int prot, int flags, int fd, long off) {
    return sys_call(222, (long)addr, (long)len, (long)prot, (long)flags, (long)fd, off);
}

static long sys_munmap(void *addr, unsigned long len) {
    return sys_call(215, (long)addr, (long)len, 0, 0, 0, 0);
}

static long sys_nanosleep(const long *req, long *rem) {
    return sys_call(101, (long)req, (long)rem, 0, 0, 0, 0);
}

static long sys_exit(int code) {
    return sys_call(93, (long)code, 0, 0, 0, 0, 0);
}

struct winsize {
    unsigned short ws_row;
    unsigned short ws_col;
    unsigned short ws_xpixel;
    unsigned short ws_ypixel;
};

static void format_pts_path(char *buf, unsigned int n) {
    int i = 9, j;
    buf[0] = '/'; buf[1] = 'd'; buf[2] = 'e'; buf[3] = 'v';
    buf[4] = '/'; buf[5] = 'p'; buf[6] = 't'; buf[7] = 's'; buf[8] = '/';
    if (n == 0) { buf[9] = '0'; buf[10] = 0; return; }
    {
        char rev[12];
        int k = 0;
        while (n > 0) { rev[k++] = '0' + (n % 10); n /= 10; }
        for (j = k - 1; j >= 0; j--) buf[i++] = rev[j];
    }
    buf[i] = 0;
}

static jintArray createResultInt(JNIEnv *env, const jint *data, int len) {
    jintArray result = (*env)->NewIntArray(env, len);
    if (result) (*env)->SetIntArrayRegion(env, result, 0, len, data);
    return result;
}

static jintArray errorResultInt(JNIEnv *env, jint err) {
    return createResultInt(env, &err, 1);
}

JNIEXPORT jintArray JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeOpenPtm(
    JNIEnv *env, jclass cls,
    jint rows, jint cols,
    jobjectArray args)
{
    int ptm, pts;
    long pid;
    unsigned int ptyno = 0;
    char pts_path[24];
    jstring jargv[256];
    const char *cargv[256];
    jsize argc, i;
    struct winsize ws;
    int lock;

    argc = (*env)->GetArrayLength(env, args);
    if (argc < 1 || argc >= 256) return errorResultInt(env, -22);

    for (i = 0; i < argc; i++) {
        jargv[i] = (jstring)(*env)->GetObjectArrayElement(env, args, i);
        if (!jargv[i]) goto cleanup_strings;
        cargv[i] = (*env)->GetStringUTFChars(env, jargv[i], NULL);
        if (!cargv[i]) { (*env)->DeleteLocalRef(env, jargv[i]); goto cleanup_strings; }
        (*env)->DeleteLocalRef(env, jargv[i]);
    }
    cargv[argc] = NULL;

    ptm = sys_open("/dev/ptmx", 2);
    if (ptm < 0) { i = argc; goto cleanup_chars; }

    if (sys_ioctl(ptm, 0x80045430, &ptyno) < 0) {
        sys_close(ptm);
        i = argc;
        goto cleanup_chars;
    }

    lock = 0;
    sys_ioctl(ptm, 0x40045431, &lock);

    ws.ws_row = (unsigned short)rows;
    ws.ws_col = (unsigned short)cols;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;
    sys_ioctl(ptm, 0x5414, &ws);

    format_pts_path(pts_path, ptyno);

    pid = sys_clone(17, 0, 0, 0, 0);
    if (pid < 0) {
        sys_close(ptm);
        i = argc;
        goto cleanup_chars;
    }

    if (pid == 0) {
        sys_close(ptm);
        pts = sys_open(pts_path, 2);
        if (pts < 0) sys_exit(1);
        sys_setsid();
        sys_ioctl(pts, 0x540E, 0);
        if (pts != 0) sys_dup3(pts, 0, 0);
        if (pts != 1) sys_dup3(pts, 1, 0);
        if (pts != 2) sys_dup3(pts, 2, 0);
        if (pts > 2) sys_close(pts);
        sys_execve(cargv[0], (char *const *)cargv, 0);
        sys_exit(127);
    }

    for (i = 0; i < argc; i++)
        (*env)->ReleaseStringUTFChars(env, jargv[i], cargv[i]);

    {
        jint result[2] = { (jint)ptm, (jint)pid };
        return createResultInt(env, result, 2);
    }

cleanup_chars:
    for (jsize ci = 0; ci < i; ci++)
        (*env)->ReleaseStringUTFChars(env, jargv[ci], cargv[ci]);
    return errorResultInt(env, ptm < 0 ? (jint)ptm : -5);

cleanup_strings:
    for (jsize si = 0; si < i; si++) {
        if (jargv[si]) {
            if (cargv[si]) (*env)->ReleaseStringUTFChars(env, jargv[si], cargv[si]);
            (*env)->DeleteLocalRef(env, jargv[si]);
        }
    }
    return errorResultInt(env, -22);
}

JNIEXPORT jint JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeWriteToPtm(
    JNIEnv *env, jclass cls, jint fd, jbyteArray data)
{
    jsize len = (*env)->GetArrayLength(env, data);
    jboolean isCopy;
    jbyte *buf = (*env)->GetByteArrayElements(env, data, &isCopy);
    if (!buf) return -5;

    long written = 0;
    while (written < len) {
        long r = sys_write((int)fd, buf + written, (unsigned long)(len - written));
        if (r < 0) {
            (*env)->ReleaseByteArrayElements(env, data, buf, 2);
            return (jint)r;
        }
        written += r;
    }

    (*env)->ReleaseByteArrayElements(env, data, buf, 2);
    return (jint)written;
}

JNIEXPORT jbyteArray JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeReadFromPtm(
    JNIEnv *env, jclass cls, jint fd, jint maxLen)
{
    unsigned char local_buf[4096];
    void *buf;
    jbyteArray result;
    long n;

    if (maxLen <= 4096) {
        buf = local_buf;
    } else {
        long mapped = sys_mmap(0, (unsigned long)maxLen, 3, 0x22, -1, 0);
        if (mapped < 0) return NULL;
        buf = (void *)mapped;
    }

    n = sys_read((int)fd, buf, (unsigned long)maxLen);
    if (n <= 0) {
        if (buf != local_buf) sys_munmap(buf, (unsigned long)maxLen);
        return NULL;
    }

    result = (*env)->NewByteArray(env, (jsize)n);
    if (result)
        (*env)->SetByteArrayRegion(env, result, 0, (jsize)n, (jbyte *)buf);

    if (buf != local_buf) sys_munmap(buf, (unsigned long)maxLen);
    return result;
}

JNIEXPORT jint JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeSetWindowSize(
    JNIEnv *env, jclass cls, jint fd, jint rows, jint cols)
{
    struct winsize ws;
    ws.ws_row = (unsigned short)rows;
    ws.ws_col = (unsigned short)cols;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;

    long ret = sys_ioctl((int)fd, 0x5414, &ws);
    if (ret < 0) return (jint)ret;
    return 0;
}

JNIEXPORT void JNICALL
Java_com_aetherix_alpine_terminal_JniPtyBridge_nativeClosePtm(
    JNIEnv *env, jclass cls, jint fd, jint childPid)
{
    sys_close((int)fd);
    if (childPid > 0) {
        sys_kill((int)childPid, 15);
        { long ts[2] = { 0, 50000000 }; sys_nanosleep(ts, 0); }
        sys_kill((int)childPid, 9);
        sys_wait4((int)childPid, 0, 1, 0);
    }
}
