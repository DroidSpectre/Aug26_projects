#define _GNU_SOURCE
#include <dlfcn.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <termios.h>
#include <stdio.h>
#include <fcntl.h>

static struct winsize g_size;
static int g_size_initialized = 0;

typedef int (*real_ioctl_t)(int, int, ...);
static real_ioctl_t real_ioctl = NULL;

static void load_term_size_file(void) {
    int fd = open("/tmp/term_size", O_RDONLY);
    if (fd < 0) return;
    char buf[64];
    int n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return;
    buf[n] = 0;
    char *space = strchr(buf, ' ');
    if (!space) return;
    *space = 0;
    int col = atoi(buf);
    int row = atoi(space + 1);
    if (col > 0 && col < 10000) g_size.ws_col = (unsigned short)col;
    if (row > 0 && row < 10000) g_size.ws_row = (unsigned short)row;
}

static void size_from_env(void) {
    char *val;
    val = getenv("COLUMNS");
    if (val && val[0]) g_size.ws_col = (unsigned short) atoi(val);
    val = getenv("LINES");
    if (val && val[0]) g_size.ws_row = (unsigned short) atoi(val);
}

static void sigwinch_handler(int sig) {
    (void)sig;
    load_term_size_file();
}

__attribute__((constructor))
static void faketty_init(void) {
    g_size.ws_col = 80;
    g_size.ws_row = 24;
    size_from_env();
    g_size_initialized = 1;

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = sigwinch_handler;
    sa.sa_flags = 0;
    sigaction(SIGWINCH, &sa, NULL);
}

int ioctl(int fd, int request, ...) {
    if (!g_size_initialized) {
        g_size.ws_col = 80;
        g_size.ws_row = 24;
        size_from_env();
        g_size_initialized = 1;
    }

    if (request == TIOCGWINSZ) {
        size_from_env();
        load_term_size_file();
        va_list ap;
        va_start(ap, request);
        struct winsize *ws = va_arg(ap, struct winsize *);
        va_end(ap);
        if (ws) {
            ws->ws_col = g_size.ws_col;
            ws->ws_row = g_size.ws_row;
            ws->ws_xpixel = 0;
            ws->ws_ypixel = 0;
        }
        return 0;
    }

    if (request == TIOCSWINSZ) {
        va_list ap;
        va_start(ap, request);
        struct winsize *ws = va_arg(ap, struct winsize *);
        va_end(ap);
        if (ws) {
            g_size.ws_col = ws->ws_col;
            g_size.ws_row = ws->ws_row;
        }
        return 0;
    }

    if (!real_ioctl) {
        real_ioctl = (real_ioctl_t) dlsym(RTLD_NEXT, "ioctl");
        if (!real_ioctl) {
            errno = ENOSYS;
            return -1;
        }
    }

    va_list ap;
    va_start(ap, request);
    void *arg = va_arg(ap, void *);
    va_end(ap);
    return real_ioctl(fd, request, arg);
}
