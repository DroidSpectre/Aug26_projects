#!/bin/sh
# Aetherix-Alpine module helper - status, dependency-aware availability, help.
# Install/uninstall happens on the Dashboard > Modules & Storage page.
BUNDLED="${AETHERIX_BUNDLED_FILE:-/etc/aetherix/bundled-modules.txt}"
MODS_D="${AETHERIX_MODULES_D:-/etc/aetherix/modules.d}"
MARKERS="${AETHERIX_MARKERS_DIR:-/etc/aetherix}"

# Parse a module.yml stream (stdin) into NAME/VER/DESC/REQ globals.
read_yaml() {
  NAME=""; VER=""; DESC=""; REQ=""
  while IFS= read -r line; do
    case "$line" in
      name:*)         NAME=$(printf '%s' "$line" | cut -d: -f2- | tr -d ' ') ;;
      version:*)      VER=$(printf '%s' "$line" | cut -d: -f2- | tr -d ' ') ;;
      description:*)  DESC=$(printf '%s' "$line" | cut -d: -f2- | sed 's/^ //') ;;
      requires:*)     REQ=$(printf '%s' "$line" | cut -d: -f2- | tr -d '[]' | tr ',' ' ' | sed 's/^ *//') ;;
    esac
  done
}

installed_marker() { [ -f "$MARKERS/$1.installed" ]; }

case "$1" in
  status|list)
    n=0
    for d in "$MODS_D"/*/; do
      [ -d "$d" ] || continue
      name=$(basename "$d")
      ver="?"; req=""
      if [ -f "$d/info" ]; then
        ver=$(grep -m1 '^version:' "$d/info" 2>/dev/null | cut -d: -f2 | tr -d ' ')
        req=$(grep -m1 '^requires:' "$d/info" 2>/dev/null | cut -d: -f2- | tr -d '[]' | tr ',' ' ' | sed 's/^ *//')
      fi
      line="$name $ver installed"
      [ -n "$req" ] && line="$line (requires: $req)"
      echo "$line"
      n=$((n+1))
    done
    echo "total: $n module(s)"
    echo ""
    echo "tip: 'module available' lists everything with dependency status;"
    echo "     'module help' shows the full install + usage guide."
    ;;
  available|list-all|all)
    echo "Modules bundled with this app (install from the Dashboard > Modules & Storage page):"
    n=0
    if [ ! -f "$BUNDLED" ]; then
      echo "  manifest missing ($BUNDLED) - reopen the app so it writes the bundle list"
      exit 0
    fi
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      NAME=$(printf '%s' "$line" | cut -f1)
      VER=$(printf '%s' "$line" | cut -f2)
      REQ=$(printf '%s' "$line" | cut -f3-)
      [ -z "$VER" ] && VER="?"
      missing=""
      for r in $REQ; do
        installed_marker "$r" || missing="$missing $r"
      done
      if installed_marker "$NAME"; then
        st="installed"
      elif [ -n "$missing" ]; then
        st="blocked (install first:$missing)"
      else
        st="ready"
      fi
      printf '  %-14s %-6s %s\n' "$NAME" "$VER" "$st"
      [ -n "$DESC" ] && printf '      %s\n' "$DESC"
      [ -n "$REQ" ] && printf '      requires: %s\n' "$REQ"
      n=$((n+1))
    done < "$BUNDLED"
    [ "$n" -eq 0 ] && echo "  (no modules bundled with this app version)"
    echo ""
    echo "tip: 'module help' explains what each module does and how to use it."
    ;;
  deps)
    name=$(printf '%s' "$2" | sed 's/[^A-Za-z0-9._-]//g')
    [ -n "$name" ] || { echo "usage: module deps <name>" >&2; exit 2; }
    d="$MODS_D/$name"
    if [ ! -d "$d" ]; then echo "module not installed: $name" >&2; exit 2; fi
    req=$(grep -m1 '^requires:' "$d/info" 2>/dev/null | cut -d: -f2- | tr -d '[]' | tr ',' ' ' | sed 's/^ *//')
    if [ -n "$req" ]; then
      echo "$name requires: $req"
      missing=""
      for r in $req; do
        installed_marker "$r" || missing="$missing $r"
      done
      if [ -n "$missing" ]; then
        echo "  MISSING:$missing - install these modules first" >&2
        exit 1
      fi
      echo "  all present"
    else
      echo "$name requires: none"
    fi
    ;;
  help|usage)
    if [ -n "$2" ]; then
      case "$2" in
        core|core-module)  core help 2>/dev/null || echo "core-module: shared base + toolchain - install from the Modules page" ;;
        hello|hello-module) echo "hello-module: environment self-test; run 'aetherix-selftest' or 'aetherix-smoke'" ;;
        llm|llm-module)    llm help 2>/dev/null || echo "llm-module: local AI chat via llama.cpp; run 'llm help'" ;;
        help|help-module)   llm docs help 2>/dev/null || echo "help-module: curated help corpus for llm - run 'llm docs find' / 'llm chat --docs'" ;;
        *) echo "no help for '$2' - try 'module help'" ;;
      esac
      exit 0
    fi
    echo "Aetherix-Alpine module guide"
    echo "============================"
    echo ""
    echo "Modules add feature tiers to the Alpine sandbox. Install them from"
    echo "the Dashboard > Modules & Storage page (All-files access required)."
    echo ""
    echo "Install order matters - a module is only available once every module"
    echo "it depends on is installed:"
    echo "  1. core-module   shared base + build toolchain (required by all)"
    echo "  2. hello-module  self-test scripts (aetherix-selftest, aetherix-smoke)"
    echo "  3. llm-module    local AI chat via llama.cpp (llm setup && llm start)"
    echo "  4. help-module   curated help corpus for llm (llm docs, llm chat --docs)"
    echo ""
    echo "Commands:"
    echo "  module status           list installed modules"
    echo "  module available        list everything with dependency status"
    echo "  module deps <name>      show an installed module's dependencies"
    echo "  module help [name]      this guide, or per-module help"
    echo ""
    echo "Device storage is mapped into ~/storage by 'sd' (one source of truth,"
    echo "so the links never drift or duplicate):"
    echo "  sd mount          (re)create ~/storage links, clearing stale ones"
    echo "  sd list | ext     show the removable volumes bound in"
    echo "  cd ~/storage/shared && ls     browse the device internal storage"
    echo ""
    echo "After install, each module adds commands to your shell:"
    echo "  sd                      browse ~/storage (device files) - see above"
    echo "  llm help                AI chat setup + usage"
    echo "  llm build-status        background build state (STALE = dead)"
    echo "  llm build-restart       resume a build that died with the app"
    echo "  core status | help      base + toolchain status"
    echo "  elv help                adb elevation (shell uid 2000)"
    ;;
  *)
    echo "usage: module <status|available|help [name]|deps <name>>" >&2
    echo "  status     list installed modules" >&2
    echo "  available  list everything with dependency status" >&2
    echo "  help       install + usage guide" >&2
    exit 2
    ;;
esac
