#!/bin/sh
# Aetherix-Alpine unified I/O helper (v0.4.3, FB-114).
# The app owns two device-agnostic folders in Downloads and binds them into
# the guest as ~/storage/input and ~/storage/output:
#   INPUT  - the user dropbox: put files here for in-app read (e.g. a code
#            file for the llm to analyze; the agent's file_read and 'llm
#            context' see them).
#   OUTPUT - everything the app exports (llm responses, build logs, reports).
# The launcher exports AETHERIX_INPUT_DIR/AETHERIX_OUTPUT_DIR; 'sd env' and
# 'io env' print the same paths for shells started before the links exist.
IN=${AETHERIX_INPUT_DIR:-$HOME/storage/input}
OUT=${AETHERIX_OUTPUT_DIR:-$HOME/storage/output}
io_usage() {
  echo "io - unified INPUT/OUTPUT (device-agnostic, app-maintained)"
  echo ""
  echo "  io env               print the input/output env exports"
  echo "  io in                list the INPUT dropbox"
  echo "  io in <path>         print a file from INPUT (max 64 KiB)"
  echo "  io out <src> [name]  copy a file/report into OUTPUT (timestamped)"
  echo "  io clean             delete exports older than 30 days"
  echo ""
  echo "  INPUT : $IN"
  echo "  OUTPUT: $OUT"
}
case "$1" in
  env)
    printf 'export AETHERIX_INPUT_DIR=%s\nexport AETHERIX_OUTPUT_DIR=%s\n' "$IN" "$OUT"
    ;;
  in)
    if [ -z "$2" ]; then
      if [ -d "$IN" ]; then
        ls -1 "$IN" 2>/dev/null | sed 's/^/  /'
      else
        echo "input dropbox not found: $IN" >&2
        echo "the app creates it on start; run 'sd mount' if the link is missing" >&2
      fi
      exit 0
    fi
    f="$IN/$2"
    case "$f" in *'..'*) echo "path traversal not allowed" >&2; exit 2;; esac
    if [ -f "$f" ]; then
      head -c 65536 "$f"
      echo ""
    else
      echo "not found in input: $2" >&2
      exit 1
    fi
    ;;
  out)
    if [ $# -lt 2 ]; then echo "usage: io out <src> [name]" >&2; exit 2; fi
    src="$2"
    [ -f "$src" ] || { echo "no such file: $src" >&2; exit 1; }
    mkdir -p "$OUT" 2>/dev/null || { echo "output dir not writable: $OUT" >&2; exit 1; }
    name="${3:-$(basename "$src")}"
    name=$(printf '%s' "$name" | sed "s/^\(.*\)\\.\\([^.]*\\)$/\\1-$(date +%Y%m%d-%H%M%S).\\2/")
    cp -f "$src" "$OUT/$name"
    echo "exported: $OUT/$name ($(wc -c < "$OUT/$name") bytes)"
    ;;
  clean)
    if [ -d "$OUT" ]; then
      n=0
      for f in "$OUT"/*; do
        [ -f "$f" ] || continue
        age=$(( $(date +%s 2>/dev/null || echo 0) - $(date -r "$f" +%s 2>/dev/null || echo 0) ))
        case "$age" in ''|*[!0-9]*) age=0;; esac
        if [ "$age" -gt 2592000 ]; then rm -f "$f"; n=$((n+1)); fi
      done
      echo "pruned $n export(s) older than 30 days"
    else
      echo "no output dir"
    fi
    ;;
  help|usage|"")
    io_usage
    ;;
  *)
    echo "io: unknown command '$1' (try: io help)" >&2
    exit 2
    ;;
esac
