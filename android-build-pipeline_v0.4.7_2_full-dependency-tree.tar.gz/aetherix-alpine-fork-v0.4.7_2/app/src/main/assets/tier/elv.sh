#!/bin/sh
# Aetherix-Alpine elevation tier: local adb self-connect (no PC, no root).
# Requires: Developer options > Wireless debugging ON (shows pairing port + PIN).
CONF=/etc/aetherix/elevation.conf
STATE=/etc/aetherix/elevation.state
mkdir -p /etc/aetherix 2>/dev/null
[ -f "$STATE" ] || echo idle > "$STATE"

port() { grep -m1 '^port=' "$CONF" 2>/dev/null | cut -d= -f2; }
serial() { grep -m1 '^serial=' "$CONF" 2>/dev/null | cut -d= -f2; }
need_adb() {
  command -v adb >/dev/null 2>&1 && return 0
  echo "adb not found - installing android-tools (needs internet)..."
  apk add android-tools >/dev/null 2>&1 || {
    echo "ERROR: could not install android-tools"; echo error > "$STATE"; return 1; }
  command -v adb >/dev/null 2>&1
}

case "$1" in
  setup)
    need_adb || exit 1
    echo "android-tools OK"
    adb version 2>/dev/null | head -1
    ;;
  pair)
    p="$2"; pin="$3"
    if [ -z "$p" ] || [ -z "$pin" ]; then
      echo "usage: elv pair <port> <pin>" >&2; exit 2; fi
    need_adb || exit 1
    echo "pairing with 127.0.0.1:$p ..."
    out=$(adb pair 127.0.0.1:"$p" "$pin" 2>&1)
    rc=$?
    echo "$out"
    if [ $rc -eq 0 ] || printf '%s' "$out" | grep -qi success; then
      echo "port=$p" > "$CONF"
      echo paired > "$STATE"
    else
      echo error > "$STATE"
      exit $rc
    fi
    ;;
  connect)
    need_adb || exit 1
    p=$(port)
    if [ -z "$p" ]; then
      echo "no saved port - run 'elv pair <port> <pin>' first" >&2; exit 2; fi
    echo "connecting to 127.0.0.1:$p ..."
    out=$(adb connect 127.0.0.1:"$p" 2>&1)
    rc=$?
    echo "$out"
    if [ $rc -eq 0 ]; then
      s=$(adb devices | awk 'NR>1 && $2=="device"{print $1; exit}')
      if [ -n "$s" ]; then
        grep -v '^serial=' "$CONF" > "$CONF.tmp" 2>/dev/null && mv "$CONF.tmp" "$CONF" 2>/dev/null
        echo "serial=$s" >> "$CONF"
        echo connected > "$STATE"
      fi
    else
      echo error > "$STATE"
    fi
    exit $rc
    ;;
  shell)
    need_adb || exit 1
    s=$(serial)
    if [ -z "$s" ]; then echo "not connected - run 'elv connect' first" >&2; exit 2; fi
    shift
    adb -s "$s" shell "$@"
    ;;
  status)
    echo "state: $(cat "$STATE" 2>/dev/null)"
    p=$(port); [ -n "$p" ] && echo "pair port: $p"
    s=$(serial)
    if [ -n "$s" ]; then
      echo "device: $s"
      adb -s "$s" shell id 2>/dev/null | head -1
    fi
    ;;
  disconnect)
    s=$(serial)
    [ -n "$s" ] && adb disconnect "$s" >/dev/null 2>&1
    echo idle > "$STATE"
    echo "disconnected"
    ;;
  help|usage)
    echo "elv - local adb elevation (shell uid 2000; no PC, no root)"
    echo ""
    echo "  Requires: Developer options > Wireless debugging ON."
    echo "  The pairing screen shows a port + 6-digit PIN."
    echo ""
    echo "  Setup:"
    echo "    elv setup                 install android-tools (needs internet)"
    echo "    elv pair <port> <pin>     pair with the wireless-debugging screen"
    echo "    elv connect               connect to the paired device"
    echo "    elv shell <cmd>           run a command as shell uid 2000"
    echo "                              (e.g. elv shell id, elv shell pm list packages)"
    echo ""
    echo "  elv status / elv disconnect"
    ;;
  *)
    echo "usage: elv <setup|pair <port> <pin>|connect|shell <cmd>|status|disconnect|help>" >&2
    exit 2
    ;;
esac
