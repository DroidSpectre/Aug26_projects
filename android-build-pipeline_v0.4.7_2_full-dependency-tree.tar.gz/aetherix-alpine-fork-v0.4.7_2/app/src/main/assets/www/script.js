var logVisible = false;
var logPollTimer = null;

function init() {
  renderSteps();
  handleResize();
  window.addEventListener('resize', handleResize);
  pollStatus();
  setInterval(pollStatus, 3000);
  setInterval(pollLog, 2000);
}

function handleResize() {
  var app = document.getElementById('app');
  var vh = window.innerHeight;
  app.style.minHeight = (vh - 32) + 'px';
}

function renderSteps() {
  var container = document.getElementById('steps-container');
  container.innerHTML = '';
  for (var i = 0; i < 7; i++) {
    var card = document.createElement('div');
    card.className = 'step-card locked';
    card.id = 'step-' + i;
    card.innerHTML =
      '<div class="step-header">' +
        '<span class="step-name">Step ' + (i+1) + ': <span id="sname-' + i + '"></span></span>' +
        '<span class="step-status" id="sstatus-' + i + '">...</span>' +
      '</div>' +
      '<div class="step-desc" id="sdesc-' + i + '"></div>' +
      '<div class="live-results" id="live-' + i + '"></div>' +
      '<div class="step-actions">' +
        '<button class="btn btn-primary" id="sbtn-' + i + '" onclick="doInstall(' + i + ')" disabled>Install</button>' +
        '<button class="btn btn-secondary" id="stest-' + i + '" onclick="doCheck(' + i + ')" disabled>Test</button>' +
      '</div>';
    container.appendChild(card);
  }
}

function updateUI(statusJson) {
  var data;
  try {
    data = JSON.parse(statusJson);
  } catch(e) {
    return;
  }

  var allTested = true;
  var anyFailed = false;

  for (var i = 0; i < data.length; i++) {
    var s = data[i];
    var card = document.getElementById('step-' + i);
    var statusEl = document.getElementById('sstatus-' + i);
    var btn = document.getElementById('sbtn-' + i);
    var testBtn = document.getElementById('stest-' + i);
    var nameEl = document.getElementById('sname-' + i);
    var descEl = document.getElementById('sdesc-' + i);

    nameEl.textContent = s.name;
    descEl.textContent = s.description;

    card.className = 'step-card';
    if (s.status === 'locked') {
      card.classList.add('locked');
    } else if (s.status === 'running') {
      card.classList.add('running');
    } else if (s.status === 'tested') {
      card.classList.add('tested');
    } else if (s.status === 'completed') {
      card.classList.add('completed');
    } else if (s.status === 'pending') {
      card.classList.add('pending');
    } else if (s.status === 'failed') {
      card.classList.add('failed');
      anyFailed = true;
    }

    statusEl.className = 'step-status ' + s.status;
    if (s.status === 'tested') {
      statusEl.textContent = '\u2713 Tested';
    } else if (s.status === 'completed') {
      statusEl.textContent = 'Installed';
    } else if (s.status === 'pending') {
      statusEl.textContent = 'Not Installed';
    } else {
      statusEl.textContent = s.status;
    }

    if (s.status === 'running') {
      btn.disabled = true;
      btn.textContent = 'Running...';
    } else if (s.status === 'tested' || s.status === 'completed') {
      btn.disabled = true;
      btn.textContent = 'Installed';
      btn.className = 'btn btn-success';
    } else if (s.status === 'locked') {
      btn.disabled = true;
      btn.textContent = 'Locked';
    } else if (s.status === 'failed') {
      btn.disabled = true;
      btn.textContent = 'Failed';
      btn.className = 'btn btn-danger';
    } else {
      btn.disabled = false;
      btn.textContent = 'Install';
      btn.className = 'btn btn-primary';
    }

    testBtn.disabled = false;
    testBtn.textContent = s.status === 'tested' ? 'Re-test' : (s.status === 'completed' ? 'Test' : 'Test');

    if (s.status !== 'tested') {
      allTested = false;
    }
  }

  var termBtn = document.getElementById('btn-terminal');
  termBtn.style.display = (data.length >= 7 && data[6].status === 'tested') ? 'block' : 'none';

  var badge = document.getElementById('status-badge');
  if (allTested) {
    badge.textContent = 'All components ready';
    badge.style.background = '#23863633';
    badge.style.color = '#3fb950';
  } else if (anyFailed) {
    badge.textContent = 'Some components failed';
    badge.style.background = '#da363333';
    badge.style.color = '#f85149';
  } else {
    badge.textContent = 'Setup in progress';
    badge.style.background = '#21262d';
    badge.style.color = '#8b949e';
  }
}

function doInstall(index) {
  AndroidBridge.installStep(index);
}

function doCheck(index) {
  AndroidBridge.checkStep(index);
}

function toggleLog() {
  logVisible = !logVisible;
  var content = document.getElementById('log-content');
  var toggle = document.getElementById('log-toggle');
  if (logVisible) {
    content.classList.add('visible');
    toggle.textContent = 'Hide Log';
    pollLog();
    logPollTimer = setInterval(pollLog, 1000);
  } else {
    content.classList.remove('visible');
    toggle.textContent = 'Show Log';
    if (logPollTimer) {
      clearInterval(logPollTimer);
      logPollTimer = null;
    }
  }
}

function pollLog() {
  if (!logVisible) return;
  var logText = AndroidBridge.getLog();
  var el = document.getElementById('log-content');
  var isNearBottom = (el.scrollHeight - el.scrollTop - el.clientHeight) < 50;
  el.textContent = logText;
  if (isNearBottom) el.scrollTop = el.scrollHeight;
}

function pollStatus() {
  var json = AndroidBridge.getStatus();
  updateUI(json);
}

function shareErrorReport() {
  AndroidBridge.shareErrorReport();
}

function openTerminal() {
  AndroidBridge.openTerminal();
}

function showCardNotification(index, type) {
  var card = document.getElementById('step-' + index);
  if (!card) return;
  var existing = card.querySelector('.step-result');
  if (existing) existing.remove();
  var note = document.createElement('div');
  note.className = 'step-result step-result-' + type;
  note.textContent = type === 'pass' ? 'Passed' : 'Failed';
  card.appendChild(note);
  card.classList.remove('flash-pass', 'flash-fail');
  void card.offsetWidth;
  card.classList.add('flash-' + type);
  setTimeout(function() {
    card.classList.remove('flash-pass', 'flash-fail');
    if (note.parentNode) note.remove();
  }, 2500);
}

function onStatusUpdate(json) {
  updateUI(json);
}

function onLogAppend(line) {
  if (logVisible) {
    pollLog();
  }
}

function onStepComplete(index, success, output) {
  pollStatus();
  if (logVisible) pollLog();
  showCardNotification(index, success ? 'pass' : 'fail');
}

function showConfirmDialog(message) {
  var btn = document.getElementById('confirm-yes');
  var text = message;
  if (message.indexOf('INFO:') === 0) {
    text = message.slice(5);
    btn.className = 'btn btn-info';
  } else {
    btn.className = 'btn btn-primary';
  }
  document.getElementById('confirm-message').textContent = text;
  document.getElementById('confirm-overlay').style.display = 'flex';
}

function confirmResponse(confirmed) {
  document.getElementById('confirm-overlay').style.display = 'none';
  AndroidBridge.confirmInternet(confirmed);
}

function showLiveResult(index, text) {
  var liveEl = document.getElementById('live-' + index);
  if (!liveEl) return;
  liveEl.style.display = 'block';
  var line = document.createElement('div');
  line.className = 'live-line';
  line.textContent = text;
  liveEl.appendChild(line);
  liveEl.scrollTop = liveEl.scrollHeight;
}

function clearLiveResults(index) {
  var liveEl = document.getElementById('live-' + index);
  if (liveEl) {
    liveEl.innerHTML = '';
    liveEl.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', init);
