package com.aetherix.alpine.a.terminal;

import android.util.Log;

public class Logger {
    public static void logError(TerminalSessionClient client, String logTag, String message) {
        if (client != null) client.logError(logTag, message);
        else Log.e(logTag, message);
    }
    public static void logWarn(TerminalSessionClient client, String logTag, String message) {
        if (client != null) client.logWarn(logTag, message);
        else Log.w(logTag, message);
    }
    public static void logInfo(TerminalSessionClient client, String logTag, String message) {
        if (client != null) client.logInfo(logTag, message);
        else Log.i(logTag, message);
    }
    public static void logDebug(TerminalSessionClient client, String logTag, String message) {
        if (client != null) client.logDebug(logTag, message);
        else Log.d(logTag, message);
    }
    public static void logVerbose(TerminalSessionClient client, String logTag, String message) {
        if (client != null) client.logVerbose(logTag, message);
        else Log.v(logTag, message);
    }
    public static void logStackTraceWithMessage(TerminalSessionClient client, String tag, String message, Throwable throwable) {
        logError(client, tag, message + ":\n" + Log.getStackTraceString(throwable));
    }
    public static void logStackTrace(TerminalSessionClient client, String tag, Throwable throwable) {
        logError(client, tag, Log.getStackTraceString(throwable));
    }
}
