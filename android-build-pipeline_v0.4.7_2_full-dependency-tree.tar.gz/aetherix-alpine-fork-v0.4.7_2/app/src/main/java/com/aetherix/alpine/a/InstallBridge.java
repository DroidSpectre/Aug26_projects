package com.aetherix.alpine.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.aetherix.alpine.a.module.ModuleManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class InstallBridge {

    private final Context context;
    private final WebView webView;
    private final LogBuffer log;
    private final StepRunner runner;
    private final ModuleManager modules;
    private final boolean[] stepStatus;
    private final boolean[] stepTested;
    private boolean stepRunning = false;
    private int currentStep = -1;

    private CountDownLatch confirmLatch;
    private boolean confirmResult;
    private int postStepState; // 0=inactive, 1=notification, 2=battery, 3=storage
    private CountDownLatch stepLatch;
    private boolean autoInstalling = false;
    private volatile boolean secretBusy = false;

    private static final String PREFS_NAME = "aetherix_setup";
    private static final String KEY_UPGRADE_DONE = "upgrade_done";

    private static final String[] STEP_NAMES = {
        "Installing PRoot Binary + Support Libraries",
        "Extracting Alpine Linux Rootfs",
        "Running System Diagnostics",
        "Creating PRoot Launcher Script",
        "Initializing Alpine Packages",
        "Testing PTY Bridge",
        "Test & Verify"
    };

    private static final String[] STEP_DESCS = {
        "Extract and verify the PRoot ARM64 binary and support libraries",
        "Extract Alpine Linux minirootfs to create the base filesystem",
        "Diagnostic checks: SELinux, shell, proot, writability, rootfs integrity, networking",
        "Create the PRoot launcher script with bind mount configuration",
        "Run apk update/upgrade, install the base Alpine packages",
        "Launch the custom PTY bridge to verify fork/PTY/exec pipeline end-to-end",
        "Full shell test plus a version self-test, then final verify"
    };

    private static final String[] STEP_INFO = {
        "Installs the PRoot layer Alpine runs on; required before anything else.",
        "Creates the Alpine root filesystem from the bundled minirootfs.",
        "Checks SELinux, shell, proot, storage, rootfs health and internet reachability.",
        "Builds the launch command with all Android bind mounts and helper libs.",
        "Initializes the package manager and installs the base Alpine packages; first internet use.",
        "Connects the PTY bridge so the terminal can run inside the sandbox.",
        "Confirms the whole environment with a shell and self-test."
    };

    public InstallBridge(Context context, WebView webView, LogBuffer log) {
        this.context = context;
        this.webView = webView;
        this.log = log;
        this.runner = new StepRunner();
        this.modules = new ModuleManager(context);
        this.stepStatus = new boolean[7];
        this.stepTested = new boolean[7];
    }

    public void runInitialVerification() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                StepRunner.ensureLauncher(context);
                StorageTier.deploy(context);
                // FB-057: mirror APK-bundled modules into the drop folder so the
                // guest `module available` CLI can list them on a fresh install.
                modules.syncBundledModules();
                for (int i = 0; i < 7; i++) {
                    stepStatus[i] = runner.verify(i, context, log);
                }
                saveStatus();
                pushStatus();
            }
        }).start();
    }

    public boolean isAllComplete() {
        for (int i = 0; i < 7; i++) {
            if (!stepTested[i]) return false;
        }
        return true;
    }

    public int firstFailedStep() {
        for (int i = 0; i < 7; i++) {
            if (!stepStatus[i]) return i;
        }
        return -1;
    }

    private void saveStatus() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();
        for (int i = 0; i < 7; i++) {
            ed.putBoolean("step_" + i + "_complete", stepStatus[i]);
            ed.putBoolean("step_" + i + "_tested", stepTested[i]);
        }
        ed.putBoolean("all_complete", isAllComplete());
        ed.apply();
    }

    public void loadSavedStatus() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        for (int i = 0; i < 7; i++) {
            stepStatus[i] = prefs.getBoolean("step_" + i + "_complete", false);
            stepTested[i] = prefs.getBoolean("step_" + i + "_tested", false);
        }
    }

    @JavascriptInterface
    public void resetSetup() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();
        for (int i = 0; i < 7; i++) {
            stepStatus[i] = false;
            stepTested[i] = false;
            ed.putBoolean("step_" + i + "_complete", false);
            ed.putBoolean("step_" + i + "_tested", false);
        }
        ed.putBoolean("all_complete", false);
        ed.putBoolean(KEY_UPGRADE_DONE, false);
        ed.apply();
        SecretStore.clear(context);
        StorageTier.syncTavilyKey(context);
        pushStatus();
    }

    /** FB-024: wipe the on-device environment back to first-install state. */
    @JavascriptInterface
    public void factoryReset() {
        try {
            Runtime.getRuntime().exec(new String[]{"/system/bin/sh", "-c",
                "kill $(pgrep -f libproot\\.so) 2>/dev/null; " +
                "kill $(pgrep -f proot-launch) 2>/dev/null; " +
                "kill $(pgrep -f alpine/bin/sh) 2>/dev/null; " +
                "kill $(pgrep -f libpty-bridge\\.so) 2>/dev/null; true"}).waitFor();
        } catch (Exception ignored) {}
        try {
            java.io.File files = context.getFilesDir();
            deleteRecursive(new java.io.File(files, "rootfs"));
            deleteRecursive(new java.io.File(files, "proot"));
            deleteRecursive(new java.io.File(files, "sdk"));
            new java.io.File(files, "setup_complete.marker").delete();
        } catch (Exception e) {
            log.append("WARNING: factoryReset wipe failed: " + e.getMessage());
        }
        for (int i = 0; i < 7; i++) {
            stepStatus[i] = false;
            stepTested[i] = false;
        }
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
        SecretStore.clear(context);
        StorageTier.syncTavilyKey(context);
        BridgeLogBuffer.clear();
        BridgeLogBuffer.append("factoryReset: environment wiped, ready for a clean install");
        pushStatus();
    }

    /**
     * FB-102: validate, live-test, and store the Tavily API key. The test runs
     * on a worker thread (one real search call); the result is pushed to the
     * dashboard through onTavilySaveResult(json) and only a verified key is
     * persisted (Keystore-encrypted at rest) + mirrored into the guest.
     */
    @JavascriptInterface
    public void saveTavilyKey(final String key) {
        final String k = key == null ? "" : key.trim();
        if (k.length() < 8 || !k.startsWith("tvly-")) {
            pushTavilyResult(failJson("key must start with tvly- and be at least 8 characters"));
            return;
        }
        if (secretBusy) return;
        secretBusy = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = testTavilyKey(k);
                if (err != null) {
                    secretBusy = false;
                    pushTavilyResult(failJson(err));
                    return;
                }
                try {
                    SecretStore.save(context, k);
                } catch (Exception e) {
                    secretBusy = false;
                    pushTavilyResult(failJson("could not encrypt key: " + e.getMessage()));
                    return;
                }
                StorageTier.syncTavilyKey(context);
                secretBusy = false;
                log.append("Tavily key saved and verified (FB-102)");
                pushTavilyResult(okJson());
            }
        }, "tavily-save").start();
    }

    @JavascriptInterface
    public String getTavilyState() {
        JSONObject o = new JSONObject();
        try {
            o.put("set", SecretStore.has(context));
            o.put("masked", SecretStore.masked(context));
        } catch (Exception ignored) {}
        return o.toString();
    }

    @JavascriptInterface
    public void removeTavilyKey() {
        SecretStore.clear(context);
        StorageTier.syncTavilyKey(context);
        log.append("Tavily key removed (FB-102)");
        pushTavilyResult(okJson());
    }

    private static String okJson() {
        return "{\"ok\":true}";
    }

    private static String failJson(String err) {
        JSONObject o = new JSONObject();
        try {
            o.put("ok", false);
            o.put("error", err == null ? "unknown error" : err);
        } catch (Exception ignored) {}
        return o.toString();
    }

    private void pushTavilyResult(final String json) {
        final String escaped = json
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n");
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("onTavilySaveResult('" + escaped + "')", null);
            }
        });
    }

    /** One live Tavily search; returns null on success or an error message. */
    private static String testTavilyKey(String apiKey) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://api.tavily.com/search");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Bearer " + apiKey);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(20000);
            conn.getOutputStream().write(
                "{\"query\":\"test\",\"search_depth\":\"basic\",\"max_results\":1}".getBytes("UTF-8"));
            int code = conn.getResponseCode();
            InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String body = readAll(is);
            if (code >= 200 && code < 300) return null;
            String msg = tavilyError(body);
            return (msg != null) ? msg : ("HTTP " + code);
        } catch (Exception e) {
            return "network error: " + e.getMessage();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String tavilyError(String body) {
        if (body == null || body.isEmpty()) return null;
        try {
            JSONObject j = new JSONObject(body);
            if (j.has("detail")) return j.optString("detail");
            if (j.has("message")) return j.optString("message");
            if (j.has("error")) return j.optString("error");
        } catch (Exception ignored) {}
        return null;
    }

    private static String readAll(InputStream is) {
        if (is == null) return "";
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            is.close();
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    /** Persist proof that the 7-step setup completed (read by ModuleManager). */
    private void writeSetupMarker() {
        try {
            java.io.File f = new java.io.File(context.getFilesDir(), "setup_complete.marker");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f, false);
            fos.write(("v" + getVersionName() + "\n").getBytes());
            fos.close();
        } catch (Exception ignored) {}
    }

    private static void deleteRecursive(java.io.File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            java.io.File[] children = f.listFiles();
            if (children != null) {
                for (java.io.File c : children) deleteRecursive(c);
            }
        }
        f.delete();
    }

    @JavascriptInterface
    public String getStatus() {
        JSONArray arr = new JSONArray();
        try {
            for (int i = 0; i < 7; i++) {
                JSONObject obj = new JSONObject();
                obj.put("index", i);
                obj.put("name", STEP_NAMES[i]);
                obj.put("description", STEP_DESCS[i]);

                String status;
                if (stepRunning && i == currentStep) {
                    status = "running";
                } else if (stepTested[i]) {
                    status = "tested";
                } else if (stepStatus[i]) {
                    status = "completed";
                } else {
                    boolean prevTested = (i == 0) || stepTested[i - 1];
                    if (prevTested) {
                        status = "pending";
                    } else {
                        status = "locked";
                    }
                }
                obj.put("status", status);
                arr.put(obj);
            }
        } catch (Exception ignored) {}
        return arr.toString();
    }

    @JavascriptInterface
    public String getDashboardData() {
        JSONObject data = new JSONObject();
        try {
            // Idempotent lazy deploy: once the rootfs exists, surface the sd /
            // device-info / tier CLIs, ~/storage links, and bash aliases even
            // if the app was opened before setup finished (FB-022).
            StorageTier.deploy(context);
            data.put("allComplete", isAllComplete());
            data.put("alpineVersion", getAlpineRelease());
            data.put("kernelVersion", System.getProperty("os.version", "unknown"));
            data.put("appVersion", getVersionName());
            data.put("stepCount", 7);
            data.put("completedCount", countComplete());
            data.put("packageCount", countPackages());
        } catch (Exception ignored) {}
        return data.toString();
    }

    private long lastPackageCountMs = 0;
    private int cachedPackageCount = -1;

    private int countPackages() {
        // FB-046: the apk db grows with every package the user installs; parsing
        // it on the 5s dashboard poll is wasted CPU. Cache for 10s.
        try {
            long now = System.currentTimeMillis();
            if (cachedPackageCount >= 0 && now - lastPackageCountMs < 10000) {
                return cachedPackageCount;
            }
            java.io.File db = new java.io.File(context.getFilesDir().getAbsolutePath()
                + "/rootfs/alpine/lib/apk/db/installed");
            if (!db.isFile()) return 0;
            int count = 0;
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(db));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("P:")) count++;
            }
            br.close();
            cachedPackageCount = count;
            lastPackageCountMs = now;
            return count;
        } catch (Exception e) {
            return 0;
        }
    }

    private int countComplete() {
        int n = 0;
        for (int i = 0; i < 7; i++) {
            if (stepStatus[i]) n++;
        }
        return n;
    }

    private String getAlpineRelease() {
        try {
            String filesDir = context.getFilesDir().getAbsolutePath();
            java.io.BufferedReader br = new java.io.BufferedReader(
                new java.io.FileReader(filesDir + "/rootfs/alpine/etc/alpine-release"));
            String v = br.readLine();
            br.close();
            return v != null ? v : "unknown";
        } catch (Exception e) {
            return "unknown";
        }
    }

    private String getVersionName() {
        try {
            return context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "0.0.1";
        }
    }

    @JavascriptInterface
    public void installStep(int index) {
        if (stepRunning) return;
        if (index > 0 && !stepTested[index - 1]) return;
        if (index < 0 || index >= 7) return;

        showInfoThenRun(index);
    }

    private void showInfoThenRun(final int index) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                confirmLatch = new CountDownLatch(1);
                confirmResult = false;
                showConfirmDialog("INFO:" + STEP_INFO[index]);
                try {
                    boolean waited = confirmLatch.await(60, TimeUnit.SECONDS);
                    if (!waited) {
                        log.append("WARNING: info dialog timeout (60s)");
                    }
                } catch (InterruptedException e) {
                    log.append("ERROR: info dialog interrupted");
                }
                runStepNow(index);
            }
        }).start();
    }

    private void runStepNow(final int index) {
        stepRunning = true;
        currentStep = index;
        pushStatus();

        runner.runStep(index, context, log, new StepRunner.LogCallback() {
            @Override
            public void onLog(String line) {
                pushLog(line);
            }

            @Override
            public void onFinished(int stepIndex, boolean success, String output) {
                stepStatus[stepIndex] = success;
                stepRunning = false;
                currentStep = -1;

                saveStatus();
                log.append("Step " + (stepIndex + 1) + (success ? " [PASS]: " : " [FAIL]: ")
                    + (output == null ? "" : output.trim()));
                pushStatus();
                pushStepResult(stepIndex, success, output);

                if (stepIndex == 2 && success) {
                    showPostStepDialogs();
                }
                if (stepIndex == 6 && success) {
                    StorageTier.deploy(context);
                    writeSetupMarker();
                }
                if (stepLatch != null) {
                    stepLatch.countDown();
                }
            }

            @Override
            public StepRunner.ConfirmationCallback getConfirmationCallback() {
                return createConfirmationCallback();
            }

            @Override
            public void onLiveResult(int stepIndex, String text) {
                pushLiveResult(stepIndex, text);
            }
        });
    }

    @JavascriptInterface
    public void checkStep(int index) {
        if (index < 0 || index >= 7) return;
        if (stepRunning) return;
        if (!stepStatus[index]) return;
        runTestNow(index);
    }

    private void runTestNow(final int step) {
        stepRunning = true;
        currentStep = step;
        stepTested[step] = false;
        pushLiveResult(step, "Running test...");
        pushStatus();
        new Thread(new Runnable() {
            @Override
            public void run() {
                StepResult r = runner.runTest(step, context, log, new StepRunner.LogCallback() {
                    @Override public void onLog(String line) {
                        pushLog(line);
                    }
                    @Override public void onFinished(int stepIndex, boolean success, String output) {}
                    @Override public StepRunner.ConfirmationCallback getConfirmationCallback() { return null; }
                    @Override public void onLiveResult(int stepIndex, String text) {
                        pushLiveResult(stepIndex, text);
                    }
                });
                if (r.success) {
                    stepTested[step] = true;
                    stepStatus[step] = true;
                }
                stepRunning = false;
                currentStep = -1;
                saveStatus();
                log.append("Step " + (step + 1) + (r.success ? " [PASS]: OK" : " [FAIL]: " + r.error));
                pushStatus();
                pushStepResult(step, r.success, r.success ? "OK" : r.error);
                if (stepLatch != null) {
                    stepLatch.countDown();
                }
            }
        }).start();
    }

    @JavascriptInterface
    public String getLog() {
        return log.getTail(200);
    }

    @JavascriptInterface
    public String generateErrorReport() {
        return ErrorReport.generate(context, getStatus(), log.getText(), modules.rootfsDiagnostics());
    }

    @JavascriptInterface
    public void shareErrorReport() {
        String report = ErrorReport.generate(context, getStatus(), log.getText(), modules.rootfsDiagnostics());
        ErrorReport.share(context, report);
    }

    @JavascriptInterface
    public void openTerminal() {
        log.append("Terminal: show terminal button pressed");
        Intent intent = new Intent(context, TerminalActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    @JavascriptInterface
    public String getBridgeLog() {
        return BridgeLogBuffer.getText();
    }

    @JavascriptInterface
    public void confirmInternet(boolean confirmed) {
        if (postStepState > 0) {
            if (postStepState == 1) {
                if (confirmed) {
                    requestNotificationPermission();
                }
                postStepState = 2;
                showBatteryPrompt();
            } else if (postStepState == 2) {
                if (confirmed) {
                    requestBatteryOptimization();
                }
                postStepState = 3;
                showStoragePrompt();
            } else if (postStepState == 3) {
                if (confirmed) {
                    requestStorageAccess();
                }
                postStepState = 0;
                log.append("Post-step permission dialogs complete");
            }
            return;
        }
        confirmResult = confirmed;
        if (confirmLatch != null) {
            confirmLatch.countDown();
        }
    }

    private void showPostStepDialogs() {
        postStepState = 1;
        showConfirmDialog(
            "1/3 — Notification permission\n\n" +
            "Aetherix-Alpine needs notification permission to keep your terminal session alive " +
            "in the background.\n\n" +
            "On the next screen, tap \"Allow\" to grant notification permission."
        );
    }

    private void showBatteryPrompt() {
        showConfirmDialog(
            "2/3 — Battery optimization\n\n" +
            "For stable background operation, disable battery optimization for Aetherix-Alpine.\n\n" +
            "On the next screen (App info), tap Battery, then choose \"Unrestricted\". " +
            "(Samsung path: App info → Battery → Unrestricted.)"
        );
    }

    private void showStoragePrompt() {
        if (Build.VERSION.SDK_INT < 30) {
            postStepState = 0;
            log.append("Post-step permission dialogs complete (storage not required below API 30)");
            return;
        }
        showConfirmDialog(
            "3/3 — All files access\n\n" +
            "Aetherix-Alpine needs \"All files access\" so Alpine can reach your full " +
            "internal store and any SD card (sd list / sd ls / sd cp).\n\n" +
            "On the next screen, tap \"Allow all files access\"."
        );
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                Activity activity = (Activity) context;
                activity.requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1001);
            } catch (Exception e) {
                log.append("WARNING: could not request notification permission: " + e.getMessage());
            }
        }
    }

    private void requestBatteryOptimization() {
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(android.net.Uri.parse("package:" + context.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            log.append("WARNING: could not open battery settings: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public void showConfirmDialog(String message) {
        final String escapedMsg = message
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n");
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(
                    "showConfirmDialog('" + escapedMsg + "')", null);
            }
        });
    }

    private StepRunner.ConfirmationCallback createConfirmationCallback() {
        return new StepRunner.ConfirmationCallback() {
            @Override
            public boolean onConfirm(String message) {
                confirmLatch = new CountDownLatch(1);
                confirmResult = false;
                showConfirmDialog(message);
                try {
                    boolean waited = confirmLatch.await(60, TimeUnit.SECONDS);
                    if (!waited) {
                        log.append("ERROR: confirmation timeout (60s)");
                    }
                } catch (InterruptedException e) {
                    log.append("ERROR: confirmation interrupted");
                }
                return confirmResult;
            }
        };
    }

    private void pushStatus() {
        final String json = getStatus();
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("onStatusUpdate(" + json + ")", null);
            }
        });
    }

    private void pushLog(final String line) {
        final String escaped = line
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n");
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("onLogAppend('" + escaped + "')", null);
            }
        });
    }

    private void pushLiveResult(final int index, final String text) {
        final String escaped = text
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n");
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(
                    "showLiveResult(" + index + ",'" + escaped + "')", null);
            }
        });
    }

    @JavascriptInterface
    public void clearLiveResults(int index) {
        final int i = index;
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("clearLiveResults(" + i + ")", null);
            }
        });
    }

    private void pushStepResult(final int index, final boolean success, final String output) {
        final String escaped = output
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n");
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(
                    "onStepComplete(" + index + "," + success + ",'" + escaped + "')", null);
            }
        });
    }

    @JavascriptInterface
public boolean isStorageGranted() {
        return StorageTier.isStorageGranted(context);
    }

    @JavascriptInterface
    public void requestStorageAccess() {
        try {
            StorageTier.requestStorageAccess((Activity) context);
        } catch (Exception e) {
            log.append("WARNING: could not open All-files settings: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public String getStorageInfo() {
        JSONObject data = new JSONObject();
        try {
            data.put("granted", StorageTier.isStorageGranted(context));
            String[] binds = StorageTier.buildBinds(context);
            JSONArray arr = new JSONArray();
            for (String b : binds) arr.put(b.trim());
            data.put("binds", arr);
            data.put("storageDir", StorageTier.modulesDir());
            data.put("modules", countModules());
            data.put("rootfsReady", modules.rootfsReady());
            data.put("rootfsDiagnostics", modules.rootfsDiagnostics());
        } catch (Exception ignored) {}
        return data.toString();
    }

    @JavascriptInterface
    public String listModules() {
        return modules.listModules();
    }

    @JavascriptInterface
    public String installModule(String name) {
        String res = modules.installModule(name);
        appendModuleActivity(name, res);
        return res;
    }

    /** FB-063: async module install. Returns immediately with an ack; the real
     *  install runs on a background thread so the Modules page never freezes
     *  (core-module's post-install can run for minutes). Progress streams to
     *  AetherixModuleProgress(...) and the final JSON to
     *  AetherixModuleResult(...) on the WebView thread. */
    @JavascriptInterface
    public String installModuleAsync(String name) {
        JSONObject ack = new JSONObject();
        try {
            ack.put("ok", true);
            ack.put("async", true);
            ack.put("message", "install started: " + name);
        } catch (Exception ignored) {}
        final String fname = name;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String res = modules.installModule(fname, new ModuleManager.ProgressCallback() {
                    @Override
                    public void onProgress(String message) {
                        pushModuleEvent("AetherixModuleProgress", message);
                    }
                });
                appendModuleActivity(fname, res);
                pushModuleEvent("AetherixModuleResult", res);
            }
        }, "module-install-" + name);
        t.setDaemon(true);
        t.start();
        return ack.toString();
    }

    /** FB-063: deliver a module event (progress/result) to the Modules page
     *  JS global from any worker thread. */
    private void pushModuleEvent(final String fn, final String payload) {
        final String escaped = payload
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n");
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(fn + "('" + escaped + "')", null);
            }
        });
    }

    @JavascriptInterface
    public String rootfsDiagnostics() {
        return modules.rootfsDiagnostics();
    }

    @JavascriptInterface
    public String uninstallModule(String name, String mode) {
        String res = modules.uninstallModule(name, mode);
        appendModuleActivity(name, res);
        return res;
    }

    /** FB-050: mirror every module action into the main app log (error report). */
    private void appendModuleActivity(String name, String res) {
        try {
            org.json.JSONObject j = new org.json.JSONObject(res);
            log.append("Module " + name + ": " + j.optString("message", "?"));
            String activity = j.optString("log", "");
            if (activity.length() > 0) log.append("  " + activity.replace("\n", "\n  "));
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public String getDeviceInfo() {
        JSONObject data = new JSONObject();
        try {
            data.put("battery", DevicePayload.readBatteryMemory(context));
            data.put("hardware", DevicePayload.readHardwareInfo(context));
            data.put("storage", DevicePayload.readStorage(context));
            data.put("app", DevicePayload.readAppSizes(context));
            data.put("network", DevicePayload.readNetwork(context));
            data.put("deviceConf", readDeviceConf());
        } catch (Exception ignored) {}
        return data.toString();
    }

    @JavascriptInterface
    public String getStepInfo() {
        JSONArray arr = new JSONArray();
        try {
            for (int i = 0; i < 7; i++) {
                JSONObject obj = new JSONObject();
                obj.put("index", i);
                obj.put("name", STEP_NAMES[i]);
                obj.put("description", STEP_DESCS[i]);
                obj.put("info", STEP_INFO[i]);
                arr.put(obj);
            }
        } catch (Exception ignored) {}
        return arr.toString();
    }

    @JavascriptInterface
    public void startAutoInstall() {
        if (autoInstalling || stepRunning) return;
        autoInstalling = true;
        pushStatus();
        new Thread(new Runnable() {
            @Override
            public void run() {
                int failedAt = -1;
                String failReason = "";
                try {
                    for (int i = 0; i < 7; i++) {
                        if (stepTested[i]) continue;
                        pushAutoEvent("step", i, "install");
                        stepLatch = new CountDownLatch(1);
                        runStepNow(i);
                        if (!awaitStepLatch(10)) {
                            failedAt = i; failReason = "install timed out"; break;
                        }
                        if (!stepStatus[i]) {
                            failedAt = i; failReason = "install failed"; break;
                        }
                        pushAutoEvent("step", i, "test");
                        stepLatch = new CountDownLatch(1);
                        runTestNow(i);
                        if (!awaitStepLatch(10)) {
                            failedAt = i; failReason = "test timed out"; break;
                        }
                        if (!stepTested[i]) {
                            failedAt = i; failReason = "test failed"; break;
                        }
                    }
                } catch (Exception e) {
                    failedAt = -1;
                    failReason = "auto-install error: " + e.getMessage();
                    log.append("ERROR: " + e.getMessage());
                } finally {
                    autoInstalling = false;
                    currentStep = -1;
                    pushStatus();
                    if (failedAt >= 0) {
                        pushAutoEvent("failed", failedAt, failReason);
                    } else if (failReason.isEmpty()) {
                        pushAutoEvent("done", -1, "");
                    } else {
                        pushAutoEvent("failed", -1, failReason);
                    }
                }
            }
        }).start();
    }

    private boolean awaitStepLatch(int minutes) {
        try {
            return stepLatch.await(minutes, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            return false;
        }
    }

    private void pushAutoEvent(final String phase, final int index, final String message) {
        final String escaped = (message == null ? "" : message)
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n");
        webView.post(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(
                    "onAutoEvent('" + phase + "'," + index + ",'" + escaped + "')", null);
            }
        });
    }

    @JavascriptInterface
    public String getTelemetry() {
        JSONObject data = new JSONObject();
        try {
            data.put("battery", DevicePayload.readBatteryMemory(context));
            data.put("hardware", DevicePayload.readHardwareInfo(context));
            data.put("storage", DevicePayload.readStorage(context));
            data.put("app", DevicePayload.readAppSizes(context));
            data.put("network", DevicePayload.readNetwork(context));
            data.put("deviceConf", readDeviceConf());
        } catch (Exception ignored) {}
        return data.toString();
    }

    private JSONObject readDeviceConf() {
        JSONObject obj = new JSONObject();
        try {
            java.io.File conf = new java.io.File(
                context.getFilesDir().getAbsolutePath() + "/rootfs/alpine/etc/aetherix/device.conf");
            if (conf.isFile()) {
                java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(conf));
                String line;
                while ((line = br.readLine()) != null) {
                    int idx = line.indexOf(": ");
                    if (idx > 0) {
                        obj.put(line.substring(0, idx), line.substring(idx + 2));
                    }
                }
                br.close();
            }
        } catch (Exception ignored) {}
        return obj;
    }

    private int countModules() {
        try {
            JSONArray arr = new JSONArray(modules.listModules());
            int n = 0;
            for (int i = 0; i < arr.length(); i++) {
                if (arr.getJSONObject(i).optBoolean("installed", false)) n++;
            }
            return n;
        } catch (Exception e) {
            return 0;
        }
    }

    // ---- v0.3a.7 tier support (elevation / LLM) ----

    /** Read a whole tier state file (fallback default). */
    private String readTierFile(String root, String rel, String dflt) {
        try {
            java.io.File f = new java.io.File(root, rel);
            if (f.isFile()) {
                String v = new String(java.nio.file.Files.readAllBytes(f.toPath())).trim();
                if (v.length() > 0) return v;
            }
        } catch (Exception ignored) {}
        return dflt;
    }

    /** Read key=value from a tier conf file. */
    private String readTierKey(String root, String rel, String key) {
        try {
            java.io.File f = new java.io.File(root, rel);
            if (f.isFile()) {
                for (String line : new String(java.nio.file.Files.readAllBytes(f.toPath())).split("\n")) {
                    if (line.startsWith(key + "=")) return line.substring(key.length() + 1).trim();
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    @JavascriptInterface
    public String getTierStatus() {
        JSONObject data = new JSONObject();
        try {
            String root = context.getFilesDir().getAbsolutePath() + "/rootfs/alpine";
            data.put("ready", modules.rootfsReady());
            data.put("rootfsDiagnostics", modules.rootfsDiagnostics());
            JSONObject elev = new JSONObject();
            elev.put("state", readTierFile(root, "etc/aetherix/elevation.state", "idle"));
            elev.put("port", readTierKey(root, "etc/aetherix/elevation.conf", "port"));
            data.put("elevation", elev);
            JSONObject llm = new JSONObject();
            llm.put("state", readTierFile(root, "etc/aetherix/llm.state", "stopped"));
            llm.put("model", readTierKey(root, "etc/aetherix/llm.conf", "model"));
            data.put("llm", llm);
        } catch (Exception ignored) {}
        return data.toString();
    }

    @JavascriptInterface
    public void openWirelessDebugging() {
        try {
            // "android.settings.WIRELESS_DEBUGGING_SETTINGS" is not in the
            // compile-time SDK stub; use the literal action (API 26+).
            Intent i = new Intent("android.settings.WIRELESS_DEBUGGING_SETTINGS");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            } catch (Exception e2) {
                log.append("WARNING: could not open wireless debugging settings");
            }
        }
    }

    /** Run a whitelisted tier CLI inside the Alpine guest (elv/llm/module/sd). */
    @JavascriptInterface
    public String runTier(String cli, String args) {
        try {
            if (args == null) args = "";
            if (!cli.matches("elv|llm|module|sd")) return "ERR invalid cli";
            if (!args.matches("[A-Za-z0-9._/~: +=,-]*")) return "ERR invalid args";
            String launcher = context.getFilesDir().getAbsolutePath() + "/proot/proot-launch.sh";
            String cmd = cli + (args.length() > 0 ? " " + args : "");
            cmd = cmd.replace("'", "'\\''");
            Process p = Runtime.getRuntime().exec(new String[]{
                "/system/bin/sh", "-c",
                "/system/bin/sh \"" + launcher + "\" '" + cmd + "'"
            });
            final StringBuilder out = new StringBuilder();
            final StringBuilder err = new StringBuilder();
            Thread t1 = pump(p.getInputStream(), out);
            Thread t2 = pump(p.getErrorStream(), err);
            t1.start();
            t2.start();
            long timeout = args.startsWith("setup") ? 300000L : 60000L;
            long deadline = System.currentTimeMillis() + timeout;
            boolean done = false;
            while (System.currentTimeMillis() < deadline) {
                try {
                    p.exitValue();
                    done = true;
                    break;
                } catch (IllegalThreadStateException e) {
                    try { Thread.sleep(200); } catch (InterruptedException ie) { break; }
                }
            }
            if (!done) p.destroy();
            t1.join(2000);
            t2.join(2000);
            String text = (out.toString() + err.toString()).trim();
            int code = done ? p.exitValue() : -1;
            return (code == 0 ? "OK\n" : "ERR\n") + text;
        } catch (Exception e) {
            return "ERR " + e.getMessage();
        }
    }

    private static Thread pump(final InputStream in, final StringBuilder sb) {
        return new Thread(new Runnable() {
            public void run() {
                try {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        sb.append(new String(buf, 0, n, "UTF-8"));
                    }
                } catch (Exception ignored) {}
            }
        });
    }
}
