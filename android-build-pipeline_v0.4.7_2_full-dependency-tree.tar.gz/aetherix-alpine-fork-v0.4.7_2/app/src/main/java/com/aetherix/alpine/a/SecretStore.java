package com.aetherix.alpine.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * FB-102: Android Keystore-backed AES-GCM encryption for small app secrets
 * (the Tavily API key). The key material never leaves AndroidKeyStore; only
 * the Base64 ciphertext (12-byte IV + GCM tag + data) is persisted in an
 * app-private SharedPreferences file. No AndroidX dependency is used, so the
 * raw aapt/javac/d8 build stays untouched.
 */
final class SecretStore {

    private SecretStore() {}

    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String ALIAS = "aetherix_tavily_key";
    private static final String PREFS = "aetherix_secrets";
    private static final String ENTRY = "tavily_ciphertext";
    private static final int GCM_IV_BYTES = 12;

    private static SecretKey key(Context ctx) throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        SecretKey k = (SecretKey) ks.getKey(ALIAS, null);
        if (k != null) return k;
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }

    /** Encrypt a secret; returns Base64(IV || ciphertext). */
    private static String encrypt(Context ctx, String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key(ctx));
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        byte[] out = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(ct, 0, out, iv.length, ct.length);
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }

    private static String decrypt(Context ctx, String b64) throws Exception {
        byte[] all = Base64.decode(b64, Base64.NO_WRAP);
        if (all.length <= GCM_IV_BYTES) throw new IllegalArgumentException("ciphertext too short");
        byte[] iv = new byte[GCM_IV_BYTES];
        byte[] ct = new byte[all.length - GCM_IV_BYTES];
        System.arraycopy(all, 0, iv, 0, GCM_IV_BYTES);
        System.arraycopy(all, GCM_IV_BYTES, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(ctx), new GCMParameterSpec(128, iv));
        return new String(c.doFinal(ct), StandardCharsets.UTF_8);
    }

    /** Persist a new secret (replaces any previous value). */
    static void save(Context ctx, String plain) throws Exception {
        SharedPreferences.Editor ed = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        ed.putString(ENTRY, encrypt(ctx, plain));
        ed.apply();
    }

    /** Decrypted secret, or null when unset or undecryptable (stale entry dropped). */
    static String read(Context ctx) {
        try {
            String b64 = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ENTRY, null);
            if (b64 == null) return null;
            return decrypt(ctx, b64);
        } catch (Exception e) {
            // Keystore key invalidated (e.g. secure-lock change): drop the stale
            // ciphertext so the app asks for the key again instead of erroring.
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(ENTRY).apply();
            return null;
        }
    }

    static boolean has(Context ctx) {
        return read(ctx) != null;
    }

    static void clear(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(ENTRY).apply();
    }

    /** Short display form, e.g. "tvly-••••1AbC"; "" when unset. Never returns plaintext. */
    static String masked(Context ctx) {
        String v = read(ctx);
        if (v == null || v.isEmpty()) return "";
        int n = v.length();
        if (n <= 8) return v.substring(0, 2) + "••••";
        return v.substring(0, 5) + "••••" + v.substring(n - 4);
    }
}
