package com.aetherix.alpine.a;

public class StepResult {
    public final boolean success;
    public final String output;
    public final String error;

    public StepResult(boolean success, String output, String error) {
        this.success = success;
        this.output = output != null ? output : "";
        this.error = error != null ? error : "";
    }
}
