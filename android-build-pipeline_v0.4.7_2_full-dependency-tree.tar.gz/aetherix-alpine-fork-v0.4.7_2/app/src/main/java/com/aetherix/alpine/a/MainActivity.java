package com.aetherix.alpine.a;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView webView;
    private InstallBridge bridge;
    private LogBuffer log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(0xFF1a1a2e);
            getWindow().setNavigationBarColor(0xFF1a1a2e);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(
                getWindow().getDecorView().getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        log = LogBuffer.getInstance();
        log.append("Aetherix-Alpine " + getVersionName() + " starting...");

        cleanupProot();

        webView = new WebView(this);
        webView.setVerticalScrollBarEnabled(true);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setDomStorageEnabled(true);
        ws.setCacheMode(WebSettings.LOAD_NO_CACHE);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                bridge.runInitialVerification();
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        bridge = new InstallBridge(this, webView, log);
        webView.addJavascriptInterface(bridge, "AndroidBridge");

        bridge.loadSavedStatus();

        webView.loadUrl("file:///android_asset/www/dashboard.html");

        setContentView(webView);

        // FB-033: a full process kill (Device Care / OOM) while the terminal was
        // active leaves no live in-memory session. Clear the marker, tell the
        // user, and reopen a fresh shell.
        try {
            SharedPreferences p = getSharedPreferences("aetherix_setup", MODE_PRIVATE);
            if (p.getBoolean("terminal_was_active", false)
                    && !TerminalSessionManager.getInstance().isSessionActive()) {
                p.edit().putBoolean("terminal_was_active", false).apply();
                android.widget.Toast.makeText(this,
                    "Previous terminal session was killed \u2014 starting a fresh shell",
                    android.widget.Toast.LENGTH_LONG).show();
                Intent i = new Intent(this, TerminalActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(i);
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        // FB-028: after an app switch the system can restore this activity even
        // though a terminal session is still alive; jump back into the terminal
        // unless the user explicitly closed it to the dashboard.
        try {
            SharedPreferences p = getSharedPreferences("aetherix_setup", MODE_PRIVATE);
            if (TerminalSessionManager.getInstance().isSessionActive()
                    && !p.getBoolean("close_to_dashboard", false)) {
                Intent i = new Intent(this, TerminalActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(i);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private String getVersionName() {
        try {
            return getPackageManager()
                .getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "0.0.1";
        }
    }

    private void cleanupProot() {
        if (TerminalSessionManager.getInstance().isSessionActive()) {
            log.append("cleanupProot: skipped, terminal session active");
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Runtime.getRuntime().exec(new String[]{
                        "/system/bin/sh", "-c",
                        "kill $(pgrep -f libproot\\.so) 2>/dev/null; " +
                        "kill $(pgrep -f proot-launch) 2>/dev/null; " +
                        "kill $(pgrep -f alpine/bin/sh) 2>/dev/null; " +
                        "kill $(pgrep -f libpty-bridge\\.so) 2>/dev/null; true"
                    }).waitFor();
                } catch (Exception ignored) {}
            }
        }).start();
    }
}
