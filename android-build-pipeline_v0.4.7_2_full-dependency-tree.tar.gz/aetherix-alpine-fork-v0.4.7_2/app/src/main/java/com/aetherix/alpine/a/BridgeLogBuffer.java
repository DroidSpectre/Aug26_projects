package com.aetherix.alpine.a;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;

public class BridgeLogBuffer {

    private static final int MAX_LINES = 200;
    private static final LinkedList<String> lines = new LinkedList<>();
    private static final SimpleDateFormat TIMESTAMP_FMT = new SimpleDateFormat("HH:mm:ss", Locale.US);
    // 15u: diagnostic - newest emulator screen rows+cursor captured live so the
    // error report can show the real prompt cells under a break ("nano"->":ano").
    private static String screenSnapshot = "";

    public static synchronized void append(String line) {
        lines.add("[" + TIMESTAMP_FMT.format(new Date()) + "] " + line);
        while (lines.size() > MAX_LINES) {
            lines.removeFirst();
        }
    }

    public static synchronized String getText() {
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(line).append("\n");
        }
        return sb.toString();
    }

    public static synchronized void clear() {
        lines.clear();
    }

    /** 15u: store the latest visible terminal screen for the error report. */
    public static synchronized void setScreenSnapshot(String snapshot) {
        screenSnapshot = (snapshot == null) ? "" : snapshot;
    }

    /** 15u: read the stored screen snapshot for the error report (empty if none). */
    public static synchronized String getScreenSnapshot() {
        return screenSnapshot;
    }
}
