package com.aetherix.alpine.a;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.aetherix.alpine.a.terminal.ExtraKeysView;
import com.aetherix.alpine.a.terminal.TerminalSession;
import com.aetherix.alpine.a.terminal.TerminalView;
import com.aetherix.alpine.a.terminal.TerminalViewClient;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class TerminalActivity extends Activity implements TerminalViewClient {

    // v0.4.7: the old button toolbar became a compact CRT category bar that
    // opens the in-terminal aetherix-menu dropdowns (llm|modules|files|
    // system|help). Session actions (close/exit/copy/clear) live in the
    // System menu and arrive via the app.request channel.
    private static final int CATEGORY_BAR_HEIGHT_DP = 36;

    private TerminalView terminalView;
    private ExtraKeysView extraKeysView;
    private TerminalSession session;
    private TextView timerText;
    private Handler timerHandler;
    private Runnable timerRunnable;
    private long sessionStartTime;
    private TextView spinnerView;
    private Handler spinnerHandler;
    private Runnable spinnerRunnable;
    private int spinnerFrame;
    // FB-0148: last toolbar Clear press - re-applied once after resume so late
    // pty bytes (a still-running build log, an alt-screen restore) cannot
    // resurrect cleared text in the scrollback.
    private long lastClearMs = 0;
    private View buildProgressDock;
    private LinearLayout buildJobStack;
    private TextView buildActivityText;
    private String buildActivityLine = "";
    private int activitySpinnerFrame = 0;
    private Handler buildProgressHandler;
    private Runnable buildProgressRunnable;
    // FB-081: docked LLM response window (llm chat transcript)
    private View replyDock;
    private TextView replyText;
    private ScrollView replyScroller;
    private Handler replyHandler;
    private Runnable replyRunnable;
    private long replyRenderedSize = -1;
    // v0.4.7: CRT category-bar status dot + System-menu app.request channel
    private TextView statusDot;
    private Handler appRequestHandler;
    private Runnable appRequestRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogBuffer.getInstance().append("Terminal: session opened");

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(0xFF0d0d0d);
            getWindow().setNavigationBarColor(0xFF0d0d0d);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(
                getWindow().getDecorView().getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        terminalView = new TerminalView(this, null);
        terminalView.setTerminalViewClient(this);
        // 15o: discrete font sizes in sp (10/12/14/16/18), default 10sp. On this
        // 420dpi panel 10sp ~= 26px. Capped at 18sp so zoom can never collapse the
        // grid the way continuous pinch zoom did (vim corruption).
        terminalView.setFontSizeSp(10);
        terminalView.setId(View.generateViewId());

        extraKeysView = new ExtraKeysView(this, null);
        extraKeysView.setTerminalView(terminalView);
        extraKeysView.setKeyboardToggleCallback(() -> {
            terminalView.post(() -> {
                terminalView.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    if (imm.isAcceptingText()) {
                        imm.hideSoftInputFromWindow(terminalView.getWindowToken(), 0);
                    } else {
                        imm.showSoftInput(terminalView, InputMethodManager.SHOW_FORCED);
                    }
                }
            });
        });
        extraKeysView.setPasteCallback(() -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && session != null) {
                ClipData.Item item = cm.getPrimaryClip().getItemAt(0);
                CharSequence text = item.coerceToText(TerminalActivity.this);
                if (text != null) session.write(text.toString());
            }
        });
        // v0.4.7: MENU opens the LLM dropdown; the ▶ reply key toggles the
        // docked LLM response window (paste stays on the long-press menu).
        extraKeysView.setReplyCallback(this::toggleReplyDock);
        extraKeysView.setMenuCallback(() -> openMenu("llm"));
        String[][] defaultKeys = {{"TAB", "ESC", "CTRL", "ALT", "LEFT", "RIGHT", "UP", "DOWN", "MENU", "\u25b6"}};
        extraKeysView.reload(defaultKeys, ExtraKeysView.defaultCharDisplay);

        int barHeightPx = (int) (CATEGORY_BAR_HEIGHT_DP * getResources().getDisplayMetrics().density + 0.5f);
        int barPad = (int) (5 * getResources().getDisplayMetrics().density + 0.5f);
        int tabPad = (int) (5 * getResources().getDisplayMetrics().density + 0.5f);

        LinearLayout categoryBar = new LinearLayout(this);
        categoryBar.setOrientation(LinearLayout.HORIZONTAL);
        categoryBar.setBackgroundColor(0xFF0d0d0d);
        categoryBar.setGravity(Gravity.CENTER_VERTICAL);
        categoryBar.setPadding(barPad, 0, barPad, 0);

        statusDot = new TextView(this);
        statusDot.setText("\u25cf");
        statusDot.setTextSize(9);
        statusDot.setTextColor(0xFF4a4a44);
        categoryBar.addView(statusDot, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView appTitle = new TextView(this);
        appTitle.setText(" AETHERIX");
        appTitle.setTextColor(0xffffb000);
        appTitle.setTextSize(11);
        appTitle.setTypeface(android.graphics.Typeface.MONOSPACE);
        categoryBar.addView(appTitle, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // flexible spacer pushes the category tabs right and the timer to the end.
        categoryBar.addView(new TextView(this), new LinearLayout.LayoutParams(0, 0, 1f));

        String[] cats = {"LLM", "MODULES", "FILES", "SYSTEM", "HELP"};
        for (int c = 0; c < cats.length; c++) {
            if (c > 0) {
                TextView sep = new TextView(this);
                sep.setText("\u2502");
                sep.setTextColor(0xFF3a3a34);
                sep.setTextSize(11);
                categoryBar.addView(sep, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            final String cat = cats[c].toLowerCase();
            TextView tab = new TextView(this);
            tab.setText(cats[c]);
            tab.setTextColor(0xffffb000);
            tab.setTextSize(11);
            tab.setTypeface(android.graphics.Typeface.MONOSPACE);
            tab.setPadding(tabPad, 0, tabPad, 0);
            tab.setGravity(Gravity.CENTER_VERTICAL);
            tab.setOnClickListener(v -> openMenu(cat));
            categoryBar.addView(tab, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }

        timerText = new TextView(this);
        timerText.setText("0:00");
        timerText.setTextColor(0xff8a7a52);
        timerText.setTextSize(10);
        timerText.setTypeface(android.graphics.Typeface.MONOSPACE);
        timerText.setGravity(Gravity.CENTER_VERTICAL);
        categoryBar.addView(timerText, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(categoryBar, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, barHeightPx));

        // FB-051: the terminal sits in a frame so an activity spinner can be
        // overlaid bottom-right without ever touching the pty / scrollback.
        FrameLayout terminalFrame = new FrameLayout(this);
        terminalFrame.addView(terminalView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        spinnerView = new TextView(this);
        spinnerView.setText(SPINNER_FRAMES.substring(0, 1));
        spinnerView.setTextColor(0xFF58a6ff);
        spinnerView.setTextSize(14);
        spinnerView.setPadding(10, 6, 10, 6);
        GradientDrawable spinBg = new GradientDrawable();
        spinBg.setColor(0xCC10131a);
        spinBg.setCornerRadius(14);
        spinnerView.setBackground(spinBg);
        spinnerView.setVisibility(View.GONE);
        FrameLayout.LayoutParams spinLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM | Gravity.END);
        spinLp.setMargins(0, 0, 12, 12);
        terminalFrame.addView(spinnerView, spinLp);

        layout.addView(terminalFrame, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        // FB-065: docked background-build progress bar. Sits below the terminal
        // frame (never touches the pty / prompt output) and above the extra
        // keys row; polls the detached llm build state + log every 2s and
        // hides itself when no build is running.
        setupBuildProgressDock(layout);
        setupReplyDock(layout);
        layout.addView(extraKeysView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(layout);

        layout.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            int left = insets.getSystemWindowInsetLeft();
            int right = insets.getSystemWindowInsetRight();
            v.setPadding(left, top, right, 0);
            extraKeysView.setPadding(0, 0, 0, bottom);
            return insets;
        });

        terminalView.requestFocus();

        // FB-028: entering the terminal consumes the close-to-dashboard flag.
        getSharedPreferences("aetherix_setup", MODE_PRIVATE).edit()
            .putBoolean("close_to_dashboard", false).apply();

        terminalView.post(() -> {
            // 16a: detect whether the previous running session was killed by the
            // system (OOM / phantom / background kill) before we start or re-attach.
            String killed = Watchdog.detectAndReset(TerminalActivity.this);
            if (killed != null) {
                LogBuffer.getInstance().append("Watchdog: " + killed);
                showKillDialog(killed);
            }
            if (TerminalSessionManager.getInstance().isSessionActive()) {
                session = TerminalSessionManager.getInstance().getSession();
                sessionStartTime = TerminalSessionManager.getInstance().getSessionStartTime();
                session.setTerminalView(terminalView);
                terminalView.attachSession(session);
                TerminalSessionManager.getInstance().setSession(session, sessionStartTime);
                TerminalService.setOnline(true);
                TerminalService.setSessionStartTime(sessionStartTime);
                Watchdog.markRunning(TerminalActivity.this);
            } else {
                sessionStartTime = System.currentTimeMillis();
                TerminalService.setSessionStartTime(sessionStartTime);
                startShell();
            }
        });

        startTimer();
        startTerminalService();
        startBuildProgressPolling();
        startReplyPolling();
        startAppRequestPolling();
    }

    private void startTerminalService() {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                NotificationManager nm = getSystemService(NotificationManager.class);
                if (nm != null && !nm.areNotificationsEnabled()) return;
            }
            Intent serviceIntent = new Intent(this, TerminalService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        } catch (Exception ignored) {}
    }

    private void stopTerminalService() {
        try {
            stopService(new Intent(this, TerminalService.class));
        } catch (Exception ignored) {}
    }

    private long estimateElapsed() {
        return 0;
    }

    private void startTimer() {
        timerHandler = new Handler(Looper.getMainLooper());
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long elapsed = System.currentTimeMillis() - sessionStartTime;
                int secs = (int) (elapsed / 1000);
                int hours = secs / 3600;
                int mins = (secs % 3600) / 60;
                secs = secs % 60;
                timerText.setText(String.format("%d:%02d:%02d", hours, mins, secs));
                updateStatusDot();
                updateSpinner();
                updateActivitySpinner();
                timerHandler.postDelayed(this, 1000);
            }
        };
        timerHandler.postDelayed(timerRunnable, 1000);
    }

    private void stopTimer() {
        if (timerHandler != null && timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }
    }

    /** FB-065/FB-084/FB-088: activity dock between the terminal frame and the
     *  extra keys row: a stack of up to 5 job rows (progress bar + [N/M] task
     *  line + spinner). Jobs launched via the 'job' CLI (apk adds, llama.cpp
     *  builds, model downloads) poll /etc/aetherix/jobs/<id>.state, so long
     *  output stays out of the terminal scrollback. */
    private void setupBuildProgressDock(LinearLayout layout) {
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dock.setPadding(12, 4, 12, 4);
        dock.setBackgroundColor(0xFF10131a);
        dock.setVisibility(View.GONE);

        LinearLayout stack = new LinearLayout(this);
        stack.setOrientation(LinearLayout.VERTICAL);
        dock.addView(stack, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        layout.addView(dock, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        buildProgressDock = dock;
        buildJobStack = stack;
    }

    private void startBuildProgressPolling() {
        if (buildProgressHandler != null) return;
        buildProgressHandler = new Handler(Looper.getMainLooper());
        buildProgressRunnable = new Runnable() {
            @Override
            public void run() {
                updateBuildProgress();
                if (buildProgressHandler != null) {
                    buildProgressHandler.postDelayed(this, 2000);
                }
            }
        };
        buildProgressHandler.postDelayed(buildProgressRunnable, 2000);
    }

    private void stopBuildProgressPolling() {
        if (buildProgressHandler != null) {
            if (buildProgressRunnable != null) buildProgressHandler.removeCallbacks(buildProgressRunnable);
            buildProgressHandler = null;
            buildProgressRunnable = null;
        }
    }

    private void updateBuildProgress() {
        try {
            File rootfs = new File(getFilesDir(), "rootfs/alpine");
            List<JobState> jobs = new ArrayList<>();
            File jobsDir = new File(rootfs, "etc/aetherix/jobs");
            File[] sf = jobsDir.listFiles();
            if (sf != null) {
                for (File f : sf) {
                    if (!f.getName().endsWith(".state")) continue;
                    JobState st = parseJobState(f);
                    if (st == null) continue;
                    // FB-088: ignore states whose runner pid is gone (the app
                    // was killed mid-job) - they show as stale, not running.
                    if (st.status.equals("running") && st.pid > 0
                        && !new File("/proc/" + st.pid).exists()) continue;
                    if (st.status.equals("running") || recentFinished(st)) jobs.add(st);
                }
            }
            // Legacy llm states (installs before the job CLI) render as rows too.
            JobState legacy = legacyBuildState(rootfs);
            if (legacy != null) jobs.add(legacy);
            legacy = legacyDownloadState(rootfs);
            if (legacy != null) jobs.add(legacy);
            if (jobs.isEmpty()) {
                setBuildProgressVisible(false);
                return;
            }
            renderJobStack(jobs);
            setBuildProgressVisible(true);
        } catch (Exception e) {
            setBuildProgressVisible(false);
        }
    }

    private static class JobState {
        String id = "";
        String status = "running";
        String task = "";
        long cur = 0;
        long tot = 0;
        long pct = 0;
        long finished = 0;
        long pid = 0;
    }

    private static long jobLong(String v) {
        try { return Long.parseLong(v); } catch (Exception e) { return 0; }
    }

    private JobState parseJobState(File f) {
        JobState st = new JobState();
        try {
            for (String line : java.nio.file.Files.readAllLines(f.toPath())) {
                int eq = line.indexOf('=');
                if (eq < 0) continue;
                String k = line.substring(0, eq).trim();
                String v = line.substring(eq + 1).trim();
                if (k.equals("id")) st.id = v;
                else if (k.equals("status")) st.status = v;
                else if (k.equals("task")) st.task = v;
                else if (k.equals("cur")) st.cur = jobLong(v);
                else if (k.equals("tot")) st.tot = jobLong(v);
                else if (k.equals("pct")) st.pct = jobLong(v);
                else if (k.equals("finished")) st.finished = jobLong(v);
                else if (k.equals("pid")) st.pid = jobLong(v);
            }
            if (st.id.length() == 0) return null;
            return st;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean recentFinished(JobState st) {
        if (!st.status.equals("done") && !st.status.equals("failed") && !st.status.equals("stopped")) return false;
        if (st.finished <= 0) return false;
        return (System.currentTimeMillis() / 1000) - st.finished < 20;
    }

    /** FB-088: render up to 5 jobs into the stacked dock - running first, then
     *  any recently finished; the top row carries the animated spinner. */
    private void renderJobStack(List<JobState> jobs) {
        if (buildJobStack == null) return;
        buildJobStack.removeAllViews();
        int shown = 0;
        boolean top = true;
        for (int pass = 0; pass < 2 && shown < 5; pass++) {
            for (JobState st : jobs) {
                boolean running = st.status.equals("running");
                if ((pass == 0) != running) continue;
                if (shown >= 5) break;
                shown++;
                addJobRow(st, top);
                top = false;
            }
        }
    }

    /** One dock row: progress bar + "id cur/tot (pct%)" plus a single task
     *  line. The top row's task line is the animated spinner target. */
    private void addJobRow(JobState st, boolean top) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, 2, 0, 2);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            bar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF58a6ff));
            bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF30363d));
        }
        long pct = st.pct;
        if (st.tot > 0) pct = Math.min(100, st.cur * 100 / st.tot);
        if (pct < 0) pct = 0;
        bar.setMax(st.tot > 0 ? (int) st.tot : 100);
        bar.setProgress(st.tot > 0 ? (int) Math.max(0, Math.min(st.tot, st.cur)) : (int) Math.min(100, pct));

        TextView txt = new TextView(this);
        txt.setTextColor(Color.WHITE);
        txt.setTextSize(11);
        txt.setSingleLine(true);
        txt.setEllipsize(android.text.TextUtils.TruncateAt.END);
        txt.setPadding(12, 0, 0, 0);
        txt.setText(st.tot > 0
            ? st.id + " " + st.cur + "/" + st.tot + " (" + pct + "%)"
            : st.id + " (" + pct + "%)");

        row.addView(bar, new LinearLayout.LayoutParams(0, 14, 1f));
        row.addView(txt);
        wrap.addView(row, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView act = new TextView(this);
        act.setText("");
        act.setTextColor(0xFF8b949e);
        act.setTextSize(10);
        act.setTypeface(android.graphics.Typeface.MONOSPACE);
        act.setSingleLine(true);
        act.setEllipsize(android.text.TextUtils.TruncateAt.END);
        act.setPadding(0, 2, 0, 0);
        String line = st.task.length() > 0 ? st.task
            : (st.tot > 0 ? "working..." : st.status);
        String marker = st.tot > 0 ? "[" + st.cur + "/" + st.tot + "] " : "";
        if (top) {
            buildActivityText = act;
            buildActivityLine = marker + line;
            renderActivityLine();
        } else {
            act.setText(marker + line);
        }
        wrap.addView(act, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        buildJobStack.addView(wrap, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    /** Legacy llm build (llm.build.state + llm-build.log) as a stack row. */
    private JobState legacyBuildState(File rootfs) {
        try {
            File stateFile = new File(rootfs, "etc/aetherix/llm.build.state");
            if (!stateFile.isFile()) return null;
            String state = new String(java.nio.file.Files.readAllBytes(stateFile.toPath())).trim();
            if (!state.equals("building")) return null;
            JobState st = new JobState();
            st.id = "llama.cpp build";
            st.status = "running";
            String tail = "";
            try {
                File logFile = new File(rootfs, "var/log/llm-build.log");
                if (logFile.isFile() && logFile.length() > 0) {
                    java.io.RandomAccessFile raf = new java.io.RandomAccessFile(logFile, "r");
                    long len = raf.length();
                    long start = Math.max(0, len - 65536);
                    raf.seek(start);
                    byte[] buf = new byte[(int) (len - start)];
                    raf.readFully(buf);
                    raf.close();
                    tail = new String(buf, "UTF-8");
                }
            } catch (Exception e) { tail = ""; }
            java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\[(\\d+)/(\\d+)\\]");
            String lastLine = "";
            for (String ln : tail.split("\\n")) {
                String t = ln.trim();
                if (t.length() == 0) continue;
                lastLine = t;
                java.util.regex.Matcher m = p.matcher(t);
                if (m.find()) {
                    st.cur = jobLong(m.group(1));
                    st.tot = jobLong(m.group(2));
                    int idx = t.indexOf(']');
                    st.task = idx >= 0 ? t.substring(idx + 1).trim() : "";
                }
            }
            if (st.tot > 0) {
                st.pct = Math.min(100, st.cur * 100 / st.tot);
            } else {
                st.task = lastLine;
            }
            return st;
        } catch (Exception e) {
            return null;
        }
    }

    /** Legacy llm hf download state as a stack row. */
    private JobState legacyDownloadState(File rootfs) {
        try {
            File dlState = new File(rootfs, "etc/aetherix/llm-download.state");
            if (!dlState.isFile()) return null;
            String dl = new String(java.nio.file.Files.readAllBytes(dlState.toPath())).trim();
            if (dl.length() == 0) return null;
            JobState st = new JobState();
            st.id = "llm hf download";
            st.status = "running";
            st.task = dl;
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)%").matcher(dl);
            if (m.find()) st.pct = jobLong(m.group(1));
            return st;
        } catch (Exception e) {
            return null;
        }
    }

    /** Render the current-task line with the animated braille spinner. */
    private void renderActivityLine() {
        if (buildActivityText == null) return;
        if (buildActivityLine.length() == 0) {
            buildActivityText.setText("");
            return;
        }
        int f = activitySpinnerFrame % SPINNER_FRAMES.length();
        buildActivityText.setText(SPINNER_FRAMES.charAt(f) + " " + buildActivityLine);
    }

    /** FB-084: tick the activity-dock spinner (driven by the 1 s timer). */
    private void updateActivitySpinner() {
        if (buildActivityText == null || buildProgressDock == null) return;
        if (buildProgressDock.getVisibility() != View.VISIBLE) return;
        activitySpinnerFrame++;
        renderActivityLine();
    }

    private void setBuildProgressVisible(boolean show) {
        if (buildProgressDock == null) return;
        buildProgressDock.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    /** FB-081: docked LLM response window between the terminal frame and the
     *  extra keys row (same slot as the build-progress dock). Shows the tail
     *  of the guest /etc/aetherix/llm-chat.log transcript written by the llm
     *  tier; the keybar REPLY button (replacing PASTE, which stays on the
     *  long-press selection menu) toggles it. */
    private void setupReplyDock(LinearLayout layout) {
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setBackgroundColor(0xFF0d1117);
        dock.setPadding(10, 6, 10, 6);
        dock.setVisibility(View.GONE);

        TextView title = new TextView(this);
        title.setText("LLM response");
        title.setTextColor(0xFF8b949e);
        title.setTextSize(10);
        dock.addView(title, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView scroller = new ScrollView(this);
        scroller.setVerticalScrollBarEnabled(true);

        TextView txt = new TextView(this);
        txt.setTextColor(Color.WHITE);
        txt.setTextSize(11);
        txt.setTextIsSelectable(true);
        txt.setTypeface(android.graphics.Typeface.MONOSPACE);
        scroller.addView(txt, new ScrollView.LayoutParams(
            ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        dock.addView(scroller, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        layout.addView(dock, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        replyDock = dock;
        replyText = txt;
        replyScroller = scroller;
    }

    private void startReplyPolling() {
        if (replyHandler != null) return;
        replyHandler = new Handler(Looper.getMainLooper());
        replyRunnable = new Runnable() {
            @Override
            public void run() {
                updateReplyDock();
                checkDockRequest();
                if (replyHandler != null) replyHandler.postDelayed(this, 750);
            }
        };
        replyHandler.postDelayed(replyRunnable, 750);
    }

    private void stopReplyPolling() {
        if (replyHandler != null) {
            if (replyRunnable != null) replyHandler.removeCallbacks(replyRunnable);
            replyHandler = null;
            replyRunnable = null;
        }
    }

    /** v0.4.3 (FB-113): the llm tier touches /etc/aetherix/dock.request after
     *  every reply so the response window opens on its own ("show the response
     *  window from within the terminal"). We read + clear the marker here in
     *  the reply poller; the file is deleted once the dock is shown. */
    private void checkDockRequest() {
        try {
            File req = new File(getFilesDir(), "rootfs/alpine/etc/aetherix/dock.request");
            if (!req.isFile()) return;
            String want = new String(java.nio.file.Files.readAllBytes(req.toPath()), "UTF-8").trim();
            req.delete();
            if (want.equals("show") && replyDock != null && replyDock.getVisibility() != View.VISIBLE) {
                toggleReplyDock();
            }
        } catch (Exception ignored) {}
    }

    /** Keyboard-open grid is ~29 rows, keyboard-closed ~56: <=35 = IME up.
     *  FB-081: 5 lines with the keyboard open, 10 when closed. */
    private void updateReplyDockHeight() {
        if (replyDock == null || replyText == null) return;
        int rows = 29;
        try {
            if (session != null && session.getEmulator() != null) rows = session.getEmulator().mRows;
        } catch (Exception ignored) {}
        int lines = (rows <= 35) ? 5 : 10;
        int pad = (int) (12 * getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) replyDock.getLayoutParams();
        int want = (int) (lines * replyText.getPaint().getFontSpacing()) + pad;
        if (lp.height != want) {
            lp.height = want;
            replyDock.setLayoutParams(lp);
        }
    }

    private long readReplyLogSize() {
        try {
            File f = new File(getFilesDir(), "rootfs/alpine/etc/aetherix/llm-chat.log");
            if (!f.isFile()) return -1;
            return f.length();
        } catch (Exception e) {
            return -1;
        }
    }

    private String currentReplyLogText() {
        try {
            File f = new File(getFilesDir(), "rootfs/alpine/etc/aetherix/llm-chat.log");
            if (!f.isFile() || f.length() == 0) return "";
            long len = f.length();
            byte[] buf;
            if (len > 65536) {
                java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r");
                raf.seek(len - 65536);
                buf = new byte[65536];
                raf.readFully(buf);
                raf.close();
            } else {
                buf = java.nio.file.Files.readAllBytes(f.toPath());
            }
            String s = new String(buf, "UTF-8");
            String[] lines = s.split("\n", -1);
            int start = Math.max(0, lines.length - 200);
            StringBuilder sb = new StringBuilder();
            for (int i = start; i < lines.length; i++) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(lines[i]);
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void scrollReplyToEnd() {
        if (replyScroller != null) {
            replyScroller.post(() -> replyScroller.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void updateReplyDock() {
        if (replyDock == null || replyText == null) return;
        updateReplyDockHeight();
        long cur = readReplyLogSize();
        if (cur < 0) {
            replyRenderedSize = -1;
            if (replyDock.getVisibility() == View.VISIBLE) {
                replyText.setText("no replies yet - try: llm chat --once \"hi\"");
            }
            return;
        }
        if (replyDock.getVisibility() != View.VISIBLE) return;
        if (cur == replyRenderedSize) return;
        replyRenderedSize = cur;
        replyText.setText(currentReplyLogText());
        scrollReplyToEnd();
    }

    private void toggleReplyDock() {
        if (replyDock == null) return;
        boolean show = replyDock.getVisibility() != View.VISIBLE;
        if (show) {
            replyDock.setVisibility(View.VISIBLE);
            replyRenderedSize = -1;
            updateReplyDock();
            if (replyText.getText().length() == 0) {
                replyText.setText("no replies yet - try: llm chat --once \"hi\"");
            }
            scrollReplyToEnd();
        } else {
            replyDock.setVisibility(View.GONE);
        }
        extraKeysView.setReplyActive(show);
    }

    /** FB-051: braille activity spinner (bottom-right overlay). Purely visual:
     *  driven by session output timestamps + prompt detection; never writes to
     *  the pty, so the scrollback / Copy All output stays clean. */
    private static final String SPINNER_FRAMES = "\u280b\u2819\u2839\u2838\u283c\u2834\u2826\u2827\u2807\u280f";
    private static final long SPINNER_TICK_MS = 120;

    private void updateSpinner() {
        if (session == null) {
            setSpinnerVisible(false);
            return;
        }
        boolean show = session.shouldShowSpinner();
        if (show) {
            String tail = currentPromptLine();
            if (tail != null && tail.matches(".*:\\S*[#$]\\s*$")) {
                session.notePromptSeen();
                show = false;
            }
        }
        setSpinnerVisible(show);
    }

    private String currentPromptLine() {
        try {
            if (session == null || session.getEmulator() == null) return null;
            int cols = session.getEmulator().mColumns;
            int row = session.getEmulator().getCursorRow();
            if (row < 0) return null;
            return session.getEmulator().getScreen().getSelectedText(0, row, cols, row + 1);
        } catch (Exception e) {
            return null;
        }
    }

    private void setSpinnerVisible(boolean show) {
        if (spinnerView == null) return;
        boolean was = spinnerView.getVisibility() == View.VISIBLE;
        if (show == was) return;
        spinnerView.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) startSpinnerAnimation(); else stopSpinnerAnimation();
    }

    private void startSpinnerAnimation() {
        if (spinnerHandler != null) return;
        spinnerHandler = new Handler(Looper.getMainLooper());
        spinnerFrame = 0;
        spinnerRunnable = new Runnable() {
            @Override
            public void run() {
                if (spinnerView == null || spinnerView.getVisibility() != View.VISIBLE) {
                    stopSpinnerAnimation();
                    return;
                }
                spinnerFrame = (spinnerFrame + 1) % SPINNER_FRAMES.length();
                spinnerView.setText(SPINNER_FRAMES.substring(spinnerFrame, spinnerFrame + 1));
                if (spinnerHandler != null) spinnerHandler.postDelayed(this, SPINNER_TICK_MS);
            }
        };
        spinnerHandler.postDelayed(spinnerRunnable, SPINNER_TICK_MS);
    }

    private void stopSpinnerAnimation() {
        if (spinnerHandler != null) {
            if (spinnerRunnable != null) spinnerHandler.removeCallbacks(spinnerRunnable);
            spinnerHandler = null;
            spinnerRunnable = null;
        }
    }

    private void closeSession() {
        new AlertDialog.Builder(this)
            .setTitle("Close Terminal")
            .setMessage("Terminal session will keep running in the background. Tap 'Open Terminal' from the Dashboard to return to it.")
            .setPositiveButton("OK", (DialogInterface dialog, int which) -> {
                LogBuffer.getInstance().append("Terminal: session closed (running in background)");
                stopTimer();
                // FB-028: remember the user chose the dashboard so an app-switch
                // return does not bounce straight back into the terminal.
                getSharedPreferences("aetherix_setup", MODE_PRIVATE).edit()
                    .putBoolean("close_to_dashboard", true)
                    .putBoolean("terminal_was_active", false).apply();
                if (session != null) {
                    session.setTerminalView(null);
                    TerminalSessionManager.getInstance().setSession(session, sessionStartTime);
                }
                Intent intent = new Intent(this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void exitSession() {
        new AlertDialog.Builder(this)
            .setTitle("Exit Terminal")
            .setMessage("End terminal session? All processes will be terminated and unsaved work will be lost.")
            .setPositiveButton("Exit", (DialogInterface dialog, int which) -> {
                LogBuffer.getInstance().append("Terminal: session exited");
                stopTimer();
                getSharedPreferences("aetherix_setup", MODE_PRIVATE).edit()
                    .putBoolean("close_to_dashboard", false)
                    .putBoolean("terminal_was_active", false).apply();
                Watchdog.markClean(TerminalActivity.this);
                if (session != null) {
                    session.write("exit\n");
                    session.destroy();
                }
                TerminalSessionManager.getInstance().clear();
                TerminalService.setOnline(false);
                stopTerminalService();
                Intent intent = new Intent(this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showKillDialog(String detail) {
        new AlertDialog.Builder(this)
            .setTitle("Terminal Session Killed")
            .setMessage(detail + "\n\nA fresh session will start now. If this happens repeatedly," +
                        " open the Dashboard -> Settings and disable battery optimization for Aetherix-Alpine.")
            .setPositiveButton("OK", null)
            .show();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!(getSystemService(NotificationManager.class)).areNotificationsEnabled()) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }
    }

    private void requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            android.content.SharedPreferences prefs = getSharedPreferences("aetherix_prefs", MODE_PRIVATE);
            if (prefs.getBoolean("battery_opt_dismissed", false)) return;
            new AlertDialog.Builder(this)
                .setTitle("Battery Optimization")
                .setMessage("For stable background operation, disable battery optimization for Aetherix-Alpine.\n\n" +
                            "On the next screen (App info), tap Battery, then choose \"Unrestricted\". " +
                            "(Samsung path: App info → Battery → Unrestricted.)")
                .setPositiveButton("Open Settings", (d, w) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("Don't ask again", (d, w) -> {
                    prefs.edit().putBoolean("battery_opt_dismissed", true).apply();
                })
                .show();
        }
    }

    /**
     * v0.4.2 (FB-104): write the last ~40 visible terminal lines to the guest
     * path /etc/aetherix/term.context (inside the rootfs). The llm tier reads
     * it for 'llm context' and injects it into ask/agent prompts. Runs on
     * resume and after settled resizes; failures are non-fatal.
     */
    private void writeTermContext() {
        try {
            if (session == null || session.getEmulator() == null) return;
            int cols = session.getEmulator().mColumns;
            int rows = session.getEmulator().mRows;
            String all = session.getEmulator().getScreen().getSelectedText(
                0, -session.getEmulator().getScreen().getActiveTranscriptRows(), cols, rows);
            if (all == null || all.isEmpty()) return;
            String[] lines = all.split("\n", -1);
            int start = Math.max(0, lines.length - 40);
            StringBuilder sb = new StringBuilder();
            for (int i = start; i < lines.length; i++) {
                if (i > start) sb.append('\n');
                sb.append(lines[i]);
            }
            java.io.File f = new java.io.File(getFilesDir(), "rootfs/alpine/etc/aetherix/term.context");
            if (f.getParentFile() != null) f.getParentFile().mkdirs();
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(sb.toString().getBytes("UTF-8"));
            fos.close();
        } catch (Exception ignored) {}
    }

    private int[] readSavedSize() {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "rootfs/alpine/tmp/term_size");
            if (f.exists()) {
                String content = new String(java.nio.file.Files.readAllBytes(f.toPath())).trim();
                String[] parts = content.split("\\s+");
                if (parts.length >= 2) {
                    int c = Integer.parseInt(parts[0]);
                    int r = Integer.parseInt(parts[1]);
                    if (c >= 4 && c < 10000 && r >= 4 && r < 10000) return new int[]{c, r};
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void startShell() {
        BridgeLogBuffer.append("startShell: entered");
        // FB-033: remember the terminal was active so a full process kill
        // (e.g. Samsung Device Care "Clean Now") can be recovered on relaunch.
        getSharedPreferences("aetherix_setup", MODE_PRIVATE).edit()
            .putBoolean("terminal_was_active", true).apply();
        float fw = terminalView.getFontWidth();
        int fls = terminalView.getFontLineSpacing();
        int flsa = terminalView.getFontLineSpacingAndAscent();
        // 15k: use the exact same formula and clamps as TerminalView.updateSize() so
        // the session's initial grid always matches what the view computes. Two
        // independent size computations (constructor vs attachSession) previously
        // disagreed (e.g. 79 vs 85 rows), which rewrote term_size twice and sent
        // back-to-back SIGWINCH signals to the shell on every start.
        int initCols = Math.max(4, Math.min(500, (int) (terminalView.getWidth() / fw)));
        int initRows = Math.max(4, Math.min(300, (terminalView.getHeight() - flsa) / fls));
        if (terminalView.getWidth() == 0 || terminalView.getHeight() == 0 || fw < 4 || fls < 12) {
            int[] saved = readSavedSize();
            if (saved != null) {
                initCols = saved[0];
                initRows = saved[1];
            } else {
                initCols = 80;
                initRows = 24;
            }
        }
        final int fCols = initCols;
        final int fRows = initRows;
        BridgeLogBuffer.append("startShell: cols=" + fCols + " rows=" + fRows);

        new Thread(() -> {
            try {
                StepRunner.ensureLauncher(this);
                // 15q: remove any residual 15i-era WINCH debug trap from the live
                // rootfs .bashrc on every launch (not just fresh installs).
                StepRunner.sanitizeRootBashrc(this);
                StorageTier.deploy(this);
                File launcher = new File(getFilesDir(), "proot/proot-launch.sh");
                if (!launcher.exists()) {
                    BridgeLogBuffer.append("startShell: LAUNCHER NOT FOUND at " + launcher.getAbsolutePath());
                    android.util.Log.e("Terminal", "Launcher not found");
                    return;
                }
                BridgeLogBuffer.append("startShell: launcher found at " + launcher.getAbsolutePath());

                ensureLauncherEnvVars(launcher);
                BridgeLogBuffer.append("startShell: ensureLauncherEnvVars done");

                Runtime.getRuntime().exec(new String[]{
                    "/system/bin/sh", "-c",
                    "kill $(pgrep -f libproot.so) 2>/dev/null; " +
                    "kill $(pgrep -f proot-launch) 2>/dev/null; " +
                    "kill $(pgrep -f alpine/bin/sh) 2>/dev/null; " +
                    "kill $(pgrep -f libpty-bridge.so) 2>/dev/null; true"
                }).waitFor();
                BridgeLogBuffer.append("startShell: old proot processes killed");

                BridgeLogBuffer.append("startShell: creating TerminalSession with /system/bin/sh " +
                    launcher.getAbsolutePath() + " bash --login");
                session = new TerminalSession(this, terminalView, fCols, fRows,
                    (int) terminalView.getFontWidth(), terminalView.getFontLineSpacing(), this,
                    new String[]{"/system/bin/sh", launcher.getAbsolutePath(), "bash", "--login"});
                BridgeLogBuffer.append("startShell: TerminalSession created, running=" + session.isRunning());

                runOnUiThread(() -> {
                    BridgeLogBuffer.append("startShell: UI callback running, isRunning=" +
                        session.isRunning() + " hasEmulator=" + (session.getEmulator() != null));
                    if (session.isRunning() && session.getEmulator() != null) {
                        terminalView.attachSession(session);
                        TerminalSessionManager.getInstance().setSession(session, sessionStartTime);
                        TerminalService.setOnline(true);
                        TerminalService.setSessionStartTime(sessionStartTime);
                        Watchdog.markRunning(TerminalActivity.this);
                        Intent statusIntent = new Intent(TerminalActivity.this, TerminalService.class);
                        statusIntent.putExtra("online", true);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(statusIntent);
                        } else {
                            startService(statusIntent);
                        }
                        BridgeLogBuffer.append("startShell: session attached to terminalView and registered in manager");
                        // 15k: show the keyboard once when a fresh shell starts so the user
                        // can type immediately. Restore-on-resume is handled in onResume().
                        terminalView.postDelayed(() -> {
                            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            if (imm != null) {
                                imm.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT);
                            }
                        }, 400);
                    }
                });

            } catch (Exception e) {
                BridgeLogBuffer.append("startShell: Exception: " + e.getMessage());
                android.util.Log.e("Terminal", "startShell failed", e);
            } catch (Error e) {
                BridgeLogBuffer.append("startShell: Error: " + e.getMessage());
                android.util.Log.e("Terminal", "startShell failed (Error)", e);
            }
        }).start();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event, TerminalSession s) {
        return false;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent e) {
        return false;
    }

    @Override
    public boolean onCodePoint(int codePoint, boolean ctrlDown, TerminalSession s) {
        return false;
    }

    @Override
    public float onScale(float scale) {
        return scale;
    }

    @Override
    public void onSingleTapUp(MotionEvent e) {
        terminalView.requestFocus();
        terminalView.postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT);
            }
        }, 300);
    }

    @Override
    public boolean shouldBackButtonBeMappedToEscape() {
        return true;
    }

    @Override
    public boolean shouldEnforceCharBasedInput() {
        return false;
    }

    @Override
    public boolean shouldUseCtrlSpaceWorkaround() {
        return false;
    }

    @Override
    public boolean isTerminalViewSelected() {
        return true;
    }

    @Override
    public void copyModeChanged(boolean copyMode) {}

    @Override
    public boolean onLongPress(MotionEvent event) {
        return false;
    }

    @Override
    public boolean readControlKey() {
        return extraKeysView != null && extraKeysView.readSpecialButton(ExtraKeysView.SpecialButton.CTRL);
    }

    @Override
    public boolean readAltKey() {
        return extraKeysView != null && extraKeysView.readSpecialButton(ExtraKeysView.SpecialButton.ALT);
    }

    @Override
    public boolean readShiftKey() {
        return false;
    }

    @Override
    public boolean readFnKey() {
        return extraKeysView != null && extraKeysView.readSpecialButton(ExtraKeysView.SpecialButton.FN);
    }

    @Override
    public void onEmulatorSet() {
        // v0.4.2 (FB-104): refresh the terminal snapshot after a settled
        // resize so the llm tier's context stays current.
        writeTermContext();
    }

    @Override
    public void logError(String tag, String message) {
        android.util.Log.e(tag, message);
    }

    @Override
    public void logWarn(String tag, String message) {
        android.util.Log.w(tag, message);
    }

    @Override
    public void logInfo(String tag, String message) {
        android.util.Log.i(tag, message);
    }

    @Override
    public void logDebug(String tag, String message) {
        android.util.Log.d(tag, message);
    }

    @Override
    public void logVerbose(String tag, String message) {
        android.util.Log.v(tag, message);
    }

    @Override
    public void logStackTraceWithMessage(String tag, String message, Exception e) {
        android.util.Log.e(tag, message, e);
    }

    @Override
    public void logStackTrace(String tag, Exception e) {
        android.util.Log.e(tag, "stack", e);
    }

    @Override
    public void onBackPressed() {
        if (session != null) {
            session.write("exit\n");
        }
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogBuffer.getInstance().append("Terminal: session resumed");
        // FB-076: the wake lock is owned by the foreground service for the
        // whole session lifetime - the activity must not acquire/release it.
        if (session != null) {
            // FB-0148: a toolbar Clear up to 60s ago is re-applied now - bytes
            // that arrived after the Clear (e.g. a still-running background
            // build log) must not resurrect the cleared scrollback.
            if (lastClearMs != 0 && System.currentTimeMillis() - lastClearMs < 60000
                    && session.getEmulator() != null) {
                session.getEmulator().clearScrollback();
                session.markCleared();
                if (terminalView != null) terminalView.postInvalidate();
            }
            if (!session.isRunning()) {
                TerminalService.setOnline(false);
                Intent statusIntent = new Intent(this, TerminalService.class);
                statusIntent.putExtra("online", false);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(statusIntent);
                } else {
                    startService(statusIntent);
                }
            }
            // 15k: after returning to the activity the view can show a stale frame (e.g.
            // after `clear` + app switch) and the IME may not re-attach, dropping the first
            // typed character. Redraw + refocus, but only restore the IME if it was actually
            // open before the pause. Unconditionally re-showing it on every resume fed a
            // show/hide cycle that, combined with resize churn, caused white-outs and
            // invisible prompt text while typing.
            terminalView.requestFocus();
            terminalView.invalidate();
            if (terminalView.isImeVisible()) {
                terminalView.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT);
                    }
                }, 300);
            }
            // v0.4.2 (FB-104): refresh the terminal snapshot the llm tier
            // injects (last ~40 visible lines -> rootfs etc/aetherix/term.context).
            writeTermContext();
        }
    }

    @Override
    protected void onDestroy() {
        stopTimer();
        stopSpinnerAnimation();
        stopBuildProgressPolling();
        stopReplyPolling();
        stopAppRequestPolling();
        super.onDestroy();
    }

    /** v0.4.7: a category bar tap writes the dropdown request into the pty;
     *  aetherix-menu runs inside Alpine and renders the CRT menu. */
    private void openMenu(String cat) {
        if (session != null) {
            session.write("aetherix-menu " + cat + "\n");
            terminalView.requestFocus();
            terminalView.postDelayed(() -> {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(terminalView.getWindowToken(), 0);
            }, 100);
        }
    }

    /** v0.4.7: copy the full scrollback transcript to the clipboard (System
     *  menu -> Copy terminal screen, via the app.request channel). */
    private void copySessionText() {
        if (session == null || session.getEmulator() == null) return;
        int cols = session.getEmulator().mColumns;
        int rows = session.getEmulator().mRows;
        String allText = session.getEmulator().getScreen().getSelectedText(
            0, -session.getEmulator().getScreen().getActiveTranscriptRows(), cols, rows);
        if (allText != null && !allText.isEmpty()) {
            String[] lines = allText.split("\n", -1);
            int start = 0, end = lines.length;
            while (start < end && lines[start].trim().isEmpty()) start++;
            while (end > start && lines[end - 1].trim().isEmpty()) end--;
            StringBuilder sb = new StringBuilder();
            for (int i = start; i < end; i++) {
                if (i > start) sb.append('\n');
                sb.append(lines[i]);
            }
            String trimmed = sb.toString();
            if (!trimmed.isEmpty()) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("terminal", trimmed));
                }
            }
        }
    }

    /** v0.4.7: clear visible screen + scrollback (System menu -> Clear). */
    private void clearSessionText() {
        if (session != null && session.getEmulator() != null) {
            lastClearMs = System.currentTimeMillis();
            session.getEmulator().clearScrollback();
            session.markCleared();
            if (terminalView != null) terminalView.postInvalidate();
            session.captureScreenSnapshot(true);
        }
    }

    /** v0.4.7: the System menu writes /etc/aetherix/app.request (close|exit|
     *  copy|clear); this poller maps those onto the same actions the old
     *  toolbar buttons performed. */
    private void startAppRequestPolling() {
        if (appRequestHandler != null) return;
        appRequestHandler = new Handler(Looper.getMainLooper());
        appRequestRunnable = new Runnable() {
            @Override
            public void run() {
                handleAppRequest();
                if (appRequestHandler != null) appRequestHandler.postDelayed(this, 1000);
            }
        };
        appRequestHandler.postDelayed(appRequestRunnable, 1000);
    }

    private void stopAppRequestPolling() {
        if (appRequestHandler != null) {
            if (appRequestRunnable != null) appRequestHandler.removeCallbacks(appRequestRunnable);
            appRequestHandler = null;
            appRequestRunnable = null;
        }
    }

    private void handleAppRequest() {
        try {
            File req = new File(getFilesDir(), "rootfs/alpine/etc/aetherix/app.request");
            if (!req.isFile()) return;
            String want = new String(java.nio.file.Files.readAllBytes(req.toPath()), "UTF-8").trim();
            req.delete();
            if (want.equals("close")) closeSession();
            else if (want.equals("exit")) exitSession();
            else if (want.equals("copy")) copySessionText();
            else if (want.equals("clear")) clearSessionText();
        } catch (Exception ignored) {}
    }

    /** v0.4.7: category bar status dot - green = AI server up, amber = build
     *  running, dim = idle. */
    private void updateStatusDot() {
        if (statusDot == null) return;
        int color = 0xFF4a4a44;
        try {
            File rootfs = new File(getFilesDir(), "rootfs/alpine");
            File st = new File(rootfs, "etc/aetherix/llm.state");
            if (st.isFile()) {
                String s = new String(java.nio.file.Files.readAllBytes(st.toPath()), "UTF-8").trim();
                if (s.equals("running")) color = 0xff00ff41;
            }
            File bst = new File(rootfs, "etc/aetherix/llm.build.state");
            if (bst.isFile()) {
                String s = new String(java.nio.file.Files.readAllBytes(bst.toPath()), "UTF-8").trim();
                if (s.equals("building")) color = 0xffffb000;
            }
        } catch (Exception ignored) {}
        statusDot.setTextColor(color);
    }

    /** v0.3a.14_1: uniform 4dp margins between toolbar buttons (FB-042). */
    private LinearLayout.LayoutParams toolbarButtonParams() {
        int m = (int) (4 * getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(m, 0, m, 0);
        return p;
    }

    private void ensureLauncherEnvVars(File launcher) {
        try {
            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(launcher));
            String line;
            while ((line = reader.readLine()) != null) lines.add(line);
            reader.close();

            boolean hasHome = false, hasTerm = false, hasAetherix = false, hasIo = false;
            int exportEndIdx = -1;
            for (int i = 0; i < lines.size(); i++) {
                String l = lines.get(i);
                if (l.startsWith("export ")) exportEndIdx = i;
                if (l.contains("HOME=/root")) hasHome = true;
                if (l.contains("TERM=xterm-256color")) hasTerm = true;
                if (l.contains("AETHERIX_VERSION=")) hasAetherix = true;
                if (l.contains("AETHERIX_INPUT_DIR=")) hasIo = true;
            }

            String versionName = "unknown";
            String androidVer = "unknown";
            try {
                versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
                androidVer = android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")";
            } catch (Exception ignored) {}

            int insertAt = exportEndIdx >= 0 ? exportEndIdx + 1 : 2;
            boolean dirty = false;

            if (!hasHome) {
                lines.add(insertAt++, "export HOME=/root");
                dirty = true;
            }
            if (!hasTerm) {
                lines.add(insertAt++, "export TERM=xterm-256color");
                dirty = true;
            }
            if (!hasAetherix) {
                lines.add(insertAt++, "export AETHERIX_VERSION=" + versionName);
                lines.add(insertAt++, "export ANDROID_VERSION=\"" + androidVer + "\"");
                dirty = true;
            }
            if (!hasIo) {
                lines.add(insertAt++, "export AETHERIX_INPUT_DIR=/root/storage/input");
                lines.add(insertAt++, "export AETHERIX_OUTPUT_DIR=/root/storage/output");
                dirty = true;
            }

            if (dirty) {
                StringBuilder sb = new StringBuilder();
                for (String l : lines) sb.append(l).append('\n');
                java.io.FileOutputStream fos = new java.io.FileOutputStream(launcher);
                fos.write(sb.toString().getBytes());
                fos.close();
            }
        } catch (Exception e) {
            android.util.Log.e("Terminal", "ensureLauncherEnvVars failed", e);
        }
    }
}
