package com.aetherix.alpine.a;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 16a: filesystem-backed watchdog that survives process death. A foreground
 * session periodically stamps a heartbeat into SharedPreferences (file-backed,
 * so it persists across an Android/system kill). On the next Activity resume we
 * read the persisted state to distinguish "clean Session" from "process was
 * killed by the system (OOM/phantom)" and then reset it for the next session.
 */
public final class Watchdog {

    private static final String PREFS = "aetherix_prefs";
    private static final String KEY_MODE = "watchdog_mode";
    private static final String KEY_HEARTBEAT = "watchdog_heartbeat";
    private static final String KEY_EXIT = "watchdog_exit";

    private static final String MODE_IDLE = "idle";
    private static final String MODE_RUNNING = "running";
    private static final String MODE_CLEAN = "clean";
    private static final String MODE_DEAD = "dead";

    /** Session considered stale (likely killed) when the last beat is older than this. */
    public static final long TTL_MS = 60000L;
    /** How often a live session re-stamps the heartbeat (also the minimal write cadence). */
    public static final long HEARTBEAT_MS = 15000L;

    private Watchdog() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** A live session started (or is being re-attached): record running + first beat. */
    public static void markRunning(Context c) {
        if (c == null) return;
        prefs(c).edit()
                .putString(KEY_MODE, MODE_RUNNING)
                .putLong(KEY_HEARTBEAT, System.currentTimeMillis())
                .putInt(KEY_EXIT, -1)
                .apply();
    }

    /** Called from the 1s service timer; only re-stamps at most every HEARTBEAT_MS. */
    public static void beat(Context c) {
        if (c == null) return;
        SharedPreferences p = prefs(c);
        if (!MODE_RUNNING.equals(p.getString(KEY_MODE, MODE_IDLE))) return;
        long hb = p.getLong(KEY_HEARTBEAT, 0L);
        if (hb == 0L || System.currentTimeMillis() - hb >= HEARTBEAT_MS) {
            p.edit().putLong(KEY_HEARTBEAT, System.currentTimeMillis()).apply();
        }
    }

    /** A clean, user-initiated teardown completed (the Exit button path / clean shell EOF). */
    public static void markClean(Context c) {
        if (c == null) return;
        prefs(c).edit()
                .putString(KEY_MODE, MODE_CLEAN)
                .putInt(KEY_EXIT, 0)
                .apply();
    }

    /** The PTY reported a hard, non-clean exit code. */
    public static void markDead(Context c, int exitCode) {
        if (c == null) return;
        prefs(c).edit()
                .putString(KEY_MODE, MODE_DEAD)
                .putInt(KEY_EXIT, exitCode)
                .apply();
    }

    /**
     * Inspect the persisted state to decide whether the previous terminal session
     * was killed by the system, then reset the persisted state for a fresh session.
     * Returns a human-readable description of the kill (or a stale heartbeat), or
     * null when the previous session ended cleanly / first launch.
     */
    public static String detectAndReset(Context c) {
        if (c == null) return null;
        SharedPreferences p = prefs(c);
        String mode = p.getString(KEY_MODE, MODE_IDLE);
        long hb = p.getLong(KEY_HEARTBEAT, 0L);
        int exit = p.getInt(KEY_EXIT, -1);
        p.edit().putString(KEY_MODE, MODE_IDLE).putInt(KEY_EXIT, -1).apply();

        if (MODE_DEAD.equals(mode)) {
            return "previous terminal session was killed by the system" +
                    (exit > 0 ? " (exit code " + exit + ")" : "") +
                    " while running in the background. Unsaved work is lost.";
        }
        if (MODE_RUNNING.equals(mode) && hb > 0L) {
            long stale = System.currentTimeMillis() - hb;
            if (stale > TTL_MS) {
                long mins = Math.max(1, stale / 60000);
                return "previous terminal session appears to have been killed by the system " +
                        "(no heartbeat for about " + mins + " min). Unsaved work is lost.";
            }
        }
        return null;
    }
}
