package com.aetherix.alpine.a;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

public class TerminalService extends Service {

    private static final String CHANNEL_ID = "terminal_foreground";
    private static final int NOTIFICATION_ID = 1;

    private static boolean sOnline = false;
    private static long sSessionStartTime;
    // FB-053: long guest jobs (llama.cpp builds) were killed by the screen-off
    // CPU freeze. Hold a partial wakelock exactly while a session is online
    // (terminal active or running in background) and drop it the moment the
    // session dies, so we never drain the battery after a shell exits.
    private static PowerManager.WakeLock sWakeLock = null;
    // FB-076: full-system wake lock - SCREEN_DIM_WAKE_LOCK keeps the whole
    // device (CPU + screen, dimmed) awake for the lifetime of the foreground
    // service + notification: while a terminal session is online (open,
    // backgrounded via Close-to-dashboard, or mid-build), released only when
    // the session exits or the service is destroyed. The PARTIAL wake lock
    // above is the CPU-only half; SCREEN_DIM is the full-system half.
    private static PowerManager.WakeLock sFullWakeLock = null;
    private static Context sAppContext = null;
    private NotificationManager mNotifManager;
    private Handler mTimerHandler;
    private final Runnable mTimerRunnable = new Runnable() {
        @Override
        public void run() {
            // 16a: heartbeat the filesystem watchdog while a session is expected to be alive.
            Watchdog.beat(TerminalService.this);
            if (mNotifManager != null && sOnline) {
                mNotifManager.notify(NOTIFICATION_ID, buildNotification());
            }
            mTimerHandler.postDelayed(this, 1000);
        }
    };

    public static void setOnline(boolean online) {
        sOnline = online;
        if (sAppContext != null) {
            if (online) {
                // FB-076: a live session keeps the whole device awake - CPU
                // (partial) plus screen-dim (full system) - until Exit.
                acquireSessionWakeLock(sAppContext);
                acquireFullSystemWakeLock(sAppContext);
            } else {
                releaseSessionWakeLock();
                releaseFullSystemWakeLock();
            }
        }
    }

    public static synchronized void acquireSessionWakeLock(Context ctx) {
        if (sWakeLock != null && sWakeLock.isHeld()) return;
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        if (pm == null) return;
        sWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aetherix:terminal-active");
        sWakeLock.setReferenceCounted(false);
        sWakeLock.acquire();
    }

    public static synchronized void releaseSessionWakeLock() {
        if (sWakeLock != null) {
            if (sWakeLock.isHeld()) sWakeLock.release();
            sWakeLock = null;
        }
    }

    /** Full-system wake lock: keep the whole device awake (screen dimmed) for
     *  the session lifetime. Acquired together with the partial lock whenever
     *  the foreground service marks a session online, released on exit or
     *  service destroy - nothing in the terminal life cycle overrides this. */
    public static synchronized void acquireFullSystemWakeLock(Context ctx) {
        if (sFullWakeLock != null && sFullWakeLock.isHeld()) return;
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        if (pm == null) return;
        sFullWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "aetherix:full-screen");
        sFullWakeLock.setReferenceCounted(false);
        sFullWakeLock.acquire();
    }

    public static synchronized void releaseFullSystemWakeLock() {
        if (sFullWakeLock != null) {
            if (sFullWakeLock.isHeld()) sFullWakeLock.release();
            sFullWakeLock = null;
        }
    }

    private static void syncWakeLock(Context ctx) {
        if (sOnline) {
            acquireSessionWakeLock(ctx);
            acquireFullSystemWakeLock(ctx);
        } else {
            releaseSessionWakeLock();
            releaseFullSystemWakeLock();
        }
    }

    public static void setSessionStartTime(long time) {
        sSessionStartTime = time;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mNotifManager = getSystemService(NotificationManager.class);
        sAppContext = getApplicationContext();
        syncWakeLock(sAppContext);
        createNotificationChannel();
        mTimerHandler = new Handler(Looper.getMainLooper());
        mTimerHandler.post(mTimerRunnable);
        try {
            startForeground(NOTIFICATION_ID, buildNotification());
        } catch (Exception e) {
            android.util.Log.e("TerminalService", "startForeground failed", e);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("online")) {
            sOnline = intent.getBooleanExtra("online", false);
            syncWakeLock(sAppContext);
            if (mNotifManager != null) {
                mNotifManager.notify(NOTIFICATION_ID, buildNotification());
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (mTimerHandler != null) {
            mTimerHandler.removeCallbacks(mTimerRunnable);
        }
        releaseSessionWakeLock();
        releaseFullSystemWakeLock();
        sAppContext = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID,
            "Terminal Session",
            NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Keeps the terminal session alive in the background");
        if (mNotifManager != null) mNotifManager.createNotificationChannel(channel);
    }

    /** Open the app to its current state: terminal if a session is active, else dashboard. */
    private PendingIntent buildContentIntent() {
        Intent intent;
        if (TerminalSessionManager.getInstance().isSessionActive()) {
            intent = new Intent(this, TerminalActivity.class);
        } else {
            intent = new Intent(this, MainActivity.class);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
            | Intent.FLAG_ACTIVITY_SINGLE_TOP
            | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(this, 0, intent, flags);
    }

    private Notification buildNotification() {
        String statusText;
        int color;
        if (sOnline) {
            long elapsed = System.currentTimeMillis() - sSessionStartTime;
            long secs = elapsed / 1000;
            long mins = secs / 60;
            long hours = mins / 60;
            String duration = hours > 0
                ? String.format("%d:%02d:%02d", hours, mins % 60, secs % 60)
                : String.format("%d:%02d", mins, secs % 60);
            statusText = "\u25CF Online — " + duration;
            color = 0xFF00FF00;
        } else {
            statusText = "\u25CB Offline";
            color = 0xFFFF0000;
        }

        return new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Aetherix-Alpine")
            .setContentText(statusText + " — tap to open")
            .setContentIntent(buildContentIntent())
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setColor(color)
            .setOngoing(true)
            .build();
    }
}
