package com.aetherix.alpine.a.terminal;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.aetherix.alpine.a.BridgeLogBuffer;
import com.aetherix.alpine.a.PtySession;
import java.io.File;
import java.nio.charset.StandardCharsets;

public class TerminalSession extends TerminalOutput implements PtySession.OutputCallback {

    private Context context;
    private PtySession pty;
    private TerminalEmulator emulator;
    private TerminalViewClient viewClient;
    private TerminalView terminalView;
    private boolean running;
    private String title;
    private long inputBlockedUntil;
    // 15r: diagnostic - log app->pty writes for a short window after each resize.
    private long inputLogUntil = 0;
    // 15u: diagnostic - throttle for capturing the visible screen into the report.
    private long lastSnapshotMs = 0;
    // 15v: diagnostic - time of the last app->pty write, so we can capture the
    // echo bytes that come BACK into the emulator right after a keystroke. This is
    // the only remaining unlogged boundary and it decides whether the leading ":"
    // in ":ano" is written by bash/readline (echo stream) or conjured by the
    // emulator (stale-cell / dropped first echoed byte).
    private long lastPtyWriteMs = 0;
    // 15w: when a size change reaches a readline shell, bash defers its prompt
    // redraw until the *next* read and swallows that first character, emitting a
    // stray ":" (proven by 15v ECHO_IN). We force the redraw to complete early
    // with a no-op space+del, so the real first keystroke is no longer eaten.
    private Handler warmUpHandler;
    private Runnable warmUpRunnable;
    // 15x: FB-036 - a warmup prime is scheduled but has not fired yet. User
    // input that arrives while the pty-bridge is still buffering stdin during a
    // resize settle is invisible to the guard's idle check (lastPtyWriteMs),
    // so we cancel the scheduled SPACE+DEL here instead, closing the race.
    private boolean warmUpPending;
    // FB-051: terminal spinner watchdog. lastOutputMs is touched on every byte
    // the pty emits; commandPending is set when the user submits a line (CR/LF)
    // and cleared when the shell repaints a fresh prompt, so the UI can show an
    // activity spinner only while a command is running with no output. Pure
    // read-only state: the spinner never writes into the pty, so Copy All /
    // Clear All / scrollback stay byte-for-byte clean.
    private volatile long lastOutputMs = 0;
    private volatile boolean commandPending = false;

    public TerminalSession(Context context, TerminalView view, int columns, int rows,
                           int cellWidth, int cellHeight,
                           TerminalViewClient client, String[] command) {
        this.context = context;
        this.terminalView = view;
        this.viewClient = client;

        emulator = new TerminalEmulator(this, columns, rows, cellWidth, cellHeight, null,
            new TerminalSessionClient() {
                public Integer getTerminalCursorStyle() { return null; }
                public void onTerminalCursorStateChange(boolean state) {}
                public void logError(String tag, String msg) { android.util.Log.e(tag, msg); }
                public void logWarn(String tag, String msg) { android.util.Log.w(tag, msg); }
                public void logInfo(String tag, String msg) { android.util.Log.i(tag, msg); }
                public void logDebug(String tag, String msg) { android.util.Log.d(tag, msg); }
                public void logVerbose(String tag, String msg) { android.util.Log.v(tag, msg); }
                public void logStackTraceWithMessage(String tag, String msg, Exception e) {
                    android.util.Log.e(tag, msg, e);
                }
                public void logStackTrace(String tag, Exception e) {
                    android.util.Log.e(tag, "stack", e);
                }
            });

        PtySession.writeTermSizeFile(context, rows, columns);
        BridgeLogBuffer.append("TerminalSession: term_size file written before pty.start");
        pty = new PtySession();
        BridgeLogBuffer.append("TerminalSession: calling pty.start, rows=" + rows + " cols=" + columns);
        running = pty.start(context, command, this, rows, columns);
        BridgeLogBuffer.append("TerminalSession: pty.start returned running=" + running);
        if (running) {
            pty.setWindowSize(rows, columns);
            BridgeLogBuffer.append("TerminalSession: initial window size set");
        } else {
            BridgeLogBuffer.append("TerminalSession: PTY not running, will not set window size");
        }
    }

    public TerminalEmulator getEmulator() {
        return emulator;
    }

    public boolean isRunning() {
        return running;
    }

    public void blockInputFor(long delayMs) {
        inputBlockedUntil = System.currentTimeMillis() + delayMs;
    }

    private long nowMs() {
        return System.currentTimeMillis();
    }

    @Override
    public void write(byte[] data, int offset, int count) {
        if (inputBlockedUntil > 0 && nowMs() < inputBlockedUntil) return;
        if (count > 0 && hasLineFeed(data, offset, count)) {
            // A submitted line means the shell is (or is about to be) busy.
            commandPending = true;
        }
        if (warmUpPending) {
            // Real keystroke beats the scheduled prime: cancel it so the DEL
            // can never consume the first typed character.
            warmUpPending = false;
            if (warmUpRunnable != null) {
                if (warmUpHandler != null) warmUpHandler.removeCallbacks(warmUpRunnable);
                warmUpRunnable = null;
            }
            BridgeLogBuffer.append("WARMUP: cancelled by user input");
        }
        if (nowMs() < inputLogUntil) {
            BridgeLogBuffer.append("INPUT " + count + "B: " + bytesToPrintable(data, offset, count));
        }
        if (pty != null) {
            byte[] chunk = new byte[count];
            System.arraycopy(data, offset, chunk, 0, count);
            pty.write(chunk);
            lastPtyWriteMs = nowMs();
        }
    }
    /** 15r: render raw input bytes for the error report (printable, capped). */
    private static String bytesToPrintable(byte[] data, int offset, int count) {
        StringBuilder sb = new StringBuilder();
        int cap = Math.min(count, 32);
        for (int i = 0; i < cap; i++) {
            int b = data[offset + i] & 0xff;
            if (b == 0x1b) sb.append("\\e");
            else if (b == '\r') sb.append("\\r");
            else if (b == '\n') sb.append("\\n");
            else if (b == '\t') sb.append("\\t");
            else if (b >= 0x20 && b <= 0x7e) sb.append((char) b);
            else sb.append(String.format("\\x%02x", b));
        }
        if (count > cap) sb.append("...");
        return sb.toString();
    }

    @Override
    public void titleChanged(String oldTitle, String newTitle) {
        this.title = newTitle;
    }

    @Override
    public void onCopyTextToClipboard(String text) {
        if (context == null || text == null) return;
        ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("terminal", text));
        }
    }

    @Override
    public void onPasteTextFromClipboard() {
        if (inputBlockedUntil > 0 && System.currentTimeMillis() < inputBlockedUntil) return;
        if (context == null || pty == null) return;
        ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip()) {
            ClipData.Item item = cm.getPrimaryClip().getItemAt(0);
            CharSequence paste = item.getText();
            if (paste != null) {
                byte[] b = paste.toString().getBytes(StandardCharsets.UTF_8);
                if (hasLineFeed(b, 0, b.length)) commandPending = true;
                pty.write(b);
            }
        }
    }

    @Override
    public void onBell() {}

    @Override
    public void onColorsChanged() {}

    public void writeCodePoint(boolean alt, int codePoint) {
        String s = new String(Character.toChars(codePoint));
        if (alt) s = "\u001b" + s;
        write(s);
    }

    public void setTerminalView(TerminalView view) {
        this.terminalView = view;
    }

    /**
     * 15w: after a size change settles, warm up bash/readline so its deferred
     * SIGWINCH redraw has already run by the time the user types. We send the
     * byte pair SPACE then DEL: readline's SPACE inserts a blank (running the
     * redraw) and DEL removes it, leaving the command line byte-for-byte
     * unchanged. Heavily guarded so we never inject into a full-screen app
     * (nano/vim alt-screen) or into a job that is mid-keystroke.
     */
    public void warmUpReadline(long delayMs) {
        if (pty == null) return;
        if (emulator != null && emulator.isAlternateBufferActive()) {
            // alt-screen (nano/vim): leave their input line untouched.
            BridgeLogBuffer.append("WARMUP: skip (alt-screen active)");
            return;
        }
        if (warmUpHandler == null) {
            warmUpHandler = new Handler(Looper.getMainLooper());
        }
        if (warmUpRunnable != null) {
            warmUpHandler.removeCallbacks(warmUpRunnable);
        }
        warmUpPending = true;
        Runnable r = () -> {
            warmUpRunnable = null;
            warmUpPending = false;
            if (!running || pty == null) return;
            if (emulator != null && emulator.isAlternateBufferActive()) return;
            // If the user has already typed since we scheduled this, don't inject.
            if (lastPtyWriteMs != 0 && (nowMs() - lastPtyWriteMs) < 400) return;
            // BUG-014: never prime a non-empty command line — the deferred
            // WINCH redraw swallows the SPACE, and the DEL backspaces the
            // user's last typed character.
            int beforeLen;
            try {
                int row = emulator.getCursorRow();
                String line = emulator.getScreen().getSelectedText(0, row, emulator.mColumns, row + 1);
                if (TerminalPromptGuard.hasTypedContent(line)) {
                    BridgeLogBuffer.append("WARMUP: skip (command line non-empty)");
                    return;
                }
                beforeLen = (line == null) ? -1 : line.length();
            } catch (Exception e) {
                return;
            }
            // FB-067: two-phase warmup. Send SPACE on its own; readline eats it
            // if its SIGWINCH redraw was deferred. Re-read the line a moment
            // later and send DEL only when the sole visible addition is our
            // injected space (length +1). DEL therefore can never erase a
            // character the user typed in the gap, removing the last
            // "first digit eaten" flip that the blind space+del burst allowed.
            if (beforeLen < 0) return;
            final long sentAt = nowMs();
            pty.write(new byte[]{(byte) 0x20});
            // FB-0148: poll for the injected SPACE. bash can paint it LATE
            // (deferred SIGWINCH redraw), so a single 40ms read can wrongly
            // conclude "consumed" and leave a ghost blank that later appears
            // on the prompt line. Check up to 3x (40/100/160ms) and DEL only
            // when our space is the sole visible addition; abort the instant a
            // user keystroke lands so we never erase typed input (FB-067).
            final boolean[] done = {false};
            final long[] userAt = {0};
            for (int i = 0; i < 3; i++) {
                final int attempt = i;
                final long at = 40L + 60L * i;
                warmUpHandler.postDelayed(() -> {
                    if (!running || pty == null || done[0] || userAt[0] != 0L) return;
                    if (lastPtyWriteMs != 0 && lastPtyWriteMs > sentAt) {
                        userAt[0] = lastPtyWriteMs; // user typed: hands off
                        return;
                    }
                    try {
                        int row = emulator.getCursorRow();
                        String line = emulator.getScreen().getSelectedText(0, row, emulator.mColumns, row + 1);
                        if (line != null && line.length() == beforeLen + 1) {
                            done[0] = true;
                            pty.write(new byte[]{(byte) 0x7f});
                            BridgeLogBuffer.append("WARMUP: injected space reverted with DEL");
                            return;
                        }
                        if (attempt == 2) {
                            // Never visible across all polls: readline consumed it.
                            BridgeLogBuffer.append("WARMUP: readline consumed SPACE - user input untouched");
                        }
                    } catch (Exception ignored) {
                    }
                }, at);
            }
        };
        warmUpRunnable = r;
        warmUpHandler.postDelayed(r, delayMs);
    }

    /** FB-051: true while a submitted command has produced no output for 2s. */
    public boolean shouldShowSpinner() {
        if (!commandPending || lastOutputMs == 0) return false;
        return (System.currentTimeMillis() - lastOutputMs) >= 2000;
    }

    /** FB-051: the shell repainted a fresh prompt; the command is done. */
    public void notePromptSeen() {
        commandPending = false;
    }

    /** FB-0148: toolbar Clear - nothing is expected from the shell, so the
     *  activity spinner must not spin over a blank screen. */
    public void markCleared() {
        commandPending = false;
        lastOutputMs = System.currentTimeMillis();
    }

    /** FB-0148: called on every pty output. Once the emulator shows a fresh
     *  prompt at rest (only whitespace after the #/$), the submitted command
     *  is over - clear commandPending so the spinner never lingers at idle.
     *  This fixes the "random spinner": the prompt repaint arrives as output,
     *  so it is caught here immediately instead of after the 2s idle window
     *  the tick-based UI check had to wait for. */
    private void detectFreshPrompt() {
        if (!commandPending) return;
        try {
            int row = emulator.getCursorRow();
            String line = emulator.getScreen().getSelectedText(0, row, emulator.mColumns, row + 1);
            if (line != null && isPromptAtRest(line)) {
                commandPending = false;
            }
        } catch (Exception ignored) {
        }
    }

    /** True when the visible line is a shell prompt at rest (a # or $ after a
     *  path with only trailing whitespace). Mirrors the UI-side check so the
     *  session and the view always agree. */
    public static boolean isPromptAtRest(String line) {
        if (line == null) return false;
        return line.matches(".*:\\S*[#$]\\s*$");
    }

    private static boolean hasLineFeed(byte[] data, int offset, int count) {
        for (int i = offset; i < offset + count; i++) {
            byte b = data[i];
            if (b == '\r' || b == '\n') return true;
        }
        return false;
    }

    public void destroy() {
        running = false;
        if (pty != null) pty.destroy();
    }

    public void updateSize(int columns, int rows, int cellWidth, int cellHeight) {
        if (emulator != null) {
            emulator.resize(columns, rows, cellWidth, cellHeight);
        }
        if (pty != null) {
            pty.setWindowSize(rows, columns);
        }
        // 15r/15u: open the input-log window so the next keystrokes appear in the
        // error report with their exact bytes (the ":" diagnosis). Widened to 10s
        // in 15u because the first-attempt "nano" starts >2s after the last resize
        // signal (15t: IME commits at 14:39:32-33, last resize 14:39:25) and the
        // bytes were therefore invisible in every report up to 15t.
        inputLogUntil = System.currentTimeMillis() + 10000;
        // 15u: freeze the emulator screen right after the reflow so the report can
        // show which cells the broken prompt actually holds.
        captureScreenSnapshot(true);
        // 15w: let readline's deferred SIGWINCH redraw finish before the user's
        // next keystroke, so the first character is not swallowed (no stray ":").
        warmUpReadline(300);
    }

    public String getTitle() {
        return title;
    }

    // OutputCallback implementation
    @Override
    public void onOutput(String line) {}

    @Override
    public void onOutputBytes(byte[] data, int len) {
        if (emulator != null && len > 0) {
            lastOutputMs = System.currentTimeMillis();
            emulator.append(data, len);
            detectFreshPrompt();
            // 15u: keep the stored screen snapshot current while the shell repaints.
            captureScreenSnapshot(false);
        }
        if (terminalView != null) {
            terminalView.postInvalidate();
        }
    }

    /** 15u: store a text dump of the visible emulator rows + cursor for the report. */
    public void captureScreenSnapshot(boolean force) {
        if (emulator == null) return;
        long now = System.currentTimeMillis();
        if (!force && (now - lastSnapshotMs < 100)) return;
        lastSnapshotMs = now;
        try {
            int cols = emulator.mColumns;
            int rows = emulator.mRows;
            int curCol = emulator.getCursorCol();
            int curRow = emulator.getCursorRow();
            StringBuilder sb = new StringBuilder(rows * 64);
            sb.append("COLS=").append(cols).append(" ROWS=").append(rows)
                .append(" CURSOR=").append(curCol).append(",").append(curRow).append("\n");
            int start = Math.max(0, rows - 40);
            for (int r = start; r < rows; r++) {
                String line = emulator.getScreen().getSelectedText(0, r, cols, r + 1);
                int end = line.length();
                while (end > 0 && line.charAt(end - 1) == ' ') end--;
                line = line.substring(0, end);
                sb.append(String.format("%4d", r)).append("|").append(line).append("\n");
            }
            BridgeLogBuffer.setScreenSnapshot(sb.toString());
        } catch (Exception e) {
            BridgeLogBuffer.setScreenSnapshot("(screen snapshot failed: " + e.toString() + ")");
        }
    }

    @Override
    public void onExit(int exitCode) {
        BridgeLogBuffer.append("TerminalSession.onExit: exitCode=" + exitCode + " finishing in 500ms");
        running = false;
        // 16a: record how the PTY really ended. A clean shell EOF (exit 0) is a
        // normal close; a non-zero exit is flagging the watchdog so the next resume
        // can tell the user the previous session was not cleanly terminated.
        // 143 = SIGTERM: produced by the app's own teardown (Exit button /
        // graceful destroy fallback), never by a system kill that would let this
        // callback run (a real Android kill takes the whole app process). So it
        // is treated as a clean, user-initiated close.
        if (exitCode == 0 || exitCode == 143) {
            com.aetherix.alpine.a.Watchdog.markClean(context);
            if (context != null) {
                context.getSharedPreferences("aetherix_setup",
                    android.content.Context.MODE_PRIVATE).edit()
                    .putBoolean("terminal_was_active", false).apply();
            }
        } else {
            com.aetherix.alpine.a.Watchdog.markDead(context, exitCode);
        }
        if (context != null) {
            com.aetherix.alpine.a.TerminalService.setOnline(false);
            android.content.Intent statusIntent = new android.content.Intent(context, com.aetherix.alpine.a.TerminalService.class);
            statusIntent.putExtra("online", false);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(statusIntent);
            } else {
                context.startService(statusIntent);
            }
        }
        if (context != null && terminalView != null) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                BridgeLogBuffer.append("TerminalSession.onExit: delayed finish executing");
                if (context instanceof Activity && !((Activity) context).isFinishing()) {
                    ((Activity) context).finish();
                }
            }, 500);
        }
    }

    @Override
    public void onError(String msg) {
        BridgeLogBuffer.append("TerminalSession.onError: " + msg);
        running = false;
    }

    @Override
    public void onDebug(String line) {
        Log.d("PTY-Bridge", line);
        BridgeLogBuffer.append(line);
    }
}
