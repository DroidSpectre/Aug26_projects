package com.aetherix.alpine.a;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.StatFs;
import android.telephony.TelephonyManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;

/**
 * v0.3.3+ telemetry tier.
 * Reads real device state — battery / charging / thermal / RAM / storage /
 * app size / CPU / GPU / NPU / network — all via public APIs + sysfs so
 * telemetry never needs a new permission beyond ACCESS_NETWORK_STATE.
 */
public class DevicePayload {

    /** Battery + RAM via Android APIs (API 21+). */
    public static JSONObject readBatteryMemory(Context context) {
        JSONObject obj = new JSONObject();
        try {
            BatteryManager bm =
                (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                obj.put("battery_capacity", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY));
                obj.put("battery_voltage", readBatteryProperty(bm, "BATTERY_PROPERTY_VOLTAGE"));
                obj.put("battery_temperature", readBatteryProperty(bm, "BATTERY_PROPERTY_TEMPERATURE"));
            }
            obj.put("charging", readChargingState(context));
            obj.put("cpuabi", Build.SUPPORTED_ABIS[0]);

            android.app.ActivityManager am = context.getSystemService(android.app.ActivityManager.class);
            android.app.ActivityManager.MemoryInfo memInfo = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(memInfo);
            obj.put("memory_total", memInfo.totalMem);
            obj.put("memory_available", memInfo.availMem);
            obj.put("memory_free", memInfoKb("MemFree"));
            obj.put("memory_cached", memInfoKb("Cached"));
        } catch (Exception ignored) {}
        return obj;
    }

    /**
     * FB-033: /proc/meminfo value in bytes (kb * 1024). Apps can read
     * /proc/meminfo; it is not on Android 16's blocked-proc list. Returns 0
     * when unreadable so the UI can omit the breakdown.
     */
    private static long memInfoKb(String key) {
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                new java.io.FileReader("/proc/meminfo"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(key + ":")) {
                    String[] parts = line.split("\\s+");
                    br.close();
                    if (parts.length >= 2) {
                        try { return Long.parseLong(parts[1]) * 1024L; } catch (Exception e) { return 0L; }
                    }
                    return 0L;
                }
            }
            br.close();
        } catch (Exception ignored) {}
        return 0L;
    }

    private static String readChargingState(Context context) {
        try {
            Intent b = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b == null) return "unknown";
            int status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int plugged = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            if (status == BatteryManager.BATTERY_STATUS_FULL) return "full";
            String plug = "ac";
            if (plugged == BatteryManager.BATTERY_PLUGGED_USB) plug = "usb";
            else if (plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS) plug = "wireless";
            if (status == BatteryManager.BATTERY_STATUS_CHARGING) return "charging_" + plug;
            if (plugged != 0) return "plugged_" + plug;
            return "not_charging";
        } catch (Exception e) {
            return "unknown";
        }
    }

    /** SoC / CPU / GPU / NPU / thermal from Build + sysfs. */
    public static JSONObject readHardwareInfo(Context context) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("board", Build.BOARD);
            obj.put("model", Build.MODEL);
            obj.put("manufacturer", Build.MANUFACTURER);
            obj.put("device", Build.DEVICE);
            obj.put("cpu_cores", Runtime.getRuntime().availableProcessors());
            obj.put("cpu_model", readCpuModel());
            obj.put("gpu_vendor", detectGpuVendor());
            obj.put("gpu", detectGpuModel());
            obj.put("npu", detectNpu());
            obj.put("thermal_celsius", readThermalCelsius());
        } catch (Exception ignored) {}
        return obj;
    }

    private static String readCpuModel() {
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                new java.io.FileReader("/proc/cpuinfo"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("Hardware") || line.startsWith("model name")) {
                    int i = line.indexOf(':');
                    if (i > 0) {
                        String v = line.substring(i + 1).trim();
                        br.close();
                        return v;
                    }
                }
            }
            br.close();
        } catch (Exception ignored) {}
        return "n/a";
    }

    private static String detectGpuVendor() {
        try {
            if (new File("/sys/kernel/gpu").isDirectory()) return "Mali";
            if (new File("/sys/class/kgsl/kgsl-3d0").isDirectory()) return "Adreno";
        } catch (Exception ignored) {}
        return "unknown";
    }

    private static volatile String cachedGpuModel = null;

    /**
     * GPU make + model, queried once per process and cached (never polled, so
     * the 5s dashboard refresh can't lag the UI). Order: EGL GL_RENDERER
     * (e.g. "Adreno (TM) 750", "Mali-G78"), then sysfs model, then vendor.
     */
    private static String detectGpuModel() {
        if (cachedGpuModel != null) return cachedGpuModel;
        String g = eglRendererString();
        if (g == null) g = readGpuModelSysfs();
        if (g == null) g = detectGpuVendor();
        cachedGpuModel = g;
        return g;
    }

    /** EGL query of GL_RENDERER — the industry-standard GPU identity string. */
    private static String eglRendererString() {
        try {
            android.opengl.EGLDisplay dpy =
                android.opengl.EGL14.eglGetDisplay(android.opengl.EGL14.EGL_DEFAULT_DISPLAY);
            if (dpy == android.opengl.EGL14.EGL_NO_DISPLAY) return null;
            int[] ver = new int[2];
            if (!android.opengl.EGL14.eglInitialize(dpy, ver, 0, ver, 1)) return null;
            int[] cfgAttrs = {
                android.opengl.EGL14.EGL_RENDERABLE_TYPE,
                android.opengl.EGL14.EGL_OPENGL_ES2_BIT,
                android.opengl.EGL14.EGL_NONE
            };
            android.opengl.EGLConfig[] cfgs = new android.opengl.EGLConfig[1];
            int[] n = new int[1];
            if (!android.opengl.EGL14.eglChooseConfig(dpy, cfgAttrs, 0, cfgs, 0, 1, n, 0) || n[0] < 1) {
                android.opengl.EGL14.eglTerminate(dpy);
                return null;
            }
            int[] ctxAttrs = {
                android.opengl.EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
                android.opengl.EGL14.EGL_NONE
            };
            android.opengl.EGLContext ctx = android.opengl.EGL14.eglCreateContext(
                dpy, cfgs[0], android.opengl.EGL14.EGL_NO_CONTEXT, ctxAttrs, 0);
            if (ctx == android.opengl.EGL14.EGL_NO_CONTEXT) {
                android.opengl.EGL14.eglTerminate(dpy);
                return null;
            }
            int[] surfAttrs = {
                android.opengl.EGL14.EGL_WIDTH, 1,
                android.opengl.EGL14.EGL_HEIGHT, 1,
                android.opengl.EGL14.EGL_NONE
            };
            android.opengl.EGLSurface surf = android.opengl.EGL14.eglCreatePbufferSurface(
                dpy, cfgs[0], surfAttrs, 0);
            if (surf == android.opengl.EGL14.EGL_NO_SURFACE) {
                android.opengl.EGL14.eglDestroyContext(dpy, ctx);
                android.opengl.EGL14.eglTerminate(dpy);
                return null;
            }
            if (!android.opengl.EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) {
                android.opengl.EGL14.eglDestroySurface(dpy, surf);
                android.opengl.EGL14.eglDestroyContext(dpy, ctx);
                android.opengl.EGL14.eglTerminate(dpy);
                return null;
            }
            String r = null;
            try {
                r = android.opengl.GLES10.glGetString(
                    android.opengl.GLES10.GL_RENDERER);
            } catch (Throwable ignored) {}
            android.opengl.EGL14.eglMakeCurrent(dpy,
                android.opengl.EGL14.EGL_NO_SURFACE, android.opengl.EGL14.EGL_NO_SURFACE,
                android.opengl.EGL14.EGL_NO_CONTEXT);
            android.opengl.EGL14.eglDestroySurface(dpy, surf);
            android.opengl.EGL14.eglDestroyContext(dpy, ctx);
            android.opengl.EGL14.eglTerminate(dpy);
            if (r != null && !r.trim().isEmpty()
                    && !r.toLowerCase(java.util.Locale.US).contains("unknown")) {
                return r.trim();
            }
        } catch (Throwable ignored) {}
        return null;
    }

    /** sysfs GPU model files (Mali/Exynos expose gpu_model; Adreno rarely). */
    private static String readGpuModelSysfs() {
        String[] models = {
            "/sys/kernel/gpu/gpu_model",
            "/sys/class/kgsl/kgsl-3d0/gpu_model"
        };
        for (String p : models) {
            try {
                File f = new File(p);
                if (f.canRead()) {
                    String v = new String(java.nio.file.Files.readAllBytes(f.toPath())).trim();
                    if (v.length() > 0) return v.replaceAll("\\s+", " ");
                }
            } catch (Exception ignored) {}
        }
        return null;
    }

    private static String detectNpu() {
        String[] probes = {"/sys/kernel/npu", "/sys/class/npu", "/sys/devices/platform/npu"};
        for (String p : probes) {
            try {
                if (new File(p).exists()) return "present (sysfs)";
            } catch (Exception ignored) {}
        }
        return "n/a";
    }

    private static String readThermalCelsius() {
        try {
            File zoneDir = new File("/sys/class/thermal");
            String[] zones = zoneDir.list();
            if (zones != null) {
                for (String z : zones) {
                    if (!z.startsWith("thermal_zone")) continue;
                    File temp = new File(zoneDir, z + "/temp");
                    if (temp.canRead()) {
                        String v = new String(java.nio.file.Files.readAllBytes(temp.toPath())).trim();
                        try {
                            return String.valueOf(Long.parseLong(v) / 1000);
                        } catch (NumberFormatException nfe) {
                            return v;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    /** Primary store + removable/USB volumes via StorageManager + StatFs. */
    public static JSONObject readStorage(Context context) {
        JSONObject obj = new JSONObject();
        try {
            StatFs primary = new StatFs("/storage/emulated/0");
            obj.put("primary_total", primary.getTotalBytes());
            obj.put("primary_available", primary.getAvailableBytes());
            JSONArray ext = new JSONArray();
            android.os.storage.StorageManager sm =
                context.getSystemService(android.os.storage.StorageManager.class);
            if (sm != null) {
                for (android.os.storage.StorageVolume v : sm.getStorageVolumes()) {
                    if (v.isPrimary()) continue;
                    File dir = v.getDirectory();
                    if (dir == null || !dir.isDirectory()) continue;
                    try {
                        StatFs sf = new StatFs(dir.getAbsolutePath());
                        JSONObject o = new JSONObject();
                        o.put("name", v.getDescription(context));
                        o.put("path", dir.getAbsolutePath());
                        o.put("total", sf.getTotalBytes());
                        o.put("available", sf.getAvailableBytes());
                        ext.put(o);
                    } catch (Exception ignored) {}
                }
            }
            obj.put("external", ext);
        } catch (Exception ignored) {}
        return obj;
    }

    /** Installed APK size + current on-device data footprint. */
    public static JSONObject readAppSizes(Context context) {
        JSONObject obj = new JSONObject();
        try {
            ApplicationInfo ai = context.getPackageManager()
                .getApplicationInfo(context.getPackageName(), 0);
            obj.put("apk_size", new File(ai.sourceDir).length());
            obj.put("data_size", dirSize(new File(context.getFilesDir().getParentFile(), "files")));
        } catch (Exception ignored) {}
        return obj;
    }

    private static long dirSize(File dir) {
        File[] fs = dir.listFiles();
        if (fs == null) return 0;
        long total = 0;
        for (File f : fs) {
            if (f.isDirectory()) total += dirSize(f);
            else total += f.length();
        }
        return total;
    }

    /** Active transport (Wi-Fi / cellular / ethernet / vpn / none) via ConnectivityManager. */
    public static JSONObject readNetwork(Context context) {
        JSONObject obj = new JSONObject();
        try {
            ConnectivityManager cm = context.getSystemService(ConnectivityManager.class);
            String active = "none";
            String detail = "";
            if (cm != null) {
                Network n = cm.getActiveNetwork();
                NetworkCapabilities caps = n != null ? cm.getNetworkCapabilities(n) : null;
                if (caps != null) {
                    if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        active = "wifi"; detail = "Wi-Fi";
                    } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        active = "cellular";
                        detail = "Cellular " + cellularType(context);
                    } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                        active = "ethernet"; detail = "Ethernet";
                    } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                        active = "vpn"; detail = "VPN";
                    }
                }
            }
            obj.put("active", active);
            obj.put("detail", detail.length() == 0
                ? (active.equals("none") ? "Offline" : active) : detail);
        } catch (Exception ignored) {}
        return obj;
    }

    private static String cellularType(Context context) {
        try {
            TelephonyManager tm = context.getSystemService(TelephonyManager.class);
            switch (tm.getDataNetworkType()) {
                case TelephonyManager.NETWORK_TYPE_LTE: return "LTE";
                case TelephonyManager.NETWORK_TYPE_NR: return "5G";
                case TelephonyManager.NETWORK_TYPE_UMTS:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_HSDPA: return "HSPA";
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_GPRS: return "2G";
                case TelephonyManager.NETWORK_TYPE_CDMA: return "CDMA";
                default: return "";
            }
        } catch (Exception e) {
            return "";
        }
    }

    /** Read device.conf (written by StepRunner.step3Diagnostics). */
    public static JSONObject readDeviceConf() {
        JSONObject obj = new JSONObject();
        try {
            java.io.File conf = new java.io.File("/etc/aetherix/device.conf");
            if (conf.isFile()) {
                java.util.Scanner scanner = new java.util.Scanner(new java.io.FileReader(conf));
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    String[] parts = line.split("=", 2);
                    if (parts.length == 2) {
                        obj.put(parts[0], parts[1]);
                    }
                }
                scanner.close();
            }
        } catch (Exception ignored) {}
        return obj;
    }

    /** VOLTAGE/TEMPERATURE are hidden in the SDK android.jar stub; read via reflection. */
    private static int readBatteryProperty(BatteryManager bm, String field) {
        try {
            java.lang.reflect.Field f = BatteryManager.class.getField(field);
            int id = f.getInt(null);
            return bm.getIntProperty(id);
        } catch (Throwable t) {
            return -1;
        }
    }
}
