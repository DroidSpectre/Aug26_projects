package com.aetherix.alpine.a.terminal;

public interface TerminalSessionClient {
    Integer getTerminalCursorStyle();
    void onTerminalCursorStateChange(boolean state);
    void logError(String tag, String message);
    void logWarn(String tag, String message);
    void logInfo(String tag, String message);
    void logDebug(String tag, String message);
    void logVerbose(String tag, String message);
    void logStackTraceWithMessage(String tag, String message, Exception e);
    void logStackTrace(String tag, Exception e);
}
