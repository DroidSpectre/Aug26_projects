package com.aetherix.alpine.a;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.FileReader;

public class ErrorReport {

    public static String generate(Context context, String statusJson, String logContent) {
        return generate(context, statusJson, logContent, "{}");
    }

    public static String generate(Context context, String statusJson, String logContent, String moduleDiagJson) {
        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append("  Aetherix-Alpine - Error Report\n");
        sb.append("========================================\n\n");

        // App version
        String version = "unknown";
        try {
            version = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException ignored) {}
        sb.append("App Version: ").append(version).append("\n");

        // Device info
        sb.append("Device: ").append(Build.MANUFACTURER).append(" ")
            .append(Build.MODEL).append("\n");
        sb.append("Android: ").append(Build.VERSION.RELEASE)
            .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("Kernel: ").append(System.getProperty("os.version", "unknown")).append("\n");
        sb.append("Arch: ").append(System.getProperty("os.arch", "unknown")).append("\n\n");

        // kernel info from /proc/version
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/version"));
            String line = br.readLine();
            if (line != null) sb.append("Proc version: ").append(line).append("\n");
            br.close();
        } catch (Exception ignored) {}
        sb.append("\n");

        // Step status
        sb.append("--- Component Status ---\n");
        sb.append(statusJson).append("\n\n");

        // Module readiness diagnostics (FB-023)
        sb.append("--- Module Readiness ---\n");
        if (moduleDiagJson != null && !moduleDiagJson.trim().isEmpty()) {
            sb.append(moduleDiagJson).append("\n");
        } else {
            sb.append("(none)\n");
        }
        sb.append("\n");

        // Log tail
        sb.append("--- Log (last 100 lines) ---\n");
        if (logContent != null && !logContent.isEmpty()) {
            String[] lines = logContent.split("\n");
            int start = Math.max(0, lines.length - 100);
            for (int i = start; i < lines.length; i++) {
                sb.append(lines[i]).append("\n");
            }
        } else {
            sb.append("(no log data)\n");
        }

        // PTY Bridge debug
        sb.append("\n--- PTY Bridge Debug ---\n");
        String bridgeLog = BridgeLogBuffer.getText();
        if (!bridgeLog.isEmpty()) {
            sb.append(bridgeLog);
        } else {
            sb.append("(no bridge debug data)\n");
        }

        // 15u: diagnostic - the actual emulator screen rows+cursor at report freeze.
        // Shows whether a ":" / missing character really lives in the cell buffer,
        // rather than only in the PTY byte stream.
        sb.append("\n--- Terminal Screen Snapshot ---\n");
        String snap = BridgeLogBuffer.getScreenSnapshot();
        if (!snap.isEmpty()) {
            sb.append(snap);
        } else {
            sb.append("(no screen snapshot)\n");
        }

        sb.append("\n========================================\n");
        sb.append("  End of Report\n");
        sb.append("========================================\n");

        return sb.toString();
    }

    public static void share(Context context, String reportText) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "Aetherix-Alpine Error Report");
        share.putExtra(Intent.EXTRA_TEXT, reportText);
        context.startActivity(Intent.createChooser(share, "Share Error Report"));
    }
}
