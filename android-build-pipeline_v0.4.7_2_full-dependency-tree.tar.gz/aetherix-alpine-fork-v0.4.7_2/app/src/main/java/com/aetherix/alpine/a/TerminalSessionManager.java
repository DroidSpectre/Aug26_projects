package com.aetherix.alpine.a;

import com.aetherix.alpine.a.terminal.TerminalSession;

public class TerminalSessionManager {

    private static TerminalSessionManager instance;

    private TerminalSession session;
    private long sessionStartTime;

    private TerminalSessionManager() {}

    public static synchronized TerminalSessionManager getInstance() {
        if (instance == null) {
            instance = new TerminalSessionManager();
        }
        return instance;
    }

    public void setSession(TerminalSession s, long startTime) {
        this.session = s;
        this.sessionStartTime = startTime;
    }

    public TerminalSession getSession() {
        return session;
    }

    public long getSessionStartTime() {
        return sessionStartTime;
    }

    public boolean isSessionActive() {
        return session != null && session.isRunning();
    }

    public void clear() {
        session = null;
        sessionStartTime = 0;
    }
}
