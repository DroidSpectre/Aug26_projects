package com.aetherix.alpine.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * v0.3.2  storage tier: full-storage binds for the PRoot launcher, the in-Alpine
 * `sd` helpers, and the All-files grant state.
 *
 * Binds are unconditional (the launcher always maps the primary store and any
 * removable volume); the sd commands gate on /etc/aetherix/storage.state which is
 * mirrored from the Android grant whenever the app starts.
 */
public class StorageTier {

    private StorageTier() {}

    /** All-files access is only possible on API 30+; lower APIs inherit legacy write. */
    public static boolean isStorageGranted(Context ctx) {
        if (Build.VERSION.SDK_INT < 30) return true;
        try {
            return Environment.isExternalStorageManager();
        } catch (Exception e) {
            return false;
        }
    }

    /** Open the All-files settings page for this app. */
    public static void requestStorageAccess(Activity activity) {
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                activity.startActivity(intent);
            } catch (Exception e2) { BridgeLogBuffer.append("StorageTier: " + e2); }
        }
    }

    /**
     * Storage bind lines for the launcher script: the primary store replaces the old
     * /sdcard bind (writable under All-files), plus one bind per removable volume.
     */
    public static String[] buildBinds(Context ctx) {
        Set<String> lines = new LinkedHashSet<String>();
        lines.add("  -b /storage/emulated/0:/mnt/sdcard \\");
        int n = 0;

        try {
            if (Build.VERSION.SDK_INT >= 24) {
                android.os.storage.StorageManager sm =
                    (android.os.storage.StorageManager) ctx.getSystemService(Context.STORAGE_SERVICE);
                for (android.os.storage.StorageVolume v : sm.getStorageVolumes()) {
                    if (v.isPrimary() || !v.isRemovable()) continue;
                    File vol = v.getDirectory();
                    if (vol == null || !vol.isDirectory()) continue;
                    lines.add("  -b " + vol.getAbsolutePath() + ":/mnt/sd-ext" + (++n) + " \\");
                }
            }
        } catch (Exception ignored) {}

        try {
            File[] dirs = ctx.getExternalFilesDirs(null);
            int extra = n;
            for (File d : dirs) {
                String abs = d.getAbsolutePath();
                if (abs == null || abs.startsWith("/storage/emulated/")) continue;
                int i = abs.indexOf("/Android/data/");
                String vol = (i > 0) ? abs.substring(0, i) : abs;
                if (!new File(vol).isDirectory()) continue;
                lines.add("  -b " + vol + ":/mnt/sd-ext" + (++extra) + " \\");
            }
        } catch (Exception ignored) {}

        return lines.toArray(new String[0]);
    }

    /**
     * Idempotent deploy of the sd helpers + module directories into the rootfs.
     * Called on every app start (covers upgrades that never re-ran setup step 5).
     * FB-025: every failure is surfaced in BridgeLogBuffer (visible in the
     * error report) instead of being silently swallowed, and the skip reason is
     * logged once per streak so a pre-setup dashboard poll cannot spam the log.
     */
    public static void deploy(Context ctx) {
        try {
            String filesDir = ctx.getFilesDir().getAbsolutePath();
            File rootfs = new File(filesDir + "/rootfs/alpine");
            // FB-047: never block the caller. Deploy is idempotent and runs on
            // every dashboard poll / module refresh / terminal start, so the
            // readiness gate must be O(1) - the 14_1 retry loop (8x500ms) made
            // every poll stall the bridge thread for seconds when bin/sh was
            // broken, which lagged the whole app (FB-046). Also heal the common
            // /bin/sh -> busybox symlink loss (an apk upgrade under proot can
            // break it while bash keeps working), which previously made the
            // bin/sh gate skip every deploy and left sd/device-info/elv/module
            // + cert.pem missing in the guest.
            healRootfsBasics(rootfs);
            boolean ready = new File(rootfs, "bin/sh").isFile()
                || new File(rootfs, "bin/busybox").isFile()
                || new File(rootfs, "etc/alpine-release").isFile();
            if (!ready) {
                if (!lastDeploySkippedLogged) {
                    BridgeLogBuffer.append("StorageTier.deploy: skipped (rootfs not ready at " + rootfs + ")");
                    lastDeploySkippedLogged = true;
                }
                return;
            }
            lastDeploySkippedLogged = false;
            File bin = new File(rootfs, "usr/local/bin");
            bin.mkdirs();
            new File(rootfs, "etc/aetherix").mkdirs();
            new File(rootfs, "var/lib/aetherix-modules").mkdirs();
            new File(rootfs, "etc/aetherix/modules.d").mkdirs();

            deployRun("sd helper", new Runnable() { public void run() { writeScript(bin, "sd", "$0 <mount|list|env|ext|ls <path>|cp <src> <dst>>"); } });
            deployRun("device-info helper", new Runnable() { public void run() { writeDeviceInfo(bin); } });
            deployRun("storage.map", new Runnable() { public void run() { writeStorageMap(ctx, rootfs); } });
            deployRun("io dirs", new Runnable() { public void run() { ensureIoDirs(ctx); } });
            deployRun("~/storage links", new Runnable() { public void run() { deployHomeStorageLinks(rootfs); } });
            deployRun("tier CLIs", new Runnable() { public void run() { deployTierScripts(ctx, rootfs); } });
            deployRun("cert.pem symlink", new Runnable() { public void run() { ensureCertPem(rootfs); } });
            deployRun("bash aliases", new Runnable() { public void run() { deployAliases(rootfs); } });
            deployRun("storage.state", new Runnable() { public void run() { writeState(ctx, rootfs); } });
            deployRun("welcome splash", new Runnable() { public void run() { WelcomeScript.writeTo(rootfs); } });
            deployRun("tavily.key", new Runnable() { public void run() { syncTavilyKey(ctx, rootfs); } });
            deployRun("deploy verify", new Runnable() { public void run() { verifyDeploy(bin); } });
        } catch (Throwable t) {
            BridgeLogBuffer.append("StorageTier.deploy: FAILED: " + t);
        }
    }

    /**
     * FB-047: recreate the /bin/sh -> busybox symlink when an apk upgrade broke
     * it under proot (bash keeps working, but the old bin/sh gate then skipped
     * every deploy). No-op when bin/sh is fine or busybox is absent.
     */
    private static void healRootfsBasics(File rootfs) {
        try {
            File binSh = new File(rootfs, "bin/sh");
            File busybox = new File(rootfs, "bin/busybox");
            if (!busybox.isFile()) return;
            if (binSh.isFile()) return; // already fine
            // A broken symlink reports exists()=false but still occupies the
            // path, so delete the stale entry before recreating it (FB-054).
            if (java.nio.file.Files.isSymbolicLink(binSh.toPath()) || binSh.exists()) {
                binSh.delete();
            }
            if (!binSh.exists()) {
                java.nio.file.Files.createSymbolicLink(binSh.toPath(),
                    new java.io.File("busybox").toPath());
                BridgeLogBuffer.append("StorageTier: healed /bin/sh -> busybox");
            }
        } catch (Exception e) {
            BridgeLogBuffer.append("StorageTier: heal /bin/sh failed: " + e);
        }
    }

    /**
     * FB-043: git/curl in Alpine default their CA file to /etc/ssl/cert.pem
     * (the minirootfs ships no /etc/ssl at all). Point it at the CA bundle we
     * deploy from assets so TLS works without depending on SSL_CERT_FILE.
     */
    private static void ensureCertPem(File rootfs) {
        try {
            File certsDir = new File(rootfs, "etc/ssl/certs");
            if (!certsDir.isDirectory() && !certsDir.mkdirs()) return;
            if (!new File(certsDir, "ca-certificates.crt").isFile()) return;
            File certPem = new File(rootfs, "etc/ssl/cert.pem");
            if (java.nio.file.Files.isSymbolicLink(certPem.toPath())) return; // already a link
            if (certPem.exists()) certPem.delete();
            java.nio.file.Files.createSymbolicLink(certPem.toPath(),
                new java.io.File("/etc/ssl/certs/ca-certificates.crt").toPath());
        } catch (Exception e) {
            BridgeLogBuffer.append("StorageTier: cert.pem: " + e);
        }
    }

    /**
     * FB-043: post-deploy sanity check so a silently missing helper shows up in
     * the error report instead of only in the first in-guest selftest run.
     */
    private static void verifyDeploy(File bin) {
        try {
            String[] need = { "sd", "device-info", "elv", "module" };
            StringBuilder missing = new StringBuilder();
            for (String n : need) {
                if (!new File(bin, n).isFile()) missing.append(' ').append(n);
            }
            if (missing.length() > 0) {
                BridgeLogBuffer.append("StorageTier.deploy: MISSING helpers:" + missing);
            }
        } catch (Exception ignored) {}
    }

    private static boolean lastDeploySkippedLogged = false;

    /**
     * FB-102: mirror the app's stored (decrypted) Tavily key into the guest so
     * tier CLIs (llm chat --web) can use it. The host copy stays Keystore-encrypted;
     * the guest copy is owner-only and removed when the key is cleared. Runs on
     * every deploy, so the guest always sees the latest state.
     */
    /** One-arg convenience for callers that just have a Context (install bridge). */
    static void syncTavilyKey(Context ctx) {
        syncTavilyKey(ctx, new File(ctx.getFilesDir(), "rootfs/alpine"));
    }

    static void syncTavilyKey(Context ctx, File rootfs) {
        try {
            File f = new File(rootfs, "etc/aetherix/tavily.key");
            String key = SecretStore.read(ctx);
            if (key == null || key.isEmpty()) {
                if (f.exists()) f.delete();
                return;
            }
            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(key.getBytes("UTF-8"));
            fos.close();
            f.setReadable(false, false);
            f.setReadable(true, true);
            f.setWritable(false, false);
            f.setWritable(true, true);
        } catch (Exception e) {
            BridgeLogBuffer.append("StorageTier: tavily.key: " + e);
        }
    }

    private static void deployRun(String what, Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            BridgeLogBuffer.append("StorageTier.deploy: FAIL " + what + ": " + t);
        }
    }

    /**
     * Deploy the tier CLIs (elv/llm/module) from assets/tier/*.sh into
     * /usr/local/bin. Idempotent: only rewrites when content changed.
     */
    private static void deployTierScripts(Context ctx, File rootfs) {
        try {
            String[] assets = ctx.getAssets().list("tier");
            if (assets == null) return;
            File bin = new File(rootfs, "usr/local/bin");
            bin.mkdirs();
            for (String a : assets) {
                if (!a.endsWith(".sh")) continue;
                String outName = a.substring(0, a.length() - 3);
                java.io.InputStream in = ctx.getAssets().open("tier/" + a);
                java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) buf.write(b, 0, n);
                in.close();
                byte[] content = buf.toByteArray();
                File out = new File(bin, outName);
                if (out.isFile()) {
                    byte[] existing = java.nio.file.Files.readAllBytes(out.toPath());
                    if (java.util.Arrays.equals(existing, content)) continue;
                }
                FileOutputStream fos = new FileOutputStream(out, false);
                fos.write(content);
                fos.close();
                out.setExecutable(true);
            }
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }

    /** Termux-style cd aliases in the guest .bashrc (idempotent). */
    private static void deployAliases(File rootfs) {
        try {
            File bashrc = new File(new File(rootfs, "root"), ".bashrc");
            if (!bashrc.isFile()) return;
            String existing = new String(java.nio.file.Files.readAllBytes(bashrc.toPath()));
            if (existing.contains("alias shared=")) return;
            String block =
                "\n# Aetherix storage aliases (v0.3a.7)\n" +
                "alias storage='cd ~/storage'\n" +
                "alias shared='cd ~/storage/shared'\n" +
                "alias external='cd ~/storage/external'\n" +
                "alias usb='cd ~/storage/usb'\n";
            FileOutputStream fos = new FileOutputStream(bashrc, true);
            fos.write(block.getBytes());
            fos.close();
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }

    public static void writeState(Context ctx) {
        try {
            File rootfs = new File(ctx.getFilesDir().getAbsolutePath() + "/rootfs/alpine");
            writeState(ctx, rootfs);
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }

    private static void writeState(Context ctx, File rootfs) {
        try {
            String value = isStorageGranted(ctx) ? "granted" : "blocked";
            File state = new File(rootfs, "etc/aetherix/storage.state");
            if (state.exists()) {
                String existing = new String(java.nio.file.Files.readAllBytes(state.toPath())).trim();
                if (existing.equals(value)) return;
            }
            FileOutputStream fos = new FileOutputStream(state, false);
            fos.write((value + "\n").getBytes());
            fos.close();
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }

    private static void writeScript(File bin, String name, String usage) {
        try {
            File f = new File(bin, name);
            String content = buildSdScript(name, usage);
            if (f.exists()) {
                String existing = new String(java.nio.file.Files.readAllBytes(f.toPath()));
                if (existing.equals(content)) return;
            }
            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(content.getBytes());
            fos.close();
            f.setExecutable(true);
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }

    private static String buildSdScript(String name, String usage) {
        // FB-0148: device-agnostic mapping. The Java side writes
        // /etc/aetherix/storage.map listing exactly what StorageManager bound
        // (PRIM|target|label for the internal store, EXT|target|label per
        // removable volume). This script only creates ~/storage links for
        // volumes that are present and non-empty; no hardcoded "usb" alias -
        // a USB stick is only labelled "usb" when StorageManager reports a USB
        // description for that volume.
        return "#!/bin/sh\n" +
            "# Aetherix-Alpine storage helper (device-agnostic ~/storage mapping)\n" +
            "MAP=/etc/aetherix/storage.map\n" +
            "if [ ! -f /etc/aetherix/storage.state ] || [ \"$(cat /etc/aetherix/storage.state)\" != \"granted\" ]; then\n" +
            "  echo \"ERROR: All-files access not granted.\" >&2\n" +
            "  echo \"Open Aetherix-Alpine > Dashboard > Storage > Grant Access.\" >&2\n" +
            "  exit 1\n" +
            "fi\n" +
            "primary() { awk -F'|' '$1==\"PRIM\" {print $2; exit}' \"$MAP\" 2>/dev/null; }\n" +
            "vol_label() { # $1 = target\n" +
            "  awk -F'|' -v t=\"$1\" '$1==\"EXT\" && $2==t {print $3; exit}' \"$MAP\" 2>/dev/null\n" +
            "}\n" +
            "is_empty() { # $1 = dir\n" +
            "  [ -d \"$1\" ] || return 1\n" +
            "  ls -A \"$1\" 2>/dev/null | grep -q . && return 1 || return 0\n" +
            "}\n" +
            "do_mount() {\n" +
            "  mkdir -p \"$HOME/storage\" 2>/dev/null\n" +
            "  # single source of truth: wipe all derived links so the tree never\n" +
            "  # drifts between the app-side seed and 'sd mount' runs\n" +
            "  rm -f \"$HOME/storage/downloads\" \"$HOME/storage/input\" \"$HOME/storage/output\" \\\n" +
            "        \"$HOME/storage/dcim\" \"$HOME/storage/pictures\" \\\n" +
            "        \"$HOME/storage/music\" \"$HOME/storage/movies\" \"$HOME/storage/documents\" \\\n" +
            "        \"$HOME/storage/usb\" \"$HOME/storage\"/external* 2>/dev/null\n" +
            "  P=$(primary)\n" +
            "  [ -n \"$P\" ] || P=/mnt/sdcard\n" +
            "  if [ -d \"$P\" ]; then\n" +
            "    ln -sfn \"$P\" \"$HOME/storage/shared\"\n" +
            "    for d in Download DCIM Pictures Music Movies Documents; do\n" +
            "      n2=$(echo \"$d\" | tr 'A-Z' 'a-z')\n" +
            "      [ \"$n2\" = download ] && n2=downloads\n" +
            "      [ -d \"$P/$d\" ] && ln -sfn \"$P/$d\" \"$HOME/storage/$n2\"\n" +
            "    done\n" +
            "    ln -sfn \"$P/Download/Aetherix-Alpine_INPUT\" \"$HOME/storage/input\"\n" +
            "    ln -sfn \"$P/Download/Aetherix-Alpine_OUTPUT\" \"$HOME/storage/output\"\n" +
            "  fi\n" +
            "  n=1\n" +
            "  while IFS='|' read -r kind target label; do\n" +
            "    [ \"$kind\" = \"EXT\" ] || continue\n" +
            "    [ -n \"$target\" ] || continue\n" +
            "    is_empty \"$target\" && continue          # removed/stale volume\n" +
            "    if [ \"$n\" -eq 1 ]; then ln -sfn \"$target\" \"$HOME/storage/external\"; fi\n" +
            "    ln -sfn \"$target\" \"$HOME/storage/external$n\"\n" +
            "    case \"$label\" in\n" +
            "      *[Uu][Ss][Bb]*|*usb*) ln -sfn \"$target\" \"$HOME/storage/usb\" ;;\n" +
            "    esac\n" +
            "    n=$((n+1))\n" +
            "  done < \"$MAP\"\n" +
            "}\n" +
            "case \"$1\" in\n" +
            "  mount)\n" +
            "    do_mount\n" +
            "    echo \"~/storage mapping:\"\n" +
            "    for l in \"$HOME/storage\"/*; do\n" +
            "      [ -e \"$l\" ] || continue\n" +
            "      printf '  %s -> %s\\n' \"$(basename \"$l\")\" \"$(readlink \"$l\")\"\n" +
            "    done\n" +
            "    echo \"Try: cd ~/storage/shared && ls\"\n" +
            "    exit 0\n" +
            "    ;;\n" +
            "  list)\n" +
            "    do_mount\n" +
            "    echo \"Storage volumes bound by the app:\"\n" +
            "    while IFS='|' read -r kind target label; do\n" +
            "      [ \"$kind\" = \"PRIM\" ] && printf '  primary   %s (%s)\\n' \"$target\" \"$label\"\n" +
            "      [ \"$kind\" = \"EXT\" ] && printf '  removable %s (%s)\\n' \"$target\" \"$label\"\n" +
            "    done < \"$MAP\"\n" +
            "    exit 0\n" +
            "    ;;\n" +
            "  ext)\n" +
            "    do_mount\n" +
            "    found=0\n" +
            "    while IFS='|' read -r kind target label; do\n" +
            "      [ \"$kind\" = \"EXT\" ] || continue\n" +
            "      is_empty \"$target\" && continue\n" +
            "      echo \"$target ($label)\"; found=1\n" +
            "    done < \"$MAP\"\n" +
            "    [ \"$found\" = 0 ] && echo \"No removable volumes bound.\"\n" +
            "    exit 0\n" +
            "    ;;\n" +
            "  env)\n" +
            "    do_mount\n" +
            "    printf 'export AETHERIX_STORAGE_PRIMARY=%s\\n' \"$(primary)\"\n" +
            "    printf 'export AETHERIX_INPUT_DIR=%s\\n' \"$HOME/storage/input\"\n" +
            "    printf 'export AETHERIX_OUTPUT_DIR=%s\\n' \"$HOME/storage/output\"\n" +
            "    n=1\n" +
            "    while IFS='|' read -r kind target label; do\n" +
            "      [ \"$kind\" = \"EXT\" ] || continue\n" +
            "      is_empty \"$target\" && continue\n" +
            "      printf 'export AETHERIX_STORAGE_EXT%s=%s\\n' \"$n\" \"$target\"\n" +
            "      n=$((n+1))\n" +
            "    done < \"$MAP\"\n" +
            "    exit 0\n" +
            "    ;;\n" +
            "  ls)\n" +
            "    if [ $# -lt 2 ]; then echo \"usage: " + usage + "\" >&2; exit 2; fi\n" +
            "    ls -la \"$2\"\n" +
            "    ;;\n" +
            "  cp)\n" +
            "    if [ $# -lt 3 ]; then echo \"usage: " + usage + "\" >&2; exit 2; fi\n" +
            "    cp -a \"$2\" \"$3\"\n" +
            "    ;;\n" +
            "  *)\n" +
            "    do_mount\n" +
            "    echo \"usage: " + usage + "\" >&2\n" +
            "    echo \"  ~/storage links are derived from the app's actual storage map.\" >&2\n" +
            "    exit 2\n" +
            "    ;;\n" +
            "esac\n";
    }

    /**
     * FB-0148/FB-078: seed the ~/storage symlink tree from the same map that
     * /usr/local/bin/sd uses, so a fresh shell already has every mapped volume
     * - no separate 'sd mount' step. Runs after storage.map on every app start
     * and only ever rewrites derived symlinks, so the tree cannot drift from
     * the map; real files/dirs are never touched (homeLink guard).
     */
    private static void deployHomeStorageLinks(File rootfs) {
        try {
            File storage = new File(new File(rootfs, "root"), "storage");
            storage.mkdirs();
            // wipe derived symlinks first - same name set as sd's do_mount()
            if (storage.isDirectory()) {
                String[] names = storage.list();
                if (names != null) {
                    for (String nm : names) {
                        if (!isDerivedStorageLink(nm)) continue;
                        File l = new File(storage, nm);
                        if (java.nio.file.Files.isSymbolicLink(l.toPath())) l.delete();
                    }
                }
            }
            File map = new File(new File(rootfs, "etc/aetherix"), "storage.map");
            String prim = "/mnt/sdcard";
            List<String[]> exts = new ArrayList<String[]>();
            if (map.isFile()) {
                String all = new String(java.nio.file.Files.readAllBytes(map.toPath()), "UTF-8");
                for (String line : all.split("\n")) {
                    String[] p = line.split("\\|", 3);
                    if (p.length >= 2 && p[0].equals("PRIM") && p[1].length() > 0) {
                        prim = p[1];
                    } else if (p.length >= 3 && p[0].equals("EXT") && p[1].length() > 0) {
                        exts.add(new String[] { p[1], p[2] });
                    }
                }
            }
            homeLink(storage, "shared", prim);
            homeLink(storage, "downloads", prim + "/Download");
            homeLink(storage, "input", prim + "/Download/Aetherix-Alpine_INPUT");
            homeLink(storage, "output", prim + "/Download/Aetherix-Alpine_OUTPUT");
            for (String d : new String[] { "DCIM", "Pictures", "Music", "Movies", "Documents" }) {
                homeLink(storage, d.toLowerCase(Locale.US), prim + "/" + d);
            }
            int n = 0;
            for (String[] e : exts) {
                n++;
                if (n == 1) homeLink(storage, "external", e[0]);
                homeLink(storage, "external" + n, e[0]);
                if (e[1].toLowerCase(Locale.US).contains("usb")) homeLink(storage, "usb", e[0]);
            }
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }

    /** Derived ~/storage link names (kept in sync with sd's do_mount wipe set). */
    private static boolean isDerivedStorageLink(String name) {
        return name.equals("downloads") || name.equals("input") || name.equals("output")
            || name.equals("dcim") || name.equals("pictures")
            || name.equals("music") || name.equals("movies") || name.equals("documents")
            || name.equals("usb") || name.equals("external")
            || name.matches("external[0-9]+");
    }

    /** v0.4.3 (FB-114): the app owns the unified I/O folders - device-agnostic
     *  Downloads/Aetherix-Alpine_INPUT (user dropbox) and _OUTPUT (exports) on
     *  the primary store, mirrored onto any removable volume that is present. */
    private static void ensureIoDirs(Context ctx) {
        try {
            java.io.File prim = android.os.Environment.getExternalStorageDirectory();
            if (prim != null) ensureIoPair(prim);
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                android.os.storage.StorageManager sm =
                    (android.os.storage.StorageManager) ctx.getSystemService(Context.STORAGE_SERVICE);
                if (sm != null) {
                    for (android.os.storage.StorageVolume v : sm.getStorageVolumes()) {
                        if (v.isPrimary() || !v.isRemovable()) continue;
                        java.io.File vol = v.getDirectory();
                        if (vol != null && vol.isDirectory()
                            && !vol.getAbsolutePath().startsWith("/storage/emulated/")) {
                            ensureIoPair(vol);
                        }
                    }
                }
            }
            try {
                java.io.File[] dirs = ctx.getExternalFilesDirs(null);
                for (java.io.File d : dirs) {
                    if (d == null) continue;
                    String abs = d.getAbsolutePath();
                    if (abs == null || abs.startsWith("/storage/emulated/")) continue;
                    int i = abs.indexOf("/Android/data/");
                    String vol = (i > 0) ? abs.substring(0, i) : abs;
                    if (new java.io.File(vol).isDirectory()) ensureIoPair(new java.io.File(vol));
                }
            } catch (Exception ignored) {}
        } catch (Exception e) { BridgeLogBuffer.append("Storage: io dirs: " + e); }
    }

    private static void ensureIoPair(java.io.File volRoot) {
        try {
            java.io.File dl = new java.io.File(volRoot, "Download");
            if (!dl.isDirectory() && !dl.mkdirs()) return;
            for (String n : new String[] { "Aetherix-Alpine_INPUT", "Aetherix-Alpine_OUTPUT" }) {
                java.io.File d = new java.io.File(dl, n);
                if (!d.isDirectory()) d.mkdirs();
            }
        } catch (Exception ignored) {}
    }

    private static void homeLink(File dir, String name, String target) {
        try {
            File l = new File(dir, name);
            if (java.nio.file.Files.isSymbolicLink(l.toPath())) {
                l.delete();
            } else if (l.exists()) {
                return; // real dir/file - never touch it
            }
            java.nio.file.Files.createSymbolicLink(l.toPath(), new java.io.File(target).toPath());
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }

    /** Root of the shared modules drop folder on /sdcard. */
    public static String modulesDir() {
        return "/sdcard/Download/Aetherix-Alpine-Fork/modules";
    }

    /**
     * FB-0148: write the guest /etc/aetherix/storage.map from the volumes the
     * launcher actually bound (see buildBinds). Rows are KIND|TARGET|LABEL:
     * PRIM for the internal store (/mnt/sdcard) and EXT for each removable
     * bind (/mnt/sd-extN), labelled with StorageManager's own description so
     * the guest can tell an SD card from a USB stick without hardcoding.
     */
    private static String volumeLabel(Context ctx, android.os.storage.StorageVolume v, java.io.File vol) {
        try {
            CharSequence d = v.getDescription(ctx);
            if (d != null && d.length() > 0) return d.toString().trim();
        } catch (Exception ignored) {}
        return (v.getUuid() != null) ? v.getUuid()
               : (vol != null ? vol.getAbsolutePath() : "removable");
    }
    private static void writeStorageMap(Context ctx, java.io.File root) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("PRIM|/mnt/sdcard|internal\n");
            int n = 0;
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                android.os.storage.StorageManager sm =
                    (android.os.storage.StorageManager) ctx.getSystemService(Context.STORAGE_SERVICE);
                for (android.os.storage.StorageVolume v : sm.getStorageVolumes()) {
                    if (v.isPrimary() || !v.isRemovable()) continue;
                    java.io.File vol = v.getDirectory();
                    if (vol == null || !vol.isDirectory()) continue;
                    n++;
                    sb.append("EXT|/mnt/sd-ext").append(n).append('|')
                      .append(volumeLabel(ctx, v, vol)).append("\n");
                }
            }
            try {
                java.io.File[] dirs = ctx.getExternalFilesDirs(null);
                for (java.io.File d : dirs) {
                    String abs = d.getAbsolutePath();
                    if (abs == null || abs.startsWith("/storage/emulated/")) continue;
                    int i = abs.indexOf("/Android/data/");
                    String vol = (i > 0) ? abs.substring(0, i) : abs;
                    if (!new java.io.File(vol).isDirectory()) continue;
                    n++;
                    sb.append("EXT|/mnt/sd-ext").append(n).append('|')
                      .append("removable").append("\n");
                }
            } catch (Exception ignored) {}
            java.io.File f = new java.io.File(root, "etc/aetherix/storage.map");
            if (f.exists()) {
                String existing = new String(java.nio.file.Files.readAllBytes(f.toPath()));
                if (existing.equals(sb.toString())) return;
            }
            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(sb.toString().getBytes());
            fos.close();
        } catch (Exception e) { BridgeLogBuffer.append("Storage: storage.map: " + e); }
    }

    /** v0.3.3 telemetry: idempotent in-Alpine device-info CLI (key: value lines). */
    private static void writeDeviceInfo(File bin) {
        try {
            File f = new File(bin, "device-info");
            String content =
                "#!/bin/sh\n" +
                "# Aetherix-Alpine device-info: one-shot telemetry (key: value lines)\n" +
                "echo \"device: $(getprop ro.product.model 2>/dev/null || echo unknown)\"\n" +
                "echo \"board: $(getprop ro.board.platform 2>/dev/null || echo unknown)\"\n" +
                "echo \"soc: $(getprop ro.soc.model 2>/dev/null || echo unknown)\"\n" +
                "echo \"abi: $(getprop ro.product.cpu.abi 2>/dev/null || echo unknown)\"\n" +
                "b=/sys/class/power_supply/battery\n" +
                "if [ -r \"$b/capacity\" ]; then echo \"battery_pct: $(cat \"$b/capacity\")\"; else echo \"battery_pct: n/a\"; fi\n" +
                "if [ -r \"$b/temp\" ]; then echo \"battery_temp_c: $(($(cat \"$b/temp\") / 10))\"; else echo \"battery_temp_c: n/a\"; fi\n" +
                "mem=$(grep -m1 MemTotal /proc/meminfo 2>/dev/null | awk '{print $2}')\n" +
                "if [ -n \"$mem\" ]; then echo \"mem_total_kb: $mem\"; else echo \"mem_total_kb: n/a\"; fi\n" +
                "if [ -r /sys/kernel/gpu/gpu_model ]; then echo \"gpu: $(cat /sys/kernel/gpu/gpu_model)\"; elif [ -d /sys/kernel/gpu ]; then echo \"gpu: Mali\"; elif [ -d /sys/class/kgsl/kgsl-3d0 ]; then echo \"gpu: Adreno\"; else echo \"gpu: n/a\"; fi\n" +
                "tz=$(ls /sys/class/thermal/thermal_zone*/temp 2>/dev/null | head -1)\n" +
                "if [ -n \"$tz\" ]; then echo \"thermal_zone0_c: $(($(cat \"$tz\") / 1000))\"; else echo \"thermal_zone0_c: n/a\"; fi\n";
            if (f.exists()) {
                String existing = new String(java.nio.file.Files.readAllBytes(f.toPath()));
                if (existing.equals(content)) return;
            }
            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(content.getBytes());
            fos.close();
            f.setExecutable(true);
        } catch (Exception e) { BridgeLogBuffer.append("StorageTier: " + e); }
    }
}
