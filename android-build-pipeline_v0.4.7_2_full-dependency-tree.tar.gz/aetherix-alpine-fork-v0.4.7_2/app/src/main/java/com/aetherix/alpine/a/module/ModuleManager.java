package com.aetherix.alpine.a.module;

import android.content.Context;

import com.aetherix.alpine.a.BridgeLogBuffer;
import com.aetherix.alpine.a.StepResult;
import com.aetherix.alpine.a.StorageTier;
import com.aetherix.alpine.a.TarExtractor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.zip.GZIPInputStream;

/**
 * v0.3.2 module loader. A module is a gzip tar at
 * /sdcard/Download/Aetherix-Alpine-Fork/modules/<name>.tar.gz whose root holds
 * module.yml (name, version) and an optional post-install.sh. Install extracts
 * into the rootfs, records /etc/aetherix/modules.d/<name>/info, and runs
 * post-install.sh through the normal launcher shell. Re-install overwrites.
 */
public class ModuleManager {

    /** FB-063: live progress callback for async installs (InstallBridge
     *  installModuleAsync). Receives phase lines and post-install output. */
    public interface ProgressCallback {
        void onProgress(String message);
    }

    /** FB-063: line-at-a-time output streaming for runLauncher. */
    private interface LineCallback {
        void onLine(String line);
    }

    private static final long YAML_MAX = 64 * 1024;
    // FB-057: core-module post-install runs a large apk add (build-base, cmake,
    // git, curl, linux-headers, openssl-dev, ccache, ninja); give it room.
    private static final long POST_INSTALL_TIMEOUT_MS = 600000;
    private static final long UNINSTALL_TIMEOUT_MS = 60000;
    // v0.4.0: modules are shipped ONLY inside the APK (assets/modules/*.bundle).
    // Retired names are never listed or installed, and any leftovers from old
    // builds (drop-folder tarball, installed marker, tier CLI) are cleaned up.
    private static final String[] RETIRED_MODULES = {"gui-module"};

    private static boolean isRetired(String name) {
        if (name == null) return false;
        for (String r : RETIRED_MODULES) {
            if (r.equals(name)) return true;
        }
        return false;
    }

    private final Context context;
    private final String filesDir;
    private final File rootfs;

    public ModuleManager(Context context) {
        this.context = context;
        this.filesDir = context.getFilesDir().getAbsolutePath();
        this.rootfs = new File(filesDir, "rootfs/alpine");
    }

    private static boolean lastReadyLogged = true;

    public boolean rootfsReady() {
        // Alpine's apk database lives at lib/apk/db/installed (same path the
        // dashboard package counter reads); var/lib/apk/db does not exist.
        // FB-023: treat the rootfs as ready on the broadest correct evidence -
        // the extracted rootfs directory plus an Alpine marker, and accept the
        // persisted setup_complete.marker written when Step 7 passes as an
        // additional proof so a transient file check can never block modules
        // after a completed install.
        boolean dirOk = rootfs.isDirectory();
        boolean releaseOk = new File(rootfs, "etc/alpine-release").isFile();
        boolean shOk = new File(rootfs, "bin/sh").isFile();
        boolean apkDbOk = new File(rootfs, "lib/apk/db/installed").isFile();
        boolean markerOk = new File(filesDir, "setup_complete.marker").isFile();
        boolean ready = dirOk && (releaseOk || shOk) && (apkDbOk || markerOk);
        if (ready) {
            lastReadyLogged = true;
        } else if (lastReadyLogged) {
            BridgeLogBuffer.append("ModuleManager: rootfs not ready (dir=" + dirOk
                + " alpine-release=" + releaseOk + " bin/sh=" + shOk
                + " apk-db=" + apkDbOk + " setup-marker=" + markerOk + ")");
            lastReadyLogged = false;
        }
        return ready;
    }

    /** @JavascriptInterface detailed reason a module install is blocked (FB-023). */
    public String rootfsDiagnostics() {
        JSONObject d = new JSONObject();
        try {
            d.put("filesDir", filesDir);
            d.put("rootfs", rootfs.getAbsolutePath());
            d.put("dir", rootfs.isDirectory());
            d.put("alpineRelease", new File(rootfs, "etc/alpine-release").isFile());
            d.put("binSh", new File(rootfs, "bin/sh").isFile());
            d.put("busybox", new File(rootfs, "bin/busybox").isFile());
            d.put("apkDb", new File(rootfs, "lib/apk/db/installed").isFile());
            d.put("setupMarker", new File(filesDir, "setup_complete.marker").isFile());
            d.put("ready", rootfsReady());
        } catch (Exception ignored) {}
        return d.toString();
    }

    private File varDir() {
        return new File(rootfs, "var/lib/aetherix-modules");
    }

    private File infoDir() {
        return new File(rootfs, "etc/aetherix/modules.d");
    }

    private File sourceDir() {
        return new File(StorageTier.modulesDir());
    }

    /**
     * Names of modules bundled in the APK under assets/modules/.
     * Files are stored with a .bundle extension because aapt strips
     * compression-suffix extensions (e.g. .tar.gz) from asset names.
     */
    private List<String> bundledNames() {
        List<String> names = new ArrayList<String>();
        try {
            String[] assets = context.getAssets().list("modules");
            if (assets != null) {
                for (String a : assets) {
                    if (a.endsWith(".bundle")) {
                        String stem = a.substring(0, a.length() - 7);
                        String name = sanitize(stem);
                        if (name.length() > 0) names.add(name);
                    }
                }
            }
        } catch (Exception ignored) {}
        return names;
    }

    /** Copy assets/modules/<name>.bundle into the /sdcard drop folder as <name>.tar.gz. */
    private boolean copyBundledToSource(String name) {
        try {
            InputStream in = context.getAssets().open("modules/" + name + ".bundle");
            File dir = sourceDir();
            dir.mkdirs();
            File out = new File(dir, name + ".tar.gz");
            FileOutputStream fos = new FileOutputStream(out, false);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                fos.write(buf, 0, n);
            }
            fos.close();
            in.close();
            return out.isFile() && out.length() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** Full module.yml from the bundled copy (works pre-install). */
    private JSONObject bundledYaml(String name) {
        try {
            InputStream in = context.getAssets().open("modules/" + name + ".bundle");
            return peekModuleYaml(in);
        } catch (Exception ignored) {}
        return null;
    }

    /**
     * Mirror every APK-bundled module into the /sdcard drop folder so the guest
     * `module available` CLI and file managers can see them. Idempotent; the
     * APK copy always wins over a stale drop tarball (FB-048 policy).
     */
    public void syncBundledModules() {
        // v0.4.0: modules live in the APK only. The drop folder is no longer a
        // module source - remove anything there (old exports / user drops) so
        // the Modules page and guest CLI can never list or install from the
        // device, and clean retired-module leftovers from old builds.
        if (StorageTier.isStorageGranted(context)) cleanupDropFolder();
        cleanupRetired();
        writeBundledManifest();
    }

    /** Delete everything under the legacy drop-folder module dir. */
    private void cleanupDropFolder() {
        try {
            File dir = sourceDir();
            if (!dir.isDirectory()) return;
            File[] files = dir.listFiles();
            if (files == null) return;
            for (File f : files) deleteRecursive(f);
        } catch (Exception e) {
            BridgeLogBuffer.append("ModuleManager: cleanupDropFolder: " + e);
        }
    }

    /** Remove installed markers / tier CLIs of retired modules (idempotent). */
    private void cleanupRetired() {
        for (String name : RETIRED_MODULES) {
            try {
                File marker = new File(rootfs, "etc/aetherix/" + name + ".installed");
                File reg = new File(infoDir(), name);
                File code = new File(varDir(), name);
                boolean present = marker.isFile() || reg.isDirectory() || code.isDirectory();
                if (!present) continue;
                String tier = name.replace("-module", "");
                StepResult r = runLauncher(
                    "rm -f /usr/local/bin/" + tier
                    + " /etc/aetherix/" + name + ".installed"
                    + " /etc/aetherix/" + tier + ".state"
                    + " /etc/aetherix/" + tier + ".conf"
                    + "; rm -rf /etc/aetherix/modules.d/" + name
                    + " /var/lib/aetherix-modules/" + name,
                    UNINSTALL_TIMEOUT_MS);
                BridgeLogBuffer.append("ModuleManager: retired " + name
                    + " cleaned" + (r.success ? "" : " (guest cleanup warning)"));
            } catch (Exception e) {
                BridgeLogBuffer.append("ModuleManager: cleanupRetired " + name + ": " + e);
            }
        }
    }

    /** Write the APK-bundled module manifest the guest `module available` reads. */
    private void writeBundledManifest() {
        try {
            StringBuilder sb = new StringBuilder();
            for (String name : bundledNames()) {
                if (isRetired(name)) continue;
                JSONObject y = bundledYaml(name);
                String ver = y != null ? y.optString("version", "").trim() : "";
                String reqs = "";
                if (y != null) reqs = join(optStringList(y, "requires"));
                sb.append(name).append('\t').append(ver).append('\t').append(reqs).append('\n');
            }
            File f = new File(rootfs, "etc/aetherix/bundled-modules.txt");
            if (f.isFile()) {
                String existing = new String(java.nio.file.Files.readAllBytes(f.toPath()));
                if (existing.equals(sb.toString())) return;
            }
            f.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(sb.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            BridgeLogBuffer.append("ModuleManager: writeBundledManifest: " + e);
        }
    }

    private static String sanitize(String name) {
        if (name == null) return "";
        String s = name.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        if (s.equals("") || s.equals(".") || s.equals("..")) return "";
        return s;
    }

    /** @JavascriptInterface JSON list of available + installed modules. */
    public String listModules() {
        JSONArray arr = new JSONArray();
        List<String> seen = new ArrayList<String>();
        Set<String> installed = new HashSet<String>(installedNames());
        try {
            // v0.4.0: modules are bundled in the APK only - never enumerated
            // from the device drop folder.
            for (String name : bundledNames()) {
                if (isRetired(name)) continue;
                if (seen.contains(name)) continue;
                seen.add(name);
                JSONObject o = installedInfo(name);
                JSONObject y = bundledYaml(name);
                JSONObject m = new JSONObject();
                m.put("name", name);
                m.put("file", "bundled with app");
                m.put("available", true);
                m.put("bundled", true);
                m.put("installed", o != null);
                String v = o != null ? o.optString("version", "") : "";
                if (v.length() == 0 && y != null) v = y.optString("version", "").trim();
                m.put("version", v);
                decorate(m, y, installed);
                m.put("postInstall", hasPostInstall(name));
                m.put("setupReady", rootfsReady());
                arr.put(m);
            }
            for (String installedName : installedNames()) {
                if (isRetired(installedName)) continue;
                if (!seen.contains(installedName)) {
                    JSONObject o = installedInfo(installedName);
                    JSONObject m = new JSONObject();
                    m.put("name", installedName);
                    m.put("file", "");
                    m.put("available", false);
                    m.put("installed", true);
                    m.put("version", o != null ? o.optString("version", "") : "");
                    m.put("postInstall", hasPostInstall(installedName));
                    arr.put(m);
                }
            }
        } catch (Exception ignored) {}
        return arr.toString();
    }

    /**
     * FB-057: attach dependency metadata and gate availability. A module is
     * available only when every module in its `requires` list is installed;
     * blocked modules keep the missing deps so the UI can explain why.
     */
    private static void decorate(JSONObject m, JSONObject yaml, Set<String> installed) {
        try {
            if (yaml == null) return;
            m.put("description", yaml.optString("description", "").trim());
            List<String> requires = optStringList(yaml, "requires");
            m.put("requires", toJsonArray(requires));
            m.put("requiresPkgs", toJsonArray(optStringList(yaml, "requires-pkgs")));
            m.put("recommendsPkgs", toJsonArray(optStringList(yaml, "recommends-pkgs")));
            JSONArray missing = new JSONArray();
            for (String r : requires) {
                if (!installed.contains(r)) missing.put(r);
            }
            boolean depsOk = missing.length() == 0;
            m.put("missingRequires", missing);
            m.put("blocked", !depsOk);
            m.put("available", depsOk);
        } catch (Exception ignored) {}
    }

    /** Modules currently installed (registry dirs under etc/aetherix/modules.d). */
    private List<String> installedNames() {
        List<String> names = new ArrayList<String>();
        File dir = infoDir();
        if (dir.isDirectory()) {
            File[] entries = dir.listFiles();
            if (entries != null) {
                for (File e : entries) {
                    if (e.isDirectory()) names.add(sanitize(e.getName()));
                }
            }
        }
        return names;
    }

    private JSONObject installedInfo(String name) {
        try {
            File info = new File(infoDir(), name + "/info");
            if (!info.isFile()) return null;
            JSONObject o = new JSONObject();
            for (String line : readAll(info)) {
                int i = line.indexOf(':');
                if (i <= 0) continue;
                o.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
            }
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean hasPostInstall(String name) {
        return new File(varDir(), name + "/post-install.sh").isFile();
    }

    /** @JavascriptInterface install <name>.tar.gz from the modules drop folder.
     *  FB-048: bundled modules (hello/llm) always come from the APK so a
     *  stale drop-folder tarball can never downgrade them (e.g. a pre-tier
     *  hello-module that leaves sd/device-info/elv/module undeployed).
     *  FB-050: every phase is returned in "log" and mirrored to the error
     *  report log so the module page shows the full activity. */
    public String installModule(String name) {
        return installModule(name, null);
    }

    /** FB-063: install with a live progress callback. The callback is invoked
     *  from worker threads (background install + post-install output pump), so
     *  it must not touch the UI directly. */
    public String installModule(String name, ProgressCallback cb) {
        JSONObject result = new JSONObject();
        StringBuilder activity = new StringBuilder();
        try {
            String safe = sanitize(name);
            if (safe.length() == 0) {
                return failLogged(result, activity, "invalid module name");
            }
            moduleStep(activity, "deploying shared helpers...", cb);
            StorageTier.deploy(context);
            if (!rootfsReady()) {
                return failLogged(result, activity, "Alpine rootfs not ready - run Initiate Install on the dashboard first (all 7 steps must pass)");
            }
            if (!StorageTier.isStorageGranted(context)) {
                return failLogged(result, activity, "All-files access not granted - open the Storage card first");
            }
            if (isRetired(safe)) {
                return failLogged(result, activity, "retired module: " + safe + " is no longer shipped");
            }
            if (!bundledNames().contains(safe)) {
                return failLogged(result, activity, "module not found: " + safe + " (not bundled with this app version)");
            }
            moduleStep(activity, "using APK-bundled module source for " + safe + "...", cb);
            JSONObject yaml = bundledYaml(safe);
            if (yaml == null) {
                return failLogged(result, activity, "invalid module: module.yml missing or unreadable");
            }
            String yamlName = yaml.optString("name", "").trim();
            if (!yamlName.equals(safe)) {
                return failLogged(result, activity, "module.yml name '" + yamlName + "' does not match '" + safe + "'");
            }
            String version = yaml.optString("version", "").trim();
            if (version.length() == 0) version = "unknown";

            // FB-057: refuse install while a required module is missing.
            List<String> missingDeps = missingRequires(yaml);
            if (!missingDeps.isEmpty()) {
                return failLogged(result, activity, "cannot install " + safe + ": missing dependencies " + missingDeps
                    + " - install them first (start with core-module on the Modules page)");
            }

            moduleStep(activity, "extracting " + safe + " " + version + "...", cb);
            varDir().mkdirs();
            File stage = new File(varDir(), safe + ".tmp-" + UUID.randomUUID().toString().substring(0, 8));
            stage.mkdirs();
            try {
                TarExtractor te = new TarExtractor();
                InputStream in = new GZIPInputStream(context.getAssets().open("modules/" + safe + ".bundle"));
                te.extract(in, stage);
                in.close();
            } catch (Exception e) {
                deleteRecursive(stage);
                return failLogged(result, activity, "extract failed: " + e.getMessage());
            }

            File target = new File(varDir(), safe);
            deleteRecursive(target);
            if (!stage.renameTo(target)) {
                deleteRecursive(stage);
                return failLogged(result, activity, "could not finalize module directory");
            }

            File postInstall = new File(target, "post-install.sh");
            boolean hasPost = postInstall.isFile();
            if (hasPost) {
                postInstall.setExecutable(true);
            }

            moduleStep(activity, "registering module info...", cb);
            File infoFile = new File(infoDir(), safe + "/info");
            infoFile.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(infoFile, false);
            fos.write(("name: " + safe + "\n").getBytes());
            fos.write(("version: " + version + "\n").getBytes());
            fos.write(("installed: " + new java.util.Date().toString() + "\n").getBytes());
            List<String> reqs = optStringList(yaml, "requires");
            if (!reqs.isEmpty()) {
                fos.write(("requires: " + join(reqs) + "\n").getBytes());
            }
            fos.close();

            String postOut = "";
            if (hasPost) {
                moduleStep(activity, "running post-install in the guest...", cb);
                final String jobId = safe + "-install";
                jobState(jobId, "running", "post-install starting...", -1, -1, -1);
                StepResult r = runLauncher(
                    "sh /var/lib/aetherix-modules/" + safe + "/post-install.sh",
                    POST_INSTALL_TIMEOUT_MS,
                    cb == null ? null : line -> { jobTick(jobId, line); cb.onProgress(line); });
                postOut = r.output.trim();
                if (postOut.length() > 0) activity.append(postOut).append('\n');
                jobState(jobId, r.success ? "done" : "failed",
                    r.success ? "post-install OK" : "post-install failed", 100, 100, 100);
                if (!r.success) {
                    return failLogged(result, activity, "post-install failed: " + (r.error != null ? r.error : postOut));
                }
            }

            result.put("ok", true);
            result.put("message", "installed " + safe + " " + version + (hasPost ? " (post-install OK)" : ""));
            result.put("output", postOut);
            moduleStep(activity, "installed " + safe + " " + version + " (post-install OK)", cb);
        } catch (Exception e) {
            return failLogged(result, activity, "install failed: " + e.getMessage());
        }
        try {
            result.put("log", activity.toString().trim());
        } catch (Exception ignored) {}
        return result.toString();
    }

    /** FB-050: record a phase in both the returned activity log and the report. */
    private static void moduleStep(StringBuilder activity, String what) {
        moduleStep(activity, what, null);
    }

    private static void moduleStep(StringBuilder activity, String what, ProgressCallback cb) {
        activity.append(what).append('\n');
        BridgeLogBuffer.append("ModuleManager: " + what);
        if (cb != null) {
            try { cb.onProgress(what); } catch (Exception ignored) {}
        }
    }

    private static String failLogged(JSONObject result, StringBuilder activity, String message) {
        try {
            result.put("log", activity.toString().trim());
        } catch (Exception ignored) {}
        return fail(result, message);
    }

    /** @JavascriptInterface remove a module and its bookkeeping (FB-044).
     *  mode "code" removes the module entry + installed marker but keeps the
     *  deployed guest tools; mode "full" also removes the module's tier CLIs,
     *  state/conf and /opt/aetherix-tests so nothing from the module remains. */
    public String uninstallModule(String name, String mode) {
        JSONObject result = new JSONObject();
        try {
            String safe = sanitize(name);
            if (safe.length() == 0) return fail(result, "invalid module name");
            boolean full = "full".equals(mode);

            // FB-057: refuse to remove a module other installed modules depend on.
            List<String> dependents = dependentsOf(safe);
            if (!dependents.isEmpty()) {
                return fail(result, "cannot uninstall " + safe + ": required by " + dependents
                    + " - uninstall those modules first");
            }

            // Collect the module's deployed tier CLI names before the dir goes.
            java.util.List<String> tiers = new java.util.ArrayList<String>();
            File tierDir = new File(new File(varDir(), safe), "tier");
            File[] tierFiles = tierDir.isDirectory() ? tierDir.listFiles() : null;
            if (tierFiles != null) {
                for (File t : tierFiles) {
                    String b = t.getName();
                    if (b.matches("[A-Za-z0-9._-]+")) tiers.add(b);
                }
            }

            StringBuilder activity = new StringBuilder();
            moduleStep(activity, (full ? "full erase" : "code-only") + " uninstall of " + safe);
            moduleStep(activity, "removing module code + registry...");
            boolean removed = deleteRecursive(new File(varDir(), safe));
            removed |= deleteRecursive(new File(infoDir(), safe));
            // The installed marker is what the splash / module status read;
            // it goes away in both modes so the module disappears from the UI.
            removed |= deleteRecursive(new File(rootfs, "etc/aetherix/" + safe + ".installed"));

            if (full) {
                StringBuilder cmd = new StringBuilder("rm -f");
                for (String t : tiers) cmd.append(" /usr/local/bin/").append(t);
                cmd.append("; rm -rf /opt/aetherix-tests");
                cmd.append("; rm -f /usr/local/bin/aetherix-selftest /usr/local/bin/aetherix-smoke");
                // State/conf files use the tier stem, not the module name
                // (llm.state / llm.conf), so clear both patterns.
                cmd.append("; rm -f /etc/aetherix/").append(safe).append(".state");
                cmd.append(" /etc/aetherix/").append(safe).append(".conf");
                for (String t : tiers) {
                    cmd.append(" /etc/aetherix/").append(t).append(".state");
                    cmd.append(" /etc/aetherix/").append(t).append(".conf");
                }
                StepResult r = runLauncher(cmd.toString(), UNINSTALL_TIMEOUT_MS);
                if (!r.success) {
                    BridgeLogBuffer.append("ModuleManager: uninstall guest cleanup failed for "
                        + safe + ": " + r.error);
                }
            }

            result.put("ok", removed || !new File(varDir(), safe).exists());
            result.put("message", "uninstalled " + safe + (full ? " (full erase)" : " (code only)"));
            moduleStep(activity, "done: " + result.optString("message"));
            try {
                result.put("log", activity.toString().trim());
            } catch (Exception ignored) {}
            BridgeLogBuffer.append("ModuleManager: uninstalled " + safe + (full ? " full" : " code-only"));
        } catch (Exception e) {
            return fail(result, "uninstall failed: " + e.getMessage());
        }
        return result.toString();
    }

    /** Compatibility overload: default to code-only removal. */
    public String uninstallModule(String name) {
        return uninstallModule(name, "code");
    }

    private static boolean deleteRecursive(File f) {
        if (!f.exists()) return false;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) {
                for (File c : children) deleteRecursive(c);
            }
        }
        return f.delete();
    }

    /** Write/update a job state file the app's activity dock renders. */
    private void jobState(String id, String status, String task, int cur, int tot, int pct) {
        try {
            File dir = new File(rootfs, "etc/aetherix/jobs");
            dir.mkdirs();
            File f = new File(dir, id + ".state");
            StringBuilder sb = new StringBuilder();
            sb.append("id=").append(id).append('\n');
            sb.append("status=").append(status).append('\n');
            sb.append("task=").append(task.replace('\n', ' ').trim()).append('\n');
            sb.append("cur=").append(cur).append('\n');
            sb.append("tot=").append(tot).append('\n');
            sb.append("pct=").append(pct).append('\n');
            sb.append("started=").append(System.currentTimeMillis() / 1000).append('\n');
            if (status.equals("done") || status.equals("failed")) {
                sb.append("finished=").append(System.currentTimeMillis() / 1000).append('\n');
            }
            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(sb.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            BridgeLogBuffer.append("ModuleManager: jobState " + id + ": " + e);
        }
    }

    /** Parse a post-install output line for apk (N/M) / cmake [N/M] progress. */
    private void jobTick(String id, String line) {
        try {
            if (line == null) return;
            String t = line.trim();
            if (t.length() == 0) return;
            int cur = -1, tot = -1;
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\((\\d+)/(\\d+)\\)").matcher(t);
            if (m.find()) {
                cur = Integer.parseInt(m.group(1));
                tot = Integer.parseInt(m.group(2));
            } else {
                m = java.util.regex.Pattern.compile("\\[(\\d+)/(\\d+)\\]").matcher(t);
                if (m.find()) {
                    cur = Integer.parseInt(m.group(1));
                    tot = Integer.parseInt(m.group(2));
                }
            }
            int pct = tot > 0 ? Math.min(100, cur * 100 / tot) : -1;
            jobState(id, "running", t, cur, tot, pct);
        } catch (Exception e) {
            BridgeLogBuffer.append("ModuleManager: jobTick " + id + ": " + e);
        }
    }

    private static String fail(JSONObject result, String message) {
        try {
            result.put("ok", false);
            result.put("message", message);
        } catch (Exception ignored) {}
        return result.toString();
    }

    /** Read module.yml from the tarball without extracting the whole thing. */
    private JSONObject peekModuleYaml(File tarGz) {
        try {
            return peekModuleYaml(new FileInputStream(tarGz));
        } catch (Exception e) {
            return null;
        }
    }

    /** Read module.yml from a gzip tar stream without extracting the whole thing. */
    private JSONObject peekModuleYaml(InputStream in) {
        GZIPInputStream gz = null;
        try {
            gz = new GZIPInputStream(in);
            byte[] header = new byte[512];
            while (true) {
                int n = readFull(gz, header);
                if (n < 512) break;
                if (isZeroBlock(header)) break;
                char type = (char) header[156];
                long size = parseOct(header, 124, 12);
                String entryName = readTarName(header);
                if (type == 'x' || type == 'g') {
                    skip(gz, size + pad(size));
                    continue;
                }
                if (size > YAML_MAX) {
                    skip(gz, size + pad(size));
                    continue;
                }
                if (entryName.equals("module.yml")) {
                    byte[] body = new byte[(int) size];
                    int got = readFull(gz, body);
                    if (got >= (int) size) {
                        return parseYaml(new String(body, 0, (int) size, "UTF-8"));
                    }
                    break;
                }
                skip(gz, size + pad(size));
            }
        } catch (Exception ignored) {
        } finally {
            if (gz != null) {
                try { gz.close(); } catch (Exception ignored) {}
            }
        }
        return null;
    }

    private static long pad(long size) {
        return (512 - (size % 512)) % 512;
    }

    private static int readFull(InputStream in, byte[] buf) {
        int off = 0;
        try {
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
        } catch (Exception e) {
            return off;
        }
        return off;
    }

    private static void skip(InputStream in, long n) {
        long remaining = n;
        try {
            while (remaining > 0) {
                long s = in.skip(remaining);
                if (s <= 0) {
                    if (in.read() < 0) return;
                    remaining--;
                } else {
                    remaining -= s;
                }
            }
        } catch (Exception ignored) {}
    }

    private static boolean isZeroBlock(byte[] h) {
        for (byte b : h) {
            if (b != 0) return false;
        }
        return true;
    }

    private static String readTarName(byte[] h) {
        int len = 100;
        int i = 0;
        while (i < len && h[i] != 0) i++;
        String name = new String(h, 0, i);
        if (name.startsWith("./")) name = name.substring(2);
        return name;
    }

    private static long parseOct(byte[] h, int off, int len) {
        long v = 0;
        for (int i = off; i < off + len; i++) {
            if (h[i] < '0' || h[i] > '7') break;
            v = v * 8 + (h[i] - '0');
        }
        return v;
    }

    private static JSONObject parseYaml(String text) {
        JSONObject o = new JSONObject();
        try {
            for (String line : text.split("\n")) {
                String l = line.trim();
                if (l.length() == 0 || l.startsWith("#")) continue;
                int i = l.indexOf(':');
                if (i <= 0) continue;
                String key = l.substring(0, i).trim();
                String value = l.substring(i + 1).trim();
                if (key.equals("name") || key.equals("version") || key.equals("description")) {
                    o.put(key, value);
                } else if (key.equals("requires") || key.equals("requires-pkgs") || key.equals("recommends-pkgs")) {
                    o.put(key, csvList(value));
                }
            }
        } catch (Exception ignored) {}
        return o;
    }

    /** "a, b, [c]" -> [a, b, c] */
    private static List<String> csvList(String value) {
        List<String> out = new ArrayList<String>();
        String s2 = value.trim();
        if (s2.startsWith("[")) s2 = s2.substring(1);
        if (s2.endsWith("]")) s2 = s2.substring(0, s2.length() - 1);
        for (String p : s2.split(",")) {
            String t = p.trim();
            if (t.length() > 0) out.add(t);
        }
        return out;
    }

    /** Read a list value whether parseYaml stored it as a JSON array or raw text. */
    private static List<String> optStringList(JSONObject o, String key) {
        List<String> out = new ArrayList<String>();
        JSONArray arr = o.optJSONArray(key);
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                String s2 = arr.optString(i, "").trim();
                if (s2.length() > 0) out.add(s2);
            }
            return out;
        }
        String raw = o.optString(key, "").trim();
        if (raw.length() > 0) out.addAll(csvList(raw));
        return out;
    }

    private static JSONArray toJsonArray(List<String> list) {
        JSONArray arr = new JSONArray();
        for (String s2 : list) arr.put(s2);
        return arr;
    }

    private static String join(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(list.get(i));
        }
        return sb.toString();
    }

    /** Required modules of `yaml` that are not installed (empty = installable). */
    private List<String> missingRequires(JSONObject yaml) {
        List<String> out = new ArrayList<String>();
        if (yaml == null) return out;
        List<String> requires = optStringList(yaml, "requires");
        if (requires.isEmpty()) return out;
        Set<String> installed = new HashSet<String>(installedNames());
        for (String r : requires) {
            if (!installed.contains(r)) out.add(r);
        }
        return out;
    }

    /** Installed modules whose `requires` includes `name` (reverse dependency). */
    private List<String> dependentsOf(String name) {
        List<String> out = new ArrayList<String>();
        for (String installed : installedNames()) {
            if (installed.equals(name)) continue;
            JSONObject info = installedInfo(installed);
            if (info == null) continue;
            String req = info.optString("requires", "").trim();
            if (req.length() == 0) continue;
            for (String r : req.split(",")) {
                if (r.trim().equals(name)) {
                    out.add(installed);
                    break;
                }
            }
        }
        return out;
    }

    private static List<String> readAll(File f) {
        List<String> lines = new ArrayList<String>();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) lines.add(line);
            br.close();
        } catch (Exception ignored) {}
        return lines;
    }

    /** Run a command inside the proot launcher (normal login shell env). */
    private StepResult runLauncher(String command, long timeoutMs) {
        return runLauncher(command, timeoutMs, null);
    }

    /** FB-063: runLauncher with line-at-a-time streaming (used for live
     *  post-install output; the callback fires from the pump threads). */
    private StepResult runLauncher(String command, long timeoutMs, LineCallback cb) {
        try {
            String launcher = filesDir + "/proot/proot-launch.sh";
            String quoted = command.replace("'", "'\\''");
            Process p = Runtime.getRuntime().exec(new String[]{
                "/system/bin/sh", "-c",
                "/system/bin/sh \"" + launcher + "\" '" + quoted + "'"
            });
            final StringBuilder out = new StringBuilder();
            final StringBuilder err = new StringBuilder();
            Thread t1 = pump(p.getInputStream(), out, cb);
            Thread t2 = pump(p.getErrorStream(), err, cb);
            t1.start();
            t2.start();
            boolean done = false;
            long deadline = System.currentTimeMillis() + timeoutMs;
            while (System.currentTimeMillis() < deadline) {
                try {
                    p.exitValue();
                    done = true;
                    break;
                } catch (IllegalThreadStateException e) {
                    try { Thread.sleep(200); } catch (InterruptedException ie) { break; }
                }
            }
            if (!done) {
                p.destroy();
                return new StepResult(false, out.toString() + err.toString(), "timeout after " + (timeoutMs / 1000) + "s");
            }
            t1.join(2000);
            t2.join(2000);
            return new StepResult(p.exitValue() == 0,
                (out.toString() + err.toString()).trim(),
                p.exitValue() == 0 ? "" : "exit code " + p.exitValue());
        } catch (Exception e) {
            return new StepResult(false, "", "launcher error: " + e.getMessage());
        }
    }

    private Thread pump(final InputStream in, final StringBuilder sb, final LineCallback cb) {
        return new Thread(new Runnable() {
            public void run() {
                try {
                    java.io.BufferedReader reader =
                        new java.io.BufferedReader(new java.io.InputStreamReader(in));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        synchronized (sb) {
                            sb.append(line).append('\n');
                        }
                        if (cb != null) {
                            try { cb.onLine(line); } catch (Exception ignored) {}
                        }
                    }
                } catch (Exception ignored) {}
            }
        });
    }
}
