package com.aetherix.alpine.a;

import java.io.File;
import java.io.FileOutputStream;

/**
 * FB-039/F7: shared login splash — compact Termux-style welcome with installed
 * modules and the always-present command cheatsheet. Written by Step 5 (fresh
 * installs) and refreshed idempotently by StorageTier.deploy() so existing
 * installs get it without a setup re-run.
 */
final class WelcomeScript {

    private WelcomeScript() {}

    static String content() {
        return "apk() {\n" +
            "  # v0.4.0: long interactive apk adds run detached through the job\n" +
            "  # dock (prompt returns immediately); scripts and other calls stay\n" +
            "  # synchronous because they are not interactive tty sessions.\n" +
            "  if [ \"${AETHERIX_DOCK:-0}\" = \"1\" ] && [ -t 0 ] && command -v job >/dev/null 2>&1 && [ \"$1\" = \"add\" ]; then\n" +
            "    job run \"apk-add-$$\" /sbin/apk \"$@\"\n" +
            "    return $?\n" +
            "  fi\n" +
            "  command apk \"$@\"\n" +
            "}\n" +
            "if [ -z \"$PROOT_WELCOME_SHOWN\" ]; then\n" +
            "  export PROOT_WELCOME_SHOWN=1\n" +
            "  echo ''\n" +
            "  echo '  =============================================='\n" +
            "  echo '    Welcome to Aetherix-Alpine'\n" +
            "  echo \"    ${AETHERIX_VERSION:-dev}  |  Alpine $(cat /etc/alpine-release 2>/dev/null)  |  \"$(apk list --installed 2>/dev/null | wc -l)\" packages\"\n" +
            "  echo '  =============================================='\n" +
            "  echo ''\n" +
            "  mods=$(ls /etc/aetherix/*.installed 2>/dev/null | sed 's|.*/||; s|\\.installed$||' | tr '\\n' ' ')\n" +
            "  [ -z \"$mods\" ] && mods=none\n" +
            "  echo \"  Installed modules: $mods\"\n" +
            "  echo ''\n" +
            "  echo '  What would you like to do?'\n" +
            "  echo '    sd mount                map device storage into ~/storage (one source)'\n" +
            "  echo '    module help             how to install modules + use this system'\n" +
            "  command -v elv >/dev/null 2>&1 && echo '    elv setup && elv shell   adb elevation (shell uid 2000)'\n" +
            "  [ -f /etc/aetherix/core-module.installed ] && echo '    core status               shared base + toolchain (module deps)'\n" +
            "  [ -f /etc/aetherix/llm-module.installed ] && echo '    llm setup && llm start   local AI chat via llama.cpp (llm help)'\n" +
            "  [ \"$(cat /etc/aetherix/llm.build.state 2>/dev/null)\" = building ] && echo \"    llm build-status         llama.cpp building (dock bar below)\"\n" +
            "  [ -f /etc/aetherix/hello-module.installed ] && echo '    aetherix-selftest       run environment checks'\n" +
            "  [ -f /etc/aetherix/hello-module.installed ] && echo '    aetherix-smoke           quick smoke test'\n" +
            "  echo ''\n" +
            "fi\n";
    }

    /** Idempotent deploy of etc/profile.d/00-welcome.sh; true when written. */
    static boolean writeTo(File rootfs) {
        try {
            File profileDir = new File(rootfs, "etc/profile.d");
            profileDir.mkdirs();
            File f = new File(profileDir, "00-welcome.sh");
            byte[] content = content().getBytes();
            if (f.isFile()) {
                byte[] existing = java.nio.file.Files.readAllBytes(f.toPath());
                if (java.util.Arrays.equals(existing, content)) return false;
            }
            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(content);
            fos.close();
            return true;
        } catch (Exception e) {
            BridgeLogBuffer.append("WelcomeScript: " + e);
            return false;
        }
    }
}
