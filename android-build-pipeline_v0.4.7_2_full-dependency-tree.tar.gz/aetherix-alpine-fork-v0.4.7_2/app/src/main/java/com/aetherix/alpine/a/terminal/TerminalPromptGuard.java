package com.aetherix.alpine.a.terminal;

/**
 * Decides whether a visible prompt line holds typed content, so the SPACE+DEL
 * resize primer never overwrites/erasures a running command line. bash prompts
 * end in a terminator char (':', '#', '$', '%', '>'); typed text appends
 * characters that do not. null / empty lines = no content (safe to prime).
 */
final class TerminalPromptGuard {
    private static final String PROMPT_TERMINATORS = ":#$%>";

    private TerminalPromptGuard() {}

    /** @return true if the line holds typed input (priming must be skipped) */
    static boolean hasTypedContent(String line) {
        if (line == null) return true;
        String t = line.replaceAll("[ \\t\\r]*$", "");
        if (t.length() == 0) return false;
        return PROMPT_TERMINATORS.indexOf(t.charAt(t.length() - 1)) < 0;
    }
}