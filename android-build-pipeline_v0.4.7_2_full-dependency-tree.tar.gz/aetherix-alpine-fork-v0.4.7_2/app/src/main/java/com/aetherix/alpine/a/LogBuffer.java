package com.aetherix.alpine.a;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;

public class LogBuffer {

    private static final int MAX_LINES = 500;
    private static LogBuffer instance;

    private final LinkedList<String> lines = new LinkedList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.US);

    private LogBuffer() {}

    public static synchronized LogBuffer getInstance() {
        if (instance == null) {
            instance = new LogBuffer();
        }
        return instance;
    }

    public synchronized void append(String msg) {
        String ts = sdf.format(new Date());
        lines.add("[" + ts + "] " + msg);
        while (lines.size() > MAX_LINES) {
            lines.removeFirst();
        }
    }

    public synchronized void appendCommand(String cmd) {
        append("$ " + cmd);
    }

    public synchronized void appendOutput(String line) {
        append("  " + line);
    }

    public synchronized String getText() {
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(line).append("\n");
        }
        return sb.toString();
    }

    public synchronized String getTail(int n) {
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, lines.size() - n);
        for (int i = start; i < lines.size(); i++) {
            sb.append(lines.get(i)).append("\n");
        }
        return sb.toString();
    }

    public synchronized void clear() {
        lines.clear();
    }
}
