package com.aetherix.alpine.a;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

public class TarExtractor {

    private static final int BLOCK_SIZE = 512;

    private String paxPath;
    private String paxLinkPath;

    public void extract(InputStream tarIn, File destDir) throws IOException {
        byte[] header = new byte[BLOCK_SIZE];
        paxPath = null;
        paxLinkPath = null;

        while (true) {
            int read = fillBuffer(tarIn, header);
            if (read < BLOCK_SIZE) break;
            if (isEndOfArchive(header)) break;

            char type = (char) header[156];
            int size = parseOct(header, 124, 12);

            if (type == 'x' || type == 'g') {
                byte[] body = new byte[size];
                fillBuffer(tarIn, body);
                paxPath = null;
                paxLinkPath = null;
                parsePaxBody(body);
                skipPadding(tarIn, size);

                read = fillBuffer(tarIn, header);
                if (read < BLOCK_SIZE) break;
                if (isEndOfArchive(header)) break;
                size = parseOct(header, 124, 12);
                type = (char) header[156];

                String nameOverride = paxPath;
                String linkOverride = paxLinkPath;
                extractEntry(header, type, size, tarIn, destDir, nameOverride, linkOverride);
                paxPath = null;
                paxLinkPath = null;
                continue;
            }

            extractEntry(header, type, size, tarIn, destDir, null, null);
        }
    }

    private void extractEntry(byte[] header, char type, int size,
                              InputStream in, File destDir,
                              String nameOverride, String linkOverride) throws IOException {
        String name = (nameOverride != null) ? nameOverride : readName(header);
        String linkName = linkOverride;
        int mode = parseOct(header, 100, 8);

        if (type == '1' || type == '2') {
            if (linkName == null) {
                linkName = readNameAt(header, 157);
            }
        }

        File entry = new File(destDir, name);
        String canonicalDest = destDir.getCanonicalPath();
        String canonicalEntry = entry.getCanonicalPath();
        if (!canonicalEntry.startsWith(canonicalDest + File.separator) &&
            !canonicalEntry.equals(canonicalDest)) {
            skipData(in, size);
            throw new IOException("Path traversal detected: " + name);
        }

        switch (type) {
            case '0':
            case '\0':
            case '7': {
                entry.getParentFile().mkdirs();
                writeFile(in, entry, size);
                if ((mode & 0111) != 0) entry.setExecutable(true, false);
                break;
            }
            case '5': {
                if (!entry.exists()) {
                    entry.mkdirs();
                }
                if ((mode & 0111) != 0) entry.setExecutable(true, false);
                break;
            }
            case '2': {
                entry.getParentFile().mkdirs();
                String target = (linkName != null) ? linkName : "";
                File linkFile = new File(target);
                if (!linkFile.isAbsolute()) {
                    linkFile = new File(entry.getParentFile(), target);
                }
                try {
                    java.nio.file.Files.createSymbolicLink(entry.toPath(), linkFile.toPath());
                } catch (IOException e) {
                    if (e.getMessage() != null && e.getMessage().contains("FileExists")) {
                        entry.delete();
                        java.nio.file.Files.createSymbolicLink(entry.toPath(), linkFile.toPath());
                    } else {
                        copyViaStream(entry, linkFile);
                    }
                }
                break;
            }
            case '1': {
                entry.getParentFile().mkdirs();
                String target = (linkName != null) ? linkName : "";
                File targetFile;
                if (new File(target).isAbsolute()) {
                    targetFile = new File(target);
                } else {
                    targetFile = new File(destDir, target);
                }
                try {
                    java.nio.file.Files.createLink(entry.toPath(), targetFile.toPath());
                } catch (IOException e) {
                    if (e.getMessage() != null && e.getMessage().contains("FileExists")) {
                        entry.delete();
                        java.nio.file.Files.createLink(entry.toPath(), targetFile.toPath());
                    }
                }
                break;
            }
            default: {
                skipData(in, size);
                break;
            }
        }
    }

    private void parsePaxBody(byte[] body) {
        int i = 0;
        while (i < body.length) {
            int start = i;
            while (i < body.length && body[i] != '\n') i++;
            if (i >= body.length) break;
            String line = new String(body, start, i - start);
            i++;

            int space = line.indexOf(' ');
            if (space < 0) continue;
            String kv = line.substring(space + 1);
            int eq = kv.indexOf('=');
            if (eq < 0) continue;
            String key = kv.substring(0, eq);
            String value = kv.substring(eq + 1);

            if (key.equals("path")) {
                paxPath = value;
            } else if (key.equals("linkpath")) {
                paxLinkPath = value;
            }
        }
    }

    private String readName(byte[] header) {
        String prefix = readNameAt(header, 345);
        String name = readNameAt(header, 0);
        if (prefix.isEmpty()) return name;
        return prefix + "/" + name;
    }

    private String readNameAt(byte[] header, int offset) {
        int end = offset;
        while (end < header.length && header[end] != 0) end++;
        return new String(header, offset, end - offset);
    }

    private int parseOct(byte[] buf, int offset, int len) {
        int start = offset;
        int end = offset + len;
        while (start < end && (buf[start] == 0 || buf[start] == ' ')) start++;
        while (end > start && (buf[end - 1] == 0 || buf[end - 1] == ' ')) end--;
        if (start >= end) return 0;
        return Integer.parseInt(new String(buf, start, end - start), 8);
    }

    private void writeFile(InputStream in, File dest, int size) throws IOException {
        OutputStream out = new FileOutputStream(dest);
        byte[] buf = new byte[32768];
        int remaining = size;
        while (remaining > 0) {
            int chunk = Math.min(buf.length, remaining);
            fillBuffer(in, buf, 0, chunk);
            out.write(buf, 0, chunk);
            remaining -= chunk;
        }
        out.close();
        skipPadding(in, size);
    }

    private void skipData(InputStream in, int size) throws IOException {
        long remaining = size;
        while (remaining > 0) {
            long skipped = in.skip(remaining);
            if (skipped <= 0) {
                byte[] tmp = new byte[(int) Math.min(remaining, 32768)];
                fillBuffer(in, tmp, 0, tmp.length);
                remaining -= tmp.length;
            } else {
                remaining -= skipped;
            }
        }
        skipPadding(in, size);
    }

    private int fillBuffer(InputStream in, byte[] buf) throws IOException {
        return fillBuffer(in, buf, 0, buf.length);
    }

    private int fillBuffer(InputStream in, byte[] buf, int off, int len) throws IOException {
        int total = 0;
        while (total < len) {
            int read = in.read(buf, off + total, len - total);
            if (read < 0) break;
            total += read;
        }
        return total;
    }

    private void skipPadding(InputStream in, int dataSize) throws IOException {
        int pad = (BLOCK_SIZE - (dataSize % BLOCK_SIZE)) % BLOCK_SIZE;
        if (pad > 0) {
            long skipped = 0;
            while (skipped < pad) {
                long s = in.skip(pad - skipped);
                if (s <= 0) {
                    byte[] tmp = new byte[(int) (pad - skipped)];
                    fillBuffer(in, tmp);
                    skipped = pad;
                } else {
                    skipped += s;
                }
            }
        }
    }

    private boolean isEndOfArchive(byte[] block) {
        for (byte b : block) {
            if (b != 0) return false;
        }
        return true;
    }

    private void copyViaStream(File dest, File src) throws IOException {
        dest.delete();
        dest.getParentFile().mkdirs();
        InputStream in = new FileInputStream(src);
        OutputStream out = new FileOutputStream(dest);
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
        }
        in.close();
        out.close();
    }
}
