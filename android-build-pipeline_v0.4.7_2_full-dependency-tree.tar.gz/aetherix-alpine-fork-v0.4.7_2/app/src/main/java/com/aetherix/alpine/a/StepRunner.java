package com.aetherix.alpine.a;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import com.aetherix.alpine.a.terminal.TerminalEmulator;
import com.aetherix.alpine.a.terminal.TerminalOutput;
import com.aetherix.alpine.a.terminal.TerminalSession;
import com.aetherix.alpine.a.terminal.TerminalSessionClient;
import com.aetherix.alpine.a.terminal.TerminalView;
import com.aetherix.alpine.a.terminal.TerminalViewClient;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.KeyEvent;
import android.view.MotionEvent;

public class StepRunner {

    public interface ConfirmationCallback {
        boolean onConfirm(String message);
    }

    public interface LogCallback {
        void onLog(String line);
        void onFinished(int stepIndex, boolean success, String output);
        ConfirmationCallback getConfirmationCallback();
        void onLiveResult(int stepIndex, String text);
    }

    private static class InternetTestResult {
        boolean success;
        int httpCode;
        String error;
        long timeMs;
    }

    public void runStep(final int stepIndex, final Context context, final LogBuffer log, final LogCallback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    StepResult result = executeStep(stepIndex, context, log, cb);
                    if (cb != null) {
                        cb.onFinished(stepIndex, result.success, result.output);
                    }
                } catch (Exception e) {
                    log.append("ERROR: " + e.getMessage());
                    if (cb != null) {
                        cb.onFinished(stepIndex, false, e.getMessage());
                    }
                }
            }
        }).start();
    }

    private StepResult executeStep(int stepIndex, Context context, LogBuffer log, LogCallback cb) {
        switch (stepIndex) {
            case 0: return step1Proot(context, log, cb);
            case 1: return step2Alpine(context, log, cb);
            case 2: return step3Diagnostics(context, log, cb);
            case 3: return step4Launcher(context, log, cb);
            case 4: return step5AlpineInit(context, log, cb);
            case 5: return step6PtyBridge(context, log, cb);
            case 6: return step7ShellVerify(context, log, cb);
            default: return new StepResult(false, "", "Unknown step " + stepIndex);
        }
    }

    public void verifyStep6UiSmoke(Context context, LogBuffer log) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                TerminalViewClient mockViewClient = new TerminalViewClient() {
                    public float onScale(float s) { return s; }
                    public void onSingleTapUp(android.view.MotionEvent e) {}
                    public boolean shouldBackButtonBeMappedToEscape() { return true; }
                    public boolean shouldEnforceCharBasedInput() { return false; }
                    public boolean shouldUseCtrlSpaceWorkaround() { return false; }
                    public boolean isTerminalViewSelected() { return true; }
                    public void copyModeChanged(boolean cm) {}
                    public boolean onKeyDown(int kc, android.view.KeyEvent e, TerminalSession s) { return false; }
                    public boolean onKeyUp(int kc, android.view.KeyEvent e) { return false; }
                    public boolean onLongPress(android.view.MotionEvent e) { return false; }
                    public boolean readControlKey() { return false; }
                    public boolean readAltKey() { return false; }
                    public boolean readShiftKey() { return false; }
                    public boolean readFnKey() { return false; }
                    public boolean onCodePoint(int cp, boolean ctrl, TerminalSession s) { return false; }
                    public void onEmulatorSet() {}
                    public void logError(String tag, String msg) {}
                    public void logWarn(String tag, String msg) {}
                    public void logInfo(String tag, String msg) {}
                    public void logDebug(String tag, String msg) {}
                    public void logVerbose(String tag, String msg) {}
                    public void logStackTraceWithMessage(String tag, String msg, Exception e) {}
                    public void logStackTrace(String tag, Exception e) {}
                };
                try {
                    TerminalView tv = new TerminalView(context, null);
                    tv.setTerminalViewClient(mockViewClient);
                    tv.setTextSize(12);
                    tv.measure(800, 1200);
                    tv.layout(0, 0, 800, 1200);
                    TerminalSession testSession = new TerminalSession(context, tv, 80, 24,
                        (int) tv.getFontWidth(), tv.getFontLineSpacing(), mockViewClient,
                        new String[]{"/system/bin/sh", "-c", "exit 0"});
                    tv.attachSession(testSession);
                    if (testSession.isRunning()) {
                        log.append("  TerminalView smoke: PASS");
                    } else {
                        log.append("  TerminalView smoke: SKIP (bridge not available)");
                    }
                } catch (NullPointerException e) {
                    log.append("  TerminalView smoke: FAIL - " + e.getClass().getSimpleName() + ": " + e.getMessage());
                } catch (RuntimeException e) {
                    log.append("  TerminalView smoke: FAIL - " + e.getClass().getSimpleName() + ": " + e.getMessage());
                } catch (Exception e) {
                    log.append("  TerminalView smoke: FAIL - " + e.getClass().getSimpleName() + ": " + e.getMessage());
                } catch (Error e) {
                    log.append("  TerminalView smoke: FAIL - " + e.getClass().getSimpleName() + ": " + e.getMessage());
                }
            }
        });
    }

    public boolean verify(int stepIndex, Context context, LogBuffer log) {
        File filesDir = context.getFilesDir();
        switch (stepIndex) {
            case 0: {
                String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
                File prootLib = new File(nativeLibDir, "libproot.so");
                File loaderLib = new File(nativeLibDir, "libproot-loader.so");
                File dexecLib = new File(nativeLibDir, "libdexec.so");
                File libDir = new File(filesDir, "proot/lib");
                return prootLib.exists()
                    && loaderLib.exists()
                    && dexecLib.exists()
                    && new File(libDir, "libtalloc.so.2").exists()
                    && new File(libDir, "libandroid-shmem.so").exists();
            }
            case 1: {
                File rootfs = new File(filesDir, "rootfs/alpine");
                File sh = new File(rootfs, "bin/sh");
                boolean hasSh = sh.exists()
                    || java.nio.file.Files.isSymbolicLink(sh.toPath());
                return new File(rootfs, "bin").exists()
                    && new File(rootfs, "etc").exists()
                    && hasSh
                    && new File(rootfs, "etc/alpine-release").exists();
            }
            case 2: {
                return new File(filesDir, "proot/.function_test_passed").exists();
            }
            case 3: {
                File f = new File(filesDir, "proot/proot-launch.sh");
                if (!f.exists()) return false;
                StepResult r = exec(context, "/system/bin/sh " + f.getAbsolutePath() + " 'echo OK'");
                return r.success && r.output.trim().endsWith("OK");
            }
            case 4: {
                File launcher = new File(filesDir, "proot/proot-launch.sh");
                if (!launcher.exists()) return false;
                StepResult r = exec(context, "/system/bin/sh " + launcher.getAbsolutePath() + " 'bash --version'");
                if (!r.success || !r.output.contains("bash")) return false;
                r = exec(context, "/system/bin/sh " + launcher.getAbsolutePath() + " 'apk --version'");
                return r.success && r.output.contains("apk");
            }
            case 5: {
                String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
                File bridge = new File(nativeLibDir, "libpty-bridge.so");
                if (!bridge.exists()) return false;
                StepResult r = execDirect(context, bridge.getAbsolutePath(),
                    "/system/bin/sh", "-c", "echo VERIFY_PTY_OK");
                return r.success && r.output.contains("VERIFY_PTY_OK");
            }
            case 6: {
                File launcher = new File(filesDir, "proot/proot-launch.sh");
                if (!launcher.exists()) return false;
                StepResult r = exec(context, "/system/bin/sh " + launcher.getAbsolutePath() + " 'uname -a && echo SHELL_READY'");
                if (!r.success || !r.output.contains("SHELL_READY")) return false;

                TerminalOutput mockSession = new TerminalOutput() {
                    public void write(byte[] data, int offset, int count) {}
                    public void titleChanged(String oldTitle, String newTitle) {}
                    public void onCopyTextToClipboard(String text) {}
                    public void onPasteTextFromClipboard() {}
                    public void onBell() {}
                    public void onColorsChanged() {}
                };
                TerminalSessionClient mockClient = new TerminalSessionClient() {
                    public Integer getTerminalCursorStyle() { return null; }
                    public void onTerminalCursorStateChange(boolean state) {}
                    public void logError(String tag, String msg) {}
                    public void logWarn(String tag, String msg) {}
                    public void logInfo(String tag, String msg) {}
                    public void logDebug(String tag, String msg) {}
                    public void logVerbose(String tag, String msg) {}
                    public void logStackTraceWithMessage(String tag, String msg, Exception e) {}
                    public void logStackTrace(String tag, Exception e) {}
                };
                try {
                    TerminalEmulator emulator = new TerminalEmulator(mockSession, 80, 24, 10, 20, null, mockClient);
                    byte[] input = "Hello Terminal\nLine two\n".getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    emulator.append(input, input.length);
                    String screenText = emulator.getScreen().getSelectedText(0, 0, 80, 24);
                    if (!screenText.contains("Hello Terminal") || !screenText.contains("Line two")) {
                        return false;
                    }
                } catch (Exception e) {
                    return false;
                }
                return true;
            }
            default: return false;
        }
    }

    private StepResult step1Proot(Context context, LogBuffer log, LogCallback cb) {
        log.append("Step 1/7: Installing PRoot Binary + Support Libraries");
        sendLog(cb, "Step 1/7: Installing PRoot Binary + Support Libraries");
        try {
            File prootDir = new File(context.getFilesDir(), "proot");
            prootDir.mkdirs();

            String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
            log.append("Native lib dir: " + nativeLibDir);
            sendLog(cb, "Native lib dir: " + nativeLibDir);

            File prootNative = new File(nativeLibDir, "libproot.so");
            log.append("Proot native lib exists: " + prootNative.exists()
                + " (" + prootNative.length() + " bytes)");
            sendLog(cb, "Proot native lib exists: " + prootNative.exists());

            String[] libs = {"libtalloc.so.2", "libandroid-shmem.so"};
            File libDir = new File(prootDir, "lib");
            libDir.mkdirs();
            AssetManager am = context.getAssets();
            for (String lib : libs) {
                InputStream lis = am.open(lib);
                File ldest = new File(libDir, lib);
                OutputStream los = new FileOutputStream(ldest);
                byte[] lbuf = new byte[65536];
                int llen;
                while ((llen = lis.read(lbuf)) > 0) {
                    los.write(lbuf, 0, llen);
                }
                lis.close();
                los.close();
                log.append("Library " + lib + ": " + ldest.length() + " bytes");
                sendLog(cb, "Library " + lib + " extracted");
            }

            if (!verify(0, context, log)) {
                log.append("ERROR: verification failed");
                sendLog(cb, "ERROR: verification failed");
                return new StepResult(false, "", "Verification failed");
            }

            log.append("Step 1 complete");
            sendLog(cb, "Step 1 complete");
            return new StepResult(true, "PRoot native lib + support libs installed", "");

        } catch (Exception e) {
            log.append("ERROR: " + e.getMessage());
            sendLog(cb, "ERROR: " + e.getMessage());
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult step2Alpine(Context context, LogBuffer log, LogCallback cb) {
        log.append("Step 2/7: Extracting Alpine Linux Rootfs");
        sendLog(cb, "Step 2/7: Extracting Alpine Linux Rootfs");
        try {
            File rootfsDir = new File(context.getFilesDir(), "rootfs/alpine");
            rootfsDir.mkdirs();

            log.append("Extracting alpine-minirootfs with built-in tar extractor...");
            sendLog(cb, "Extracting alpine-minirootfs...");

            AssetManager am = context.getAssets();
            InputStream in = am.open("alpine-minirootfs.tar");

            TarExtractor extractor = new TarExtractor();
            extractor.extract(in, rootfsDir);
            in.close();

            log.append("Verifying extraction...");
            sendLog(cb, "Verifying extraction...");

            if (verify(1, context, log)) {
                log.append("Rootfs verified: /bin, /etc, /bin/sh, /etc/alpine-release all present");
                sendLog(cb, "Rootfs verified");
            } else {
                String msg = "Extraction failed";
                log.append("ERROR: " + msg);
                sendLog(cb, "ERROR: " + msg);
                return new StepResult(false, "", msg);
            }

            log.append("Updating CA certificate bundle from asset...");
            sendLog(cb, "Updating CA cert bundle...");
            File caDest = new File(rootfsDir, "etc/ssl/certs/ca-certificates.crt");
            caDest.getParentFile().mkdirs();
            try {
                InputStream caIn = am.open("ca-certificates.crt");
                OutputStream caOut = new FileOutputStream(caDest);
                byte[] caBuf = new byte[65536];
                int caLen;
                while ((caLen = caIn.read(caBuf)) > 0) {
                    caOut.write(caBuf, 0, caLen);
                }
                caIn.close();
                caOut.close();
                log.append("CA bundle updated: " + caDest.length() + " bytes");
                sendLog(cb, "CA bundle updated");
            } catch (Exception e) {
                log.append("WARNING: could not update CA bundle: " + e.getMessage());
                sendLog(cb, "WARNING: CA bundle update failed");
            }

            // FB-043: git/curl in Alpine default to /etc/ssl/cert.pem, which the
            // minirootfs does not ship; point it at the bundle just written so
            // TLS works even if SSL_CERT_FILE is not honored by the git build.
            try {
                File certPem = new File(rootfsDir, "etc/ssl/cert.pem");
                File certBundle = new File(rootfsDir, "etc/ssl/certs/ca-certificates.crt");
                if (!certPem.exists() && certBundle.isFile()) {
                    java.nio.file.Files.createSymbolicLink(certPem.toPath(),
                        new File("/etc/ssl/certs/ca-certificates.crt").toPath());
                    log.append("CA cert.pem symlink created");
                }
            } catch (Exception e) {
                log.append("WARNING: could not create cert.pem symlink: " + e.getMessage());
            }

            log.append("Writing profile scripts...");
            sendLog(cb, "Writing profile scripts...");
            try {
                File profileDir = new File(rootfsDir, "etc/profile.d");
                profileDir.mkdirs();

                OutputStream welcomeOut = new FileOutputStream(
                    new File(profileDir, "00-welcome.sh"));
                String welcome = WelcomeScript.content();
                welcomeOut.write(welcome.getBytes());
                welcomeOut.close();

                OutputStream sslOut = new FileOutputStream(
                    new File(profileDir, "ssl-cert.sh"));
                String sslCert =
                    "# Point OpenSSL at the CA bundle directly (bypass symlinks)\n" +
                    "export SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt\n";
                sslOut.write(sslCert.getBytes());
                sslOut.close();

                // FB-043: belt-and-suspenders so tier CLIs resolve even if the
                // minirootfs /etc/profile ever stops setting PATH itself.
                OutputStream pathOut = new FileOutputStream(
                    new File(profileDir, "01-path.sh"));
                String pathScript =
                    "# Aetherix-Alpine: ensure tier CLIs are on PATH\n" +
                    "case \":$PATH:\" in\n" +
                    "  *:/usr/local/bin:*) ;;\n" +
                    "  *) export PATH=/usr/local/sbin:/usr/local/bin:$PATH ;;\n" +
                    "esac\n";
                pathOut.write(pathScript.getBytes());
                pathOut.close();

                log.append("Profile scripts written");
                sendLog(cb, "Profile scripts written");
            } catch (Exception e) {
                log.append("WARNING: could not write profile scripts: " + e.getMessage());
                sendLog(cb, "WARNING: profile scripts failed");
            }

            log.append("Writing DNS configuration...");
            sendLog(cb, "Writing DNS configuration...");
            File resolvConf = new File(rootfsDir, "etc/resolv.conf");
            try {
                String resolvContent =
                    "# Android host DNS forwarded by PRoot\n" +
                    "nameserver 8.8.8.8\n" +
                    "nameserver 1.1.1.1\n" +
                    "options attempts:2 timeout:2\n";
                OutputStream rcOut = new FileOutputStream(resolvConf);
                rcOut.write(resolvContent.getBytes());
                rcOut.close();
                log.append("  /etc/resolv.conf: 8.8.8.8, 1.1.1.1");
                sendLog(cb, "resolv.conf written");
            } catch (Exception e) {
                log.append("WARNING: could not write resolv.conf: " + e.getMessage());
                sendLog(cb, "WARNING: resolv.conf failed");
            }

            log.append("Step 2 complete");
            sendLog(cb, "Step 2 complete");
            return new StepResult(true, "Alpine rootfs extracted", "");

        } catch (Exception e) {
            log.append("ERROR: " + e.getMessage());
            sendLog(cb, "ERROR: " + e.getMessage());
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult step3Diagnostics(Context context, LogBuffer log, LogCallback cb) {
        log.append("Step 3/7: Running System Diagnostics");
        sendLog(cb, "Step 3/7: Running System Diagnostics");
        try {
            String filesDir = context.getFilesDir().getAbsolutePath();
            String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
            String prootLibDir = filesDir + "/proot/lib";
            String rootfs = filesDir + "/rootfs/alpine";

            boolean allCritical = true;

            log.append("=== Diagnostic Checks ===");
            sendLog(cb, "Running diagnostics...");

            // 1. SELinux context
            log.append("[1/7] SELinux Domain...");
            StepResult selinux = exec(context, "cat /proc/self/attr/current");
            log.append("  Domain: " + selinux.output.trim());
            sendLog(cb, "Domain: " + selinux.output.trim());

            // 2. Basic shell test
            log.append("[2/7] Shell Test...");
            sendLog(cb, "Testing basic shell...");
            StepResult shell = exec(context, "/system/bin/sh -c 'echo FUNCTION_TEST_OK'");
            boolean shellOk = shell.success && shell.output.trim().equals("FUNCTION_TEST_OK");
            log.append("  Shell: " + (shellOk ? "PASS" : "FAIL"));
            sendLog(cb, "Shell: " + (shellOk ? "PASS" : "FAIL"));
            if (!shellOk) allCritical = false;

            // 3. Native lib exec test
            log.append("[3/7] PRoot Binary Execution...");
            sendLog(cb, "Testing PRoot binary...");
            StepResult prootTest = exec(context,
                "LD_LIBRARY_PATH=" + prootLibDir + " " + nativeLibDir + "/libproot.so 2>&1 || true");
            boolean prootOk = prootTest.success || prootTest.output.contains("proot");
            log.append("  PRoot: " + (prootOk ? "PASS" : "FAIL"));
            log.append("  Output: " + prootTest.output.trim().replace("\n", " | "));
            sendLog(cb, "PRoot exec: " + (prootOk ? "PASS" : "FAIL"));
            if (!prootOk) allCritical = false;

            // 4. Loader accessibility
            log.append("[4/7] PROOT_LOADER Check...");
            sendLog(cb, "Checking loader...");
            StepResult loaderStat = exec(context, "ls -l " + nativeLibDir + "/libproot-loader.so");
            log.append("  Loader: " + (loaderStat.success ? "PASS" : "FAIL"));
            log.append("  " + loaderStat.output.trim());
            sendLog(cb, "Loader: " + (loaderStat.success ? "PASS" : "FAIL"));
            if (!loaderStat.success) allCritical = false;

            // 5. Temp dir writability
            log.append("[5/7] Temp Dir Writable...");
            sendLog(cb, "Checking temp dir...");
            StepResult tmpTest = exec(context,
                "mkdir -p " + filesDir + "/proot/tmp && touch " + filesDir + "/proot/tmp/function_test_w && echo WRITABLE_OK");
            boolean tmpOk = tmpTest.success && tmpTest.output.contains("WRITABLE_OK");
            log.append("  Temp dir: " + (tmpOk ? "PASS" : "FAIL"));
            sendLog(cb, "Temp dir: " + (tmpOk ? "PASS" : "FAIL"));
            if (!tmpOk) allCritical = false;

            // 6. Rootfs details
            log.append("[6/7] Rootfs Integrity...");
            sendLog(cb, "Checking rootfs...");
            StepResult rootSh = exec(context, "ls -la " + rootfs + "/bin/sh");
            log.append("  bin/sh: " + rootSh.output.trim());
            sendLog(cb, "bin/sh: " + rootSh.output.trim());
            StepResult alpineRel = exec(context, "cat " + rootfs + "/etc/alpine-release");
            log.append("  Alpine: " + alpineRel.output.trim());
            sendLog(cb, "Alpine release: " + alpineRel.output.trim());
            StepResult rootBin = exec(context, "ls " + rootfs + "/bin/ | head -5");
            log.append("  bin/ contents: " + rootBin.output.trim().replace("\n", ", "));
            sendLog(cb, "Rootfs bin/: " + rootBin.output.trim().replace("\n", ", "));

            // 7. Critical rootfs libraries (apk dependencies)
            log.append("[7/7] Rootfs Library Diagnostics...");
            sendLog(cb, "Checking rootfs libraries...");
            String[] criticalLibs = {
                "lib/libz.so.1",
                "lib/libz.so.1.3.1",
                "lib/libcrypto.so.3",
                "lib/libssl.so.3",
                "lib/ld-musl-aarch64.so.1",
                "lib/libapk.so.2.14.0",
                "sbin/apk"
            };
            int libsFound = 0;
            int totalLibs = criticalLibs.length;
            for (String libPath : criticalLibs) {
                String fullPath = rootfs + "/" + libPath;
                StepResult st = exec(context, "stat " + fullPath + " 2>&1 | head -1");
                String statInfo = st.success
                    ? st.output.trim().split("\n")[0]
                    : "NOT FOUND";
                log.append("  " + libPath + ": " + statInfo);
                if (st.success) libsFound++;
            }
            log.append("  Libraries found: " + libsFound + "/" + totalLibs);
            sendLog(cb, "Rootfs libs: " + libsFound + "/" + totalLibs);
            if (libsFound < totalLibs) allCritical = false;

            // 8. Internet connectivity test
            log.append("[8/9] Internet Connectivity Test...");
            sendLog(cb, "Testing internet connectivity...");

            ConfirmationCallback confirmCb = cb.getConfirmationCallback();
            if (confirmCb != null) {
                boolean userConfirmed = confirmCb.onConfirm(
                    "Step 5 (Alpine Init) needs internet access to download packages.\n" +
                    "The app has INTERNET permission (auto-granted on Android).\n" +
                    "This test verifies connectivity to well-known sites.\n\n" +
                    "Continue with internet connectivity test?"
                );
                if (!userConfirmed) {
                    log.append("  Skipped — user declined");
                    sendLog(cb, "Internet test skipped by user");
                } else {
                    log.append("  User confirmed — running tests...");
                    sendLog(cb, "Running internet tests...");

                    String[] testUrls = {
                        "https://clients3.google.com/generate_204",
                        "https://alpinelinux.org",
                        "https://github.com"
                    };
                    int passedTests = 0;
                    for (String testUrl : testUrls) {
                        InternetTestResult tr = testUrl(testUrl, 10000);
                        String statusStr = tr.success
                            ? "PASS (HTTP " + tr.httpCode + ", " + tr.timeMs + "ms)"
                            : "FAIL (" + tr.error + ", " + tr.timeMs + "ms)";
                        log.append("  " + testUrl + ": " + statusStr);
                        sendLog(cb, testUrl + ": " + statusStr);
                        if (tr.success) passedTests++;
                    }
                    log.append("  Connectivity: " + passedTests + "/" + testUrls.length + " sites reachable");
                    sendLog(cb, "Internet: " + passedTests + "/" + testUrls.length);
                }
            } else {
                log.append("  Confirmation unavailable — skipping");
                sendLog(cb, "Internet test: no confirmation callback");
            }

            // 9. libz.so.1 symlink fixup (PRoot symlink resolution workaround)
            log.append("[9/9] Rootfs Library Fixup...");
            sendLog(cb, "Applying library fixups...");
            StepResult libzFix = exec(context, "rm -f " + rootfs + "/lib/libz.so.1 && cp " + rootfs + "/lib/libz.so.1.3.1 " + rootfs + "/lib/libz.so.1");
            log.append("  libz.so.1: " + (libzFix.success ? "replaced with regular copy" : "fix failed: " + libzFix.error));
            sendLog(cb, "libz fix: " + (libzFix.success ? "OK" : "FAILED"));
            StepResult verifyFix = exec(context, "stat " + rootfs + "/lib/libz.so.1 2>&1 | head -1");
            log.append("  Verified: " + verifyFix.output.trim());
            sendLog(cb, "libz verified: " + verifyFix.success);

            // 10. Write device.conf with hardware info for telemetry (v0.3.3)
            log.append("[10/10] Device Configuration Capture...");
            sendLog(cb, "Capturing device info for telemetry...");
            writeDeviceConf(rootfs, log, cb);

            log.append("=== Diagnostics Complete ===");
            if (allCritical) {
                log.append("Result: ALL CRITICAL CHECKS PASSED");
                sendLog(cb, "All critical checks passed");
                exec(context, "touch " + filesDir + "/proot/.function_test_passed");
                return new StepResult(true, "All diagnostics passed", "");
            } else {
                log.append("Result: SOME CRITICAL CHECKS FAILED — step 3 will be blocked");
                sendLog(cb, "Critical checks failed");
                exec(context, "touch " + filesDir + "/proot/.function_test_failed");
                return new StepResult(false, "", "Critical diagnostics failed");
            }

        } catch (Exception e) {
            log.append("ERROR: " + e.getMessage());
            sendLog(cb, "ERROR: " + e.getMessage());
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult step4Launcher(Context context, LogBuffer log, LogCallback cb) {
        log.append("Step 4/7: Creating PRoot Launcher Script");
        sendLog(cb, "Step 4/7: Creating PRoot Launcher Script");
        try {
            ensureLauncher(context);

            log.append("Writing launcher script...");
            sendLog(cb, "Writing launcher script...");

            log.append("Testing launcher...");
            sendLog(cb, "Testing launcher...");
            File launcher = new File(context.getFilesDir(), "proot/proot-launch.sh");
            StepResult test = exec(context, "/system/bin/sh " + launcher.getAbsolutePath() + " 'echo OK'");
            if (test.success && test.output.trim().endsWith("OK")) {
                log.append("Launcher test passed");
                sendLog(cb, "Launcher test passed");
            } else {
                log.append("ERROR: launcher test failed: " + test.output.trim());
                sendLog(cb, "ERROR: launcher test failed");
                return new StepResult(false, "", "Launcher test: " + test.output.trim());
            }

            log.append("Step 4 complete");
            sendLog(cb, "Step 4 complete");
            return new StepResult(true, "Launcher created and tested", "");

        } catch (Exception e) {
            log.append("ERROR: " + e.getMessage());
            sendLog(cb, "ERROR: " + e.getMessage());
            return new StepResult(false, "", e.getMessage());
        }
    }

    /**
     * Regenerate proot-launch.sh with the currently-installed native library path.
     * Android randomizes the install directory on every APK update while the launcher
     * persists in filesDir, so the baked NATIVE_DIR must be refreshed at each app start.
     */
    public static void ensureLauncher(Context context) {
        try {
            String filesDir = context.getFilesDir().getAbsolutePath();
            String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
            String versionName;
            String androidVer;
            try {
                versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            } catch (Exception e) {
                versionName = "unknown";
            }
            androidVer = android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")";
            String[] binds = StorageTier.buildBinds(context);
            String script = buildLauncherScript(filesDir, nativeLibDir, versionName, androidVer, binds);

            File launcher = new File(filesDir, "proot/proot-launch.sh");
            if (launcher.exists()) {
                try {
                    String existing = new String(java.nio.file.Files.readAllBytes(launcher.toPath()));
                    if (existing.equals(script)) return;
                } catch (Exception ignored) {}
            }

            launcher.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(launcher);
            fos.write(script.getBytes());
            fos.close();
            launcher.setExecutable(true);
        } catch (Exception ignored) {}
    }

    /**
     * 15q: strip any 15i-era debug WINCH trap from the live rootfs .bashrc and
     * re-assert the size plumbing. The 15n sanitizer only runs during Step 4 of a
     * fresh install; on upgraded devices whose setup never re-ran, the old trap
     * ("WINCH_RECEIVED: ...") still prints into the terminal on every resize and
     * shows up as a stray ":" when typing right after the keyboard pops up
     * (observed again in the 15p report: "nano" became ":ano").
     */
    public static void sanitizeRootBashrc(Context context) {
        try {
            File bashrc = new File(context.getFilesDir(), "rootfs/alpine/root/.bashrc");
            if (!bashrc.exists()) return;
            String existing = new String(java.nio.file.Files.readAllBytes(bashrc.toPath()));
            boolean changed = false;
            StringBuilder cleaned = new StringBuilder();
            for (String line : existing.split("\n", -1)) {
                if (line.contains("WINCH_RECEIVED") || (line.contains("trap") && line.contains("WINCH"))) {
                    changed = true;
                    continue;
                }
                cleaned.append(line).append('\n');
            }
            String out = cleaned.toString();
            if (!out.contains("checkwinsize")) { out += "shopt -s checkwinsize 2>/dev/null\n"; changed = true; }
            if (!out.contains("stty erase")) { out += "stty erase ^? 2>/dev/null\n"; changed = true; }
            if (!out.contains("unset COLUMNS LINES")) { out += "unset COLUMNS LINES\n"; changed = true; }
            if (!out.contains("PROMPT_COMMAND")) {
                out += "PROMPT_COMMAND='if [ -f /tmp/term_size ]; then read COLS ROWS < /tmp/term_size; export COLUMNS=$COLS LINES=$ROWS; fi'; export PROMPT_COMMAND\n";
                changed = true;
            }
            if (changed) {
                FileOutputStream fos = new FileOutputStream(bashrc, false);
                fos.write(out.getBytes());
                fos.close();
                BridgeLogBuffer.append("startShell: .bashrc sanitized (WINCH trap removed)");
            }
        } catch (Exception e) {
            BridgeLogBuffer.append("startShell: .bashrc sanitize skipped: " + e.getMessage());
        }
    }

    private static String buildLauncherScript(String filesDir, String nativeLibDir, String versionName, String androidVer, String[] storageBinds) {
        StringBuilder sb = new StringBuilder();
        for (String b : storageBinds) {
            sb.append(b).append('\n');
        }
        // FB-032: make /dev/urandom (and /dev/random) explicitly visible in the
        // guest. The minirootfs /dev is empty; git needs urandom for its pack
        // temp files, so a bare "-b /dev" is not enough on every device.
        StringBuilder rngBinds = new StringBuilder();
        if (new File("/dev/urandom").exists()) rngBinds.append("  -b /dev/urandom:/dev/urandom \\\n");
        if (new File("/dev/random").exists()) rngBinds.append("  -b /dev/random:/dev/random \\\n");
        return
            "#!/system/bin/sh\n" +
            "PROOT_DIR=" + filesDir + "/proot\n" +
            "ROOTFS=" + filesDir + "/rootfs/alpine\n" +
            "SDK=" + filesDir + "/sdk\n" +
            "NATIVE_DIR=" + nativeLibDir + "\n" +
            "if [ ! -e \"$NATIVE_DIR/libproot.so\" ]; then\n" +
            "  APKPATH=$(pm path com.aetherix.alpine.a 2>/dev/null | grep '/base.apk' | head -n1 | sed 's/^package://')\n" +
            "  if [ -n \"$APKPATH\" ]; then NATIVE_DIR=$(dirname \"$APKPATH\")/lib/arm64; fi\n" +
            "fi\n" +
            "mkdir -p $SDK $PROOT_DIR/tmp\n" +
            "export PROOT_NO_SECCOMP=1\n" +
            "export PROOT_LINK2SYMLINK=1\n" +
            "export HOME=/root\n" +
            "export LD_LIBRARY_PATH=$PROOT_DIR/lib\n" +
            "export PROOT_TMP_DIR=$PROOT_DIR/tmp\n" +
            "export PROOT_LOADER=$NATIVE_DIR/libproot-loader.so\n" +
            "export TERM=xterm-256color\n" +
            "export AETHERIX_VERSION=" + versionName + "\n" +
            "export AETHERIX_DOCK=1\n" +
            "export AETHERIX_INPUT_DIR=/root/storage/input\n" +
            "export AETHERIX_OUTPUT_DIR=/root/storage/output\n" +
            "export ANDROID_VERSION=\"" + androidVer + "\"\n" +
            "exec $NATIVE_DIR/libproot.so \\\n" +
            "  -0 -r $ROOTFS \\\n" +
            "  -b /dev -b /proc -b /sys \\\n" +
            rngBinds.toString() +
            "  -b /system:/system \\\n" +
            "  -b $SDK:/opt/android-sdk \\\n" +
            sb.toString() +
            "  -w /root --link2symlink \\\n" +
            "  /bin/sh --login -c \"unset LD_LIBRARY_PATH; export LD_PRELOAD=/usr/lib/libfaketty.so; export SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt; $*\"\n";
    }

    private StepResult step5AlpineInit(Context context, LogBuffer log, LogCallback cb) {
        log.append("Step 5/7: Initializing Alpine Packages");
        sendLog(cb, "Step 5/7: Initializing Alpine Packages");
        try {
            String filesDir = context.getFilesDir().getAbsolutePath();
            String launcher = filesDir + "/proot/proot-launch.sh";

            StepResult update = null;
            int maxRetries = 3;
            for (int retry = 0; retry < maxRetries; retry++) {
                if (retry > 0) {
                    log.append("Retrying apk update (attempt " + (retry + 1) + "/" + maxRetries + ")...");
                    sendLog(cb, "Retry " + (retry + 1) + "/" + maxRetries + "...");
                    try { Thread.sleep(5000 * retry); } catch (InterruptedException ie) {}
                } else {
                    log.append("Running apk update...");
                    sendLog(cb, "Running apk update...");
                }
                update = execStreaming(context,
                    "/system/bin/sh " + launcher + " 'apk update'", log, cb);
                if (update.success) {
                    if (update.output.trim().isEmpty() || update.output.trim().equals("OK")) {
                        log.append("  apk update: already up to date");
                        sendLog(cb, "  up to date");
                    }
                    break;
                }
                log.append("  apk update failed (attempt " + (retry + 1) + ")");
                sendLog(cb, "  apk update attempt " + (retry + 1) + " failed");
            }
            if (update == null || !update.success) {
                log.append("ERROR: apk update failed after " + maxRetries + " attempts");
                sendLog(cb, "ERROR: apk update failed after " + maxRetries + " attempts");
                return new StepResult(false, "", "apk update failed after " + maxRetries + " retries");
            }

            log.append("Running apk upgrade...");
            sendLog(cb, "Running apk upgrade...");
            for (int retry = 0; retry < 3; retry++) {
                StepResult upgrade = execStreaming(context,
                    "/system/bin/sh " + launcher + " 'apk upgrade'", log, cb);
                if (upgrade.success) {
                    if (upgrade.output.trim().isEmpty() || upgrade.output.trim().equals("OK")) {
                        log.append("  apk upgrade: nothing to upgrade");
                        sendLog(cb, "  nothing to upgrade");
                    }
                    break;
                }
                if (retry < 2) {
                    log.append("  apk upgrade failed, retrying...");
                    sendLog(cb, "  apk upgrade retry " + (retry + 2) + "/3");
                    try { Thread.sleep(3000); } catch (InterruptedException ie) {}
                }
            }

            // Install/update CA cert bundle from Alpine repo
            log.append("Installing ca-certificates-bundle...");
            sendLog(cb, "Installing ca-certificates-bundle...");
            execStreaming(context,
                "/system/bin/sh " + launcher + " 'apk add ca-certificates-bundle'", log, cb);

            log.append("Installing bash, coreutils, and ncurses-terminfo...");
            sendLog(cb, "Installing bash, coreutils, and ncurses-terminfo...");
            StepResult install = execStreaming(context,
                "/system/bin/sh " + launcher + " 'apk add bash coreutils ncurses-terminfo'", log, cb);
            if (!install.success) {
                log.append("ERROR: package installation failed");
                sendLog(cb, "ERROR: package installation failed");
                return new StepResult(false, "", "apk add failed: " + install.error);
            }

            log.append("Verifying bash...");
            sendLog(cb, "Verifying bash...");
            StepResult verify = exec(context, "/system/bin/sh " + launcher + " 'bash --version'");
            if (!verify.success || !verify.output.contains("bash")) {
                log.append("ERROR: bash not found after install");
                sendLog(cb, "ERROR: bash verification failed");
                return new StepResult(false, "", "bash --version failed");
            }
            log.append("bash OK");
            sendLog(cb, "bash OK");

            log.append("Installing base Alpine packages (alpine-base, tzdata, util-linux, shadow, procps)...");
            sendLog(cb, "Installing base Alpine packages...");
            StepResult base = execStreaming(context,
                "/system/bin/sh " + launcher + " 'apk add alpine-base tzdata util-linux shadow procps'", log, cb);
            if (!base.success) {
                log.append("ERROR: base package installation failed");
                sendLog(cb, "ERROR: base package installation failed");
                return new StepResult(false, "", "apk add base packages failed: " + base.error);
            }
            log.append("base packages OK");
            sendLog(cb, "base packages OK");

            log.append("Deploying libfaketty.so...");
            sendLog(cb, "Deploying libfaketty.so...");
            try {
                String rootfsPath = filesDir + "/rootfs/alpine";
                File usrLib = new File(rootfsPath, "usr/lib");
                usrLib.mkdirs();
                File libFakeTty = new File(usrLib, "libfaketty.so");
                InputStream in = context.getAssets().open("libfaketty.so");
                FileOutputStream out = new FileOutputStream(libFakeTty);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                out.close();
                libFakeTty.setExecutable(true);
                log.append("libfaketty.so deployed to " + libFakeTty.getAbsolutePath());
                sendLog(cb, "libfaketty.so deployed");
            } catch (Exception e) {
                log.append("WARNING: libfaketty.so deploy failed: " + e.getMessage());
                sendLog(cb, "WARNING: libfaketty.so deploy failed");
            }

            log.append("Enabling bash checkwinsize...");
            sendLog(cb, "Enabling bash checkwinsize...");
            try {
                String rootfsPath = filesDir + "/rootfs/alpine";
                File bashrc = new File(rootfsPath, "root/.bashrc");
                String checkwinsizeLine = "shopt -s checkwinsize 2>/dev/null\n";
                String sttyEraseLine = "stty erase ^? 2>/dev/null\n";
                String unsetSizeLine = "unset COLUMNS LINES\n";
                String promptCommandLine = "PROMPT_COMMAND='if [ -f /tmp/term_size ]; then read COLS ROWS < /tmp/term_size; export COLUMNS=$COLS LINES=$ROWS; fi'; export PROMPT_COMMAND\n";
                if (bashrc.exists()) {
                    String existing = new String(java.nio.file.Files.readAllBytes(bashrc.toPath()));
                    // 15n: strip the 15i-era debug WINCH trap - it printed
                    // "WINCH_RECEIVED: ..." into the terminal on every resize,
                    // which appeared as a stray ":" at the prompt while typing.
                    boolean hadWinchTrap = existing.contains("WINCH_RECEIVED");
                    if (hadWinchTrap) {
                        StringBuilder cleaned = new StringBuilder();
                        for (String line : existing.split("\n", -1)) {
                            if (!line.contains("WINCH_RECEIVED")) {
                                cleaned.append(line).append('\n');
                            }
                        }
                        existing = cleaned.toString();
                    }
                    boolean hasCheckwinsize = existing.contains("checkwinsize");
                    boolean hasSttyErase = existing.contains("stty erase");
                    boolean hasUnsetSize = existing.contains("unset COLUMNS LINES");
                    boolean hasPromptCommand = existing.contains("PROMPT_COMMAND");
                    if (hadWinchTrap || !hasCheckwinsize || !hasSttyErase || !hasUnsetSize || !hasPromptCommand) {
                        // Rewrite sanitized content (no append) plus any missing lines.
                        FileOutputStream fos = new FileOutputStream(bashrc, false);
                        fos.write(existing.getBytes());
                        if (!hasCheckwinsize) fos.write(checkwinsizeLine.getBytes());
                        if (!hasSttyErase) fos.write(sttyEraseLine.getBytes());
                        if (!hasUnsetSize) fos.write(unsetSizeLine.getBytes());
                        if (!hasPromptCommand) fos.write(promptCommandLine.getBytes());
                        fos.close();
                        if (hadWinchTrap) {
                            log.append("WINCH debug trap removed from .bashrc");
                            sendLog(cb, "WINCH debug trap removed");
                        }
                        if (!hasCheckwinsize) {
                            log.append("checkwinsize added to .bashrc");
                            sendLog(cb, "checkwinsize enabled");
                        }
                        if (!hasSttyErase) {
                            log.append("stty erase set in .bashrc");
                            sendLog(cb, "stty erase configured");
                        }
                        if (!hasUnsetSize) {
                            log.append("unset COLUMNS LINES added to .bashrc");
                            sendLog(cb, "unset COLUMNS LINES enabled");
                        }
                        if (!hasPromptCommand) {
                            log.append("PROMPT_COMMAND added to .bashrc");
                            sendLog(cb, "PROMPT_COMMAND enabled");
                        }
                    } else {
                        log.append(".bashrc already configured");
                        sendLog(cb, "bashrc already configured");
                    }
                } else {
                    bashrc.getParentFile().mkdirs();
                    FileOutputStream fos = new FileOutputStream(bashrc);
                    fos.write(unsetSizeLine.getBytes());
                    fos.write(checkwinsizeLine.getBytes());
                    fos.write(sttyEraseLine.getBytes());
                    fos.write(promptCommandLine.getBytes());
                    fos.close();
                    log.append(".bashrc created with unset, checkwinsize, stty erase, and PROMPT_COMMAND");
                    sendLog(cb, "bashrc configured");
                }
            } catch (Exception e) {
                log.append("WARNING: checkwinsize setup failed: " + e.getMessage());
                sendLog(cb, "WARNING: checkwinsize setup failed");
            }

            log.append("Step 5 complete");
            sendLog(cb, "Step 5 complete");
            StorageTier.deploy(context);
            return new StepResult(true, "Alpine packages installed", "");

        } catch (Exception e) {
            log.append("ERROR: " + e.getMessage());
            sendLog(cb, "ERROR: " + e.getMessage());
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult step6PtyBridge(Context context, LogBuffer log, LogCallback cb) {
        log.append("Step 6/7: Testing PTY Bridge");
        sendLog(cb, "Step 6/7: Testing PTY Bridge");
        if (!verify(4, context, log)) {
            log.append("SKIPPED: Step 5 (Alpine packages) not completed");
            sendLog(cb, "SKIPPED: prerequisite not met");
            return new StepResult(false, "", "Step 5 must complete first");
        }
        try {
            String launcher = new File(context.getFilesDir(), "proot/proot-launch.sh").getAbsolutePath();
            String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
            File bridgeSo = new File(nativeLibDir, "libpty-bridge.so");

            log.append("Bridge binary: " + bridgeSo.getAbsolutePath());
            sendLog(cb, "Bridge: " + bridgeSo.getAbsolutePath());

            if (!bridgeSo.exists()) {
                log.append("ERROR: libpty-bridge.so not found in " + nativeLibDir);
                sendLog(cb, "ERROR: PTY bridge not found");
                return new StepResult(false, "", "libpty-bridge.so not found");
            }
            log.append("Bridge size: " + bridgeSo.length() + " bytes");
            sendLog(cb, "Bridge size: " + bridgeSo.length() + " bytes");

            log.append("Launching PTY bridge with echo test...");
            sendLog(cb, "Launching PTY bridge...");

            log.append("  Command: " + bridgeSo.getAbsolutePath() + " 80 24 /system/bin/sh " + launcher + " 'echo PTY_BRIDGE_OK'");
            sendLog(cb, "  Launching...");

            StepResult r = execBridge(context, 45000,
                bridgeSo.getAbsolutePath(),
                "80", "24",
                "/system/bin/sh",
                launcher,
                "echo PTY_BRIDGE_OK && echo DONE");

            log.append("Exit code: " + (r.success ? "0" : "non-zero"));
            log.append("Output: " + r.output.trim().replace("\n", " | "));
            sendLog(cb, "PTY exit: " + (r.success ? "PASS" : "FAIL"));

            if (r.output.contains("PTY_BRIDGE_OK")) {
                log.append("PTY bridge output verified");
                sendLog(cb, "PTY bridge: PASS");
                return new StepResult(true, "PTY bridge OK", "");
            } else {
                String failMsg = r.success
                    ? "PTY bridge exited 0 but output missing expected string"
                    : "PTY bridge failed (exit code non-zero or crash)";
                log.append("ERROR: " + failMsg);
                sendLog(cb, "ERROR: " + failMsg);
                return new StepResult(false, "", failMsg + ": " + r.output.trim());
            }

        } catch (Exception e) {
            log.append("ERROR: " + e.getMessage());
            sendLog(cb, "ERROR: " + e.getMessage());
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult step7ShellVerify(Context context, LogBuffer log, LogCallback cb) {
        log.append("Step 7/7: Test & Verify");
        sendLog(cb, "Step 7/7: Test & Verify");
        if (!verify(5, context, log)) {
            log.append("SKIPPED: Step 6 (PTY Bridge) not completed");
            sendLog(cb, "SKIPPED: prerequisite not met");
            return new StepResult(false, "", "Step 6 must complete first");
        }
        try {
            String launcher = new File(context.getFilesDir(), "proot/proot-launch.sh").getAbsolutePath();

            log.append("Running full shell test...");
            sendLog(cb, "Running full shell test...");
            StepResult test = execStreaming(context,
                "/system/bin/sh " + launcher + " 'uname -a && echo SHELL_READY'", log, cb);

            if (test.success && test.output.contains("SHELL_READY")) {
                log.append("Shell environment ready!");
                sendLog(cb, "Shell environment ready!");
            } else {
                String msg = "Shell test failed: " + test.output.trim();
                log.append("ERROR: " + msg);
                sendLog(cb, "ERROR: " + msg);
                return new StepResult(false, "", msg);
            }

            log.append("Running final self-test...");
            sendLog(cb, "Running final self-test...");
            StepResult selftest = execStreaming(context,
                "/system/bin/sh " + launcher + " 'echo VERSION=$AETHERIX_VERSION && bash --version >/dev/null && apk --version >/dev/null && which coreutils >/dev/null && echo SELF_TEST_PASS'", log, cb);
            if (selftest.success && selftest.output.contains("SELF_TEST_PASS")) {
                log.append("Self-test passed (" + selftest.output.trim() + ")");
                sendLog(cb, "Self-test passed");
            } else {
                String msg = "Self-test failed: " + selftest.output.trim();
                log.append("ERROR: " + msg);
                sendLog(cb, "ERROR: " + msg);
                return new StepResult(false, "", "Self-test not passed");
            }

            log.append("All steps complete!");
            sendLog(cb, "All steps complete!");
            return new StepResult(true, "Environment fully ready", "");

        } catch (Exception e) {
            log.append("ERROR: " + e.getMessage());
            sendLog(cb, "ERROR: " + e.getMessage());
            return new StepResult(false, "", e.getMessage());
        }
    }

    public String getStepName(int index) {
        String[] names = {
            "PRoot Binary + Support Libraries",
            "Alpine Rootfs",
            "System Diagnostics",
            "Launcher Script",
            "Alpine Packages",
            "PTY Bridge",
            "Test & Verify"
        };
        if (index >= 0 && index < names.length) return names[index];
        return "Step " + (index + 1);
    }

    public StepResult runTest(int stepIndex, Context context, LogBuffer log, LogCallback cb) {
        log.append("=== Manual Test: Step " + (stepIndex + 1) + ": " + getStepName(stepIndex) + " ===");
        sendLog(cb, "Running manual test for " + getStepName(stepIndex) + "...");
        switch (stepIndex) {
            case 0: return testStep0(context, log, cb);
            case 1: return testStep1(context, log, cb);
            case 2: return testStep2(context, log, cb);
            case 3: return testStep3(context, log, cb);
            case 4: return testStep4(context, log, cb);
            case 5: return testStep5(context, log, cb);
            case 6: return testStep6(context, log, cb);
            case 7: return testFix1Background(context, log, cb);
            case 8: return testFix2Keyboard(context, log, cb);
            case 9: return testFix3ExtraKeys(context, log, cb);
            default: return new StepResult(false, "", "Unknown step");
        }
    }

    private StepResult testStep0(Context context, LogBuffer log, LogCallback cb) {
        String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
        String filesDir = context.getFilesDir().getAbsolutePath();
        String[][] files = {
            {nativeLibDir, "libproot.so"},
            {nativeLibDir, "libproot-loader.so"},
            {nativeLibDir, "libdexec.so"},
            {filesDir + "/proot/lib", "libtalloc.so.2"},
            {filesDir + "/proot/lib", "libandroid-shmem.so"}
        };
        int found = 0;
        int total = files.length;
        for (String[] f : files) {
            File file = new File(f[0], f[1]);
            boolean ok = file.exists() && file.length() > 100;
            String msg = "  " + f[1] + ": " + (ok ? "PASS" : "FAIL") + " (" + file.length() + " bytes)";
            log.append(msg);
            sendLog(cb, msg);
            if (cb != null) cb.onLiveResult(0, msg);
            if (ok) found++;
        }
        log.append("  Files: " + found + "/" + total + " present");
        sendLog(cb, "  Files: " + found + "/" + total);
        return new StepResult(found == total, found + "/" + total + " files OK", "");
    }

    private StepResult testStep1(Context context, LogBuffer log, LogCallback cb) {
        String rootfs = context.getFilesDir().getAbsolutePath() + "/rootfs/alpine";
        String[][] checks = {
            {rootfs + "/bin/sh", "bin/sh exists"},
            {rootfs + "/etc", "etc/ exists"},
            {rootfs + "/etc/alpine-release", "alpine-release exists"},
            {rootfs + "/lib", "lib/ exists"},
            {rootfs + "/bin/busybox", "busybox exists"}
        };
        int found = 0;
        int total = checks.length;
        for (String[] c : checks) {
            File f = new File(c[0]);
            boolean ok = f.exists();
            if (!ok && f.isFile() == false) {
                try {
                    ok = java.nio.file.Files.isSymbolicLink(f.toPath());
                } catch (Exception e) {
                    try {
                        ok = f.getCanonicalPath() != null && !f.getAbsolutePath().equals(f.getCanonicalPath());
                    } catch (Exception e2) {}
                }
            }
            String msg = "  " + c[1] + ": " + (ok ? "PASS" : "FAIL");
            log.append(msg);
            sendLog(cb, msg);
            if (cb != null) cb.onLiveResult(1, msg);
            if (ok) found++;
        }
        StepResult shTest = exec(context, "ls -L " + rootfs + "/bin/sh >/dev/null 2>&1 && echo EXEC_OK || echo EXEC_FAIL");
        boolean execOk = shTest.success && shTest.output.contains("EXEC_OK");
        String msg = "  /bin/sh executable: " + (execOk ? "PASS" : "FAIL");
        log.append(msg);
        sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(1, msg);
        if (execOk) found++;
        total++;
        log.append("  Rootfs checks: " + found + "/" + total);
        sendLog(cb, "  Rootfs: " + found + "/" + total);
        return new StepResult(found == total, found + "/" + total + " checks OK", "");
    }

    private StepResult testStep2(Context context, LogBuffer log, LogCallback cb) {
        String filesDir = context.getFilesDir().getAbsolutePath();
        String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
        String prootLibDir = filesDir + "/proot/lib";
        String rootfs = filesDir + "/rootfs/alpine";
        int passed = 0;
        int total = 6;

        StepResult selinux = exec(context, "cat /proc/self/attr/current");
        String msg = "  [1/" + total + "] SELinux domain: " + selinux.output.trim();
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(2, msg);
        passed++;

        StepResult shell = exec(context, "/system/bin/sh -c 'echo TEST_SHELL_OK'");
        boolean shellOk = shell.success && shell.output.contains("TEST_SHELL_OK");
        msg = "  [2/" + total + "] Shell: " + (shellOk ? "PASS" : "FAIL");
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(2, msg);
        if (shellOk) passed++;

        StepResult prootTest = exec(context,
            "LD_LIBRARY_PATH=" + prootLibDir + " " + nativeLibDir + "/libproot.so 2>&1 || true");
        boolean prootOk = prootTest.success || prootTest.output.contains("proot");
        msg = "  [3/" + total + "] PRoot binary: " + (prootOk ? "PASS" : "FAIL");
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(2, msg);
        if (prootOk) passed++;

        StepResult alpineRel = exec(context, "cat " + rootfs + "/etc/alpine-release");
        msg = "  [4/" + total + "] Alpine release: " + alpineRel.output.trim();
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(2, msg);
        if (alpineRel.success) passed++;

        String[] criticalLibs = {"lib/libz.so.1", "lib/libcrypto.so.3", "lib/libapk.so.2.14.0"};
        int libsFound = 0;
        for (String lib : criticalLibs) {
            if (new File(rootfs + "/" + lib).exists()) libsFound++;
        }
        msg = "  [5/" + total + "] Critical libs: " + libsFound + "/" + criticalLibs.length + " found";
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(2, msg);
        if (libsFound == criticalLibs.length) passed++;

        StepResult tmpTest = exec(context,
            "mkdir -p " + filesDir + "/proot/tmp && touch " + filesDir + "/proot/tmp/manual_test && echo WRITE_OK");
        boolean tmpOk = tmpTest.success && tmpTest.output.contains("WRITE_OK");
        msg = "  [6/" + total + "] Temp writable: " + (tmpOk ? "PASS" : "FAIL");
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(2, msg);
        if (tmpOk) passed++;

        msg = "  Diagnostics: " + passed + "/" + total + " passed";
        log.append(msg); sendLog(cb, msg);
        return new StepResult(passed == total, passed + "/" + total + " passed", "");
    }

    private StepResult testStep3(Context context, LogBuffer log, LogCallback cb) {
        File launcher = new File(context.getFilesDir(), "proot/proot-launch.sh");
        boolean exists = launcher.exists();
        String msg = "  Launcher exists: " + (exists ? "PASS" : "FAIL");
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(3, msg);
        if (!exists) return new StepResult(false, "proot-launch.sh not found", "");

        boolean execOk = launcher.canExecute();
        msg = "  Launcher executable: " + (execOk ? "PASS" : "FAIL");
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(3, msg);

        StepResult test = exec(context, "/system/bin/sh " + launcher.getAbsolutePath() + " 'echo LAUNCHER_TEST_OK'");
        boolean testOk = test.success && test.output.trim().endsWith("LAUNCHER_TEST_OK");
        msg = "  Launcher echo test: " + (testOk ? "PASS" : "FAIL");
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(3, msg);
        log.append("  Output: " + test.output.trim().replace("\n", " | "));

        return new StepResult(exists && execOk && testOk,
            (exists ? "exists " : "") + (execOk ? "executable " : "") + (testOk ? "test_passed" : "test_failed"), "");
    }

    private StepResult testStep4(Context context, LogBuffer log, LogCallback cb) {
        File launcherFile = new File(context.getFilesDir(), "proot/proot-launch.sh");
        if (!launcherFile.exists()) {
            return new StepResult(false, "Launcher not found", "");
        }
        String launcher = launcherFile.getAbsolutePath();
        String[][] tests = {
            {"bash --version < /dev/null", "bash"},
            {"apk --version < /dev/null", "apk"},
            {"which coreutils < /dev/null", "coreutils"},
            {"echo TEST_PKG_OK < /dev/null", "TEST_PKG_OK"}
        };
        int passed = 0;
        int total = tests.length;
        for (String[] t : tests) {
            StepResult r = exec(context, "/system/bin/sh " + launcher + " '" + t[0] + "'");
            boolean ok = r.success && r.output.contains(t[1]);
            String msg = "  " + t[0] + ": " + (ok ? "PASS" : "FAIL");
            log.append(msg); sendLog(cb, msg);
            if (cb != null) cb.onLiveResult(4, msg);
            if (ok) passed++;
        }
        log.append("  Packages: " + passed + "/" + total + " verified");
        sendLog(cb, "  Packages: " + passed + "/" + total);
        return new StepResult(passed == total, passed + "/" + total + " verified", "");
    }

    private StepResult testStep5(Context context, LogBuffer log, LogCallback cb) {
        String nativeLibDir = context.getApplicationInfo().nativeLibraryDir;
        File launcherFile = new File(context.getFilesDir(), "proot/proot-launch.sh");
        File bridgeSo = new File(nativeLibDir, "libpty-bridge.so");

        String msg = "  PTY bridge binary: " + bridgeSo.getAbsolutePath();
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(5, msg);

        if (!bridgeSo.exists()) {
            msg = "  Bridge binary: FAIL (not found)";
            log.append(msg); sendLog(cb, msg);
            if (cb != null) cb.onLiveResult(5, msg);
            return new StepResult(false, "libpty-bridge.so not found", "");
        }

        log.append("  Running PTY bridge with echo test...");
        sendLog(cb, "  Bridge: launching...");

        StepResult r = execBridge(context, 30000,
            bridgeSo.getAbsolutePath(),
            "80", "24",
            "/system/bin/sh",
            launcherFile.getAbsolutePath(),
            "echo PTY_MANUAL_TEST_OK && echo DONE");

        msg = "  Exit code: " + (r.success ? "0" : "non-zero");
        log.append(msg); sendLog(cb, msg);
        if (cb != null) cb.onLiveResult(5, msg);

        boolean outputOk = r.output.contains("PTY_MANUAL_TEST_OK");
        if (outputOk) {
            msg = "  Bridge output: PASS (PTY_MANUAL_TEST_OK found)";
            log.append(msg); sendLog(cb, msg);
        } else {
            msg = "  Bridge output: FAIL (missing expected text)";
            log.append(msg); sendLog(cb, msg);
            log.append("  Raw output: " + r.output.trim().replace("\n", " | "));
        }
        if (cb != null) cb.onLiveResult(5, msg);

        return new StepResult(r.success && outputOk,
            (r.success ? "exit=0 " : "exit=non-zero ") + (outputOk ? "output_ok" : "output_mismatch"), "");
    }

    private StepResult testFix1Background(Context context, LogBuffer log, LogCallback cb) {
        log.append("=== Fix 1: TerminalView Background Color ===");
        sendLog(cb, "Testing background color fill...");
        try {
            TerminalView tv = new TerminalView(context, null);
            TerminalViewClient mockClient = new TerminalViewClient() {
                public float onScale(float s) { return s; }
                public void onSingleTapUp(MotionEvent e) {}
                public boolean shouldBackButtonBeMappedToEscape() { return true; }
                public boolean shouldEnforceCharBasedInput() { return false; }
                public boolean shouldUseCtrlSpaceWorkaround() { return false; }
                public boolean isTerminalViewSelected() { return true; }
                public void copyModeChanged(boolean cm) {}
                public boolean onKeyDown(int kc, KeyEvent e, TerminalSession s) { return false; }
                public boolean onKeyUp(int kc, KeyEvent e) { return false; }
                public boolean onLongPress(MotionEvent e) { return false; }
                public boolean readControlKey() { return false; }
                public boolean readAltKey() { return false; }
                public boolean readShiftKey() { return false; }
                public boolean readFnKey() { return false; }
                public boolean onCodePoint(int cp, boolean ctrl, TerminalSession s) { return false; }
                public void onEmulatorSet() {}
                public void logError(String tag, String msg) {}
                public void logWarn(String tag, String msg) {}
                public void logInfo(String tag, String msg) {}
                public void logDebug(String tag, String msg) {}
                public void logVerbose(String tag, String msg) {}
                public void logStackTraceWithMessage(String tag, String msg, Exception e) {}
                public void logStackTrace(String tag, Exception e) {}
            };
            tv.setTerminalViewClient(mockClient);
            tv.setTextSize(12);
            tv.measure(500, 500);
            tv.layout(0, 0, 500, 500);

            TerminalSession testSession = new TerminalSession(context, tv, 80, 24,
                (int) tv.getFontWidth(), tv.getFontLineSpacing(), mockClient,
                new String[]{"/system/bin/sh", "-c", "exit 0"});
            tv.attachSession(testSession);

            Bitmap bitmap = Bitmap.createBitmap(500, 500, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            tv.draw(canvas);

            int expectedBg = 0xff000000;
            int pixelMargin = bitmap.getPixel(450, 450);
            int pixelText = bitmap.getPixel(5, 5);

            String msg = "  Pixel at margin (450,450): 0x" + Integer.toHexString(pixelMargin);
            log.append(msg); sendLog(cb, msg);
            msg = "  Pixel at first cell (5,5): 0x" + Integer.toHexString(pixelText);
            log.append(msg); sendLog(cb, msg);

            if ((pixelMargin & 0xff000000) == 0) {
                log.append("  FAIL: margin pixel transparent - background not filled");
                sendLog(cb, "  FAIL: background fill missing");
                return new StepResult(false, "Background not filled (transparent margin)", "");
            }
            if ((pixelText & 0xff000000) == 0) {
                log.append("  FAIL: text area pixel transparent - background not filled");
                sendLog(cb, "  FAIL: text area not filled");
                return new StepResult(false, "Text area not filled (transparent)", "");
            }

            log.append("  PASS: background color correctly filled");
            sendLog(cb, "  PASS: background OK");
            return new StepResult(true, "Background fill OK", "");
        } catch (Exception e) {
            String msg = "  FAIL: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            log.append(msg); sendLog(cb, msg);
            return new StepResult(false, "Exception: " + e.getMessage(), "");
        } catch (Error e) {
            String msg = "  FAIL: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            log.append(msg); sendLog(cb, msg);
            return new StepResult(false, "Error: " + e.getMessage(), "");
        }
    }

    private StepResult testFix2Keyboard(Context context, LogBuffer log, LogCallback cb) {
        log.append("=== Fix 2: Keyboard Popup Smoke Test ===");
        sendLog(cb, "Testing keyboard popup readiness...");
        try {
            final boolean[] onEmulatorSetCalled = {false};
            TerminalView tv = new TerminalView(context, null);
            TerminalViewClient mockClient = new TerminalViewClient() {
                public float onScale(float s) { return s; }
                public void onSingleTapUp(MotionEvent e) {}
                public boolean shouldBackButtonBeMappedToEscape() { return true; }
                public boolean shouldEnforceCharBasedInput() { return false; }
                public boolean shouldUseCtrlSpaceWorkaround() { return false; }
                public boolean isTerminalViewSelected() { return true; }
                public void copyModeChanged(boolean cm) {}
                public boolean onKeyDown(int kc, KeyEvent e, TerminalSession s) { return false; }
                public boolean onKeyUp(int kc, KeyEvent e) { return false; }
                public boolean onLongPress(MotionEvent e) { return false; }
                public boolean readControlKey() { return false; }
                public boolean readAltKey() { return false; }
                public boolean readShiftKey() { return false; }
                public boolean readFnKey() { return false; }
                public boolean onCodePoint(int cp, boolean ctrl, TerminalSession s) { return false; }
                public void onEmulatorSet() { onEmulatorSetCalled[0] = true; }
                public void logError(String tag, String msg) {}
                public void logWarn(String tag, String msg) {}
                public void logInfo(String tag, String msg) {}
                public void logDebug(String tag, String msg) {}
                public void logVerbose(String tag, String msg) {}
                public void logStackTraceWithMessage(String tag, String msg, Exception e) {}
                public void logStackTrace(String tag, Exception e) {}
            };
            tv.setTerminalViewClient(mockClient);
            tv.setTextSize(12);
            tv.measure(200, 200);
            tv.layout(0, 0, 200, 200);

            TerminalSession testSession = new TerminalSession(context, tv, 80, 24,
                (int) tv.getFontWidth(), tv.getFontLineSpacing(), mockClient,
                new String[]{"/system/bin/sh", "-c", "exit 0"});
            tv.attachSession(testSession);

            if (!onEmulatorSetCalled[0]) {
                log.append("  FAIL: onEmulatorSet() was not called during attachSession");
                sendLog(cb, "  FAIL: onEmulatorSet not called");
                return new StepResult(false, "onEmulatorSet not called", "");
            }
            log.append("  onEmulatorSet() was called during attachSession");

            boolean imeReady = tv.onCheckIsTextEditor();
            if (!imeReady) {
                log.append("  FAIL: TerminalView.onCheckIsTextEditor() returns false");
                sendLog(cb, "  FAIL: view not IME-ready");
                return new StepResult(false, "View not IME-ready", "");
            }
            log.append("  TerminalView is IME-ready (onCheckIsTextEditor=true)");

            log.append("  PASS: keyboard callback chain verified");
            sendLog(cb, "  PASS: keyboard readiness OK");
            log.append("  NOTE: IMM.showSoftInput requires manual device verification");
            sendLog(cb, "  NOTE: Verify keyboard pops up manually on device");
            return new StepResult(true, "Keyboard readiness OK", "");
        } catch (Exception e) {
            String msg = "  FAIL: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            log.append(msg); sendLog(cb, msg);
            return new StepResult(false, "Exception: " + e.getMessage(), "");
        } catch (Error e) {
            String msg = "  FAIL: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            log.append(msg); sendLog(cb, msg);
            return new StepResult(false, "Error: " + e.getMessage(), "");
        }
    }

    private StepResult testFix3ExtraKeys(Context context, LogBuffer log, LogCallback cb) {
        log.append("=== Fix 3: ExtraKeysView ===");
        sendLog(cb, "Testing ExtraKeysView...");
        try {
            Class<?> ekvClass = Class.forName("com.aetherix.alpine.a.terminal.ExtraKeysView");
            log.append("  ExtraKeysView class loaded");
            sendLog(cb, "  Class found");

            Object ekv = ekvClass.getConstructor(Context.class, android.util.AttributeSet.class)
                .newInstance(context, null);
            log.append("  ExtraKeysView instantiated");
            sendLog(cb, "  Instance created");

            java.lang.reflect.Method reloadMethod = ekvClass.getMethod("reload", String[][].class, java.util.Map.class);
            String[][] keys = {{"CTRL", "ALT", "FN"}, {"ESC", "TAB", "ENTER"}};
            reloadMethod.invoke(ekv, keys, ekvClass.getField("defaultCharDisplay").get(null));
            log.append("  reload() with key matrix: OK");
            sendLog(cb, "  reload OK");

            int childCount = ((android.view.ViewGroup) ekv).getChildCount();
            log.append("  Button count after reload: " + childCount);
            sendLog(cb, "  " + childCount + " buttons");

            Class<?> sbEnum = Class.forName("com.aetherix.alpine.a.terminal.ExtraKeysView$SpecialButton");
            java.lang.reflect.Method readMethod = ekvClass.getMethod("readSpecialButton", sbEnum);
            Object ctrlVal = sbEnum.getMethod("valueOf", String.class).invoke(null, "CTRL");
            Object altVal = sbEnum.getMethod("valueOf", String.class).invoke(null, "ALT");
            boolean ctrlState = (Boolean) readMethod.invoke(ekv, ctrlVal);
            boolean altState = (Boolean) readMethod.invoke(ekv, altVal);
            if (ctrlState || altState) {
                log.append("  FAIL: readSpecialButton returned true before toggle");
                sendLog(cb, "  FAIL: false positive read");
                return new StepResult(false, "readSpecialButton false positive", "");
            }
            log.append("  readSpecialButton returns false before toggle (correct)");
            sendLog(cb, "  State OK");

            log.append("  PASS: ExtraKeysView creation, reload, and state all OK");
            sendLog(cb, "  PASS: ExtraKeysView OK");
            return new StepResult(true, "ExtraKeysView OK", "");
        } catch (ClassNotFoundException e) {
            log.append("  FAIL: ExtraKeysView class not found (not yet implemented)");
            sendLog(cb, "  FAIL: ExtraKeysView not implemented");
            return new StepResult(false, "ExtraKeysView not implemented", "");
        } catch (Exception e) {
            String msg = "  FAIL: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            log.append(msg); sendLog(cb, msg);
            return new StepResult(false, "Exception: " + e.getMessage(), "");
        }
    }

    private StepResult testStep6(Context context, LogBuffer log, LogCallback cb) {
        File launcherFile = new File(context.getFilesDir(), "proot/proot-launch.sh");
        if (!launcherFile.exists()) {
            return new StepResult(false, "Launcher not found", "");
        }
        String launcher = launcherFile.getAbsolutePath();
        int passed = 0;
        int total = 5;
        String[][] tests = {
            {"uname -a", "Linux"},
            {"echo SHELL_ENV_OK", "SHELL_ENV_OK"},
            {"whoami", "root"},
            {"pwd", "/root"},
            {"id", "uid=0"}
        };
        for (String[] t : tests) {
            StepResult r = exec(context, "/system/bin/sh " + launcher + " '" + t[0] + "'");
            boolean ok = r.success && r.output.contains(t[1]);
            String msg = "  " + t[0] + ": " + (ok ? "PASS" : "FAIL");
            log.append(msg); sendLog(cb, msg);
            if (cb != null) cb.onLiveResult(6, msg);
            if (ok) passed++;
        }
        String msg = "  Shell environment: " + passed + "/" + total + " checks passed";
        log.append(msg); sendLog(cb, msg);
        return new StepResult(passed == total, passed + "/" + total + " passed", "");
    }

    private StepResult exec(Context context, String command) {
        try {
            ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", command);
            pb.redirectErrorStream(true);
            Process p = pb.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            int exitCode = p.waitFor();
            return new StepResult(exitCode == 0, output.toString(), "");
        } catch (Exception e) {
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult execDirect(Context context, String... command) {
        try {
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            int exitCode = p.waitFor();
            return new StepResult(exitCode == 0, output.toString(), "");
        } catch (Exception e) {
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult execBridge(Context context, long timeoutMs, String... command) {
        try {
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            final Process p = pb.start();

            p.getOutputStream().close();

            final StringBuilder output = new StringBuilder();
            final int[] exitCode = new int[]{-1};

            Thread reader = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                        String line;
                        while ((line = br.readLine()) != null) {
                            Log.d("PTY-Bridge-Test", line);
                            if (line.startsWith("DBG[")) {
                                BridgeLogBuffer.append(line);
                            }
                            output.append(line).append("\n");
                        }
                    } catch (Exception ignored) {}
                }
            });
            reader.start();

            long deadline = System.currentTimeMillis() + timeoutMs;
            while (System.currentTimeMillis() < deadline) {
                try {
                    Thread.sleep(200);
                    exitCode[0] = p.exitValue();
                    break;
                } catch (InterruptedException e) {
                    break;
                } catch (IllegalThreadStateException e) {
                    // process still running
                }
            }

            boolean timedOut = !Thread.currentThread().isInterrupted()
                && System.currentTimeMillis() >= deadline;

            if (timedOut) {
                p.destroyForcibly();
                try { Thread.sleep(1000); } catch (Exception e) {}
                output.append("\n[PROCESS TIMEOUT after " + timeoutMs + "ms]\n");
                try { exitCode[0] = p.exitValue(); } catch (Exception e) { exitCode[0] = -1; }
            }

            try { reader.join(2000); } catch (Exception e) {}

            return new StepResult(exitCode[0] == 0, output.toString(), "");

        } catch (Exception e) {
            return new StepResult(false, "", e.getMessage());
        }
    }

    private StepResult execStreaming(Context context, String command, LogBuffer log, LogCallback cb) {
        try {
            ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", command);
            pb.redirectErrorStream(true);
            Process p = pb.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
                log.appendOutput(line);
                if (cb != null) cb.onLog("  " + line);
            }
            int exitCode = p.waitFor();
            return new StepResult(exitCode == 0, output.toString(), "");
        } catch (Exception e) {
            return new StepResult(false, "", e.getMessage());
        }
    }

    private void sendLog(LogCallback cb, String msg) {
        if (cb != null) cb.onLog(msg);
    }

    private InternetTestResult testUrl(String urlString, int timeoutMs) {
        InternetTestResult r = new InternetTestResult();
        long start = System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setInstanceFollowRedirects(false);
            conn.connect();
            r.httpCode = conn.getResponseCode();
            r.success = r.httpCode >= 200 && r.httpCode < 400;
        } catch (Exception e) {
            r.success = false;
            r.error = e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (conn != null) conn.disconnect();
        }
        r.timeMs = System.currentTimeMillis() - start;
        return r;
    }

    /** Hidden android.os.SystemProperties via reflection (no compile-time dependency). */
    private static String getSystemProperty(String key) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            java.lang.reflect.Method m = sp.getMethod("get", String.class);
            Object v = m.invoke(null, key);
            return v != null ? v.toString() : "";
        } catch (Throwable t) {
            return "";
        }
    }

    private void writeDeviceConf(String rootfs, LogBuffer log, LogCallback cb) {
        try {
            File conf = new File(rootfs, "etc/aetherix/device.conf");
            conf.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(conf, false);
            fos.write(("board: " + getSystemProperty("ro.board.platform") + "\n").getBytes());
            fos.write(("model: " + getSystemProperty("ro.product.model") + "\n").getBytes());
            fos.write(("cpu_abi: " + getSystemProperty("ro.product.cpu.abi") + "\n").getBytes());
            fos.write(("manufacturer: " + getSystemProperty("ro.product.manufacturer") + "\n").getBytes());
            String gpuVendor = "unknown";
            java.io.File maliCheck = new java.io.File("/sys/kernel/gpu/gpu_busy");
            if (maliCheck.exists()) {
                gpuVendor = "Mali";
            } else {
                java.io.File adrenoCheck = new java.io.File("/sys/class/kgsl/kgsl-3d0/");
                if (adrenoCheck.exists()) {
                    gpuVendor = "Adreno";
                }
            }
            fos.write(("gpu_vendor: " + gpuVendor + "\n").getBytes());
            java.io.File cpuTemp = new java.io.File("/sys/class/thermal/thermal_zone0/temp");
            if (cpuTemp.exists()) {
                String tempText = new java.io.BufferedReader(new java.io.FileReader(cpuTemp)).readLine();
                try {
                    int tempC = Integer.parseInt(tempText) / 1000;
                    fos.write(("cpu_temp_celsius: " + tempC + "\n").getBytes());
                } catch (Exception ignored) {}
            }
            java.io.File memInfo = new java.io.File("/proc/meminfo");
            if (memInfo.exists()) {
                String memInfoText = new java.io.BufferedReader(new java.io.FileReader(memInfo)).readLine();
                if (memInfoText != null) {
                    fos.write(("memory_info: " + memInfoText + "\n").getBytes());
                }
            }
            fos.close();

            log.append("  Device config saved to " + conf.getAbsolutePath());
            sendLog(cb, "Device config saved to " + conf.getAbsolutePath());
        } catch (Exception e) {
            log.append("ERROR: Failed to write device.conf: " + e.getMessage());
            sendLog(cb, "Failed to write device.conf");
        }
    }
}
