package com.aetherix.alpine.a;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PtySession {

    private Process process;
    private OutputStream stdin;
    private InputStream stdout;
    private Thread outputReader;
    private Thread stderrReader;
    private volatile boolean running = false;
    private OutputCallback callback;
    private String termSizeFilePath;
    private int lastWrittenRows = -1;
    private int lastWrittenCols = -1;

    public interface OutputCallback {
        void onOutput(String line);
        void onOutputBytes(byte[] data, int len);
        void onExit(int exitCode);
        void onError(String msg);
        default void onDebug(String line) {}
    }

    public boolean start(Context context, String[] command, OutputCallback cb, int rows, int cols) {
        this.callback = cb;
        try {
            String bridgePath = extractBridge(context);
            if (bridgePath == null) return false;

            termSizeFilePath = context.getFilesDir().getAbsolutePath() + "/rootfs/alpine/tmp/term_size";

            String rowsStr = String.valueOf(rows);
            String colsStr = String.valueOf(cols);

            String[] cmd = new String[command.length + 3];
            cmd[0] = bridgePath;
            cmd[1] = rowsStr;
            cmd[2] = colsStr;
            System.arraycopy(command, 0, cmd, 3, command.length);

            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(false);
            pb.environment().put("COLUMNS", String.valueOf(cols));
            pb.environment().put("LINES", String.valueOf(rows));
            // 15l: hand the bridge the exact term_size path inside the live rootfs
            // (files/rootfs/alpine/tmp), which is what bash/libfaketty actually read.
            pb.environment().put("AETHERIX_TERM_SIZE_PATH", termSizeFilePath);
            process = pb.start();
            stdin = process.getOutputStream();
            stdout = process.getInputStream();
            InputStream stderr = process.getErrorStream();
            running = true;

            outputReader = new Thread(new Runnable() {
                @Override
                public void run() {
                    byte[] buf = new byte[4096];
                    StringBuilder lineBuf = new StringBuilder();
                    try {
                        while (running) {
                            int n = stdout.read(buf);
                            if (n <= 0) break;
                            if (callback != null) {
                                callback.onOutputBytes(buf, n);
                            }
                            for (int i = 0; i < n; i++) {
                                char c = (char) (buf[i] & 0xff);
                                if (c == '\n') {
                                    if (callback != null && lineBuf.length() > 0) {
                                        callback.onOutput(lineBuf.toString());
                                    }
                                    lineBuf.setLength(0);
                                } else if (c != '\r') {
                                    lineBuf.append(c);
                                }
                            }
                        }
                    } catch (Exception ignored) {}
                    try {
                        int exitCode = process.waitFor();
                        running = false;
                        if (callback != null) callback.onExit(exitCode);
                    } catch (Exception ignored) {}
                }
            });
            outputReader.start();

            stderrReader = new Thread(() -> {
                byte[] buf = new byte[4096];
                StringBuilder partial = new StringBuilder();
                try {
                    while (running) {
                        int n = stderr.read(buf);
                        if (n <= 0) break;
                        for (int i = 0; i < n; i++) {
                            char c = (char)(buf[i] & 0xff);
                            if (c == '\n') {
                                if (callback != null && partial.length() > 0) {
                                    callback.onDebug(partial.toString());
                                }
                                partial.setLength(0);
                            } else if (c != '\r') {
                                partial.append(c);
                            }
                        }
                    }
                    if (partial.length() > 0 && callback != null) {
                        callback.onDebug(partial.toString());
                    }
                } catch (Exception ignored) {}
            });
            stderrReader.start();
            return true;

        } catch (Exception e) {
            running = false;
            if (callback != null) callback.onError(e.getMessage());
            return false;
        }
    }

    public synchronized void write(byte[] data) {
        write(data, 0, data.length);
    }

    public synchronized void write(byte[] data, int offset, int count) {
        if (stdin != null && running) {
            try {
                stdin.write(data, offset, count);
                stdin.flush();
            } catch (Exception ignored) {}
        }
    }

    public void write(String s) {
        write(s.getBytes());
    }

    public void writeLine(String s) {
        write(s + "\n");
    }

    public synchronized void setWindowSize(int rows, int cols) {
        if (!running) return;
        if (rows < 4) rows = 4;
        if (cols < 4) cols = 4;
        if (rows > 9999) rows = 9999;
        if (cols > 9999) cols = 9999;
        if (rows == lastWrittenRows && cols == lastWrittenCols) return;
        lastWrittenRows = rows;
        lastWrittenCols = cols;
        try {
            if (termSizeFilePath != null) {
                new File(termSizeFilePath).getParentFile().mkdirs();
                java.io.FileOutputStream fos = new java.io.FileOutputStream(termSizeFilePath);
                fos.write((cols + " " + rows + "\n").getBytes());
                fos.close();
            }
        } catch (Exception ignored) {}
    }

    public void destroy() {
        running = false;
        if (process != null) {
            try { stdin.write("exit\n".getBytes()); stdin.flush(); } catch (Exception ignored) {}
            try {
                long deadline = System.currentTimeMillis() + 2000;
                while (System.currentTimeMillis() < deadline) {
                    try {
                        process.exitValue();
                        return;
                    } catch (IllegalThreadStateException stillRunning) {
                        Thread.sleep(50);
                    }
                }
            } catch (Exception ignored) {}
            process.destroy();
        }
    }

    public boolean isRunning() {
        return running;
    }

    public static void writeTermSizeFile(Context context, int rows, int cols) {
        if (rows < 4) rows = 4;
        if (cols < 4) cols = 4;
        if (rows > 9999) rows = 9999;
        if (cols > 9999) cols = 9999;
        String path = context.getFilesDir().getAbsolutePath() + "/rootfs/alpine/tmp/term_size";
        try {
            new File(path).getParentFile().mkdirs();
            java.io.FileOutputStream fos = new java.io.FileOutputStream(path);
            fos.write((cols + " " + rows + "\n").getBytes());
            fos.close();
        } catch (Exception ignored) {}
    }

    private String extractBridge(Context context) {
        try {
            String libDir = context.getApplicationInfo().nativeLibraryDir;
            File bridge = new File(libDir, "libpty-bridge.so");
            if (!bridge.exists()) {
                AssetManager am = context.getAssets();
                InputStream in = am.open("libpty-bridge.so");
                FileOutputStream out = new FileOutputStream(bridge);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                in.close();
                out.close();
            }
            if (!bridge.setExecutable(true)) {
                bridge.setExecutable(true, false);
            }
            return bridge.getAbsolutePath();
        } catch (Exception e) {
            if (callback != null) callback.onError("extract bridge: " + e.getMessage());
            return null;
        }
    }
}
