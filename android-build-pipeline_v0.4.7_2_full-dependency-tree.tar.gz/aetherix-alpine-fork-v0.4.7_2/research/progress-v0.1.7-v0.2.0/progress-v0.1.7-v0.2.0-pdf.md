---
title: "DevEnv-PRoot: Terminal Integration and Package Manager Resolution on Samsung Knox"
subtitle: "Progress Report v0.1.7\u2013v0.2.0"
author: "DevEnv-PRoot Project"
date: "July 22, 2026"
abstract: |
  This progress report covers DevEnv-PRoot builds v0.1.7 through v0.2.0, during which
  the project evolved from a proof-of-concept PRoot chain into a working development
  environment with interactive terminal, HTTPS package management, and a fully passing
  6-step setup pipeline. Three bugs introduced in v0.1.8 (shell quoting, verify
  assertion, double welcome banner) were progressively fixed. The HTTPS TLS
  certificate verification issue was resolved through ca-certificates-bundle upgrade.
bibliography: "../references.bib"
csl: "../ieee.csl"
...

# DevEnv-PRoot: Terminal Integration and Package Manager Resolution on Samsung Knox (v0.1.7\u2013v0.2.0)

**Device:** Samsung SM-S166V (Android 16, API 36, kernel 5.15.189, Knox 3.x)  
**Prerequisite:** breakthrough-v0.1.0 (covers v0.0.1\u2013v0.1.6)

## 1. Introduction

The DevEnv-PRoot project achieved its first successful PRoot execution chain at v0.1.0 [@proot_me; @termux_proot], demonstrating that a musl-linked Alpine Linux binary could execute inside a PRoot sandbox on a locked Samsung Knox Android 16 device. This report documents the subsequent five builds (v0.1.7\u2013v0.2.0) that transformed this proof-of-concept into a usable development environment with three key capabilities: (1) interactive bash terminal, (2) operational package management over HTTPS, and (3) a fully passing 6-step setup pipeline.

## 2. Terminal Integration (v0.1.7)

### 2.1 Implementation

v0.1.7 introduced a terminal interface using Android's WebView [@android_webview_safearea] with a JavaScript bridge. TerminalActivity.java uses ProcessBuilder [@android_processbuilder] to launch `/system/bin/sh proot-launch.sh "bash --login"`, establishing the full PRoot execution chain within an interactive session.

Key design decisions:

- **WebView over TerminalView**: The standard Termux TerminalView widget (from termux-terminal library) was not integrated to minimize dependencies. Instead, a WebView loads `terminal.html` from app assets, providing a basic terminal aesthetic with CSS-controlled styling. Commands flow through `TerminalBridge.sendCommand()` (Java \u2192 shell stdin), and output is captured via BufferedReader on the Process InputStream and injected via `evaluateJavascript()`.

- **Process lifecycle**: Before spawning the shell, the app runs `pgrep -f libproot.so` and `kill` to clean stale PRoot processes from prior sessions [@linux_pgrep]. This prevents "process already running" errors that would occur if the user reopens the terminal without closing a previous session.

- **Error handling**: `redirectErrorStream(true)` merges stderr into stdout, ensuring error messages appear in the terminal output.

### 2.2 Execution Chain

The complete chain for terminal operation:

```
App Java (untrusted_app)
  \u2192 exec /system/bin/sh (system_file, execute)
    \u2192 exec $NATIVE_DIR/libproot.so (apk_data_file, execute_no_trans, stays untrusted_app)
      \u2192 PRoot forks tracee (inherits untrusted_app)
        \u2192 tracee execve /bin/sh (Alpine musl, INTERP not on host)
          \u2192 PRoot uses PROOT_LOADER
          \u2192 tracee execve $NATIVE_DIR/libproot-loader.so (apk_data_file, execute_no_trans)
            \u2192 NO domain transition \u2192 ALLOWED by Knox
            \u2192 Shell runs interactively
```

No regressions from v0.1.0. The terminal connected and accepted commands.

## 3. Profile Scripts and SSL_CERT_FILE (v0.1.8)

### 3.1 Implementation

Two profile scripts were added to `/etc/profile.d/` inside the Alpine rootfs: `00-welcome.sh` (system information banner) and `ssl-cert.sh` (SSL_CERT_FILE export). The launcher was modified to set both `--login` (enabling profile sourcing) and an inline `SSL_CERT_FILE` in the `-c` command string.

### 3.2 Critical: HTTPS TLS Verification

The bundled CA certificate bundle (`ca-certificates-bundle 20230506-r0`) from Alpine 3.19.1 predated the Let's Encrypt YR2 certificate chain transition. `dl-cdn.alpinelinux.org` serves with this chain, causing [@alpine_apk]:

```
tls_post_process_server_certificate:certificate verify failed
```

This was the root cause of HTTPS apk failures from v0.1.0 through v0.1.6. The ca-certificates-bundle from May 2023 does not contain the ISRG Root X2 intermediate needed to verify YR2 certificates.

### 3.3 Three Bugs Introduced

**Bug 1 (Shell quoting, cosmetic):** The welcome script used single quotes:
```sh
echo '  Alpine: $(cat /etc/alpine-release)'
```
POSIX shell treats single-quoted strings literally [@posix_shell]. `$(cat /etc/alpine-release)` printed as literal text instead of expanding to `3.19.1`.

**Bug 2 (Verify assertion, blocking):** The `verify(3)` check used `.equals("OK")`, which failed because the `--login` flag causes profile scripts to print before the `-c` command executes. The output became `|banner|OK` instead of just `OK`.

**Bug 3 (Double banner, annoyance):** The terminal command `sh proot-launch.sh "bash --login"` creates two nested login shells: `/bin/sh --login` (from launcher) and `bash --login` (from -c command). Both independently source `/etc/profile`, printing the welcome banner twice.

## 4. Safe-Area Bottom Fix (v0.1.9)

A single CSS change: `padding-bottom: calc(8px + env(safe-area-inset-bottom, 0px))` on `#input-row` [@css_env]. This prevented the soft keyboard from obscuring the input field. However, no corresponding `safe-area-inset-top` was added, leaving terminal output behind the Android status bar.

## 5. Bug Fixes (v0.1.10)

Two fixes:

**Fix A (Banner quoting):** Changed from single-quoted `$(...)` to:
```sh
echo '  Alpine: '$(cat /etc/alpine-release)''
```
The `$(cat /etc/alpine-release)` is now outside single quotes, enabling shell expansion. Echo receives two arguments (`  Alpine: ` and `3.19.1`).

**Fix B (Verify method):** Changed from `.equals("OK")` to `.endsWith("OK")`. After `trim()`, the last content of the launcher output is always `OK` (the echo OK command). This tolerates any prepended welcome text.

## 6. Version 0.2.0: Terminal Stability

### 6.1 Welcome Guard Variable

The welcome script was wrapped in an environment variable guard:
```sh
if [ -z "$PROOT_WELCOME_SHOWN" ]; then
  export PROOT_WELCOME_SHOWN=1
  echo '=== DevEnv PRoot on Alpine ==='
  ...
fi
```
Environment variables are inherited across exec. When `sh --login` sources the script and sets `PROOT_WELCOME_SHOWN=1`, the subsequently exec'd `bash --login` inherits this value, preventing a second print. This is a standard POSIX shell pattern for preventing duplicate initialization [@posix_shell].

### 6.2 Safe-Area Top

`padding-top: env(safe-area-inset-top, 0px)` was added to `body` [@css_env]. The `env()` CSS function reads the Android system's safe-area value (typically the status bar height, ~24px). With `viewport-fit=cover`, the WebView draws under the status bar unless this padding is present [@android_webview_safearea].

### 6.3 HTTP Fallback Removal

The ~50-line HTTPS\u2192HTTP fallback logic was removed from `step4AlpineInit()`. `apk update` now runs directly over HTTPS. This became possible because:

1. The initial `apk update` succeeds using the Mozilla CA bundle (or HTTP fallback)
2. `apk add ca-certificates-bundle` upgrades from `20230506-r0` to `20250911-r0`
3. The fresh bundle contains current ISRG Root X2, enabling HTTPS verification

The root cause of the HTTPS failure with the Mozilla bundle was not definitively isolated. Three hypotheses remain:
- **Symlink chain issue**: PRoot path translation may not handle the `/etc/ssl/cert.pem \u2192 /etc/ssl/certs/ca-certificates.crt` symlink chain correctly.
- **OpenSSL path translation**: `SSL_CTX_load_verify_locations()` internal `open()` syscalls may fail during PRoot interception for certain path patterns.
- **Bundle format mismatch**: Mozilla's PEM concatenation format may differ from Alpine's expected layout.

### 6.4 Version Milestone

v0.2.0 represents a minor version bump signaling the transition from "core chain working experimentally" to "terminal interface functional + package manager operational."

## 7. Results

### 7.1 Working Capabilities (v0.2.0)

- PRoot chain execution with Alpine Linux rootfs
- Interactive bash terminal via WebView (single banner, safe-area-aware)
- Package management: `apk update` and `apk upgrade` over HTTPS
- All 6 setup steps passing
- 3.7 MB APK (15 entries)

### 7.2 Remaining Limitations

- HTTPS TLS verification root cause not definitively isolated
- No terminal escape sequence handling (WebView limitation)
- Phantom process killer may terminate background sessions [@dont_kill_my_app]

## 8. Conclusion

The v0.1.7\u2013v0.2.0 phase successfully transformed DevEnv-PRoot from a proof-of-concept into a usable development environment. The three bugs introduced in v0.1.8 serve as a textbook case of how adding profile scripts and login shells can cause subtle regressions in nested execution environments. The HTTPS TLS verification issue, despite remaining not fully root-caused, was resolved through practical ca-certificates-bundle management.

## References
