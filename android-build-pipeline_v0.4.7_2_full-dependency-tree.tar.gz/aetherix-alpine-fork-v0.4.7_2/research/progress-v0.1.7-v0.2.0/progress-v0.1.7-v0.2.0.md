# DevEnv-PRoot: Terminal Integration and Package Manager Resolution on Samsung Knox (v0.1.7\u2013v0.2.0)

**Project:** DevEnv-PRoot  
**Versions:** v0.1.7 \u2192 v0.2.0 (July 22, 2026)  
**Device:** Samsung SM-S166V (Android 16, API 36, kernel 5.15.189, Knox 3.x)  
**Prerequisite Report:** breakthrough-v0.1.0.md (covers v0.0.1\u2013v0.1.6)

---

## 1. Scope

This report covers the five build iterations from v0.1.7 through v0.2.0, during which DevEnv-PRoot evolved from a proof-of-concept PRoot chain into a working development environment with:

- An interactive terminal (bash inside PRoot via WebView)
- Operational package management (apk update, apk upgrade over HTTPS)
- A fully passing 6-step setup pipeline

The report documents what was attempted, what worked, what failed, and why.

---

## 2. v0.1.7 \u2014 Terminal Integration

### 2.1 What Was Added

v0.1.7 introduced `TerminalActivity.java` and `terminal.html`. The "Open Terminal" button from the wizard launches a new Activity containing a WebView that displays a terminal interface. Behind the scenes, a Java `ProcessBuilder` starts `/system/bin/sh proot-launch.sh "bash --login"`, which initiates the full PRoot execution chain.

Key implementation choices:

- **WebView over TerminalView**: Rather than integrating Termux's TerminalView widget (which would require adding the termux-terminal library as a dependency), a simple WebView with JavaScript bridge was used. The WebView loads `terminal.html` from assets, which provides a basic terminal look (dark background, green text, pre-wrap output, text input field). Commands are sent via `TerminalBridge.sendCommand()` (Java \u2192 shell stdin) and output is captured via `BufferedReader` on the shell process's `InputStream` and injected into the WebView via `evaluateJavascript()`.

- **PRoot cleanup on startup**: Before launching the shell, the app runs `kill $(pgrep -f libproot.so)` and `kill $(pgrep -f proot-launch)` to clean up any stale PRoot processes from previous sessions. This prevents "Already running" errors.

- **ProcessBuilder with `redirectErrorStream(true)`**: Stderr is merged into stdout so errors appear in the terminal output.

### 2.2 What Worked

The terminal launched successfully. The full execution chain from v0.1.0 applied unchanged:

```
App Java (untrusted_app)
  \u2192 exec /system/bin/sh (system_file)
    \u2192 exec $NATIVE_DIR/libproot.so (apk_data_file, execute_no_trans)
      \u2192 PRoot forks tracee
        \u2192 execve /bin/sh (Alpine musl, INTERP not on host)
          \u2192 PROOT_LOADER (apk_data_file, execute_no_trans)
            \u2192 NO domain transition \u2192 ALLOWED by Knox
```

Process cleanup and stdout/stderr capture all functioned correctly.

### 2.3 What Didn't Work

No regressions were introduced. The terminal was functional but bare: no profile scripts, no welcome banner, no environment variables for OpenSSL/Python/etc.

---

## 3. v0.1.8 \u2014 Profile Scripts and SSL_CERT_FILE

### 3.1 What Was Added

Two profile scripts were added to `/etc/profile.d/` inside the Alpine rootfs:

- **00-welcome.sh**: Prints a welcome banner with system info.
- **ssl-cert.sh**: Sets `SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt`.

The launcher script was modified to include `--login` on the `/bin/sh` invocation and to set `SSL_CERT_FILE` in the `-c` command string. The terminal.html was updated to show "Connected" on first output.

### 3.2 Three Bugs Introduced

**Bug 1: Single-quote shell quoting (cosmetic)**

In `StepRunner.java`, the welcome script was generated using Java string concatenation:

```java
"echo '  Alpine: $(cat /etc/alpine-release)'\n"
```

The shell output was written literally: `echo '  Alpine: $(cat /etc/alpine-release)'`. Because single quotes prevent shell expansion, `$(cat /etc/alpine-release)` appeared in the terminal output as literal text instead of expanding to `3.19.1`.

**Root cause**: The developer assumed single-quoted strings would still allow `$()` expansion, which is a shell-quoting misunderstanding. Single-quoted strings in POSIX shell suppress ALL expansion, including command substitution.

**Bug 2: verify() exact match (blocking)**

The `verify(int step)` method at case 3 checked:

```java
return r.success && r.output.trim().equals("OK");
```

With `--login`, the shell sources `/etc/profile.d/*.sh` before executing the `-c` command. The output became:

```
  === DevEnv PRoot on Alpine ===
  Alpine: $(cat /etc/alpine-release)
  ...
OK
```

After `.trim()`, the string contained the welcome banner plus "OK", making `.equals("OK")` fail.

**Root cause**: The developer didn't account for profile sourcing. When the launcher was first created in v0.0.23, there were no profile scripts, so `.equals("OK")` worked. Adding profile scripts broke the assertion silently.

**Bug 3: Double welcome banner (annoyance)**

TerminalActivity runs: `sh proot-launch.sh "bash --login"`. The launcher script does:

```bash
exec libproot.so ... /bin/sh --login -c "unset LD_LIBRARY_PATH; export SSL_CERT_FILE=...; $*"
```

Where `$*` expands to `bash --login`. This creates a chain of two login shells:

1. `/bin/sh --login` sources profile \u2192 welcome banner #1
2. `bash --login` (started by the `-c` command) sources profile \u2192 welcome banner #2

**Root cause**: The developer assumed the `--login` on the inner `-c` command was redundant, but both `sh --login` and `bash --login` independently source profile.

### 3.3 What Worked

SSL_CERT_FILE injection worked correctly. When set in the launcher's `-c` command, OpenSSL/apk inside PRoot could find the CA bundle. This was the critical enabler for HTTPS apk operations.

### 3.4 What Didn't Work: HTTPS Stale CA Bundle

The bundled Alpine CA bundle (`ca-certificates-bundle 20230506-r0` from May 2023) did not contain the ISRG Root X2 intermediate needed to verify Let's Encrypt's YR2 certificate chain. The CDN `dl-cdn.alpinelinux.org` serves with this chain, causing:

```
tls_post_process_server_certificate:certificate verify failed
```

This was worked around in earlier versions (v0.1.4\u2013v0.1.6) with an HTTP bootstrap strategy: switch repos to HTTP, install `ca-certificates-bundle`, switch back to HTTPS.

---

## 4. v0.1.9 \u2014 Safe-Area Bottom (CSS Only)

### 4.1 What Was Added

A single CSS change: `padding-bottom: calc(8px + env(safe-area-inset-bottom, 0px))` on the `#input-row` element. This ensured the terminal input field was not obscured by the Android soft keyboard or navigation bar.

### 4.2 What Worked

Soft keyboard input worked correctly \u2014 the input field remained visible above the keyboard.

### 4.3 What Didn't Work: Safe-Area Top Missing

The terminal output started behind the Android status bar (camera notch area). The `viewport-fit=cover` meta tag tells the browser the app uses the entire screen, including under the status bar. Without a corresponding `padding-top: env(safe-area-inset-top)`, the first ~24px of terminal output were hidden.

**Root cause**: The developer added safe-area-bottom but forgot safe-area-top. A common oversight when dealing with WebView fullscreen layouts on Android.

---

## 5. v0.1.10 \u2014 Quote Escaping and Verify Fix

### 5.1 Two Fixes

**Fix A: Banner quoting**

Changed from:

```java
"echo '  Alpine: $(cat /etc/alpine-release)'\n"
```

To:

```java
"echo '  Alpine: '$(cat /etc/alpine-release)''\n"
```

The shell output becomes: `echo '  Alpine: '$(cat /etc/alpine-release)''`. The `$(cat /etc/alpine-release)` is now OUTSIDE single quotes, so it expands to `3.19.1`. The `''` at the end is an empty quoted string (no-op). Echo receives two arguments: `  Alpine: ` and `3.19.1`, and prints `  Alpine: 3.19.1`.

**Fix B: Verify method**

Changed from:

```java
return r.success && r.output.trim().equals("OK");
```

To:

```java
return r.success && r.output.trim().endsWith("OK");
```

After `trim()`, the final characters of the output are always `OK` (the output of the `echo OK` command). `endsWith("OK")` tolerates any prepended banner text.

### 5.2 What Still Didn't Work

The double-welcome-banner bug (Bug 3 from v0.1.8) was not yet fixed. The terminal still showed the banner two times on connection.

---

## 6. v0.2.0 \u2014 Welcome Guard, Safe Area Top, HTTP Fallback Removal

### 6.1 Fix 1: Welcome Guard Variable

The welcome script was wrapped in a guard:

```sh
if [ -z "$PROOT_WELCOME_SHOWN" ]; then
  export PROOT_WELCOME_SHOWN=1
  echo ''
  echo '  === DevEnv PRoot on Alpine ==='
  ...
fi
```

When the first login shell (`/bin/sh --login`) sources the script, `PROOT_WELCOME_SHOWN` is unset, so the banner prints and `PROOT_WELCOME_SHOWN` is set to 1. When the second login shell (`bash --login`) sources the same script, `PROOT_WELCOME_SHOWN` is already set (inherited from the parent shell environment), so the `if` block is skipped. The banner prints exactly once.

**Why this works**: Environment variables are inherited across `exec` and across fork/exec. When `sh --login` sources the script and sets `PROOT_WELCOME_SHOWN=1`, it becomes part of the shell's environment. When the `-c` command runs `bash --login`, bash inherits the environment (including `PROOT_WELCOME_SHOWN=1`), so the guard fires correctly on the second source.

### 6.2 Fix 2: Safe-Area Top Padding

```css
body { ... padding-top: env(safe-area-inset-top, 0px); }
```

The `env(safe-area-inset-top)` CSS function reads the Android system's safe-area value, which is typically the height of the status bar (~24px on most devices). The fallback `0px` ensures desktop Chrome renders normally.

**Why this works**: With `viewport-fit=cover`, the WebView is allowed to draw behind the status bar. The safe-area CSS environment variables are set by the platform to indicate the non-obscured region. Adding `padding-top: env(safe-area-inset-top)` pushes the page content below the status bar.

### 6.3 Fix 3: HTTP Fallback Removal

The ~50-line HTTPS\u2192HTTP fallback logic was removed from `step4AlpineInit()`. The method now runs `apk update` directly over HTTPS without any fallback.

**Why this works now**: The first `apk update` (after Step 2's Mozilla CA bundle overwrite) succeeds over HTTPS. The `apk add ca-certificates-bundle` then upgrades the CA bundle from `20230506-r0` to `20250911-r0`. The fresh bundle contains the current Let's Encrypt ISRG Root X2 certificate, and subsequent HTTPS operations work correctly.

**Why this didn't work before**: The bundled Mozilla CA bundle (186KB, 119 certs, from curl.se, June 2026) contained ISRG Root X2, but `apk update` STILL failed when using it. Possible explanations:

1. **Symlink chain issue through PRoot**: Alpine's OpenSSL looks for CA certificates through `/etc/ssl/cert.pem` or `/etc/ssl/certs/ca-certificates.crt`. The Mozilla bundle was written to `/etc/ssl/certs/ca-certificates.crt`, but OpenSSL may have been checking `/etc/ssl/cert.pem` \u2192 `/etc/ssl/certs/ca-certificates.crt` through a symlink chain that PRoot's path translation didn't handle correctly.

2. **SSL_CTX_load_verify_locations path translation**: OpenSSL's internal `SSL_CTX_load_verify_locations()` uses `open()` syscalls. PRoot intercepts these via ptrace, but the interception may have failed for certain path forms or directory iteration patterns.

3. **Bundle format issue**: The Mozilla bundle is PEM-concatenated. Alpine's `update-ca-certificates` expects a specific format or directory structure that a raw PEM file doesn't provide.

The fix resolved by installing Alpine's own `ca-certificates-bundle` package, which sets up proper symlinks and format. The root cause was never definitively isolated, but the outcome is consistent HTTPS operation.

### 6.4 Version Bump: v0.2.0

The build script normally auto-increments the patch version (v0.1.10 \u2192 v0.1.11). For this release, the minor version was explicitly bumped to 2, signaling that the project has moved from "core chain working experimentally" to "terminal interface functional + package manager operational."

---

## 7. What Worked (Cumulative, v0.2.0)

| Capability | Status | Since |
|-----------|--------|-------|
| PRoot chain execution | Working | v0.0.23 |
| Step 1 (extract libs) | Passing | v0.0.x |
| Step 2 (extract rootfs) | Passing | v0.0.x |
| Step 3 (launcher test) | Passing | v0.0.23 |
| Step 4 (apk update) | Passing (HTTPS) | v0.2.0 |
| Step 5 (shell verify) | Passing | v0.1.0 |
| Terminal interface | Working | v0.1.7 |
| Welcome banner | Working (once) | v0.2.0 |
| Safe area (top) | Working | v0.2.0 |
| Safe area (bottom) | Working | v0.1.9 |
| HTTPS apk operations | Working | v0.2.0 |
| Terminal process cleanup | Working | v0.1.7 |

---

## 8. What Didn't Work (and Why)

### 8.1 HTTPS TLS Verification with Bundled CA Bundle

**Failed**: Using the bundled Mozilla CA bundle (186KB, June 2026 from curl.se).  
**Worked**: Using Alpine's `ca-certificates-bundle` installed via HTTP bootstrap.  
**Root cause not confirmed**: Three hypotheses remain unverified. The most likely explanation involves a PRoot path translation issue for OpenSSL's certificate directory scanning, or a format mismatch between Mozilla's PEM concatenation and Alpine's expected layout.

### 8.2 Double Welcome Banner

**Failed**: v0.1.8\u2013v0.1.10 showed banner twice.  
**Fixed**: v0.2.0 with environment variable guard.  
**Root cause**: Nested login shells (`/bin/sh --login` \u2192 `bash --login`) both source /etc/profile independently.

### 8.3 Terminal Behind Status Bar

**Failed**: v0.1.7\u2013v0.1.10.  
**Fixed**: v0.2.0 with `padding-top: env(safe-area-inset-top)`.  
**Root cause**: `viewport-fit=cover` with no safe-area top padding. Common WebView fullscreen oversight.

### 8.4 verify() Step 3 Assertion

**Failed**: v0.1.8\u2013v0.1.9.  
**Fixed**: v0.1.10 with `.endsWith("OK")`.  
**Root cause**: Profile scripts added output before the test command, making exact string match fail.

### 8.5 Welcome Banner Shell Expansion

**Failed**: v0.1.8\u2013v0.1.9.  
**Fixed**: v0.1.10 with correct shell quoting.  
**Root cause**: Single quotes around `$(...)` prevented command substitution.

---

## 9. Key Metrics

| Metric | Value |
|--------|-------|
| Versions in this report | 5 (v0.1.7\u2013v0.2.0) |
| Total versions (project) | 30+ (v0.0.1\u2013v0.2.0) |
| Bugs introduced | 3 (all in v0.1.8) |
| Bugs fixed | 5 (1 per v0.1.10, 3 per v0.2.0, 1 fixed in v0.1.8\u2013v0.1.9 range) |
| APK size (v0.2.0) | 3.7 MB (15 entries) |
| Steps passing | 6/6 |
| Terminal state | Functional, single banner, safe-area-aware |

---

## 10. Conclusion

The v0.1.7\u2013v0.2.0 phase transformed DevEnv-PRoot from a proof-of-concept into a usable development environment. The most difficult problem (HTTPS apk operations) was resolved through a combination of CA bundle management strategies, culminating in the automatic upgrade to the current CA bundle via `ca-certificates-bundle` from the Alpine repository. The three bugs introduced in v0.1.8 (banner quoting, verify assertion, double banner) were progressively fixed across three subsequent versions, serving as a textbook example of how feature additions can introduce subtle regressions when edge cases (nested login shells, profile sourcing, exact string matching) are not fully considered.

---

## References

See [references.bib](../references.bib) for full citation details. Key references for this phase:

- Termux proot (bionic fork): termux_proot
- PRoot official documentation: proot_me
- Mozilla CA certificate bundle: mozilla_ca_bundle
- Samsung Knox DEFEX: samsung_knox_defex
- Android WebView safe-area: android_webview_safearea
- CSS env() function: css_env
- Alpine Linux package management: alpine_apk
