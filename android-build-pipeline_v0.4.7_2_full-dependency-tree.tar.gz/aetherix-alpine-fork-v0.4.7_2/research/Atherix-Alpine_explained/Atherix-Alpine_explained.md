# Atherix-Alpine Explained

**A Linux Environment for Locked Samsung Phones**

**Version:** v0.2.0 | **Size:** 3.7 MB | **What You Need:** A Samsung phone with Developer Mode and USB debugging

---

## What Is This?

Atherix-Alpine is an Android app that turns your locked Samsung phone into a portable Linux computer. No root. No jailbreak. No special permissions.

You install the app, run through a 6-step setup, and you get a working Linux terminal with a package manager that can install Python, Git, Node.js, GCC, databases, and hundreds of other tools. Everything runs inside a secure sandbox on your phone.

It was built because normal Linux-on-Android apps like Termux do not work on Samsung phones with Knox security (most corporate and government devices). Atherix-Alpine solves this by using a technique that Samsung's security system does not block.

---

## Why Would Anyone Want This?

Most people don't need Linux on their phone. But if you're any of these people, Atherix-Alpine might be exactly what you've been looking for:

- **A developer whose work phone is a Samsung** and IT won't let you unlock the bootloader or switch devices
- **A student who's learning Linux** but only has a phone and no laptop
- **A system administrator** who needs to SSH into servers and run diagnostics from the field
- **A security researcher** testing on locked-down devices
- **Anyone who travels light** and wants a development environment in their pocket
- **An IT professional** managing infrastructure from a mobile device
- **A hobbyist** who just wants to play with Linux commands on their phone

You get a real, full Linux environment \u2014 the same tools you'd have on a desktop Ubuntu or Debian system \u2014 running on a device that fits in your pocket.

---

## How It Works (In Plain Language)

### The Short Version

Your phone has security (Samsung Knox) that checks every program before it runs. Most Linux programs fail these checks because they're written for a different kind of system. Atherix-Alpine uses a clever trick: it runs everything through a back door that Samsung has to leave open for every app. The program never triggers a single security alarm.

### The Longer Version (Still No Jargon)

Think of your Samsung phone as a secure office building:

- Every door has a badge reader
- Security guards (Samsung Knox) check badges at every door
- Different colored badges let you into different rooms
- If you try to enter a room you don't have access to, an alarm goes off

Normal apps have a blue badge (`untrusted_app`). They can go to most rooms, but they cannot run programs written for a different operating system.

App B (Termux, the popular Linux app) tries to use a different door that gives it a purple badge (`linker`). With a purple badge, it can now run Linux programs. But on Samsung phones, the security guards have extra training (`DEFEX`). They check: "Did you just change your badge color? That's suspicious. Alarm!" And the program gets killed.

Atherix-Alpine does something different. Instead of switching to a purple badge, it stays blue the whole time. It uses a special back door that security must leave open for every app (the `nativeLibraryDir` / `apk_data_file` door). Every Linux program it runs enters through this same back door, always showing the same blue badge. Security checks happen, but they all pass because the badge never changes. No alarm ever sounds.

### What's Actually Inside the App

| Piece | What It Does |
|-------|-------------|
| PRoot | A translator that converts Linux program requests into Android-compatible operations. Every time a Linux program needs to access a file or start another program, PRoot intercepts the request and translates it. |
| Alpine Linux | A tiny, complete Linux system (28 MB when unpacked). It contains bash (the command shell), apk (the package manager), BusyBox (a collection of essential Unix tools), and all the libraries Linux programs need. |
| PROOT_LOADER | A special helper program that loads Linux binaries into memory. Most Linux programs are written for musl libc, which Android doesn't have. The loader bridges this gap. |
| The Terminal | A terminal window built with web technology that shows a command prompt and lets you type commands. Commands go into the sandbox, output comes back to the screen. |
| The Wizard | A 6-step setup process that installs everything. You tap "Run Step" six times, and after a few minutes, you have a working Linux environment. |

### The 6-Step Wizard

| Step | What Happens | Time |
|------|-------------|------|
| 1 | Install support libraries (PRoot's helpers) | ~2 seconds |
| 2 | Extract Alpine Linux root filesystem and CA certificates | ~5 seconds |
| 3 | Create and test the launcher script | ~3 seconds |
| 4 | Run `apk update`, install `ca-certificates-bundle`, install `bash` and `coreutils` | ~30 seconds (needs internet) |
| 5 | Verify that bash works correctly | ~2 seconds |
| 6 | All done! Open the terminal | \u2014 |

---

## The Problem It Solves

### The Samsung Knox Problem

Samsung Knox is a set of security extensions that Samsung adds to Android on its phones. It's why Samsung phones are considered more secure than other Android phones, and why many companies and governments issue them to employees.

Knox includes two main components that affect Linux-on-phone apps:

- **DEFEX (Defeat Exploit)**: Watches for programs that try to change their security level. If a program starts as one type and tries to become another type, DEFEX stops it.
- **RKP (Real-time Kernel Protection)**: Protects the core of the operating system from being modified. Runs in a separate, ultra-secure part of the phone's processor.

These features make Samsung phones very secure. But they also break standard Linux-on-phone apps.

### Why Termux and Other Apps Don't Work

Termux is the most popular Linux terminal for Android (10+ million installs). It works on most phones by using a standard trick: it runs programs through Android's dynamic linker (`/system/bin/linker64`), which temporarily gives programs different security permissions. This is a well-known technique that works on Google Pixel phones, OnePlus phones, and most others.

On Samsung phones with Knox, this trick fails. The linker-based approach makes programs change their security level (`linker` domain), and Samsung's DEFEX catches this and blocks it. The program gets killed with an "Operation not permitted" error.

This has been a known problem in the Android community for years, with no solution \u2014 until Atherix-Alpine.

---

## 12 Use Cases

Here's what you can actually DO with this app. Each use case shows what works today and what might be possible with future upgrades.

### Working Today

**1. Python Scripting**

Install Python 3 and run .py scripts directly from your phone. Process data, build tools, practice programming.

*Install:* `apk add python3`
*Try:* `python -c "print('hello from alpine')"`

**2. Git Version Control**

Clone GitHub repos, commit changes, push and pull. Manage branches, review diffs, write commit messages \u2014 all from your phone.

*Install:* `apk add git`
*Try:* `git clone https://github.com/your/project.git`

**3. Local Web Server**

Run Node.js, Python Flask, or any HTTP server locally. Test web apps before deploying. Great for learning web development on mobile.

*Install:* `apk add nodejs` or `apk add python3`
*Try:* `python3 -m http.server 8080`

**4. SSH to Remote Servers**

Connect to your cloud VPS, work server, or home computer from a proper bash terminal. Manage infrastructure from the field.

*Install:* `apk add openssh`
*Try:* `ssh user@server.example.com`

**5. Text Processing with grep, awk, sed**

Process log files, parse JSON from APIs, transform CSV data. All standard Unix text tools come built-in.

*No install needed* (BusyBox is pre-installed)
*Try:* `cat /etc/alpine-release | grep -o '^[0-9]'`

**6. Compile C, Go, or Rust Programs**

Write and compile code directly on your phone. Practice programming without needing a laptop.

*Install:* `apk add gcc make` or `apk add go` or `apk add rust`
*Try:* `echo 'main(){puts("hi");}' | gcc -xc - -o /tmp/test && /tmp/test`

**7. Run Databases Locally**

Install SQLite, MariaDB, or PostgreSQL for local development. Test queries, design schemas, prototype applications.

*Install:* `apk add sqlite` or `apk add mariadb`
*Try:* `sqlite3 /tmp/test.db "CREATE TABLE t(v); INSERT INTO t VALUES(1); SELECT * FROM t;"`

**8. Network Diagnostics**

Check SSL certificates, measure bandwidth, trace network routes. Diagnose connectivity issues from your phone.

*Install:* `apk add curl nmap iperf3 mtr`
*Try:* `curl -v https://example.com`

**9. DevOps and Cloud Tools**

Manage servers with Ansible, deploy infrastructure with Terraform, control Kubernetes clusters with kubectl. Respond to production incidents from anywhere.

*Install:* `apk add ansible` or `apk add terraform`
*Try:* `ansible all -m ping`

**10. Media Processing with ffmpeg**

Convert video formats, extract audio tracks, resize batches of images. Use your phone's processor for media encoding.

*Install:* `apk add ffmpeg`
*Try:* `ffmpeg -i input.mp4 -c copy output.avi`

### Future / Needs More Work

**11. Background Task Automation (Cron)**

Schedule periodic tasks like backup scripts or log rotation. Currently blocked by Android's "Phantom Process Killer" which kills background processes after about 30 seconds. This affects ALL Linux-on-phone apps, not just Atherix-Alpine.

*What's needed:* A foreground service in the app, or a Developer Options tweak to disable phantom process monitoring.

**12. GUI Applications**

Run graphical Linux programs with a window manager and VNC. Access them from a separate VNC viewer app. Would allow running full desktop applications on your phone screen.

*What's needed:* Install Xfce or similar window manager + TigerVNC inside the sandbox, connect from a VNC app on the same phone. Performance depends on the phone's CPU.

---

## What Works Right Now (v0.2.0)

| Feature | Status |
|---------|--------|
| Interactive bash terminal | Working |
| Package management (`apk update`, `apk upgrade`) | Working over HTTPS |
| Install any Alpine package | Working |
| Welcome banner (shows system info) | Working, shown once |
| Screen safe areas (status bar, keyboard) | Handled correctly |
| Process cleanup (no stale PRoot processes) | Working |
| All 6 setup steps | Passing |

### What's Limited

| Limitation | Why |
|-----------|-----|
| Background processes killed after ~30 seconds | Android Phantom Process Killer (affects ALL Linux-on-phone apps) |
| No GUI applications yet | Needs VNC server + client integration |
| No Docker or containers | Needs kernel features that may not be available on locked phones |
| WebView terminal (limited escape sequences) | Simpler than Termux's native TerminalView, trade-off for smaller app size |

---

## How to Get It

### Requirements

- Samsung phone with Developer Mode enabled
- USB debugging turned on
- A computer with `adb` installed

### Installation

1. Download the APK from the releases page (or use `adb push` to transfer it)
2. Connect your phone to your computer via USB
3. Run: `adb install DevEnv-PRoot-v0.2.0.apk`
4. Open the app
5. Tap through the 6-step wizard (internet required for Step 4)
6. Click "Open Terminal" and start using Linux commands

### Why ADB Installation Is Needed

Atherix-Alpine is self-signed (like most independent Android apps). Samsung phones, by default, only allow installation of apps signed by known certificates (Google Play Store, Samsung Galaxy Store). Self-signed apps must be installed through ADB from a computer. This is a Samsung policy, not something the app can change.

---

## Project Status and Roadmap

| Phase | Status |
|-------|--------|
| Core PRoot execution chain | v0.1.0 (Complete) |
| Package manager (apk over HTTPS) | v0.2.0 (Complete) |
| Interactive terminal | v0.2.0 (Complete) |
| Safe-area UI, profile scripts | v0.2.0 (Complete) |
| Performance optimization | Future |
| Additional Linux distributions | Future |
| GUI forwarding (VNC) | Future |
| Background service for cron | Future |

---

## Technical Appendix

*For those who want the technical details. Skip this section if you don't care \u2014 it won't affect your ability to use the app.*

### Device Tested

- **Phone:** Samsung SM-S166V
- **Android:** 16 (API 36)
- **Kernel:** 5.15.189-android13-3-33503169
- **SELinux:** Enforcing, `u:r:untrusted_app:s0`
- **Knox:** 3.x with DEFEX + RKP

### The Bypass in One Sentence

PRoot is executed from the app's native library directory (file type `apk_data_file`, SELinux permission `execute_no_trans`), and all child processes use the same mechanism \u2014 so the process NEVER changes SELinux domain, and Samsung Knox's cross-domain ptrace check is NEVER triggered.

### Architecture Diagram (Text)

```
App Java \u2192 exec /system/bin/sh
  \u2192 exec libproot.so (from nativeLibraryDir, stays untrusted_app)
    \u2192 PRoot forks child (stays untrusted_app)
      \u2192 child tries to run Alpine's /bin/sh
        \u2192 PRoot: Alpine binary needs PROOT_LOADER
        \u2192 child execs libproot-loader.so (from nativeLibraryDir, stays untrusted_app)
          \u2192 NO security zone change \u2192 Samsung Knox allows it
          \u2192 Alpine shell runs. You get a bash prompt.
```

### Key Files in the APK

| File | Size | Purpose |
|------|------|---------|
| `libproot.so` | 231 KB | The PRoot engine (does all the translation work) |
| `libproot-loader.so` | 18 KB | The loader that runs Alpine binaries on Android |
| `alpine-minirootfs.tar` | 8.6 MB | The Alpine Linux filesystem (extracted to app data) |

### References

Detailed technical reports are available in the research folder:

- `breakthrough-v0.1.0.md` \u2014 How the SELinux bypass works (technical)
- `progress-v0.1.7-v0.2.0/` \u2014 How terminal + HTTPS were implemented
- `project-report-v0.0.1-v0.2.0/` \u2014 Complete version history and bug analysis
- `Atherix-Alpine_explained.json` \u2014 Structured data version of this document

---

*Generated July 22, 2026 for Atherix-Alpine / DevEnv-PRoot v0.2.0*
