# v0.0.22 — Function Test Step + LD_PRELOAD Removal

**Date:** 2026-07-21  
**APK Size:** 3.6M (13 entries)  
**Steps:** 6 (Step 2.5 = Function Test inserted between Steps 2 and 3)

---

## What Changed

### Root Cause of v0.0.21 Failure

`LD_PRELOAD=libdexec.so` was inherited by PRoot's ptrace child process. When the tracee called `execve("/system/bin/sh")`, libdexec.so intercepted it and redirected through `/system/bin/linker64`. This confused PRoot's ptrace mechanism → `Operation not permitted`.

**Fix:** Remove `LD_PRELOAD`, `TERMUX_EXEC__SYSTEM_LINKER_EXEC__MODE`, and `TERMUX__PREFIX` from the launcher script. With PRoot now running in `untrusted_app` domain (not `linker`), `PROOT_LOADER=$NATIVE_DIR/libproot-loader.so` (apk_data_file) should work directly without any execve interception shim.

### Step 2.5 — Function Test

New diagnostic step inserted between Alpine rootfs extraction and launcher creation. Runs 6 checks and reports pass/fail:

| # | Check | Critical? | Details |
|---|-------|-----------|---------|
| 1 | SELinux Domain | Info | Reads `/proc/self/attr/current` |
| 2 | Shell Test | **Yes** | `echo FUNCTION_TEST_OK` via `/system/bin/sh` |
| 3 | PRoot Binary Exec | **Yes** | Runs `libproot.so` with no args via `LD_LIBRARY_PATH` |
| 4 | PROOT_LOADER Check | **Yes** | `ls -l` on `libproot-loader.so` |
| 5 | Temp Dir Writable | **Yes** | `touch` file in `proot/tmp/` |
| 6 | Rootfs Integrity | Info | `ls -la /bin/sh`, `cat /etc/alpine-release`, `ls /bin/` |

If any critical check fails, Step 2.5 returns failure and Step 3 stays locked.

### Launcher Script (v0.0.22)

```bash
#!/system/bin/sh
PROOT_DIR=<filesDir>/proot
ROOTFS=<filesDir>/rootfs/alpine
SDK=<filesDir>/sdk
NATIVE_DIR=<nativeLibDir>
mkdir -p $SDK $PROOT_DIR/tmp
export PROOT_NO_SECCOMP=1
export PROOT_LINK2SYMLINK=1
export LD_LIBRARY_PATH=$PROOT_DIR/lib
export PROOT_TMP_DIR=$PROOT_DIR/tmp
export PROOT_LOADER=$NATIVE_DIR/libproot-loader.so
exec $NATIVE_DIR/libproot.so \
  -0 -r $ROOTFS \
  -b /dev -b /proc -b /sys \
  -b /system:/system \
  -b $SDK:/opt/android-sdk \
  -b /sdcard:/mnt/sdcard \
  -w /root --link2symlink \
  /system/bin/sh --login -c "$*"
```

No LD_PRELOAD. No termux-exec env vars. PROOT_LOADER points to apk_data_file in nativeLibraryDir.

### Changed Files

| File | Change |
|------|--------|
| `app/.../StepRunner.java` | Added `step25FunctionTest()` method at case index 2. Shifted launcher→3, alpine-init→4, shell-ready→5. Updated all step labels (e.g., "Step 1/6"). Updated `verify()` switch with case 2 (combined prerequisite check). Fixed `step3Launcher()` — removed LD_PRELOAD + termux-exec env vars. |
| `app/.../InstallBridge.java` | Added "Function Test" to `STEP_NAMES[2]` and `STEP_DESCS[2]`. Resized `stepStatus` from 5→6. Updated all loops `i < 5` → `i < 6`. Updated boundary checks `>= 5` → `>= 6`. |
| `app/.../assets/www/script.js` | Updated `renderSteps()` loop: `i < 5` → `i < 6`. |
| `releases/v0.0.22/` | Full source snapshot with changelog. |

### Execution Chain (v0.0.22, expected)

```
1. App Java (untrusted_app)
2.   → exec /system/bin/sh (system file → ALLOWED)
3.     → shell script sets env vars (no LD_PRELOAD)
4.       → exec $NATIVE_DIR/libproot.so (apk_data_file → untrusted_app CAN exec)
5.         → kernel loads INTERP /system/bin/linker64 (system_file → ALLOWED)
6.           → linker64 loads libproot.so + deps from LD_LIBRARY_PATH
7.             → PRoot runs in untrusted_app domain
8.               → PRoot forks tracee child (inherits untrusted_app)
9.               → tracee calls execve(PROOT_LOADER = apk_data_file)
10.               → untrusted_app exec apk_data_file → executeNoTransition → ALLOWED
11.                 → loader loads /system/bin/sh (via PRoot path translation)
12.                   → shell runs inside PRoot sandbox ✓
```

### Test Plan

1. Install `DevEnv-PRoot-v0.0.22.apk` on device
2. Run Steps 1 → 2 → **2.5** → observe diagnostic output
3. If Step 2.5 passes all critical checks, attempt Step 3
4. Report all output for analysis

### Version History

| Version | Approach | Status |
|---------|----------|--------|
| v0.0.10-20 | linker domain approaches | All blocked |
| v0.0.21 | untrusted_app + LD_PRELOAD | Blocked: libdexec.so interfered with PRoot ptrace |
| **v0.0.22** | **untrusted_app + PROOT_LOADER only** | **NEW — no LD_PRELOAD, proper domain** |
