# Adaptive Terminal Sizing for Aetherix Alpine on Samsung Android 16: Master Synthesis and Implementation Plan

## Abstract

This document synthesizes findings from five independent research investigations into the problem of adaptive terminal sizing on Samsung Android 16 (kernel 5.15), where the TIOCSWINSZ ioctl is blocked by SELinux on both master (ENOTTY) and slave (EACCES) PTY file descriptors. We analyze the root cause across kernel, SELinux, and vendor policy layers, survey solutions including LD_PRELOAD ioctl interception, alternative SIGWINCH delivery, PRoot extension syscall rewriting, and mobile industry best practices, and present a ranked, phased implementation plan. The recommended approach combines an LD_PRELOAD TIOCGWINSZ faker (returns COLUMNS/LINES) with TIOCSIG/kill(-pgid) SIGWINCH delivery from the subprocess, supplemented by UI-layer improvements for keyboard detection and Android 16 resizability compliance.

---

## 1. Root Cause Analysis

### 1.1 Master fd (ENOTTY, errno -25)

The SELinux LSM hook (`security_file_ioctl()`) intercepts ioctl calls before they reach the TTY handler. The `unpriv_tty_ioctls` whitelist in AOSP SELinux policy is applied to `untrusted_app_devpts` (slave PTY context) but **not** to `ptmx_device` (master PTY context). TIOCSWINSZ (0x5414) is in the whitelist but the allowxperm rule for `ptmx_device:chr_file` is missing. The kernel returns ENOTTY because the LSM layer does not recognize the ioctl command before the TTY handler is reached.

### 1.2 Slave fd (EACCES, errno -13)

Samsung's vendor SELinux policy (`nonplat_sepolicy.cil` and SEPF) overrides AOSP's `unpriv_tty_ioctls` baseline, imposing Knox-specific restrictions on `/dev/pts/*` ioctls. Community reports confirm SELinux denials for PTY ioctls (TCXONC 0x540a, TCSETSF 0x5404, and likely TIOCSWINSZ 0x5414) on Samsung Android 16 devices.

### 1.3 Kernel handler is functional

The kernel's TIOCSWINSZ → `tiocswinsz()` → `pty_resize()` → `kill_pgrp(SIGWINCH)` chain in `drivers/tty/pty.c` is fully functional on upstream Linux 5.15. The failure occurs at the SELinux LSM layer, before the TTY handler.

### 1.4 Broader Samsung PTY restrictions

Termux community reports confirm systemic PTY-related failures on Samsung Android 16: GDB crashes, GNU Screen SELinux denials, SSHD hangs with screen off, and APT/apt-get failures. This suggests Samsung's hardening extends beyond TIOCSWINSZ to multiple PTY ioctls.

---

## 2. Comparative Analysis of Approaches

| # | Approach | Confidence | Impact | Effort | Risk | Score | Source |
|---|----------|-----------|--------|--------|------|-------|--------|
| 1 | LD_PRELOAD ioctl(TIOCGWINSZ) faker | High | High | Low | Low | 81 | Q2, Q4 |
| 2 | TIOCSIG/kill(-pgid) SIGWINCH from subprocess | High | High | Low | Low | 81 | Q3 |
| 3 | Keyboard sentinel View + OnGlobalLayoutListener | High | High | Low | Low | 81 | Q5 |
| 4 | SELinux Magisk injection (allowxperm 0x5414) | High | High | Low | Medium | 54 | Q1 |
| 5 | COLUMNS/LINES env vars + bash checkwinsize | Medium | Medium | Very Low | None | 48 | Q2 |
| 6 | WindowInsets API for keyboard detection (API 30+) | High | Medium | Medium | Low | 36 | Q5 |
| 7 | DECSET 2048 in-band resize protocol | Medium | Medium | Medium | Low | 24 | Q3, Q5 |
| 8 | PRoot fake_winsize extension | Medium | High | High | Medium | 12 | Q4 |
| 9 | pidfd_send_signal from Java/JNI | Low | Medium | High | Medium | 4 | Q3 |

**Score formula:** Confidence(3/1) × Impact(3/1) × Effort(1~3) × Risk(1~3), normalized. Max = 81.

---

## 3. Phased Implementation Plan

### Phase 0: Quick Wins (hours-1 day)

**Goal:** Validate that environment variable approach works for basic programs.

1. **Set COLUMNS/LINES in Alpine environment**
   - Add to `/etc/profile.d/terminal.sh` in Alpine rootfs
   - Export COLUMNS and LINES based on actual terminal dimensions
   - Enable bash `checkwinsize` shopt via `/etc/bash/bashrc`

2. **Test with ncurses programs**
   - Launch nano, vim, htop with COLUMNS/LINES set
   - Verify initial display size is correct
   - Note: SIGWINCH-driven resize will NOT work (kernel never delivers it)

3. **Files to modify:**
   - `/root/android-dev-env/native/pty-bridge.c` — ensure ESC ESC W carries new dims
   - Alpine rootfs `/etc/profile.d/terminal.sh` — export COLUMNS/LINES
   - Alpine rootfs `/etc/bash/bashrc` — enable `shopt -s checkwinsize`

4. **Verification:**
   - `echo $COLUMNS $LINES` shows correct values
   - `nano` opens at correct size
   - `stty size` returns expected values (falls back to COLUMNS/LINES via shell)

---

### Phase 1: Core Fix (1-3 days)

**Goal:** Implement reliable TIOCGWINSQ and SIGWINCH for dynamically-linked Alpine programs.

#### 1a. LD_PRELOAD ioctl(TIOCGWINSZ) Interceptor

Build a shared library (`libfaketty.so`) that intercepts `ioctl()` and returns synthetic winsize from COLUMNS/LINES for TIOCGWINSZ:

```c
#define _GNU_SOURCE
#include <dlfcn.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef int (*ioctl_fn)(int, int, ...);
static ioctl_fn real_ioctl = NULL;

int ioctl(int fd, int request, ...) {
    if (!real_ioctl)
        real_ioctl = (ioctl_fn)dlsym(RTLD_NEXT, "ioctl");

    if (request == TIOCGWINSZ) {
        // Only intercept on TTY fds to avoid SELinux denials on pipes
        if (isatty(fd)) {
            va_list ap;
            va_start(ap, request);
            struct winsize *ws = va_arg(ap, struct winsize *);
            va_end(ap);

            char *cols = getenv("COLUMNS");
            char *lines = getenv("LINES");
            if (cols && lines && ws) {
                ws->ws_col = atoi(cols);
                ws->ws_row = atoi(lines);
                return 0;
            }
        }
    }
    if (request == TIOCSWINSZ) {
        // Accept but discard — kernel blocks it anyway
        return 0;
    }

    va_list ap;
    va_start(ap, request);
    void *arg = va_arg(ap, void *);
    va_end(ap);
    return real_ioctl(fd, request, arg);
}
```

**Key considerations:**
- Compile with `musl-gcc -shared -fPIC -o libfaketty.so libfaketty.c -ldl`
- Place in Alpine rootfs at `/usr/lib/libfaketty.so`
- Inject via `LD_PRELOAD` in PRoot launcher script
- Guard TIOCGWINSZ with `isatty()` to prevent SELinux denials on non-TTY fds
- Return success for TIOCSWINSZ (accept-and-discard) to prevent application errors

#### 1b. TIOCSIG / kill(-pgid, SIGWINCH) in subprocess

In `pty-bridge.c` (the subprocess that holds the PTY master fd):

```c
// After receiving ESC ESC W [rows] [cols] via stdin pipe:
void handle_resize(int master_fd, int slave_fd, int rows, int cols) {
    // Option A: TIOCSIG on master fd
    // (best if available — sends SIGWINCH to slave's fg process group)
    int sigwinch = SIGWINCH;
    if (ioctl(master_fd, TIOCSIG, &sigwinch) == 0)
        return;

    // Option B: kill(-pgid) via tcgetpgrp on slave fd
    pid_t pgid = tcgetpgrp(slave_fd);
    if (pgid > 0) {
        kill(-pgid, SIGWINCH);
    }
}
```

**Verification:**
- `trap 'echo resize' SIGWINCH; while true; do sleep 1; done` prints "resize" on resize
- `nano` redraws after keyboard show/hide in terminal
- `vim` redraws correctly after rotation
- `htop` updates column layout on resize

---

### Phase 2: UI Layer Improvements (1-2 weeks)

**Goal:** Proper keyboard detection, Android 16 compliance, smooth viewport transitions.

#### 2a. Keyboard Overlap Sentinel View

Add a 1dp transparent View at the bottom of the root view layout, monitored with `OnGlobalLayoutListener`. When the sentinel's visible height drops below ~1dp, the keyboard is overlapping the terminal content. Apply dynamic bottom margin.

Reference: Termux `TermuxActivityRootView.java`

#### 2b. Modern WindowInsets API

For API 30+:
- Replace `SOFT_INPUT_ADJUST_RESIZE` with `setDecorFitsSystemWindows(false)`
- Use `OnApplyWindowInsetsListener` with `WindowInsetsCompat.Type.ime()`
- Animate transitions with `WindowInsetsAnimationCompat.Callback`

Keep `SOFT_INPUT_ADJUST_RESIZE` as fallback for API < 30.

#### 2c. configChanges Declaration

Set in AndroidManifest.xml:
```xml
<activity
    android:configChanges="orientation|screenSize|smallestScreenSize|density|screenLayout|uiMode|keyboard|keyboardHidden|navigation"
    android:windowSoftInputMode="adjustResize"
    android:resizeableActivity="true">
```

Handle `onConfigurationChanged()` to recalculate font metrics and trigger resize.

#### 2d. Font Metrics Recalculation

Implement proper columns/rows calculation:
```java
int columns = (int) Math.floor((float) viewWidth / fontCharWidth);
int rows = (int) Math.floor((float) (viewHeight - descent) / (fontLineSpacing));
```

Use `Paint.getFontMetrics()` or `Typeface` measurements. Cache font metrics and recalculate on density change and font size change.

---

### Phase 3: Advanced (conditional, 2-4 weeks)

**Goal:** Static binary support, root-based fix, in-band protocol.

#### 3a. SELinux Policy Injection (requires root)

If device is rooted with Magisk:
```bash
magiskpolicy --live 'allowxperm untrusted_app ptmx_device chr_file ioctl 0x5414'
magiskpolicy --live 'allowxperm untrusted_app untrusted_app_devpts chr_file ioctl 0x5414'
```

Also consider broader PTY ioctl fix:
```bash
magiskpolicy --live 'allowxperm untrusted_app devpts chr_file 0x5400-0x54FF'
```

#### 3b. PRoot fake_winsize Extension

If static binary support (Go, Rust, busybox static) is needed:

1. Fork `termux/proot`
2. Add `src/extension/fake_winsize/fake_winsize.c`
3. Add `PR_ioctl` to `FilteredSysnum filtered_sysnums[]`
4. In `SYSCALL_ENTER_END`: intercept TIOCSWINSZ → store winsize in extension context
5. In `SYSCALL_EXIT_START`: intercept TIOCGWINSZ → return stored winsize
6. Communication channel: environment variables or shared memory

Build statically for Android ARM64 with NDK.

#### 3c. DECSET 2048 In-Band Resize Protocol

Implement Private Mode 2048 from the DECSET specification:
- Terminal sends `CSI 48 ; rows ; cols ; height_px ; width_px t` through PTY stream
- Applications opt-in by enabling the mode
- Provides alternative resize notification when TIOCSWINSZ/SIGWINCH is blocked

---

## 4. Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Java Process (UI)                    │
│  ┌────────────────────────────────────────────┐      │
│  │ TerminalView                                │      │
│  │  onSizeChanged() → updateSize() → ...      │      │
│  │  OnGlobalLayoutListener (sentinel)          │      │
│  │  OnApplyWindowInsetsListener (IME)          │      │
│  └──────────────┬─────────────────────────────┘      │
│                 │ ESC ESC W [rows] [cols]             │
│                 ▼                                     │
│  ┌────────────────────────────────────────────┐      │
│  │ stdin Pipe                                  │      │
│  └──────────────┬─────────────────────────────┘      │
└─────────────────┼───────────────────────────────────┘
                  │
┌─────────────────┼───────────────────────────────────┐
│  ▼              ▼                                    │
│  libpty-bridge.so (subprocess)                       │
│  ┌────────────────────────────────────────────┐      │
│  │ Receives ESC ESC W from stdin pipe          │      │
│  │  → TIOCSIG(master_fd, SIGWINCH)            │      │
│  │  → OR kill(-tcgetpgrp(slave_fd), SIGWINCH)  │      │
│  │  → OR (fallback) write to /dev/null         │      │
│  └──────────────┬─────────────────────────────┘      │
│                 │ owns                                │
│  ┌──────────────▼─────────────────────────────┐      │
│  │ PTY master /dev/ptmx                        │      │
│  │   (SELinux: ptmx_device, TIOCSWINSZ blocked)│      │
│  └──────────────┬─────────────────────────────┘      │
│                 │ data + SIGWINCH                     │
│                 ▼                                     │
│  ┌────────────────────────────────────────────┐      │
│  │ PRoot → Alpine guest                       │      │
│  │  LD_PRELOAD=libfaketty.so                  │      │
│  │  COLUMNS/LINES set                         │      │
│  │  nano/vim/htop (dynamically linked)        │      │
│  │   → ioctl(TIOCGWINSZ) intercepted          │      │
│  │   → returns COLUMNS/LINES values           │      │
│  └────────────────────────────────────────────┘      │
└─────────────────────────────────────────────────────┘
```

---

## 5. Implementation Effort Estimate

| Phase | Task | Timeline | Dependencies |
|-------|------|----------|--------------|
| 0 | COLUMNS/LINES env vars + checkwinsize | 2-4 hours | Alpine rootfs access |
| 1a | LD_PRELOAD libfaketty.so | 1-2 days | musl toolchain, dlsym |
| 1b | TIOCSIG/kill(-pgid) in pty-bridge.c | 1 day | PTY fds accessible |
| 1 | Testing + iteration | 1 day | Device for testing |
| 2a | Keyboard sentinel View | 2-3 days | Custom ViewGroup |
| 2b | WindowInsets API migration | 1-2 days | API 30+ devices |
| 2c | configChanges + onConfigurationChanged | 1 day | Android manifest |
| 2d | Font metrics recalculation | 1-2 days | Paint/FontMetrics |
| 3a | SELinux Magisk injection | 1 day | Rooted device |
| 3b | PRoot fake_winsize extension | 2-4 weeks | PRoot fork maintenance |
| 3c | DECSET 2048 implementation | 1-2 weeks | Terminal emulator parsing |

**Total Phase 0-1:** 3-5 days
**Total Phase 0-2:** 2-3 weeks
**Total Phase 0-3:** 4-8 weeks (conditional on root/binary requirements)

---

## 6. Key Risks and Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| TIOCSIG also blocked by Samsung kernel | Medium | High | Fall back to kill(-pgid); if that also blocked, use LD_PRELOAD polling thread |
| Go/Rust static binaries not covered by LD_PRELOAD | High | Medium | Phase 3a PRoot extension; or recompile binaries dynamically linked |
| Android 16 blocks LD_PRELOAD via SELinux | Low | High | Use PRoot extension; or SELinux policy injection |
| Keyboard detection unreliable on Samsung | Medium | Medium | Multiple detection methods (WindowInsets + sentinel + onSizeChanged) |
| Performance regression from ptrace interception | Low | Low | Not used for Phase 1; only Phase 3a if PRoot extension needed |

---

## 7. Conclusion

The TIOCSWINSZ blockade on Samsung Android 16 is a SELinux policy issue, not a kernel bug. The kernel's PTY resize mechanism is functional but unreachable through the SELinux LSM layer. Three complementary solutions address this:

1. **LD_PRELOAD ioctl interposition** (Phase 1a) — intercepts TIOCGWINSZ at the userspace symbol level, returning COLUMNS/LINES values. Covers all dynamically-linked programs (bash, nano, vim, htop, Python, etc.).

2. **TIOCSIG/kill(-pgid, SIGWINCH)** (Phase 1b) — delivers SIGWINCH from the subprocess that owns the PTY master fd. Bypasses the need for TIOCSWINSZ → kernel SIGWINCH path.

3. **SELinux policy injection via Magisk** (Phase 3a) — fixes the root cause if root access is available, restoring native TIOCSWINSZ functionality.

Together, Phase 1 provides a complete userspace resize solution for dynamically-linked programs. Phase 2 improves the UI-side keyboard detection pipeline. Phase 3 extends coverage to static binaries and provides a root-level fix.

---

## Appendix: Report Summaries

### Q1: Samsung Kernel PTY Restrictions
Root cause: Missing SELinux allowxperm for TIOCSWINSZ on ptmx_device. Samsung SEPF overrides unpriv_tty_ioctls on slave. Kernel handler is functional. Community-confirmed pattern on Samsung Android 16.

### Q2: LD_PRELOAD TIOCGWINSZ Interception
Viable with direct precedent (shellex, libioctl). ~50 lines of C. Compile with musl for Alpine. Must guard with isatty() for SELinux. SIGWINCH requires separate mechanism.

### Q3: SIGWINCH Alternatives
TIOCSIG on master fd is optimal (single ioctl, no pgid lookup). kill(-pgid, SIGWINCH) is reliable fallback. PRoot signal forwarding is complex. In-band profile.d approach is simple but limited.

### Q4: PRoot Extension for Ioctl
Technically feasible (fake_id0 as template) but 2-4 weeks effort. LD_PRELOAD is simpler, faster (~100x less overhead), and covers >95% of use cases. PRoot extension is for static binary fallback.

### Q5: Mobile Terminal Resize Survey
Termux has the most mature Android architecture. Keyboard sentinel View + OnGlobalLayoutListener is proven. WindowInsets API is the modern replacement. Android 16 forces resizability. DECSET 2048 is emerging alternative.
