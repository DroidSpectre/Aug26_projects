# Signaling Through Silence: Alternative SIGWINCH Delivery Paths When TIOCSWINSZ Is Blocked

**Query ID:** q3  
**Date:** 2026-07-28  
**Researcher:** Aetherix Research Agent 3

---

## Executive Summary

Samsung's Android 16 kernel (5.15) blocks the `TIOCSWINSZ` ioctl (`ENOTTY` on master, `EACCES` on slave), breaking the standard kernel-based SIGWINCH delivery mechanism. This report investigates six alternative approaches to deliver window-change notifications to terminal programs running under PRoot/Alpine in this constrained environment.

The most promising approach is the **TIOCSIG ioctl** on the PTY master fd — a low-effort, high-confidence solution that works within the existing architecture. The `kill(-pgid, SIGWINCH)` pattern is equally reliable but requires `tcgetpgrp()`. An **LD_PRELOAD library** offers the best transparency for unmodified Alpine binaries.

---

## 1. Background: How Linux SIGWINCH Normally Works

### 1.1 The Canonical Path

When a terminal emulator (e.g., xterm, our Java process) creates a PTY pair and the user resizes the window, the standard flow is:

1. Terminal emulator calls `ioctl(master_fd, TIOCSWINSZ, &winsize)` on the PTY master
2. The kernel's `pty_resize()` function in `drivers/tty/pty.c` updates the `winsize` struct
3. It then calls `kill_pgrp(pgrp, SIGWINCH, 1)` for both the master and slave process groups
4. All processes in the slave's foreground process group receive SIGWINCH
5. Applications query the new size via `TIOCGWINSZ` in their signal handler

### 1.2 The Blocked Path

Samsung's Android 16 kernel 5.15 returns `ENOTTY` on attempts to `TIOCSWINSZ` on the master fd, and `EACCES` on the slave fd. This means step 1 fails, and steps 2-4 never execute. The kernel-side `winsize` struct remains at whatever value was set when the PTY was created.

### 1.3 Our Architecture

```
Java Process (terminal emulator)
    |
    | stdin pipe
    |
    v
Subprocess (libpty-bridge.so)
    |
    | master fd | slave fd
    v           v
  PTY Master -- PTY Slave -- PRoot -- Alpine (bash/vim/nano)
```

The Java process communicates resize via in-band `ESC ESC W` escape sequences through the stdin pipe to the subprocess. The subprocess has access to both the PTY master and slave file descriptors.

---

## 2. Findings: Six Alternative Approaches

### 2.1 TIOCSIG ioctl on PTY Master (Recommended)

**Kernel source:** `drivers/tty/pty.c:pty_signal()`

The `TIOCSIG` ioctl (value `0x5362` on x86) is a PTY-specific ioctl that sends an arbitrary signal to the foreground process group of the *other side* of the PTY. When called on the master fd, it delivers the signal to the slave's foreground process group.

```c
// Kernel implementation (pty.c)
static int pty_signal(struct tty_struct *tty, int sig)
{
    struct pid *pgrp = tty_get_pgrp(tty->link); // link = other side
    if (pgrp)
        kill_pgrp(pgrp, sig, 1);
    put_pid(pgrp);
    return 0;
}
```

The subprocess, after receiving an in-band resize notification:
```c
ioctl(master_fd, TIOCSIG, SIGWINCH); // sends SIGWINCH to slave's fg pg
```

**Pros:** No pgid lookup needed, works on PTY master fd, direct kernel path  
**Cons:** Requires `TIOCSIG` not be blocked by Samsung's kernel hardening (needs verification)  
**Effort:** 1-2 days  
**Confidence:** High  

### 2.2 kill(-pgid, SIGWINCH) with tcgetpgrp

The subprocess can discover the foreground process group of the slave and send SIGWINCH directly:

```c
pid_t pgid = tcgetpgrp(slave_fd); // or /dev/tty
if (pgid > 0)
    kill(-pgid, SIGWINCH);  // negative PID = process group
```

This is confirmed working in production code (rlwrap, portable-pty). The key insight from Stack Overflow analysis: SIGWINCH from `kill(-pgid)` is delivered to the *current* foreground process group of the terminal at the time of the call.

**Pros:** Standard POSIX interfaces, well-understood semantics  
**Cons:** Requires slave fd or `/dev/tty` access, tcgetpgrp may also be restricted  
**Effort:** 1-2 days  
**Confidence:** High  

### 2.3 LD_PRELOAD Library for Transparent SIGWINCH Injection

An LD_PRELOAD shared library monitors stdin for the `ESC ESC W` escape sequence and injects SIGWINCH into the current process group:

```c
// Thread monitoring stdin
void *monitor_thread(void *arg) {
    while (1) {
        char buf[256];
        ssize_t n = read(stdin_pipe_fd, buf, sizeof(buf));
        // Parse ESC ESC W sequences
        if (detected_resize) {
            kill(getpgrp(), SIGWINCH);
        }
    }
}
```

Or hook `read()` / `ioctl()` at the library level to intercept the escape sequence before the application sees it.

**Pros:** Transparent to all Alpine binaries, no application changes  
**Cons:** Thread safety, complexity of intercepting stdio in arbitrary applications  
**Effort:** 3-5 days  
**Confidence:** Medium  

### 2.4 In-Band + profile.d/bashrc Trap

For shell-based workflows, install a trap handler via `/etc/profile.d/`:

```bash
# /etc/profile.d/sigwinch.sh
trap 'eval "$(resize)"' SIGWINCH
shopt -s checkwinsize
```

Combined with a small consumer that reads `ESC ESC W` from stdin and updates `COLUMNS`/`LINES` environment variables. This uses bash's existing SIGWINCH handling infrastructure.

**Pros:** Zero C code, pure shell, easy to deploy  
**Cons:** Only works for shell-based workflows, not full-screen TUI apps  
**Effort:** 1 day  
**Confidence:** Medium  

### 2.5 PRoot Signal Forwarding

PRoot operates at the ptrace level and can intercept signals. Extending PRoot to forward host-side SIGWINCH into the Alpine guest:

- PRoot's signal handling can be configured with `-k` (kill signal on exit) and signal routing
- A custom PRoot extension or seccomp filter could inject SIGWINCH when resize events are detected
- Requires understanding PRoot's signal forwarding semantics

**Pros:** Works at the sandbox boundary  
**Cons:** Requires PRoot source modification, complex, ptrace overhead  
**Effort:** 1-2 weeks  
**Confidence:** Low  

### 2.6 Java/JNI pidfd_send_signal

The Java process maintains pidfds to terminal applications via `pidfd_open()` and uses `pidfd_send_signal()` (Linux 5.1+):

```java
// JNI
int pidfd = pidfd_open(pid, 0);
pidfd_send_signal(pidfd, SIGWINCH, NULL, 0);
```

**Pros:** Race-free signaling from Java layer  
**Cons:** Requires per-process tracking, only signals one process at a time, JNI complexity  
**Effort:** 1-2 weeks  
**Confidence:** Low  

---

## 3. Comparative Analysis

| Approach | Impact | Effort | Risk | Confidence | Dependencies |
|----------|--------|--------|------|------------|--------------|
| TIOCSIG ioctl | High | Low | Low | High | master fd, TIOCSIG not blocked |
| kill(-pgid) | High | Low | Low | High | slave fd, tcgetpgrp permission |
| LD_PRELOAD library | High | Medium | Medium | Medium | LD_PRELOAD support, stdin intercept |
| profile.d/bashrc trap | Medium | Low | Low | Medium | bash shell, checkwinsize |
| PRoot signal forwarding | Medium | High | High | Low | PRoot source, ptrace |
| pidfd_send_signal | Medium | High | Medium | Low | pidfd_open, JNI, process tracking |

---

## 4. Implementation Recommendations

### Phase 1 (Immediate): TIOCSIG + kill(-pgid) Parity

Implement both approaches in the subprocess. After receiving `ESC ESC W`:

1. Try `ioctl(master_fd, TIOCSIG, SIGWINCH)` — if it succeeds, done
2. Fall back to `tcgetpgrp(slave_fd)` + `kill(-pgid, SIGWINCH)`

### Phase 2 (Short-term): LD_PRELOAD Injection

Build an LD_PRELOAD library that:
- Creates a monitoring thread reading from a shared fd
- Detects `ESC ESC W` escape sequences
- Calls `kill(getpgrp(), SIGWINCH)` on detection
- Deployed via `LD_PRELOAD` in the Alpine environment

### Phase 3 (Contingency): PRoot Extension

If Samsung's kernel also blocks TIOCSIG and tcgetpgrp, extend PRoot with a signal forwarding mechanism that injects SIGWINCH from the ptrace event loop.

---

## 5. Conclusion

The TIOCSIG ioctl approach is the recommended solution: it requires minimal code, uses only the master fd already available in the subprocess, and leverages an existing kernel path for signal delivery. This should be implemented first, with the `kill(-pgid)` fallback providing robust coverage.

The LD_PRELOAD approach offers the most transparent solution for Alpine binaries and should be the second priority. The bashrc trap is a quick win for shell users. PRoot and pidfd approaches are higher-effort contingency options.

**Source count:** 13 distinct sources consulted across kernel source code, man pages, production codebases, and community analysis.

---

## References

See `report.bib` for complete bibliographic entries, and `report.pdf` for the formatted LaTeX report.
