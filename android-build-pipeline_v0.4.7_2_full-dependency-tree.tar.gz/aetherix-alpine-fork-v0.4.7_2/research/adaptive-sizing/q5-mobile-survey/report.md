# Viewport to PTY: A Survey of Adaptive Terminal Resizing Strategies on Mobile Platforms

## Abstract

Terminal emulators on mobile platforms face a fundamental challenge: the device viewport changes size frequently due to soft keyboard show/hide, device rotation, multi-window transitions, foldable reconfiguration, and desktop-mode docking (e.g., Samsung DeX). Each resize event must propagate from the Android/iOS UI layer to the kernel-level PTY via `TIOCSWINSZ`, and into the running process as `SIGWINCH`. This survey examines how eight major mobile terminal applications (Termux, jackpal Android Terminal Emulator, JuiceSSH/ConnectBot, Blink Shell, UserLAnd, iSH, a-shell, and the AOSP Terminal) handle this pipeline. We identify three architectural patterns, document the specific Android APIs used for keyboard detection and viewport recalculation, and make concrete recommendations for the Aetherix Alpine stack on Android 16 (Samsung kernel 5.15).

## 1. Introduction

Mobile terminal emulators must deliver a responsive, correctly-sized PTY to the user's shell and any full-screen programs (vim, htop, tmux). The pipeline is:

1. **Viewport change detection** (Android `View.onSizeChanged()`, `OnGlobalLayoutListener`, `WindowInsets`)
2. **Grid recalculation** (pixel dimensions $\to$ character columns $\times$ rows using font metrics)
3. **PTY notification** (kernel `ioctl(fd, TIOCSWINSZ, &winsize)` via JNI)
4. **Process notification** (kernel delivers `SIGWINCH` to foreground process group)
5. **Application response** (vim/nano/htop redraw to new size)

On mobile, steps 1--3 present platform-specific challenges that differ substantially from desktop terminals. This survey maps the solution space.

## 2. Background

### 2.1 The PTY Resize Mechanism

On Linux, a pseudoterminal consists of a master end (`/dev/ptmx`) and a slave end (`/dev/pts/N`). The kernel maintains a `struct winsize`:

```c
struct winsize {
    unsigned short ws_row;    /* rows, in characters */
    unsigned short ws_col;    /* columns, in characters */
    unsigned short ws_xpixel; /* horizontal size, pixels */
    unsigned short ws_ypixel; /* vertical size, pixels */
};
```

When the master end calls `ioctl(fd, TIOCSWINSZ, &sz)`, the kernel updates the stored winsize and delivers `SIGWINCH` to the foreground process group of the slave end. The gVisor issue tracker confirms that some container runtimes fail to deliver this signal (google/gvisor\#13317), which mirrors our experience with Samsung kernel 5.15 and Alpine namespaces.

### 2.2 Android Viewport Architecture

Android's view measurement pipeline matters for terminal resizing because:

- `View.onSizeChanged()` is called during layout passes and reliably reports new view dimensions.
- `OnGlobalLayoutListener` fires after any layout pass, allowing detection of keyboard-driven inset changes.
- `WindowInsets` (API 30+) provide IME visibility queries and animations.
- `SOFT_INPUT_ADJUST_RESIZE` (deprecated API 30) causes the activity window to shrink when the keyboard opens.
- `SOFT_INPUT_ADJUST_NOTHING` leaves the window full-size; the app must handle keyboard overlap itself.

Android 16 (API 36) forces resizable behavior on large screens ($\ge$ 600dp), meaning terminals can no longer lock orientation or disable multi-window.

## 3. Survey Methodology

We searched for primary source code (GitHub repositories of each terminal), issue tracker discussions about resize bugs, Android developer documentation, and community blog posts. For each terminal we identified: (a) viewport change detection mechanism, (b) grid recalculation formula, (c) PTY notification method, (d) keyboard show/hide handling, and (e) rotation/multi-window behavior.

## 4. Findings

### 4.1 Termux

**Architecture.** Termux uses a `TerminalView` (custom `View`) with a `TerminalRenderer` class for font metrics. The JNI layer in `termux.c` handles PTY creation (fork+exec) and resize.

**Viewport detection.** `TerminalView.onSizeChanged()` calls `updateSize()`, which reads `getWidth()` and `getHeight()`:

```java
// TerminalView.java (line ~1004)
@Override
protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    updateSize();
}
```

**Grid calculation.** Columns and rows are derived from pixel dimensions:

```java
int newColumns = Math.max(4, (int) (viewWidth / mRenderer.mFontWidth));
int newRows = Math.max(4, (viewHeight - mRenderer.mFontLineSpacingAndAscent)
                         / mRenderer.mFontLineSpacing);
```

`mFontWidth` is `mTextPaint.measureText("X")`. `mFontLineSpacing` is `Math.ceil(mTextPaint.getFontSpacing())`.

**PTY notification.** `TerminalSession.updateSize()` calls `JNI.setPtyWindowSize(fd, rows, cols, cellWidth, cellHeight)`, which executes:

```c
struct winsize sz = {
    .ws_row = rows, .ws_col = cols,
    .ws_xpixel = cols * cell_width,
    .ws_ypixel = rows * cell_height
};
ioctl(fd, TIOCSWINSZ, &sz);
```

Termux fills both character and pixel fields, which allows `TIOCGWINSZ` to return pixel dimensions.

**Keyboard handling.** Termux uses `SOFT_INPUT_ADJUST_RESIZE` (set dynamically, not in manifest since commit 39c69db). A `TermuxActivityRootView` (custom `LinearLayout`) implements `OnGlobalLayoutListener` with a sentinel `bottom_space_view` (1dp transparent View) to detect when keyboard overlapped content is not properly handled by `adjustResize` alone. When the sentinel is partially hidden, additional margin is added to push content up.

**Samsung DeX.** Termux sets `android:resizeableActivity="true"` and `android:configChanges="orientation|screenSize|smallestScreenSize|density|screenLayout|uiMode|keyboard|keyboardHidden|navigation"` to avoid activity recreation. Separate font sizes for DeX vs phone are requested but not implemented (issue \#3119). Windowed mode on Samsung causes flickering (issue \#5089, \#4647) due to repeated `onSizeChanged` triggers.

**Confidence: High.** Source code examined: `TerminalView.java`, `TerminalSession.java`, `TermuxActivityRootView.java`, `termux.c`, `KeyboardUtils.java`.

### 4.2 jackpal Android Terminal Emulator

**Architecture.** The classic reference implementation. `EmulatorView` extends `View`, `TermSession` manages the PTY via JNI (`termExec.cpp`).

**Viewport detection.** `EmulatorView.onSizeChanged()` checks for deferred initialization:

```java
@Override
protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    if (mTermSession == null) { mDeferInit = true; return; }
    if (!mKnownSize) { mKnownSize = true; initialize(); }
    else { updateSize(false); }
}
```

**Grid calculation.** Uses `mCharacterWidth` (from `TextRenderer`) and `mCharacterHeight`:

```java
mColumns = Math.max(1, (int) (((float) w) / mCharacterWidth));
mRows = Math.max(1, (h - mTopOfScreenMargin) / mCharacterHeight);
```

**PTY notification.** `updateSize()` calls `mTermSession.updateSize(mColumns, mRows)`, which in the original uses `Process.session.updateSize(columns, rows)`. The TIOCSWINSZ call is in `termExec.cpp`:

```c
static void setPtyWindowSize(JNIEnv *env, jobject clazz, jobject fileDescriptor,
    jint row, jint col, jint xpixel, jint ypixel) {
    struct winsize sz;
    sz.ws_row = row; sz.ws_col = col;
    sz.ws_xpixel = xpixel; sz.ws_ypixel = ypixel;
    ioctl(fd, TIOCSWINSZ, &sz);
}
```

**Keyboard/resize.** Uses `onConfigurationChanged()` to call `mEmulatorView.updateSize()`. No special keyboard overlap handling beyond basic `adjustResize`.

**Confidence: High.** Source code examined: `EmulatorView.java`, `TermSession.java`, `termExec.cpp`, `Term.java`.

### 4.3 JuiceSSH and ConnectBot

**Architecture.** SSH clients that maintain terminal emulators locally and forward resize events over SSH protocol.

**Viewport detection.** ConnectBot uses a fork of the jackpal emulator (`termlib`). The `termbot` library calls `onResize` callbacks that propagate to SSH channel messages.

**SSH resize forwarding.** When the SSH client receives a local viewport change, it sends `SSH_MSG_CHANNEL_REQUEST` with `"window-change"` type, including character dimensions and pixel dimensions. The SSH server then calls `ioctl(ptyfd, TIOCSWINSZ, &w)` on the remote PTY, delivering `SIGWINCH` to the remote process.

**Keyboard handling.** ConnectBot has a `"Force Size"` feature (issue \#1053) that lets users manually set dimensions, bypassing automatic detection. This is a workaround for keyboard overlap issues where the terminal fails to detect the reduced viewport.

**Confidence: Medium.** Source partially available; some SSH-specific handler logic is in `termlib` fork. Issue \#1053 and \#70 document resize bugs.

### 4.4 Blink Shell (iOS, Android beta)

**Architecture.** Blink uses Mosh (mobile shell) as its primary transport, with SSH fallback. On iOS it uses `WKWebView`-based terminal rendering with a custom `TerminalView`.

**Resize strategy.** Blink delegates resize awareness to Mosh, which uses the State Synchronization Protocol over UDP. When the viewport changes, Blink sends a new terminal dimensions message in-band through the Mosh protocol, which the `mosh-server` translates into a local PTY resize via `TIOCSWINSZ`. This approach is inherently robust to network changes.

**iOS keyboard handling.** Blink has a "Lock terminal size" feature (issue \#1148) that prevents resize notifications from triggering when the iOS helper bar appears/disappears (a known iPadOS issue). Pinch-to-zoom changes font size instead of triggering resize.

**Confidence: Medium.** Blink is proprietary; analysis based on documentation, issue tracker, and Mosh protocol specs.

### 4.5 UserLAnd

**Architecture.** UserLAnd runs Linux distributions in chroot containers. The primary terminal interface is SSH (using ConnectBot or Termux as client) or VNC (for GUI sessions).

**Resize strategy.** Since UserLAnd itself does not include a terminal emulator, resize handling is delegated to the SSH/VNC client. The VNC approach uses static geometry (originally 1024$\times$768) configurable via `~/.vncrc` (issue \#362). The SSH approach relies on the client's resize mechanisms.

**Confidence: Medium.** Analysis based on GitHub issues and documentation. UserLAnd is effectively unmaintained (last release October 2021).

### 4.6 iSH (iOS)

**Architecture.** iSH uses usermode x86 emulation with syscall translation on iOS. It includes an in-process PTY implementation.

**Viewport detection.** `TerminalViewController` in iSH observes iOS `UIKeyboard` notifications (`keyboardDidSomething:`), converting screen-space keyboard frames to view-space coordinates. Recent fixes ensure correct coordinate space conversion across Split View and Slide Over.

**SIGWINCH in emulated environment.** iSH implements a software PTY within the emulated x86 environment. When the iOS UI detects a size change, it calls `ioctl(pty, TIOCSWINSZ)` on the emulated PTY, which triggers `SIGWINCH` delivery to the emulated Alpine Linux process.

**Keyboard bar sizing.** iSH has a custom `BarView` (`UIInputView`) that adjusts button sizes based on idiom (phone vs iPad) and available width (full-screen, split, slide-over).

**Confidence: Medium-High.** Source code examined: `TerminalViewController.m`, related commits. PTY implementation is in C code within the emulator.

### 4.7 a-shell (iOS)

**Architecture.** A native iOS terminal using `ios_system` for command execution, supporting multiple windows via iPadOS multi-windowing.

**Resize behavior.** a-shell uses iOS layout constraints and safe areas. The `config` command adjusts font size, background color, text color, and cursor. Each window has independent settings. a-shell uses the Apple `Terminal.framework`-like approach with `UIViewController` containment for each terminal session. Viewport changes come through standard iOS view layout callbacks.

**Confidence: Low-Medium.** Less documentation available; primary source is GitHub.

### 4.8 AOSP Terminal (platform/packages/apps/Terminal)

**Architecture.** The reference terminal for AOSP, using a C++ JNI backend (`libjni_terminal`) with libvterm for terminal emulation.

**Viewport detection.** `TerminalView` (the Android app version in `packages/apps/Terminal`) uses `onSizeChanged()`:

```java
@Override
protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    final int rows = h / mMetrics.charHeight;
    final int cols = w / mMetrics.charWidth;
    if (mTerm != null && sizeChanged) mTerm.resize(rows, cols, scrollRows);
}
```

**PTY notification.** The native `Terminal::resize()` method calls `ioctl(mMasterFd, TIOCSWINSZ, &size)` and `vterm_set_size()`.

**Configuration changes.** The AOSP `Term` activity declares `android:configChanges="orientation|screenSize|keyboard|keyboardHidden"` and calls `mEmulatorView.updateSize()` from `onConfigurationChanged()`.

**Confidence: High.** Source code examined: `TerminalView.java`, `Terminal.java`, `com_android_terminal_Terminal.cpp`.

### 4.9 Desktop Terminals (Foot, Kitty, iTerm2, Ghostty)

**In-band resize protocol.** A new private mode (DECSET 2048) defines in-band resize notifications: `CSI ? 2048 h` enables reporting, and the terminal sends `CSI 48 ; rows ; cols ; height_px ; width_px t` on each resize. Currently supported by foot, kitty, iTerm2, ghostty, and Bobcat. This is relevant for Aetherix Alpine as an alternative to relying on kernel `TIOCSWINSZ`.

## 5. Comparative Analysis

| Terminal | Viewport Detection | Grid Calculation | PTY Notification | Keyboard Handling | Samsung DeX |
|----------|-------------------|------------------|------------------|-------------------|-------------|
| Termux | `onSizeChanged()` + `OnGlobalLayoutListener` | `viewWidth/fontWidth`, `(viewHeight - lineSpacingAscent)/fontLineSpacing` | JNI `TIOCSWINSZ` with pixel + char fields | `SOFT_INPUT_ADJUST_RESIZE` + sentinel View for overlap fix | `resizeableActivity=true`, configChanges |
| jackpal | `onSizeChanged()` | `w/charWidth`, `(h - margin)/charHeight` | JNI `TIOCSWINSZ` | `onConfigurationChanged()` + `updateSize()` | N/A (pre-DeX era) |
| JuiceSSH/ConnectBot | `onSizeChanged()` (via termlib fork) | Same as jackpal | SSH `window-change` channel request | "Force Size" manual override | Limited |
| Blink Shell | iOS view layout + Mosh | Font-metrics-driven | Mosh protocol in-band | "Lock size" to suppress resize | N/A (iOS focus) |
| UserLAnd | Delegated to SSH/VNC client | Client-dependent | Client-dependent | Delegated | N/A |
| iSH | iOS `UIKeyboard` notifications | iOS font metrics | Emulated PTY `ioctl` | `inputAccessoryView` sizing | N/A (iOS) |
| a-shell | iOS view layout + safe areas | iOS font metrics | `ioctl` via ios_system | iOS standard keyboard | N/A (iOS) |
| AOSP Terminal | `onSizeChanged()` + `onConfigurationChanged()` | `h/charHeight`, `w/charWidth` | Native `ioctl(masterFd, TIOCSWINSZ)` | `SOFT_INPUT_ADJUST_RESIZE` | N/A |

### 5.1 Font Metric Calculation Comparison

| Terminal | Char Width | Char Height | Notes |
|----------|-----------|-------------|-------|
| Termux | `measureText("X")` | `Math.ceil(getFontSpacing())` | Also uses `mFontLineSpacingAndAscent` for accurate row calc |
| jackpal | From `TextRenderer.getCharacterWidth()` | From `TextRenderer.getCharacterHeight()` | Top-of-screen margin subtracted |
| AOSP Terminal | `Math.ceil(getTextWidths("X"))` | `Math.ceil(fm.descent - fm.top)` | Simple division approach |
| iOS a-shell | `"W".size(withAttributes:)` | `font.lineHeight` | Uses `floor(contentRect / cellSize)` |
| smithers/ghostty iOS | `"W".size(withAttributes:)` | `font.lineHeight` | Packs into `TerminalIOSGridSignature` struct |

## 6. Android-Specific Challenges

### 6.1 Keyboard Show/Hide Detection

Three approaches exist:

1. **`SOFT_INPUT_ADJUST_RESIZE` + `onSizeChanged()`.** Simplest, but deprecated on API 30+. Termux uses this dynamically (set in Java, not manifest). Problem: some keyboards (Gboard with suggestions bar) report incorrect inset heights, causing overlap.

2. **`WindowInsets` API (API 30+).** The modern approach. Query `WindowInsetsCompat.Type.ime()` for IME visibility and height. Use `OnApplyWindowInsetsListener` with `setDecorFitsSystemWindows(false)`. Termux has a pending PR (\#5006) to migrate from deprecated flags.

3. **`OnGlobalLayoutListener` + sentinel view.** Termux's robust solution: a 1dp transparent View at the bottom of the layout. `onGlobalLayout()` checks if the sentinel is visible; if not, adds bottom margin to compensate for keyboard overlap.

### 6.2 `onSizeChanged()` vs `onConfigurationChanged()`

- `onSizeChanged()` fires reliably on every layout pass where dimensions change. Keyboards trigger this.
- `onConfigurationChanged()` fires on orientation, keyboard hardware, and screen layout changes. Termux and AOSP Terminal both declare `configChanges` to avoid activity recreation.
- For Android 16 (API 36), `onConfigurationChanged()` is the recommended way to handle multi-window and desktop-mode transitions without activity restart.

### 6.3 Android 16 (API 36) Implications

- Orientation, resizability, and aspect ratio restrictions are ignored on screens $\ge$ 600dp.
- `resizeableActivity` attribute is ignored; all apps are resizable.
- Activity recreation on configuration changes is reduced (API 37+).
- `WindowInsetsAnimation.Callback` enables synchronized keyboard animations.
- For terminals: the app must handle arbitrary viewport sizes at any time.

### 6.4 Samsung Kernel Considerations

- Samsung kernel 5.15 may have custom PTY behavior. The `gVisor#13317` bug (TIOCSWINSZ fails to deliver SIGWINCH in container environments) is analogous to our experience with Alpine inside a Samsung kernel namespace.
- DeX mode triggers `uiMode` configuration change; `configChanges` must include `uiMode` to avoid activity restart.
- Samsung's `keepalive` manifest metadata prevents process death when switching between phone and DeX modes.
- Issue \#1525 documents Termux keyboard overlap on Samsung One UI; the sentinel View approach fixes it.

## 7. Implementation Recommendations for Aetherix Alpine

### Recommendation 1: Use Termux's Three-Layer Resize Architecture

**Approach:** Implement the full Termux pipeline: `onSizeChanged()` $\to$ `updateSize()` $\to$ `JNI.setPtyWindowSize()` with pixel+char winsize, plus `TerminalEmulator.resize()` for the in-memory screen.

**Details:**
- **Layer 1 (UI):** Override `onSizeChanged()` in `TerminalView`. Guard against 0-width/height and absent session.
- **Layer 2 (Grid):** Calculate columns as `viewWidth / fontWidth`, rows as `(viewHeight - lineSpacingAndAscent) / fontLineSpacing`. Use `Paint.measureText("X")` for font width and `Math.ceil(Paint.getFontSpacing())` for line height.
- **Layer 3 (PTY):** Call JNI that does `ioctl(fd, TIOCSWINSZ, &sz)` with both character and pixel fields populated. Verify with `TIOCGWINSZ` that the kernel accepted the change.

**Impact:** High. **Effort:** Low. **Risk:** Low. **Confidence:** High.

### Recommendation 2: Implement Keyboard Overlap Sentinel View

**Approach:** Add a 1dp transparent View at the bottom of the RootView layout. Monitor with `OnGlobalLayoutListener`. When hidden by keyboard, add dynamic bottom margin.

**Rationale:** `SOFT_INPUT_ADJUST_RESIZE` is deprecated and unreliable with keyboards that have suggestion bars (Gboard, Samsung Keyboard). The sentinel View approach is proven in Termux.

**Impact:** High. **Effort:** Low. **Risk:** Low. **Confidence:** High.

### Recommendation 3: Declare `configChanges` for All Relevant Configurations

**Approach:** Add to `AndroidManifest.xml`:

```xml
android:configChanges="orientation|screenSize|smallestScreenSize|density|screenLayout|uiMode|keyboard|keyboardHidden|navigation"
```

And set `android:resizeableActivity="true"` for Samsung DeX compatibility.

**Rationale:** Prevents activity recreation on rotation, keyboard attach/detach, DeX mode switch, and font size change. Termux, AOSP Terminal, and Samsung documentation all recommend this.

**Impact:** High. **Effort:** Low. **Risk:** Low. **Confidence:** High.

### Recommendation 4: Implement In-Band Resize Fallback (DECSET 2048)

**Approach:** Implement Private Mode 2048 for in-band resize notifications. When `ENABLE_IN_BAND_RESIZE` is requested by the application, send `CSI 48 ; rows ; cols ; height_px ; width_px t` through the PTY stream on each viewport change.

**Rationale:** If kernel `TIOCSWINSZ` fails in the Samsung kernel 5.15 + Alpine namespace environment (as we suspect), in-band notifications provide a workaround. The Alpine environment's shell can read escape sequences directly. This is supported by modern terminal emulators (foot, kitty, iTerm2, ghostty).

**Impact:** Medium. **Effort:** Medium (requires `TerminalEmulator` escape sequence handling + opt-in protocol). **Risk:** Low (backward compatible; disabled by default). **Confidence:** Medium.

### Recommendation 5: Use `WindowInsets` API (API 30+) as Primary Keyboard Detection

**Approach:** Replace `SOFT_INPUT_ADJUST_RESIZE` with `setDecorFitsSystemWindows(false)` + `OnApplyWindowInsetsListener`. Query `WindowInsetsCompat.Type.ime()` for IME height. Apply bottom padding equal to IME inset height.

**Rationale:** Forward-compatible; avoids deprecated APIs; synchronizes with keyboard animation on API 30+.

**Impact:** Medium. **Effort:** Medium. **Risk:** Medium (must handle both API 30+ and pre-30 fallback). **Confidence:** High.

### Recommendation 6: Handle Samsung DeX and Multi-Window Transitions

**Approach:** In `onConfigurationChanged()`, detect `uiMode` changes (desktop vs mobile), density changes (xxxhdpi to mdpi), and screen size changes. Recalculate font metrics if density changed. Store separate font preferences for DeX vs phone.

**Rationale:** Termux users report pixel density changes between phone (xxxhdpi) and DeX (mdpi) that require different font sizes. Without handling, fonts appear too large on DeX.

**Impact:** Medium. **Effort:** Medium. **Risk:** Low. **Confidence:** Medium.

## 8. Conclusion

The mobile terminal emulation ecosystem has converged on a standard resize pipeline: `onSizeChanged()` $\to$ grid recalculation $\to$ `TIOCSWINSZ` via JNI. Termux represents the most mature and battle-tested implementation on Android, with sophisticated keyboard overlap handling and multi-window support. For Aetherix Alpine on Android 16 + Samsung kernel 5.15, we recommend adopting Termux's three-layer architecture (UI \&rarr; grid \&rarr; PTY), implementing the sentinel View for keyboard overlap, adding in-band resize (DECSET 2048) as a fallback, and properly handling DeX configuration changes.

## References

1. Termux source: `terminal-view/src/main/java/com/termux/view/TerminalView.java`, `terminal-emulator/src/main/java/com/termux/terminal/TerminalSession.java`, `terminal-emulator/src/main/jni/termux.c`
2. jackpal Android-Terminal-Emulator: `emulatorview/src/main/java/jackpal/androidterm/emulatorview/EmulatorView.java`
3. AOSP Terminal: `platform/packages/apps/Terminal/src/com/android/terminal/TerminalView.java`
4. iSH: `app/TerminalViewController.m`, `ish-app/ish` on GitHub
5. Blink Shell: `docs.blink.sh`, github.com/blinksh/blink
6. Android Developers: "Handle input method visibility", "Support multi-window mode", "Behavior changes: Android 16"
7. Samsung DeX: developer.samsung.com/samsung-dex/modify-optimizing.html
8. "Private Mode for In-Band Window Resize Notifications": gist.github.com/rockorager/e695fb2924d36b2bcf1fff4a3704bd83
9. Android Terminal Emulator: `apps/Term/jni/termExec.cpp` from platform/development
10. a-shell: github.com/holzschu/a-shell
11. TIOCSWINSZ/SIGWINCH: Linux man pages (`ioctl_tty.2`), stackexchange.com
12. gVisor issue \#13317: TIOCSWINSZ fails to deliver SIGWINCH in container runtimes
