#!/bin/bash
DIR="$1"
TEXFILE="$2"
cd "$DIR"
echo "=== pdflatex pass 1 ==="
pdflatex -interaction=nonstopmode "$TEXFILE" 2>&1 | tail -20
echo "=== bibtex ==="
bibtex "${TEXFILE%.tex}" 2>&1 | tail -20
echo "=== pdflatex pass 2 ==="
pdflatex -interaction=nonstopmode "$TEXFILE" 2>&1 | tail -20
echo "=== pdflatex pass 3 ==="
pdflatex -interaction=nonstopmode "$TEXFILE" 2>&1 | tail -20
echo "=== DONE ==="
ls -la "${TEXFILE%.tex}.pdf" 2>/dev/null
