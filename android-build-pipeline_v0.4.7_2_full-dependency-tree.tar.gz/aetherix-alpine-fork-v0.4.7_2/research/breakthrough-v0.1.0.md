# Breaking the Samsung Knox SELinux execve Barrier for PRoot-based Linux Containers on Android 16

**Project:** DevEnv-PRoot  
**Version:** v0.1.0 (milestone release)  
**Date:** 2026-07-21  
**Device:** Samsung SM-S166V (Android 16, API 36, kernel 5.15.189, Knox 3.x)  
**Architecture:** aarch64  
**Status:** First successful PRoot chain execution on locked Samsung Knox device

---

## 1. Abstract

Running a full Linux userspace environment on stock Android without root privileges has been a long-standing challenge, addressed primarily through PRoot -- a ptrace-based, user-space chroot and mount implementation. On Samsung devices with Knox security extensions and Android 16 (API 36), this challenge intensifies: aggressive SELinux policies combined with Samsung's DEFEX and RKP kernel modules block virtually all execution paths that would allow an unprivileged app to run foreign binaries.

This report documents the systematic evolution of the DevEnv-PRoot project across 24 build iterations, culminating in a breakthrough at build v0.0.23 (promoted to v0.1.0). The critical insight is the exploitation of PROOT_LOADER -- PRoot's mechanism for handling binaries whose ELF interpreter does not exist on the host system. By using a musl-linked Alpine Linux rootfs (whose binaries have INTERP=/lib/ld-musl-aarch64.so.1, absent on Android), PRoot is forced to route all binary execution through PROOT_LOADER. The loader, deployed as a native library in the app's jniLibs directory (labeled apk_data_file by SELinux), executes via the no-transition execute_no_trans permission. This keeps the process in the untrusted_app SELinux domain, bypassing Samsung's ptrace cross-domain access check that had blocked all prior attempts.

At v0.1.0, the PRoot chain successfully executes echo OK inside an Alpine Linux sandbox on a Samsung Knox Android 16 device. A shared library resolution issue (libz.so.1 not found by musl's dynamic linker) prevents the package manager from running, but the core architecture is validated.

---

## 2. The Problem: Samsung Knox SELinux on Android 16

### 2.1 The Target Device

The target is a Samsung SM-S166V running Android 16 (API level 36) with kernel 5.15.189-android13-3-33503169 and Samsung Knox 3.x security suite. The device is unrooted and must remain so. The app (com.devenv.prootbuild) targets SDK level 34+ (API >= 29), which means it runs in the u:r:untrusted_app:s0 SELinux domain with all Android 10+ execution restrictions active.

### 2.2 Three SELinux Blockers

Three distinct SELinux mechanisms block unprivileged binary execution on this device:

**Blocker A: app_data_file execute_no_trans removed (since API 29).**

Files in /data/data/<pkg>/ (labeled app_data_file) traditionally had an execute_no_trans permission for the app's own domain. This allows an app to execute its own extracted binaries without transitioning to another SELinux domain. This permission was removed in Android 10 (API 29) for targetSdk >= 29 apps. The app's own data directory is now purely a data store -- executables placed there cannot be directly executed.

**Blocker B: linker domain cannot execute outside /system (neverallow rule 76).**

Android's SELinux policy includes neverallow rule 76, which states: neverallow { domain -appdomain -shell -system_server -zygote } { file_type -system_file -exec_type }:file execute. This means any process NOT in appdomain (such as the linker domain, which includes /system/bin/linker64) cannot execute files outside /system. Samsung Knox enhances this rule with additional enforcement, making it stricter than standard AOSP.

**Blocker C: ptrace cross-domain execve blocked (Samsung Knox DEFEX enhancement).**

When a tracer process (e.g., PRoot) ptrace-s a tracee that subsequently calls execve, the SELinux kernel hook checks whether the tracer is allowed to ptrace the tracee's NEW domain (after the domain transition triggered by execve). On Samsung Knox, this check is extended by DEFEX to deny most cross-domain transitions for processes using ptrace. This is the most subtle and impactful restriction, and it is not well-documented in standard Android SELinux references.

### 2.3 File Type Labels on Android

Two file labels are critical to understanding the execution landscape:

- app_data_file: Files in /data/data/<pkg>/ created at runtime or extracted from app assets/. For targetSdk >= 29, this label grants read, write, open, and getattr, but NOT execute.

- apk_data_file: Native library files extracted by the Android package manager from jniLibs/ in the APK (via extractNativeLibs=true). This label is placed in the app's nativeLibraryDir (/data/app/<pkg>/lib/arm64/). Critically, apk_data_file DOES grant execute_no_trans for appdomain processes, allowing direct execution without SELinux domain transition.

### 2.4 Samsung Knox Extensions

Samsung Knox adds three security layers beyond standard AOSP SELinux:

- DEFEX (Defeat Exploit): A kernel module that hooks critical syscalls (execve, ptrace, setuid) and applies runtime monitoring. On our target device, DEFEX specifically denies execve calls that would cross SELinux domain boundaries when the process is being ptraced.

- RKP (Real-time Kernel Protection): A hypervisor-level integrity checker running in ARM TrustZone. It prevents modification of kernel code and critical data structures. Cannot be bypassed from userspace.

- Knox Enforcement: Additional neverallow rules and type_transition restrictions in the vendor SEPolicy beyond the AOSP baseline. These are not publicly documented.

---

## 3. Taxonomy of Failed Approaches (v0.0.10 -- v0.0.22)

Before the breakthrough, 13 build iterations systematically explored and eliminated every standard approach to running PRoot on a locked Samsung device.

### 3.1 The linker Domain Trap (v0.0.10 -- v0.0.14)

The Termux community's standard approach uses /system/bin/linker64 as an exec trampoline. When Android 10+ removed app_data_file execute, the community discovered that passing an absolute binary path to /system/bin/linker64 as argv[0] allowed execution: /system/bin/linker64 /path/to/binary [args]. The kernel treats this as executing the linker itself, which is a system file and SELinux-allowable. The linker then loads the specified binary.

This approach works on standard AOSP devices but catastrophically fails on Samsung Knox. The process transitions to the u:r:linker:s0 SELinux domain. Once in this domain, neverallow rule 76 (amplified by Knox) prevents execution of any binary outside /system -- including the Alpine rootfs binaries and the PROOT_LOADER at apk_data_file.

Our first five builds attempted various configurations of this approach:
- v0.0.10: glibc-compiled proot. Failed because the host lacks glibc.
- v0.0.11: Bionic-compiled proot with LD_LIBRARY_PATH. Failed because PROOT_TMP_DIR was not set.
- v0.0.12: PROOT_TMP_DIR set. Failed because TarExtractor did not set executable permission bits.
- v0.0.13: Executable permissions fixed. Failed because musl-linked Alpine /bin/sh has INTERP=/lib/ld-musl-aarch64.so.1 which does not exist on the host.
- v0.0.14: PROOT_LOADER set to loader binary in assets. Failed because the loader was in app_data_file (no exec) and seccomp mode prevented loader use.

### 3.2 PROOT_NO_SECCOMP + PROOT_LOADER (v0.0.15 -- v0.0.17)

Setting PROOT_NO_SECCOMP=1 forced PRoot into pure ptrace mode, enabling PROOT_LOADER to function. However, the loader binary was initially placed in assets (app_data_file):

- v0.0.15: PROOT_LOADER set, seccomp disabled. SELinux returned Permission denied -- a clean SELinux denial of app_data_file execute from linker domain.

- v0.0.16: Direct execution of proot from app_data_file without linker64 prefix. This put PRoot in untrusted_app domain, but proot itself was app_data_file (no exec). Permission denied.

- v0.0.17: Returned to linker64 prefix but moved PROOT_LOADER to nativeLibraryDir (apk_data_file, which DOES allow exec). The error changed from Permission denied to Operation not permitted, indicating a different type of denial. At this point we suspected Samsung Knox was adding restrictions beyond standard SELinux.

### 3.3 The Seccomp Bug (v0.0.18)

v0.0.18 attempted to work around the PROOT_LOADER issue by using seccomp mode (no PROOT_LOADER) and targeting /system/bin/sh directly (a native Android binary with INTERP=/system/bin/linker64). This gave Operation not permitted with error details: seccomp prevented execution of chmod and chdir syscalls. This is known kernel bug LP#1202161 -- SECCOMP_RET_TRACE does not properly handle certain syscalls that PRoot needs to intercept.

### 3.4 Native Lib Approach (v0.0.19 -- v0.0.20)

These builds confirmed that PROOT_LOADER at nativeLibraryDir (apk_data_file) WAS being found and attempted, but the linker domain's execve was still blocked by Samsung Knox. The error was consistently Operation not permitted, with PRoot reporting that execve of the loader failed. The root cause: Samsung Knox denies ALL execve from the linker domain, not just of app_data_file. Even apk_data_file (which has the execute_no_trans permission for appdomain) was blocked because the calling process was in linker domain, not appdomain.

### 3.5 The untrusted_app Pivot (v0.0.21 -- v0.0.22)

v0.0.21 made the critical architectural decision to stop using linker64 as a prefix. Instead, PRoot's binary was placed directly in nativeLibraryDir as libproot.so. When executed from nativeLibraryDir (apk_data_file), the process stays in untrusted_app domain via execute_no_trans. No domain transition to linker occurs.

This solved the execution permission problem but created a new one: all of PRoot's children inherit the untrusted_app domain, and when those children execve binaries, any domain transition triggers the ptrace cross-domain check.

- v0.0.21: Added LD_PRELOAD=libdexec.so (termux-exec shim) to redirect execve through linker64. This was intended to solve the missing INTERP problem, but the LD_PRELOAD library interfered with PRoot's internal ptrace mechanism, corrupting the tracer-tracee relationship.

- v0.0.22: Removed LD_PRELOAD. Kept only PROOT_LOADER pointing to nativeLibraryDir. The target binary was /system/bin/sh (Android's shell, INTERP=/system/bin/linker64). Since linker64 exists on the host, PRoot did NOT use PROOT_LOADER -- it attempted a normal execve. This triggered a domain transition from untrusted_app to shell, and Samsung Knox blocked the cross-domain execve for the ptraced tracee.

---

## 4. The Breakthrough: PROOT_LOADER + musl-linked Binaries (v0.0.23 / v0.1.0)

### 4.1 The Key Insight

The critical insight at v0.0.23 was understanding exactly when PRoot uses PROOT_LOADER. PRoot checks whether the target binary's ELF interpreter (INTERP) exists on the host filesystem. If it does not exist, PRoot classifies the binary as foreign and routes execution through PROOT_LOADER.

Alpine Linux uses musl as its C library. Alpine aarch64 binaries have INTERP=/lib/ld-musl-aarch64.so.1. This path does NOT exist on the Android host (which uses /system/bin/linker64). Therefore, every Alpine binary triggers PROOT_LOADER usage.

When PROOT_LOADER is used, PRoot changes the tracee's execve target from the original binary to the loader itself. The loader binary, located at nativeLibraryDir/libproot-loader.so, is apk_data_file. execve of apk_data_file from untrusted_app uses execute_no_trans -- the process STAYS in untrusted_app. No domain transition occurs. Since there is no domain transition, the SELinux ptrace cross-domain check is not triggered, and Samsung Knox does not block the execution.

### 4.2 The Execution Chain

The complete execution chain at v0.1.0 operates as follows:

```
1. App Java calls Runtime.exec("/system/bin/sh proot-launch.sh 'echo OK'")
   SELinux: untrusted_app exec system_file (sh) -> execute -> process transitions to shell domain

2. Shell script exports environment variables and execs libproot.so
   Command: exec $NATIVE_DIR/libproot.so -0 -r $ROOTFS ... /bin/sh --login -c "echo OK"
   
3. Kernel loads libproot.so (apk_data_file)
   SELinux: untrusted_app exec apk_data_file -> execute_no_trans -> STAYS untrusted_app
   
4. Kernel reads INTERP=/system/bin/linker64 from libproot.so ELF header
   Kernel loads /system/bin/linker64 (system_file)
   SELinux: kernel-internal read + mmap EXEC of system_file by untrusted_app -> ALLOWED
   
5. linker64 loads libproot.so and its dependencies (libtalloc.so.2, libandroid-shmem.so, libc.so)
   PRoot is now running in untrusted_app domain

6. PRoot forks a tracee process
   Tracee inherits untrusted_app domain
   
7. Tracee calls execve("/bin/sh", ...)
   
8. PRoot intercepts via ptrace, translates path:
   /bin/sh -> $ROOTFS/bin/sh (Alpine's BusyBox ash, musl-linked)
   
9. PRoot reads ELF header of $ROOTFS/bin/sh
   INTERP = /lib/ld-musl-aarch64.so.1
   
10. PRoot stats /lib/ld-musl-aarch64.so.1 on host -> ENOENT (does not exist)
    PRoot classifies as foreign binary
    DECISION: use PROOT_LOADER
    
11. PRoot changes tracee's execve target:
    execve($NATIVE_DIR/libproot-loader.so, ["/bin/sh", "--login", "-c", "echo OK"], envp)
    SELinux: untrusted_app exec apk_data_file (libproot-loader.so) -> execute_no_trans -> STAYS untrusted_app
    ** NO DOMAIN TRANSITION -> NO ptrace cross-domain check -> ALLOWED **
    
12. PROOT_LOADER (static ELF, no INTERP) starts executing
    Uses raw syscalls (open, mmap, mprotect) to load target binary
    
13. PROOT_LOADER opens $ROOTFS/bin/sh and $ROOTFS/lib/ld-musl-aarch64.so.1
    All syscalls intercepted by PRoot's ptrace -> paths translated through rootfs
    
14. PROOT_LOADER loads musl's dynamic linker and transfers control
    
15. musl's ld-musl-aarch64.so.1 loads BusyBox ash from rootfs
    Searches /lib, /usr/lib for shared libraries (musl-linked BusyBox is mostly static)
    
16. /bin/sh (BusyBox ash) executes "echo OK" inside Alpine rootfs
    Output: "OK"
```

### 4.3 Why This Works on Samsung Knox

The breakthrough exploits a specific gap in Samsung's security model:

1. Standard AOSP SELinux allows untrusted_app to exec apk_data_file via execute_no_trans. Samsung Knox does NOT block this (it cannot, or all apps would break).

2. Standard AOSP SELinux does NOT restrict ptrace cross-domain execve when the domain transition is standard (e.g., untrusted_app -> shell). Samsung Knox adds this restriction.

3. By using PROOT_LOADER, the tracee ALWAYS executes apk_data_file, which uses execute_no_trans. The tracee NEVER changes domain. Therefore, the ptrace cross-domain check is NEVER triggered.

4. The PROOT_LOADER binary, being a static ELF, requires no INTERP lookup, so the kernel never needs to check the loader's interpreter -- a second potential failure point.

The architecture essentially creates a self-contained execution environment where ALL binaries run in the untrusted_app domain, and ALL file operations are translated through PRoot's ptrace. The kernel sees only:
- A process in untrusted_app execve-ing apk_data_file (allowed via execute_no_trans)
- A process in untrusted_app making open/read/write syscalls on files in app_data_file (allowed)

No domain transitions ever occur, so no cross-domain checks are ever triggered.

### 4.4 Verification

The breakthrough was verified by executing echo OK through the full PRoot chain. The launcher script test at Step 3 calls:
```
/system/bin/sh launcher.sh 'echo OK'
```

This triggers the complete execution chain described above. The test passed with output OK, confirming:
- PRoot binary executes from nativeLibraryDir (apk_data_file) without domain transition
- PROOT_LOADER correctly handles musl-linked binaries
- The tracee stays in untrusted_app domain through all execve operations
- Samsung Knox does not block the execution path
- Path translation through the Alpine rootfs works correctly
- The musl dynamic linker functions inside the PRoot sandbox
- BusyBox ash can execute and produce output

---

## 5. The SELinux ptrace Cross-Domain Check: A Detailed Analysis

### 5.1 How ptrace and SELinux Interact

When a tracer process uses ptrace to monitor a tracee, SELinux applies a specific check. The check is performed at PTRACE_ATTACH time (when the tracer first attaches) and at PTRACE_CONT/PTRACE_SYSCALL/PTRACE_EVENT time (when the tracee's state changes). Crucially, when the tracee calls execve, the kernel performs a SELinux transition check. If the execve would change the tracee's SELinux domain, the kernel must verify that the TRACER is allowed to trace the tracee's NEW domain.

The relevant SELinux permission is: allow TRACER_DOMAIN TRACEE_DOMAIN_DOMAIN:process ptrace;

In standard AOSP, this is typically allowed for common transitions. For example, untrusted_app tracing a child transitioning to shell would be allowed by the rule: allow appdomain shell:process ptrace;

On Samsung Knox, DEFEX monitors this check and, according to our empirical findings, denies transitions for ptraced processes more aggressively than standard AOSP.

### 5.2 Why the Check is Triggered

In our pre-breakthrough builds:
- v0.0.22: The tracee called execve("/system/bin/sh"). The kernel looked up the type_transition rule: untrusted_app shell_exec:process shell. This would transition the tracee from untrusted_app to shell. The kernel then checked: can untrusted_app (tracer) ptrace shell (tracee's new domain)? On Samsung Knox, this was denied.

### 5.3 How PROOT_LOADER Avoids the Check

When PROOT_LOADER is used:
1. The tracee calls execve("$NATIVE_DIR/libproot-loader.so", ...).
2. The kernel checks: is there a type_transition for untrusted_app on apk_data_file? There is NOT -- only execute_no_trans is allowed.
3. Since no type_transition applies, the process stays in untrusted_app.
4. Since the domain does not change, no ptrace cross-domain check is performed.
5. The execution proceeds without SELinux intervention.

This is the fundamental mechanism behind the breakthrough. PROOT_LOADER does not create new capabilities; it works entirely within existing SELinux permissions by avoiding domain transitions entirely.

### 5.4 The Role of Static Linking

libproot-loader.so is a STATIC ELF binary -- it has no INTERP section and relies on no external shared libraries. This is by design:
- If it had INTERP referencing a non-existent path, the kernel would fail the execve before SELinux even checks permissions.
- If it had INTERP referencing /system/bin/linker64, the kernel would load linker64, triggering a domain transition to linker (the specific type_transition for linker_exec files), returning us to the blocked state.
- A static binary has no INTERP, so the kernel loads it directly. The SELinux check is simply: can untrusted_app exec apk_data_file? Yes, via execute_no_trans.

---

## 6. Architecture Deep Dive: v0.1.0

### 6.1 Component Layout

The APK contains the following components:

**Native Libraries (jniLibs/arm64-v8a/, extracted to nativeLibraryDir by package manager):**

| File | Size | Type | INTERP | Function |
|------|------|------|--------|----------|
| libproot.so | 231K | Dynamic ELF | /system/bin/linker64 | PRoot binary (Termux bionic build), the ptrace-based container engine |
| libproot-loader.so | 18K | Static ELF | None | PROOT_LOADER, loads musl-linked binaries via raw syscalls |
| libdexec.so | 53K | Dynamic ELF | /system/bin/linker64 | Termux exec shim (currently unused, kept for compatibility) |

**Assets (extracted to app data directory at runtime):**

| Asset | Size | Extraction Target | Purpose |
|-------|------|-------------------|---------|
| alpine-minirootfs.tar | 8.2MB | $FILES_DIR/rootfs/alpine/ | Alpine Linux 3.21.0 root filesystem |
| libtalloc.so.2 | 31K | $FILES_DIR/proot/lib/ | PRoot dependency (talloc memory allocator) |
| libandroid-shmem.so | 15K | $FILES_DIR/proot/lib/ | PRoot dependency (Android shared memory) |
| proot-arm64 | 231K | (kept for fallback reference) | Original glibc proot binary |

### 6.2 Launcher Script

The launcher script at $FILES_DIR/proot/proot-launch.sh is generated at runtime:

```bash
#!/system/bin/sh
PROOT_DIR=<filesDir>/proot
ROOTFS=<filesDir>/rootfs/alpine
SDK=<filesDir>/sdk
NATIVE_DIR=<nativeLibDir>
mkdir -p $SDK $PROOT_DIR/tmp
export PROOT_NO_SECCOMP=1
export PROOT_LINK2SYMLINK=1
export LD_LIBRARY_PATH=$PROOT_DIR/lib
export PROOT_TMP_DIR=$PROOT_DIR/tmp
export PROOT_LOADER=$NATIVE_DIR/libproot-loader.so
exec $NATIVE_DIR/libproot.so \
  -0 -r $ROOTFS \
  -b /dev -b /proc -b /sys \
  -b /system:/system \
  -b $SDK:/opt/android-sdk \
  -b /sdcard:/mnt/sdcard \
  -w /root --link2symlink \
  /bin/sh --login -c "$*"
```

Key environment variables and their purposes:

| Variable | Value | Role |
|----------|-------|------|
| PROOT_NO_SECCOMP | 1 | Disables seccomp-based acceleration; forces pure ptrace mode. Required because Android kernel bug LP#1202161 causes seccomp to return EPERM on chmod/chdir syscalls during PRoot's internal operations. Without this, Step 3 fails at proot startup. |
| PROOT_LINK2SYMLINK | 1 | Converts hardlinks to symlink+anchor groups. Required for Alpine rootfs compatibility on Android's ext4/f2fs filesystems, which do not fully support hardlinks across the app's data boundary. |
| LD_LIBRARY_PATH | $PROOT_DIR/lib | Points to the directory containing PRoot's own dependencies (libtalloc.so.2, libandroid-shmem.so). NOT used for rootfs libraries -- those are found through /lib and /usr/lib inside the rootfs via PRoot's path translation. |
| PROOT_TMP_DIR | $PROOT_DIR/tmp | PRoot's temporary directory for creating loader scripts and intermediate files. Must be writable by the app's UID. |
| PROOT_LOADER | $NATIVE_DIR/libproot-loader.so | Path to the static ELF loader. Used when PRoot detects a foreign binary (one whose INTERP does not exist on the host). The loader is an apk_data_file, enabling execute_no_trans. |

### 6.3 Step Pipeline

The app implements a 5-step wizard (6 steps including Step 2.5 diagnostics):

| Step | Function | Verification | Status in v0.1.0 |
|------|----------|-------------|-------------------|
| 1 | Extract PRoot support libs (libtalloc.so.2, libandroid-shmem.so) to $FILES_DIR/proot/lib/ | All native libs exist in nativeLibraryDir, support libs in proot/lib/ | Complete |
| 2 | Extract Alpine minirootfs tarball to $FILES_DIR/rootfs/alpine/ | Rootfs has /bin, /etc, /etc/alpine-release, /bin/sh | Complete |
| 3 | Create and test PRoot launcher script | Launcher runs echo OK through full PRoot chain | Complete |
| 4 | Run apk update and install bash + coreutils | bash --version succeeds inside PRoot | Blocked (libz.so.1) |
| 5 | Verify complete shell environment | uname -a && echo SHELL_READY | Locked |

---

## 7. Comparison with Industry Standards

### 7.1 Termux

Termux is the dominant terminal emulator for Android, with over 10 million installs. It is the reference implementation for running Linux tools on Android.

Termux uses an LD_PRELOAD-based exec shim (libtermux-exec-ld-preload.so) that intercepts execve and related functions. The shim:
1. Translates Linux paths (/bin/bash) to Termux paths ($PREFIX/bin/bash).
2. On Android 10+ devices, redirects execution through /system/bin/linker64 to bypass W^X restrictions.

Termux does NOT use PRoot by default. For its native packages, it compiles all binaries against Android's bionic libc, linking against /system/bin/linker64. This means all Termux binaries have INTERP=/system/bin/linker64, which exists on the host. The LD_PRELOAD shim handles the exec mechanism, and no ptrace is involved.

For proot-distro (Termux's container manager), Termux uses the same PRoot binary as we do, but launches it through the LD_PRELOAD shim:
1. termux-app runs sh with LD_PRELOAD set.
2. sh execve proot through the shim (which redirects through linker64).
3. proot transitions to linker domain.
4. proot's children use PROOT_LOADER for foreign binaries.

On standard AOSP devices, Step 4 works because the linker domain is in appdomain or has explicit ptrace permissions. On Samsung Knox, this fails.

Key difference from our approach: Termux launches PRoot through linker64, which transitions to linker domain. We launch PRoot directly from nativeLibraryDir, staying in untrusted_app.

### 7.2 UserLAnd

UserLAnd is a container manager that also uses PRoot. Based on analysis of their open-source components, UserLAnd uses the same PROOT_LOADER mechanism:

```
PROOT_LOADER=$LIB_PATH/loader PROOT_LOADER_32=$LIB_PATH/loader32 $PROOT -r $ROOTFS_PATH ...
```

UserLAnd places the loader and proot binary in the app's library path, similar to our approach. However, UserLAnd has been stalled since 2021 and does not handle Samsung-specific SELinux configurations. Their approach assumes standard AOSP SELinux behavior.

### 7.3 Andronix

Andronix is built on top of Termux infrastructure. It does not introduce novel execution mechanisms. It inherits Termux's LD_PRELOAD + proot-distro approach and is therefore subject to the same Samsung Knox limitations.

### 7.4 proroot (Emerging Technology)

proroot is a recently emerged project (2026) that replaces PRoot's ptrace-based approach with an LD_PRELOAD-based mechanism. Instead of intercepting syscalls via ptrace, proroot intercepts libc functions (open, stat, execve) at the userspace level via LD_PRELOAD. This eliminates the 2-context-switch overhead per syscall that PRoot incurs.

proroot places its binaries as native libraries (libproroot.so, libproroot-linker.so, etc.) in the app's library path. It uses a stub loader similar to PROOT_LOADER. However, proroot is very new (first public release ~April 2026) and has not been tested on Samsung Knox devices. Its LD_PRELOAD approach may interfere with Android's own LD_PRELOAD usage.

For DevEnv-PRoot, proroot represents a potential future optimization once the core execution path is fully stable.

### 7.5 LinuxDeploy

LinuxDeploy supports both chroot (requires root) and PRoot (no root). In PRoot mode, it works similarly to our approach. However, LinuxDeploy is designed primarily for rooted devices with chroot, and its PRoot mode has not been actively maintained.

### 7.6 Android Virtualization Framework (AVF)

Android 16 introduces AVF, which provides KVM-based virtual machines. AVF requires a Pixel device and is currently experimental. It cannot be used on Samsung devices and requires hardware virtualization support that may be restricted by Knox.

### 7.7 Comparative Summary

| Aspect | Termux | UserLAnd | Andronix | proroot | DevEnv v0.1.0 |
|--------|--------|----------|----------|---------|---------------|
| Core mechanism | LD_PRELOAD exec shim + bionic binaries | PRoot + PROOT_LOADER | Termux-based | LD_PRELOAD path translation | PRoot + PROOT_LOADER |
| PRoot domain | linker (via linker64) | linker (via linker64) | linker (inherited) | N/A (no ptrace) | untrusted_app |
| Samsung Knox compatible | No (linker domain blocked) | No (linker domain blocked) | No (inherited) | Unknown | **Yes** |
| Root required | No | No | No | No | No |
| Active development | Yes | Stalled (2021) | Yes (closed source) | Yes (new, 2026) | Yes |
| PROOT_LOADER support | Yes (for foreign binaries) | Yes | Inherited from Termux | Built-in stub loader | Yes |
| Container management | proot-distro | Built-in | Built-in | None yet | Built-in (5-step wizard) |
| ptrace overhead | Yes (via PRoot for containers) | Yes | Yes | No (LD_PRELOAD only) | Yes |

---

## 8. Current Limitations

### 8.1 libz.so.1 Not Found by musl's Dynamic Linker

At v0.1.0, Step 4 (apk update) fails:

```
Error loading shared library libz.so.1: No such file or directory (needed by apk)
Error loading shared library libz.so.1: No such file or directory (needed by /lib/libapk.so.2.14.0)
Error relocating /lib/libapk.so.2.14.0: inflateEnd: symbol not found
Error relocating /lib/libapk.so.2.14.0: deflate: symbol not found
...
```

The Alpine package manager apk requires libz.so.1 (zlib compression library). The file IS present in the Alpine minirootfs tarball at ./lib/libz.so.1 (a symlink to libz.so.1.3.1). The question is whether the TarExtractor extracted these files correctly and whether musl's dynamic linker inside the PRoot sandbox can find them.

Two hypotheses exist:
- Hypothesis A: The TarExtractor failed to extract libz.so.1 and/or libz.so.1.3.1 correctly (e.g., symlink creation failed, file permissions wrong, PAX header parsing missed the entry).
- Hypothesis B: The files were extracted correctly, but musl's dynamic linker (ld-musl-aarch64.so.1) cannot reach them due to PRoot path translation issues (e.g., LD_LIBRARY_PATH taking precedence, openat vs open syscall handling, symlink resolution through ptrace).

Diagnostics planned for v0.1.1 will stat each critical library from outside the PRoot sandbox to determine which hypothesis is correct.

### 8.2 Remaining Step Pipeline

After the libz.so.1 issue is resolved, the remaining steps are:
- Step 4: apk update, apk add bash coreutils. Requires working dynamic linker and internet access.
- Step 5: Verify shell environment (uname -a, bash --version, echo SHELL_READY). Requires all previous steps to succeed.
- Terminal integration: Launch a terminal emulator (Termux-style) inside the app for user interaction.

### 8.3 Performance Considerations

PRoot's ptrace-based approach incurs a 2-context-switch overhead per syscall (tracer -> kernel -> tracee -> kernel). For CPU-bound operations, the overhead is near zero. For I/O-bound operations (file access, network), the overhead is significant. Industry benchmarks show PRoot reduces I/O throughput by approximately 44% compared to native execution. This is acceptable for the development environment use case but may be noticeable for heavy file operations.

### 8.4 Phantom Process Killer

Android's Phantom Process Killer (introduced in Android 12) may kill PRoot's child processes if the app is in the background. Mitigations include requesting developer-mode exemption or acquiring a foreground service wakelock. This is a known issue across all PRoot-based solutions and is not specific to our approach.

---

## 9. Lessons Learned

### 9.1 Never Use linker64 as an Exec Trampoline on Samsung

The Termux community's standard approach of prefixing with /system/bin/linker64 is effective on standard AOSP but catastrophic on Samsung Knox. The linker domain is locked down more aggressively by Samsung's DEFEX module than by standard AOSP SELinux. On Samsung, the linker domain cannot execute ANYTHING outside /system -- not even apk_data_file.

### 9.2 apk_data_file is the Only Executable File Type

For targetSdk >= 29 apps, the ONLY file label that grants execute permission is apk_data_file (native libraries from jniLibs). All binaries must be placed in nativeLibraryDir. Any executable placed in assets (which extracts to app_data_file) cannot be executed directly.

### 9.3 execute_no_trans is More Valuable Than execute

SELinux has two exec permissions: execute (allows domain transition) and execute_no_trans (executes in-place without domain transition). For PRoot's ptrace use case, execute_no_trans is actually MORE valuable than execute, because it avoids the domain transition that triggers the ptrace cross-domain check.

### 9.4 Static Binaries Are Essential for PROOT_LOADER

The PROOT_LOADER binary itself must be a static ELF with no INTERP. If it had INTERP, the kernel would try to load it, potentially triggering another domain transition. A static binary loads directly with no interpreter lookup, and the SELinux check is limited to execute_no_trans on the binary's file label.

### 9.5 Force PROOT_LOADER by Using musl-linked Rootfs

PROOT_LOADER is automatically used when PRoot detects a binary whose INTERP does not exist on the host. By choosing a musl-based distro (Alpine) whose binaries reference /lib/ld-musl-aarch64.so.1, every single binary in the rootfs triggers PROOT_LOADER usage. This is not a limitation -- it is the essential design feature that enables the SELinux bypass.

### 9.6 Mixing Android and Alpine Shells Was the Accidental Fix

The transition from targeting /system/bin/sh (Android shell, INTERP=linker64) to /bin/sh (Alpine shell, INTERP=ld-musl) was the critical change. This was originally done to work around a suspected binary compatibility issue, but it accidentally triggered the PROOT_LOADER mechanism that bypasses the SELinux restriction.

### 9.7 Build Fast, Test Often

Across 24 build iterations, the average cycle time was approximately 3 minutes per build. Each build tested exactly one variable. This iterative approach allowed rapid elimination of hypotheses. When paired with comprehensive error logging (the app captures full PRoot stderr output), each failure provided precise diagnostic information.

---

## 10. Conclusion and Roadmap

### 10.1 Summary

The DevEnv-PRoot project has achieved the first documented successful execution of a PRoot-based Linux container on a locked Samsung Knox Android 16 device. The key architectural insight --- using PROOT_LOADER to avoid SELinux domain transitions and thus bypass the ptrace cross-domain check --- is applicable to any Android app that needs to run foreign binaries within a ptrace-based sandbox on restricted devices.

### 10.2 Roadmap

| Version | Focus | Status |
|---------|-------|--------|
| v0.1.0 | Working PRoot chain (echo OK) | Complete |
| v0.1.1 | Lib diagnostics, log fixes, verify(2) flag | In progress |
| v0.1.2 | Fix libz.so.1 resolution / apk init | Planned |
| v0.1.3 | bash + coreutils install, shell validation | Planned |
| v0.1.4 | Terminal integration | Planned |
| v0.2.0 | Performance optimization, additional distros | Future |

### 10.3 Applicability

This approach applies to any Android device running API >= 29 with Samsung Knox or similar SELinux enhancements. It does not require root access, ADB debugging, or modification of system policies. It relies entirely on standard Android app APIs (jniLibs extraction, ProcessBuilder exec, file I/O) that are available to all third-party applications.

---

## References

1. Termux termux-exec-package. GitHub repository. https://github.com/termux/termux-exec-package

2. Termux proot (bionic fork). GitHub repository. https://github.com/termux/proot

3. PRoot, the official ptrace-based chroot. GitHub repository. https://github.com/proot-me/proot

4. PRoot issue #45: Unable to run dynamic uClibc-linked binaries with proot. https://github.com/proot-me/proot/issues/45

5. Termux PRoot manual.txt. Documentation. https://github.com/termux/proot/blob/master/doc/proot/manual.txt

6. Termux PRoot loader.c (PROOT_LOADER implementation). https://github.com/termux/proot/blob/master/src/loader/loader.c

7. Termux-proot issue #158: proot not found ld-linux.so. https://github.com/termux/proot/issues/158

8. UserLAnd. GitHub repository. https://github.com/CypherpunkArmory/UserLAnd

9. UserLAnd-Assets-Support execInProot.sh. https://github.com/CypherpunkArmory/UserLAnd-Assets-Support/blob/staging/assets/all/execInProot.sh

10. Andronix. Official website. https://andronix.app/

11. Android SELinux Internals Part II (8kSec). https://8ksec.io/android-selinux-internals-part-ii/

12. Android SELinux Internals Part IV (8kSec). https://8ksec.io/android-selinux-internals-part-iv/

13. AOSP SELinux concepts and neverallow rules. https://source.android.com/docs/security/features/selinux/concepts

14. app_data_file exec Magisk module. https://github.com/okyes/app-data-file-exec

15. Samsung Knox DEFEX documentation. https://www.samsungknox.com/en/blog/this-is-protection-samsung-knox

16. Samsung RKP documentation. https://docs.samsungknox.com/admin/fundamentals/whitepaper/samsung-knox-mobile-security/system-security/real-time-kernel-protection/

17. Musl cross-compilation toolchains. https://musl.cc/

18. proroot: Zero-ptrace PRoot alternative. GitHub repository. https://github.com/coderredlab/proroot

19. Termux execution environment documentation. https://github.com/termux/termux-packages/wiki/Termux-execution-environment

20. Linux kernel bug LP#1202161: seccomp returns EPERM for certain syscalls. https://bugs.launchpad.net/ubuntu/+source/linux/+bug/1202161
