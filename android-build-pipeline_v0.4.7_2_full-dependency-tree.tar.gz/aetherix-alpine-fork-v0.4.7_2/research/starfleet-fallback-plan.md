# DevEnv PRoot — StarFleet Fallback Plan

Four-layer redundancy for PRoot binary execution on Android.

---

## Layer 1 — Primary: Bionic PRoot (Active)

| Field | Value |
|-------|-------|
| **Binary** | Termux `proot` v5.1.107.86 (bionic-compiled) |
| **INTERP** | `/system/bin/linker64` |
| **DT_NEEDED** | `libtalloc.so.2`, `libandroid-shmem.so`, `libc.so` |
| **Bundled deps** | `libtalloc.so.2` + `libandroid-shmem.so` (assets → `$PROOT_DIR/lib/`) |
| **Launcher** | `exec /system/bin/linker64 $PROOT_DIR/proot-arm64 ...` with `LD_LIBRARY_PATH=$PROOT_DIR/lib` and `PROOT_TMP_DIR=$PROOT_DIR/tmp` |
| **Asset size** | 231K (binary) + 31K + 15K = 277K |
| **Status** | v0.0.13 — Steps 1-2 pass, Step 3 awaiting exec permission fix |

**Fail scenarios:**
- SELinux blocks execution of Alpine binaries inside rootfs (app data context)
- `/data` mount is `noexec` on this device/kernel config
- File permissions not preserved during extraction (TarExtractor fix in v0.0.13)

---

## Layer 2 — Secondary: Glibc Bundle

| Field | Value |
|-------|-------|
| **Binary** | Original glibc `proot-arm64` (INTERP `/lib/ld-linux-aarch64.so.1`) |
| **Bundled glibc** | `ld-linux-aarch64.so.1` + `libc.so.6` + `libtalloc.so.2` (from Ubuntu 24.04 ARM64) |
| **Install path** | `$PROOT_DIR/lib/` alongside bionic libs |
| **Launcher** | `exec $PROOT_DIR/lib/ld-linux-aarch64.so.1 --library-path $PROOT_DIR/lib $PROOT_DIR/proot-arm64-glibc ...` |
| **Asset size** | 212K (binary) + 204K (ld) + 1.7M (libc) + ~40K (libtalloc) = ~2.2M |
| **Trigger** | If Layer 1 `echo OK` test fails at verify(2) |

**How it works:**
- Instead of `/system/bin/linker64`, use bundled `ld-linux-aarch64.so.1` as the loader
- `--library-path` tells the glibc loader where to find its libc.so.6
- This creates a complete glibc runtime inside the app sandbox
- The launcher script tries Layer 1 first; if it fails, auto-falls through to Layer 2

**Fail scenarios:**
- Glibc expects Linux filesystem layout (`/etc/ld.so.cache`, `/dev/null`, `/proc/self/...`)
- Glibc version mismatch with kernel syscall interface on Android kernel 5.15
- libtalloc on host glibc may have different ABI than what proot was compiled against

---

## Layer 3 — Tertiary: Musl-Static PRoot

| Field | Value |
|-------|-------|
| **Binary** | PRoot statically compiled against musl libc |
| **INTERP** | None (static ELF) |
| **DT_NEEDED** | None |
| **Launcher** | `exec /system/bin/linker64 $PROOT_DIR/proot-arm64-musl ...` (for SELinux bypass) or direct if policy allows |
| **Asset size** | ~500K-800K (fully static) |
| **Trigger** | If Layers 1+2 both fail verify(2) |

**Build requirements (cross-compile on this container):**
1. musl-cross-make toolchain for aarch64
2. Build libtalloc statically against musl
3. Build PRoot against musl + static libtalloc
4. Strip binary

**Advantages:**
- Zero runtime dependencies — no `.so` files, no linker issues
- No `LD_LIBRARY_PATH` complexity
- Immune to glibc/bionic ABI mismatches
- Immune to library path resolution failures

**Fail scenarios:**
- Static build fails due to PRoot's autoconf assumptions about the runtime
- Musl's ptrace behavior differs from glibc (edge cases in PRoot's seccomp/ptrace handling)
- Binary larger than expected (> 1MB APK impact)

---

## Layer 4 — Quaternary: app_process Launcher

| Field | Value |
|-------|-------|
| **Binary** | Any of the above proot binaries |
| **Launcher** | `exec app_process -Djava.class.path=/dev/null /system/bin --nice-name=proot $PROOT_DIR/proot-arm64 ...` |
| **SELinux** | Bypassed — `app_process` runs with `system_server` context |
| **Trigger** | If `/data` is mounted `noexec` (kernel-level block, not SELinux) |

**How it works:**
- Android's `app_process` (Zygote) has a privileged SELinux context that can execute files from any directory
- When invoked as a command-line launcher, it creates a process with Zygote's context
- This context is typically `u:r:zygote:s0` or similar, which has `execmem` and `exec` permissions on `app_data_file`
- Used by Frida, Magisk modules, and other tools to escape app sandbox exec restrictions
- The process eventually exec's the target binary via JNI or by reading the binary's name from argv
- Does NOT require root — works on production Android devices

**Command form:**
```
exec app_process -Djava.class.path=/dev/null /system/bin --nice-name=proot \
  /system/bin/linker64 $PROOT_DIR/proot-arm64 \
  -0 -r $ROOTFS -b /dev -b /proc -b /sys \
  -b $SDK:/opt/android-sdk -b /sdcard:/mnt/sdcard \
  -w /root --link2symlink /bin/sh --login -c "$*"
```

**Fail scenarios:**
- `app_process` not available or restricted on this Android version (unlikely — it's part of AOSP)
- `app_process` requires a Java classpath to a valid DEX/APK (can use `/dev/null` as shown above)
- Different naming on newer Android versions (`app_process32`/`app_process64`)
- Only needed if ALL other layers fail — last resort

---

## Decision Tree

```
Step 3 verify(2) call
  │
  ├─ Layer 1: Run Termux proot via linker64
  │   ├─ echo OK? → ✅ Done
  │   └─ Fail?
  │       │
  │       ├─ Layer 2: Run glibc proot via bundled ld-linux
  │       │   ├─ echo OK? → ✅ Done
  │       │   └─ Fail?
  │       │       │
  │       │       ├─ Layer 3: Run musl-static proot via linker64
  │       │       │   ├─ echo OK? → ✅ Done  
  │       │       │   └─ Fail?
  │       │       │       │
  │       │       │       └─ Layer 4: Run via app_process (any binary)
  │       │       │           ├─ echo OK? → ✅ Done
  │       │       │           └─ Fail? → ❌ Error: "No compatible proot binary"
  │       │       │
  │       │       └─── (if 3 or 4 works, report which layer succeeded for diagnostics)
  │       │
  │       └─── (if 2 works, report which layer succeeded)
  │
  └─── (if 1 works, no fallback needed)
```

---

## Implementation Order

1. **v0.0.13**: Fix TarExtractor file permissions — if this alone fixes Step 3, no fallback needed
2. **v0.0.14**: Add Layer 2 (glibc bundle) — extract glibc libs, add as assets, create fallback launcher
3. **v0.0.15**: Add Layer 3 (musl-static) — cross-compile toolchain + static build
4. **v0.0.16**: Add Layer 4 (app_process) — if SELinux blocking exec from app data

Each layer's trigger is a `verify(2)` failure cascade inside `step3Launcher()`. The launcher script tests `echo OK` with each binary and reports which layer succeeded.
