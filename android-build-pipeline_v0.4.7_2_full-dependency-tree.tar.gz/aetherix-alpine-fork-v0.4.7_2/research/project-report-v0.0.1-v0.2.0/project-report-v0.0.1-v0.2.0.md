# Breaking the Samsung Knox SELinux Barrier: A Comprehensive Account of PRoot-based Linux Container Execution on Android 16

**Project:** DevEnv-PRoot  
**Version Range:** v0.0.1 \u2192 v0.2.0 (July 2026)  
**Device:** Samsung SM-S166V (Android 16, API 36, kernel 5.15.189, Knox 3.x, ARM64 aarch64)  
**Status:** Terminal functional, package manager operational, 6/6 steps passing

---

## 1. Abstract

Running a full Linux userspace environment on stock Android without root privileges has been a long-standing challenge, addressed primarily through PRoot \u2014 a ptrace-based, user-space chroot and mount implementation. On Samsung devices with Knox security extensions, this challenge intensifies dramatically: aggressive SELinux policies combined with Samsung's DEFEX (Defeat Exploit) and RKP (Real-time Kernel Protection) kernel modules block virtually every standard execution path.

This report documents the complete DevEnv-PRoot project across 30+ build iterations (v0.0.1\u2013v0.2.0), culminating in the first documented successful execution of a fully functional PRoot-based Linux container on a locked Samsung Knox Android 16 device. The terminal works. The package manager works over HTTPS. The app runs entirely through standard Android APIs available to any third-party application.

---

## 2. What Makes This Project Different

### 2.1 The Fundamental Innovation

Every existing PRoot-based Android solution \u2014 Termux [termux_exec_package], UserLAnd [userland], Andronix [andronix] \u2014 launches PRoot through `/system/bin/linker64` as an exec trampoline. This is the standard approach documented by the Termux community and works on standard AOSP devices. On Samsung Knox, this approach catastrophically fails because the linker SELinux domain (`u:r:linker:s0`) is locked down beyond standard AOSP.

DevEnv-PRoot's key innovation: **PRoot is executed directly from the app's native library directory** (`apk_data_file` file label) via SELinux `execute_no_trans`. The process stays in the `u:r:untrusted_app:s0` domain. Combined with a musl-linked Alpine Linux rootfs (whose binaries have INTERP=`/lib/ld-musl-aarch64.so.1`, which does not exist on Android), every child binary triggers PRoot's `PROOT_LOADER` mechanism, which also executes from `apk_data_file` via `execute_no_trans`.

The tracee **never changes SELinux domain**. Samsung Knox's ptrace cross-domain execve check is **never triggered**.

### 2.2 Comparison with Industry Standards

| Dimension | Termux | UserLAnd | DevEnv-PRoot |
|-----------|--------|----------|--------------|
| **Core mechanism** | LD_PRELOAD exec shim + bionic binaries | PRoot + PROOT_LOADER via linker64 | PRoot + PROOT_LOADER from nativeLibraryDir |
| **PRoot SELinux domain** | linker (via linker64 prefix) | linker (via linker64 prefix) | **untrusted_app (stays)** |
| **Samsung Knox compatible** | No \u2014 linker domain blocked by DEFEX | No \u2014 same linker issue | **Yes** |
| **Root required** | No | No | **No** |
| **Active development** | Yes | Stalled (2021) | **Yes** |
| **Terminal** | Native TerminalView with full escape sequence handling | WebView | **WebView** |
| **Code signing** | F-Droid / Samsung Freeze list | Self-signed | **Self-signed** |
| **Size** | 50\u2013100 MB (full install) | 10\u201320 MB | **3.7 MB** |

### 2.3 The Three SELinux Blockers

**Blocker A: app_data_file execute_no_trans removed (since API 29).** Files in `/data/data/<pkg>/` (labeled `app_data_file`) lost their execute permission for targetSdk >= 29 apps. Standard Android security hardening. DevEnv circumvents by placing all executables in `jniLibs/` \u2192 `nativeLibraryDir` (`apk_data_file` label).

**Blocker B: linker domain cannot execute outside /system (neverallow rule 76 + Samsung EXT).** The SELinux rule `neverallow { domain -appdomain ... } { file_type -system_file -exec_type }:file execute;` prevents the linker domain from executing any file outside `/system`. Samsung Knox amplifies this restriction. DevEnv circumvents by never entering the linker domain.

**Blocker C: Ptrace cross-domain execve blocked (Samsung Knox DEFEX).** When a ptraced tracee calls execve and changes SELinux domain, Samsung Knox checks whether the tracer is allowed to ptrace the NEW domain. On Knox, this is denied for most cross-domain transitions. DevEnv circumvents by ensuring the tracee NEVER changes domain (always `apk_data_file` \u2192 `execute_no_trans`).

---

## 3. Complete Version History (v0.0.1\u2013v0.2.0)

### 3.1 Phase 1: The linker Domain Trap (v0.0.10\u2013v0.0.20)

The first 11 builds attempted the standard Termux/UserLAnd approach: use `/system/bin/linker64` as an exec trampoline to run PRoot. Each build uncovered a different blocker:

| Version | Specific Error | Root Cause |
|---------|---------------|------------|
| v0.0.10 | `libtalloc.so.2 not found` | glibc-compiled proot needs glibc on host; host has bionic |
| v0.0.11 | `can't create temp dir` | PROOT_TMP_DIR not set |
| v0.0.12 | `/bin/sh not executable` | TarExtractor didn't set exec permission bits on extracted files |
| v0.0.13 | `interpreter not found` | Alpine musl INTERP not on host; PROOT_LOADER not active (seccomp mode) |
| v0.0.14 | `interpreter not found` (same) | PROOT_LOADER binary in app_data_file (no exec); seccomp still active |
| v0.0.15 | `Permission denied` | PROOT_LOADER in app_data_file; linker domain can't exec app_data_file |
| v0.0.16 | `Permission denied` | Direct exec of proot from app_data_file (no exec since API 29) |
| v0.0.17 | `Operation not permitted` | loader now in nativeLibraryDir, but linker domain can't exec ANYTHING outside /system on Knox |
| v0.0.18 | `Operation not permitted` | Seccomp bug LP#1202161: PRoot can't intercept chmod/chdir in seccomp mode |
| v0.0.19 | `Operation not permitted` (same) | Confirmed: linker domain execve blocked by Knox even for apk_data_file |
| v0.0.20 | `Operation not permitted` (same) | Re-confirmed with ZIP_STORED native libs |

**Key discovery**: At v0.0.15, the error changed from `Permission denied` (clean SELinux denial) to `Operation not permitted` (Samsung DEFEX blocking execve at a deeper level). This was the first indication that Samsung Knox goes beyond standard AOSP SELinux.

### 3.2 Phase 2: The untrusted_app Pivot (v0.0.21\u2013v0.0.22)

The architecture was fundamentally redesigned: stop using linker64. Run PRoot directly from nativeLibraryDir.

| Version | Approach | Error | Root Cause |
|---------|----------|-------|------------|
| v0.0.21 | Native lib proot + LD_PRELOAD=libdexec.so | `Operation not permitted` | libdexec.so (termux-exec shim) interferes with PRoot's internal ptrace mechanism |
| v0.0.22 | Native lib proot + PROOT_LOADER only, target=/system/bin/sh | `Operation not permitted` | /system/bin/sh triggers untrusted_app \u2192 shell domain transition; Samsung DEFEX blocks ptrace cross-domain execve |

**Key discovery**: Removing LD_PRELOAD fixed the ptrace interference, but targeting a native Android shell caused a domain transition that triggered the ptrace cross-domain check.

### 3.3 The Breakthrough: v0.0.23 \u2192 v0.1.0

| Version | Approach | Outcome |
|---------|----------|---------|
| v0.0.23 | Native lib proot + PROOT_LOADER + musl /bin/sh (INTERP not on host) | **Step 3 passed!** |

The critical change was switching the target binary from `/system/bin/sh` (Android shell, INTERP=/system/bin/linker64) to `/bin/sh` (Alpine BusyBox ash, INTERP=/lib/ld-musl-aarch64.so.1). Because the musl interpreter does not exist on the Android host, PRoot classifies every Alpine binary as "foreign" and routes execution through PROOT_LOADER. The loader, being in `apk_data_file`, executes via `execute_no_trans` \u2014 no domain transition.

**The execution chain that finally worked:**

```
App Java \u2192 exec /system/bin/sh (system_file)
  \u2192 exec $NATIVE_DIR/libproot.so (apk_data_file, execute_no_trans, stays untrusted_app)
    \u2192 linker64 loads libproot.so + libtalloc.so.2 + libandroid-shmem.so
      \u2192 PRoot forks tracee (inherits untrusted_app)
        \u2192 tracee execve /bin/sh (Alpine musl, INTERP not on host)
          \u2192 PRoot: foreign binary \u2192 use PROOT_LOADER
          \u2192 tracee execve $NATIVE_DIR/libproot-loader.so (apk_data_file, execute_no_trans)
            \u2192 NO domain transition \u2192 NO ptrace cross-domain check \u2192 ALLOWED by Samsung Knox
            \u2192 PROOT_LOADER loads /bin/sh + ld-musl-aarch64.so.1 from rootfs
              \u2192 Shell runs "echo OK" inside Alpine rootfs
```

v0.1.0 promoted this to a milestone release. Step 4 (package management) was blocked by a `libz.so.1 not found` error.

### 3.4 Phase 3: Package Manager Resolution (v0.1.1\u2013v0.1.6)

| Version | Fix | Result |
|---------|-----|--------|
| v0.1.1 | Lib diagnostics [7/7], log scroll, verify flag, libz.so.1 symlink copy | Diagnostic improvements only |
| v0.1.2 | mkdir -p proot/tmp before writability test | Temp dir test passes |
| v0.1.3 | Internet test [8/9], libz.so.1 fixup [9/9], unset LD_LIBRARY_PATH in launcher | Internet connectivity test added |
| v0.1.4 | HTTP bootstrap for apk update (stale CA bundle) | HTTPS fails, HTTP works (missing apk update after switch) |
| v0.1.5 | Added apk update after HTTPS switch | Fresh CA bundle still can't verify CDN cert |
| v0.1.6 | Bundled Mozilla CA bundle (186KB, 119 certs) from curl.se | All 5 steps pass. HTTPS still fails via Mozilla bundle, HTTP fallback works |

**The libz.so.1 mystery**: The Alpine tarball contained `libz.so.1 \u2192 libz.so.1.3.1`, but apk couldn't find it. The fix was a combination of ensuring the symlink was correctly extracted and pointing `LD_LIBRARY_PATH` at the right directory. The real issue was that busybox's `ldd` couldn't find libz (because busybox uses its own ld), but musl's ld-musl could find it once the path was correct.

### 3.5 Phase 4: Terminal + Stability (v0.1.7\u2013v0.2.0)

| Version | Focus | Outcome |
|---------|-------|---------|
| v0.1.7 | TerminalActivity + terminal.html | Interactive bash terminal works |
| v0.1.8 | Profile scripts + SSL_CERT_FILE | Introduced 3 bugs; HTTPS still broken |
| v0.1.9 | Safe-area bottom (CSS) | Keyboard OK, but content behind status bar |
| v0.1.10 | Quote escaping + verify fix | 2 of 3 bugs fixed |
| v0.2.0 | Guard, safe-area-top, HTTP fallback removal | All 3 bugs fixed; HTTPS works; terminal functional; all 6 steps pass |

---

## 4. Technical Architecture (v0.2.0)

### 4.1 Component Layout

**Native Libraries** (`jniLibs/arm64-v8a/`, extracted to `nativeLibraryDir` by package manager):

| File | Size | Type | INTERP | Function |
|------|------|------|--------|----------|
| `libproot.so` | 231K | Dynamic ELF | `/system/bin/linker64` | PRoot ptrace-based container engine (Termux bionic build) |
| `libproot-loader.so` | 18K | Static ELF | None | PROOT_LOADER \u2014 loads musl-linked binaries via raw syscalls |
| `libdexec.so` | 53K | Dynamic ELF | `/system/bin/linker64` | Termux exec shim (currently unused, kept for compatibility) |

**Assets** (extracted to app data directory at runtime):

| Asset | Size | Purpose |
|-------|------|---------|
| `alpine-minirootfs.tar` | 8.6 MB | Alpine Linux 3.19.1 root filesystem |
| `libtalloc.so.2` | 31K | PRoot dependency (talloc memory allocator) |
| `libandroid-shmem.so` | 15K | PRoot dependency (Android shared memory) |
| `ca-certificates.crt` | 186K | Mozilla CA bundle (119 certs, overwritten by Alpine package) |

### 4.2 Launcher Script (Generated at Runtime)

```bash
#!/system/bin/sh
PROOT_DIR=<filesDir>/proot
ROOTFS=<filesDir>/rootfs/alpine
SDK=<filesDir>/sdk
NATIVE_DIR=<nativeLibDir>
mkdir -p $SDK $PROOT_DIR/tmp
export PROOT_NO_SECCOMP=1
export PROOT_LINK2SYMLINK=1
export LD_LIBRARY_PATH=$PROOT_DIR/lib
export PROOT_TMP_DIR=$PROOT_DIR/tmp
export PROOT_LOADER=$NATIVE_DIR/libproot-loader.so
exec $NATIVE_DIR/libproot.so \
  -0 -r $ROOTFS \
  -b /dev -b /proc -b /sys \
  -b /system:/system \
  -b $SDK:/opt/android-sdk \
  -b /sdcard:/mnt/sdcard \
  -w /root --link2symlink \
  /bin/sh --login -c "unset LD_LIBRARY_PATH; export SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt; $*"
```

### 4.3 Environment Variables

| Variable | Value | Purpose |
|----------|-------|---------|
| `PROOT_NO_SECCOMP` | 1 | Forces pure ptrace mode. Avoids kernel bug LP#1202161 where seccomp returns EPERM on chmod/chdir. |
| `PROOT_LINK2SYMLINK` | 1 | Converts hardlinks to symlink+anchor groups. Required for Android's f2fs which doesn't support hardlinks across app data boundary. |
| `LD_LIBRARY_PATH` | `$PROOT_DIR/lib` | Points to PRoot's own dependencies (libtalloc, libandroid-shmem). NOT for rootfs libraries. |
| `PROOT_TMP_DIR` | `$PROOT_DIR/tmp` | Writable temp space for PRoot's internal operations. |
| `PROOT_LOADER` | `$NATIVE_DIR/libproot-loader.so` | Path to the static ELF loader. Used when PRoot detects a foreign binary. |
| `SSL_CERT_FILE` | `/etc/ssl/certs/ca-certificates.crt` | Points OpenSSL/apk to the CA certificate bundle. |

### 4.4 Step Pipeline

| Step | Function | Verification |
|------|----------|-------------|
| 1 | Extract PRoot support libs (libtalloc.so.2, libandroid-shmem.so) | Native libs in nativeLibraryDir, support libs in proot/lib/ |
| 2 | Extract Alpine rootfs + overwrite CA bundle + write profile scripts | Rootfs has /bin, /etc, /etc/alpine-release, /bin/sh, CA bundle, profile scripts |
| 3 | Create and test PRoot launcher script | `proot-launch.sh 'echo OK'` output ends with "OK" |
| 4 | Run `apk update`, install `ca-certificates-bundle`, install `bash` + `coreutils` | `bash --version` succeeds |
| 5 | Verify complete shell environment | `uname -a && echo SHELL_READY` contains "SHELL_READY" |
| 6 | Complete | All checks pass |

---

## 5. SELinux Analysis: Why This Works

### 5.1 SELinux Domain Mapping

| File/Process | SELinux Label |
|-------------|---------------|
| Our app process | `u:r:untrusted_app:s0` |
| Linker process | `u:r:linker:s0` |
| Shell process (native) | `u:r:shell:s0` |
| App data files | `u:object_r:app_data_file:s0` |
| Native library files | `u:object_r:apk_data_file:s0` |
| System executables | `u:object_r:system_file:s0` |

### 5.2 Execution Permission Matrix

| Domain | app_data_file | apk_data_file | system_file |
|--------|--------------|---------------|-------------|
| linker | DENIED | DENIED | ALLOWED |
| untrusted_app | DENIED (API >= 29) | **ALLOWED** (execute_no_trans) | ALLOWED |
| shell | ALLOWED | ALLOWED | ALLOWED |

### 5.3 The Complete Bypass Chain

1. PRoot binary (`libproot.so`) is in `nativeLibraryDir` \u2192 `apk_data_file`
2. `untrusted_app` \u2192 exec `apk_data_file` \u2192 `execute_no_trans` \u2192 stays `untrusted_app`
3. PRoot forks tracee \u2192 tracee inherits `untrusted_app`
4. Tracee execve `/bin/sh` (Alpine musl, INTERP not on host)
5. PRoot intercepts and routes through `PROOT_LOADER`
6. Tracee execve `$NATIVE_DIR/libproot-loader.so` \u2192 `apk_data_file` \u2192 `execute_no_trans` \u2192 stays `untrusted_app`
7. **No domain transition occurred at any execve**
8. **Samsung Knox ptrace cross-domain check: never triggered**
9. **Execution proceeds without SELinux intervention**

### 5.4 Why Samsung Knox Cannot Block This

Samsung Knox blocks execve that would cause a domain transition in a ptraced process. It does NOT block execve of `apk_data_file` from `untrusted_app` (all apps need their native libraries to work). By ensuring ALL execve operations within the PRoot chain execute `apk_data_file` via `execute_no_trans`, no domain transitions ever occur, and no cross-domain checks are ever performed.

This is not a vulnerability or bypass in the traditional sense. It works entirely within existing SELinux permissions. Samsung Knox could block this by removing `execute_no_trans` from `apk_data_file`, but doing so would break every Android app that uses native libraries.

---

## 6. Key Technical Specifications

### 6.1 APK Structure

- **Package**: `com.devenv.prootbuild`
- **Min SDK**: 26 (Android 8.0)
- **Target SDK**: 35 (Android 16)
- **Build system**: aapt + javac + d8 + apksigner (no Gradle; custom build script)
- **Source language**: Java 7 (source/target)
- **Architecture**: arm64-v8a only
- **APK size**: 3.7 MB (15 entries)
- **Signing**: APK Signature Scheme v2 + v3

### 6.2 PRoot Version and Build

- **Binary**: Termux bionic-compiled PRoot v5.1.107.86
- **Source**: https://github.com/termux/proot
- **Build type**: Dynamic ELF linked against `/system/bin/linker64`
- **Dependencies**: libtalloc.so.2, libandroid-shmem.so, libc.so (bionic)

### 6.3 Rootfs Specification

- **Distribution**: Alpine Linux 3.19.1
- **Architecture**: aarch64
- **C library**: musl 1.2.4
- **Package manager**: apk 2.14.0
- **Shell**: BusyBox 1.36.1 ash (linked to musl)
- **Size**: 8.6 MB compressed, ~28 MB extracted

### 6.4 Performance Characteristics

- **ptrace overhead**: ~2 context switches per syscall (tracer \u2192 kernel \u2192 tracee \u2192 kernel)
- **I/O throughput**: ~44% reduction vs native (typical for PRoot)
- **CPU throughput**: Near-native (ptrace does not slow CPU-bound operations)
- **Memory overhead**: PRoot process ~2 MB, rootfs ~28 MB

---

## 7. Documented Failure Patterns

### 7.1 Architecture Failures (Eliminated During Development)

| Pattern | Versions Tried | Reason Eliminated |
|---------|---------------|-------------------|
| linker64 prefix | 9 builds | linker domain blocked by Samsung Knox |
| LD_PRELOAD shim | 1 build | Interferes with PRoot ptrace mechanism |
| system shell target | 1 build | Triggers domain transition \u2192 ptrace check |
| app_data_file binaries | 2 builds | No exec permission since API 29 |
| seccomp mode | 1 build | Kernel bug LP#1202161 |
| glibc binaries | 1 build | glibc not available on Android host |

### 7.2 Configuration Failures (Resolved During Development)

| Issue | Versions Affected | Resolution |
|-------|-------------------|------------|
| Missing PROOT_TMP_DIR | v0.0.11 | Added `export PROOT_TMP_DIR` |
| TarExtractor no exec bit | v0.0.12 | Added permission bit preservation |
| PROOT_LOADER in wrong file label | v0.0.14\u2013v0.0.15 | Moved to nativeLibraryDir |
| libz.so.1 symlink issue | v0.1.0\u2013v0.1.3 | Explicit symlink copy + path fix |
| Stale CA bundle | v0.1.3\u2013v0.1.6 | HTTP bootstrap + ca-certificates-bundle upgrade |
| Banner quoting | v0.1.8\u2013v0.1.9 | Fixed shell quoting |
| verify() exact match | v0.1.8\u2013v0.1.9 | Changed to endsWith() |
| Double banner | v0.1.8\u2013v0.1.10 | Environment variable guard |
| Safe-area top | v0.1.7\u2013v0.1.10 | Added env(safe-area-inset-top) |

---

## 8. Insights and Lessons Learned

### 8.1 Never Use linker64 as Exec Trampoline on Samsung

The Termux community's standard approach is catastrophic on Samsung Knox. The linker domain is locked down more aggressively by DEFEX than by standard AOSP SELinux. On Samsung, the linker domain cannot execute ANYTHING outside `/system`.

### 8.2 apk_data_file is the Only Executable File Type

For targetSdk >= 29 apps, the ONLY file label that grants execute permission is `apk_data_file`. All binaries must be placed in `jniLibs/` \u2192 `nativeLibraryDir`. Any executable in `assets/` (which extracts to `app_data_file`) cannot be executed directly.

### 8.3 execute_no_trans > execute

For PRoot's ptrace use case, `execute_no_trans` is MORE valuable than standard `execute`, because it avoids the domain transition that triggers the ptrace cross-domain check. Samsung's security model has a gap: it restricts cross-domain ptrace but does not restrict same-domain execve+ptrace.

### 8.4 Force PROOT_LOADER with musl-linked Rootfs

Choosing Alpine Linux (musl libc) is not arbitrary. Every Alpine binary has INTERP=`/lib/ld-musl-aarch64.so.1`, which does not exist on Android. This FORCES PRoot to use PROOT_LOADER for every binary. This is the essential design feature that enables the SELinux bypass.

### 8.5 Static Binaries Are Essential for PROOT_LOADER

The loader binary must be a static ELF with no INTERP. If it had INTERP, the kernel would load the interpreter, potentially triggering another domain transition. A static binary loads directly with no interpreter lookup.

### 8.6 Build Fast, Test Often

30+ build iterations with an average cycle time of ~3 minutes allowed rapid elimination of hypotheses. Each build tested exactly one variable. Comprehensive error logging captured full PRoot stderr for precise diagnosis.

---

## 9. Code Signing and Distribution

DevEnv-PRoot is distributed as a self-signed APK. On Samsung Knox devices, self-signed APKs cannot be installed directly through the Settings app. The device must be switched to **Developer mode** with **USB debugging** enabled, and the APK must be installed via:

```
adb install DevEnv-PRoot-v0.2.0.apk
```

On fully locked Samsung devices (where Developer mode is unavailable or disabled by MDM), this approach does not work, and Termux's freeze-listed approach (via Samsung Knox customization) would be required.

---

## 10. Conclusion

The DevEnv-PRoot project demonstrates that a fully functional PRoot-based Linux container can run on a locked Samsung Knox Android 16 device through careful exploitation of SELinux permission gaps. The key insight \u2014 using PROOT_LOADER to avoid domain transitions and thus bypass Samsung's ptrace cross-domain check \u2014 is applicable to any Android app that needs to run foreign binaries within a ptrace-based sandbox on restricted devices.

At v0.2.0, the project has achieved:
- Working PRoot chain with Alpine Linux rootfs
- Interactive bash terminal via WebView
- Package management via apk (HTTPS)
- 6/6 passing setup steps
- Safe-area-aware UI
- Clean process lifecycle management

The project is currently at a stable stopping point for documentation and analysis.

---

## References

See [references.bib](../references.bib) for full citation details. Key references:

1. Termux termux-exec-package: [termux_exec_package]
2. Termux proot (bionic fork): [termux_proot]
3. PRoot official: [proot_me]
4. PRoot PROOT_LOADER source: [termux_loader_c]
5. UserLAnd: [userland]
6. Andronix: [andronix]
7. Samsung Knox DEFEX: [samsung_knox_defex]
8. Samsung RKP: [samsung_rkp]
9. Android SELinux Internals: [8ksec_selinux_ii], [8ksec_selinux_iv]
10. Alpine Linux: [alpine_linux]
11. Mozilla CA bundle: [mozilla_ca_bundle]
12. CSS env() function: [css_env]
13. Android WebView safe-area: [android_webview_safearea]
14. PRoot loader (loader.c): [termux_loader_c]
15. Kernel bug LP#1202161: [kernel_bug_1202161]
