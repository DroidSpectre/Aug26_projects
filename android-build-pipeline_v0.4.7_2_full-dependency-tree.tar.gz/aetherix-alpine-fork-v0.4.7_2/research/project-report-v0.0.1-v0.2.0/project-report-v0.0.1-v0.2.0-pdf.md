---
title: "Breaking the Samsung Knox SELinux Barrier"
subtitle: "DevEnv-PRoot Full Project Report (v0.0.1\u2013v0.2.0)"
author: "DevEnv-PRoot Project"
date: "July 22, 2026"
abstract: |
  This report documents the complete DevEnv-PRoot project across 30+ build iterations,
  culminating in the first documented successful execution of a fully functional
  PRoot-based Linux container on a locked Samsung Knox Android 16 device. The key
  innovation is executing PRoot directly from the app's native library directory
  (apk_data_file) via SELinux execute_no_trans, combined with a musl-linked Alpine
  rootfs that forces PROOT_LOADER usage for every binary. This avoids SELinux domain
  transitions entirely, bypassing Samsung Knox's ptrace cross-domain execve restriction.
  Terminal interface and HTTPS package management are operational at v0.2.0.
bibliography: "../references.bib"
csl: "../ieee.csl"
...

# Breaking the Samsung Knox SELinux Barrier: A Comprehensive Account of PRoot-based Linux Container Execution on Android 16

## 1. Introduction

Running a full Linux userspace environment on stock Android without root privileges has been a long-standing challenge, addressed primarily through PRoot [@proot_me], a ptrace-based user-space implementation of chroot, mount --bind, and binfmt_misc semantics. On Samsung devices with Knox security extensions [@samsung_knox_defex; @samsung_rkp], this challenge intensifies dramatically: aggressive SELinux policies combined with Samsung's DEFEX and RKP kernel modules block virtually every standard execution path.

This report documents the complete DevEnv-PRoot project across 30+ build iterations (v0.0.1\u2013v0.2.0) on a Samsung SM-S166V running Android 16 (API 36, kernel 5.15.189, Knox 3.x). At v0.2.0, the project has achieved a fully functional terminal and package manager running inside a PRoot sandbox on a locked Samsung device.

## 2. The SELinux Challenge

### 2.1 Three SELinux Blockers

Three distinct SELinux mechanisms block unprivileged binary execution on modern Samsung Knox devices:

**Blocker A: app_data_file execute_no_trans removed.** Since Android 10 (API 29), files in `/data/data/<pkg>/` (labeled `app_data_file`) cannot be executed by targetSdk >= 29 apps [@aosp_selinux]. The `execute_no_trans` permission that previously allowed direct execution of extracted binaries was removed.

**Blocker B: linker domain restricted by neverallow rule 76.** The SELinux rule `neverallow { domain -appdomain ... } { file_type -system_file -exec_type }:file execute;` prevents the linker domain (`u:r:linker:s0`) from executing any file outside `/system` [@8ksec_selinux_ii]. Samsung Knox amplifies this restriction beyond standard AOSP.

**Blocker C: Ptrace cross-domain execve blocked by Samsung DEFEX.** When a ptraced tracee calls execve and transitions to a different SELinux domain, Samsung's DEFEX module checks whether the tracer is allowed to ptrace the new domain. On Knox, this is denied for most cross-domain transitions [@samsung_knox_defex].

### 2.2 File Type Labels

- **app_data_file** (`/data/data/<pkg>/...`): read, write, open, getattr only (no execute for API >= 29)
- **apk_data_file** (`/data/app/<pkg>/lib/arm64/...`): read, write, open, getattr, AND execute_no_trans for appdomain
- **system_file** (`/system/bin/...`): full execute for all domains

### 2.3 The ptrace Cross-Domain Mechanism

When a tracer uses ptrace to monitor a tracee that calls execve, SELinux checks whether the tracee's domain transition is allowed by the rule `allow TRACER_DOMAIN TRACEE_NEW_DOMAIN:process ptrace;` [@8ksec_selinux_iv]. On Samsung Knox, DEFEX enhances this check to deny transitions that would be allowed on standard AOSP.

## 3. Failed Approaches (v0.0.10\u2013v0.0.22)

### 3.1 The linker Domain Trap

Thirteen builds attempted the standard Termux/UserLAnd approach of using `/system/bin/linker64` as an exec trampoline [@termux_exec_env]. Every build in the linker domain failed on Samsung Knox, culminating at v0.0.20 with the confirmed finding that the linker domain cannot execute ANYTHING outside `/system` on Samsung devices.

| Version | Error | Root Cause |
|---------|-------|------------|
| v0.0.10 | libtalloc.so.2 not found | glibc binary incompatible with bionic host |
| v0.0.11 | can't create temp dir | PROOT_TMP_DIR not set |
| v0.0.12 | /bin/sh not executable | TarExtractor didn't preserve exec bit |
| v0.0.13 | interpreter not found | PROOT_LOADER not active (seccomp mode) |
| v0.0.14 | interpreter not found | PROOT_LOADER in app_data_file (no exec) |
| v0.0.15\u2013v0.0.20 | Permission denied / Operation not permitted | Samsung Knox blocks linker domain exec of any non-system file |

### 3.2 The untrusted_app Pivot (v0.0.21\u2013v0.0.22)

v0.0.21 made the critical architectural decision: stop using linker64. Instead, PRoot's binary was placed directly in `nativeLibraryDir` as `libproot.so`. When executed from `apk_data_file`, the process stays in `u:r:untrusted_app:s0` via `execute_no_trans`.

- v0.0.21: Added `LD_PRELOAD=libdexec.so`. Failed because the shim interfered with PRoot's internal ptrace mechanism.
- v0.0.22: Removed LD_PRELOAD, targeted `/system/bin/sh`. Failed because this triggers untrusted_app \u2192 shell domain transition, blocked by Knox's ptrace cross-domain check.

## 4. The Breakthrough (v0.0.23 / v0.1.0)

### 4.1 The Key Insight

The target binary was changed from `/system/bin/sh` (Android shell, INTERP=`/system/bin/linker64`) to `/bin/sh` (Alpine BusyBox ash, INTERP=`/lib/ld-musl-aarch64.so.1`). Because the musl interpreter does not exist on the Android host, PRoot classifies every Alpine binary as "foreign" and routes execution through PROOT_LOADER [@termux_loader_c; @termux_proot_manual].

The loader (`libproot-loader.so`) executes from `apk_data_file` via `execute_no_trans` \u2014 no SELinux domain transition. Since no domain transition occurs, the ptrace cross-domain check is never triggered, and Samsung Knox does not block execution.

### 4.2 The Complete Execution Chain

```
1. App Java \u2192 exec /system/bin/sh (system_file, execute)
2.   \u2192 exec $NATIVE_DIR/libproot.so (apk_data_file, execute_no_trans, stays untrusted_app)
3.     \u2192 linker64 loads libproot.so + libtalloc.so.2 + libandroid-shmem.so
4.       \u2192 PRoot forks tracee (inherits untrusted_app)
5.         \u2192 tracee execve /bin/sh (Alpine musl, INTERP not on host)
6.           \u2192 PRoot: foreign binary \u2192 use PROOT_LOADER
7.           \u2192 tracee execve $NATIVE_DIR/libproot-loader.so (apk_data_file, execute_no_trans)
8.             \u2192 NO domain transition \u2192 NO ptrace cross-domain check \u2192 ALLOWED
9.             \u2192 PROOT_LOADER loads /bin/sh + ld-musl from rootfs
10.              \u2192 Shell runs inside Alpine rootfs
```

### 4.3 Why This Works

The architecture exploits a specific gap in Samsung's security model. `apk_data_file` must allow `execute_no_trans` for `untrusted_app` because every Android app needs to execute its native libraries. Samsung Knox cannot block this without breaking all apps. By ensuring ALL execve operations within the PRoot chain use `apk_data_file` \u2192 `execute_no_trans`, no domain transitions ever occur, and the ptrace cross-domain check is never invoked.

## 5. Package Manager Resolution (v0.1.1\u2013v0.1.6)

The libz.so.1 issue was resolved through a combination of symlink copy and LD_LIBRARY_PATH configuration. The HTTPS TLS verification issue required a Mozilla CA bundle (186KB, 119 certs) from curl.se [@mozilla_ca_bundle] and an HTTP bootstrap strategy to install the current `ca-certificates-bundle` from Alpine [@alpine_linux].

## 6. Terminal and Stability (v0.1.7\u2013v0.2.0)

### 6.1 Terminal

TerminalActivity.java [@android_processbuilder] launches bash inside PRoot via ProcessBuilder. Output is captured through BufferedReader and displayed in a WebView [@android_webview_safearea]. Three bugs were introduced in v0.1.8 (shell quoting, verify assertion, double banner) and progressively fixed through v0.2.0.

### 6.2 HTTPS Resolution

HTTPS apk operations became consistently reliable after `ca-certificates-bundle` upgrade from `20230506-r0` to `20250911-r0` (via `apk add`). The HTTP fallback was removed in v0.2.0.

## 7. Technical Architecture (v0.2.0)

### 7.1 Component Layout

| Asset | Location | Size | Function |
|-------|----------|------|----------|
| libproot.so | jniLibs/arm64-v8a/ | 231K | PRoot engine (dyamic, INTERP=linker64) |
| libproot-loader.so | jniLibs/arm64-v8a/ | 18K | PROOT_LOADER (static ELF) |
| libdexec.so | jniLibs/arm64-v8a/ | 53K | Exec shim (unused) |
| alpine-minirootfs.tar | assets/ | 8.6 MB | Alpine Linux 3.19.1 |
| ca-certificates.crt | assets/ | 186K | Mozilla CA bundle (119 certs) |

### 7.2 Launcher Environment

- `PROOT_NO_SECCOMP=1`: Forces pure ptrace; avoids kernel bug LP#1202161
- `PROOT_LINK2SYMLINK=1`: Converts hardlinks for Android f2fs compatibility
- `PROOT_LOADER=$NATIVE_DIR/libproot-loader.so`: Static ELF loader
- `SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt`: CA bundle path

## 8. Comparison with Existing Solutions

| Solution | Mechanism | PRoot Domain | Samsung Knox |
|----------|-----------|-------------|--------------|
| Termux [@termux_exec_package] | LD_PRELOAD + linker64 prefix | linker | Fails |
| UserLAnd [@userland] | PRoot + linker64 | linker | Fails |
| Andronix [@andronix] | Termux-based | linker (inherited) | Fails |
| proroot [@proroot] | LD_PRELOAD (no ptrace) | N/A | Unknown |
| DevEnv-PRoot | PRoot from nativeLibraryDir | untrusted_app (stays) | **Works** |

## 9. Conclusion

DevEnv-PRoot demonstrates the first documented successful execution of a fully functional PRoot-based Linux container on a locked Samsung Knox Android 16 device. At v0.2.0, the project provides an interactive bash terminal with working HTTPS package management, all through standard Android APIs available to any third-party application.

## References
