# Android SELinux Exec Bypass for PRoot-based Containers on Samsung Android 16

**Date:** 2026-07-21  
**Target Device:** Samsung (Android 16, kernel 5.15.189, Knox 3.x)  
**App Package:** `com.devenv.prootbuild`  
**PRoot Build:** Termux bionic-compiled, linker64-prefixed

---

## Executive Summary

Running PRoot-based Linux containers on Samsung Android 16 (targetSdk >= 29, no root) faces three SELinux/seccomp blockers. The critical one—`execve("/bin/sh"): Permission denied`—occurs because PRoot's tracee process inherits the `u:r:linker:s0` domain and SELinux denies `linker` domain execution of `app_data_file` binaries.

### Comparison of Exec Bypass Methods

| # | Method | SELinux Domain | Root? | Complexity | Android Versions | Likelihood |
|---|--------|---------------|-------|-----------|-----------------|------------|
| 1 | PROOT_LOADER in nativeLibraryDir | `untrusted_app` | No | Medium | 10-16 | **HIGH** |
| 2 | termux-exec LD_PRELOAD shim | `untrusted_app` | No | Medium | 10-16 | **HIGH** |
| 3 | Musl-static PRoot | `untrusted_app` | No | High | 10-16 | Medium |
| 4 | jniLibs binary exec | `untrusted_app` | No | Low | 10-16 | Medium (limited) |
| 5 | app_process / Zygote spawn | `zygote` → app domain | No | High | 10-16 | Low |
| 6 | run-as via ADB | `runas_app` | Debug only | Low | All | Low (no root) |
| 7 | Magisk module | `magisk` | **Yes** | Low | All | Not applicable |
| 8 | Samsung DEFEX bypass | N/A | **Yes** | Extreme | Samsung | Not applicable |

**Recommended approach:** Combine method 1 (PROOT_LOADER in nativeLibraryDir) with method 2 (termux-exec-style LD_PRELOAD) for a complete solution.

---

## Round 1: SELinux Analysis on Samsung Android 16

### 1.1 Domain Comparison: linker vs zygote vs untrusted_app

| Domain | Uses | exec app_data_file? | exec apk_data_file? | Notes |
|--------|------|---------------------|---------------------|-------|
| `u:r:linker:s0` | Dynamic linker (/system/bin/linker64) | **DENIED** | **DENIED** | Neverallow rule 76 prohibits non-appdomain domains from executing non-system files |
| `u:r:zygote:s0` | Zygote process | Allowed (for preloading) | Allowed | Has `apk_data_file:file execute` |
| `u:r:untrusted_app:s0` | Third-party apps (targetSdk >= 29) | **DENIED** | **ALLOWED** | `app_data_file:file execute_no_trans` removed since Android 10 |
| `u:r:untrusted_app_28:s0` | Apps targeting SDK 28 | **ALLOWED** (execute_no_trans) | **ALLOWED** | Grandfathered permission |
| `u:r:runas_app:s0` | run-as tool | **ALLOWED** | **ALLOWED** | Debug builds only |

### 1.2 The Neverallow Rule (Rule 76)

```
neverallow { domain -appdomain -dumpstate -shell -system_server -zygote }
    { file_type -system_file -exec_type }:file execute;
```

This prohibits any non-appdomain process from executing files outside `/system`. The `linker` domain is NOT in `appdomain`, so it cannot exec `app_data_file` or `apk_data_file`. This is the root cause of our error.

### 1.3 app_data_file vs apk_data_file

- **app_data_file**: Files in `/data/data/<pkg>/` created at runtime or extracted from `assets/`. Label: `u:object_r:app_data_file:s0:c<cat>,c<cat>,c<cat>,c<cat>`. For targetSdk >= 29: `{ read write open getattr }` but NOT `execute`.
- **apk_data_file**: Native libs extracted via `extractNativeLibs=true` from `jniLibs/`. Label: `u:object_r:apk_data_file:s0:c<cat>,c<cat>,c<cat>,c<cat>`. **Allows `execute`** for `appdomain` processes.

### 1.4 Samsung Knox Extensions

Samsung Knox adds three layers beyond AOSP SELinux:

1. **DEFEX (Defeat Exploit)**: Runtime monitoring of privileged processes. Prevents unauthorized changes to process privileges. Runs as a kernel module that hooks critical syscalls.
2. **RKP (Real-time Kernel Protection)**: Hypervisor-level kernel integrity. Prevents modification of kernel code/data structures. Runs in TrustZone.
3. **Knox Enforcement**: Additional neverallow rules beyond AOSP, stricter vendor policy.

On our target (kernel 5.15.189, Knox 3.x), DEFEX specifically monitors:
- `execve()` calls that cross domain boundaries
- `ptrace()` usage by non-system processes
- Changes to process credentials (setuid, setresuid)

### 1.5 Android 16 SELinux Changes

Based on the 8kSec Android SELinux Internals Part IV (June 2026):
- New kernel 6.6 structural changes (some devices; our kernel 5.15 keeps legacy paths)
- New domains added for newer SDK levels
- `untrusted_app_35` introduced for Android 16 (SDK 36) with same restrictions
- `app_data_file` exec remains prohibited for targetSdk >= 29
- Genfs versioning system for policy files
- Vendor policy split remains the primary attack surface

### 1.6 Samsung Knox DEFEX and PRoot

PRoot's `ptrace()` usage triggers DEFEX monitoring. On Samsung devices:
- DEFEX may add additional auditing for processes that use ptrace
- The `linker` domain using ptrace may be flagged
- `PROOT_NO_SECCOMP=1` worsens this by forcing full ptrace mode

**Key finding**: The `app_process` approach (method 5) avoids ptrace entirely, which may bypass some DEFEX monitoring.

---

## Round 2: Launch Mechanism Survey

### 2.1 Termux termux-exec

**Source**: `termux/termux-exec-package` — `libtermux-exec.so`

**Mechanism**:
1. `LD_PRELOAD=$PREFIX/lib/libtermux-exec.so` set for all shell sessions
2. Library intercepts `execve()`, `execvp()`, `execvpe()` libc wrappers
3. Translates `/path/to/binary` → `/system/bin/linker64 /absolute/path/to/binary`
4. Translates shebangs: `#!/bin/sh` → `#!/data/data/com.termux/files/usr/bin/sh`

**SELinux perspective**: The kernel sees only `linker64` being exec'd. `linker64` is a system file (`u:object_r:linker_exec:s0`), so exec is always allowed. The linker then loads the target binary via `dlopen()`/mmap—no second execve occurs.

**Why Termux works on our device**:
- Termux F-Droid uses targetSdk 28 → runs as `untrusted_app_28` → retains `app_data_file:file execute_no_trans`
- Even without that, termux-exec redirects all exec through linker64
- Bionic-compiled binaries use Android's native libc (no glibc dependency)
- Termux's PRoot fork includes Android-specific patches

**Our problem**: We use linker64 prefix (`/system/bin/linker64 $PROOT_DIR/proot-arm64`) which works for launching PRoot itself, but PRoot's *children* execute via standard `execve()`. termux-exec would fix this if we LD_PRELOAD it for the entire PRoot process tree.

### 2.2 UserLAnd

**Architecture**:
- Uses `PRoot` (their own fork) with `PROOT_LOADER` env var
- Custom loader binary placed in nativeLibraryDir
- `libdisableselinux.so`: LD_PRELOAD library that stubs SELinux syscalls (`selinux_android_setcontext`, etc.)
- Assets include Ubuntu/Debian rootfs tarballs

**Key differences from our approach**:
1. UserLAnd's PROOT_LOADER binary is extracted via jniLibs → gets `apk_data_file` → executable
2. Their `libdisableselinux.so` prevents SELinux domain transitions that might restrict child processes
3. The loader is a static ELF that maps target binaries without execve

**Limitations**: UserLAnd hasn't been actively updated; may not work on Android 16.

### 2.3 Frida

**Architecture**:
- `frida-server` runs as root, spawns `re.frida.helper` via `app_process`
- Helper process initially runs as `u:r:shell:s0` (domain transition from entrypoint)
- Uses `/system/bin/app_process64` to create a minimal Android runtime
- Injects frida-agent into target via ptrace

**SELinux domain flow**:
```
frida-server (u:r:magisk:s0)
  → app_process64 (u:r:zygote:s0)
  → re.frida.helper (u:r:shell:s0)
  → ptrace attach to target
```

**Lesson for us**: `app_process` starts in zygote domain, then transitions. But the child is a Java process, not a native binary. Not directly useful for running PRoot.

### 2.4 adb shell → run-as

**Mechanism**:
- `run-as com.devenv.prootbuild` transitions to `u:r:runas_app:s0`
- This domain has `app_data_file:file execute_no_trans` permission
- However, `run-as` only works on debuggable apps or userdebug/eng builds

**Not applicable** for production (non-debug, non-rooted) devices.

### 2.5 Magisk / KernelSU

Root-based approaches. Magisk injects `u:r:magisk:s0` domain with broad permissions. Not applicable without root.

---

## Round 3: app_process Deep Analysis

### 3.1 Source & Mechanism

**Binary**: `/system/bin/app_process64` (symlink: `/system/bin/app_process`)
**Source**: `frameworks/base/cmds/app_process/app_main.cpp`

**Invocation syntax**:
```
app_process [java-options] <parent-dir> [--zygote|--application]
    [--nice-name=<name>] <class-name> [args...]
```

**Key parameters**:
- `-Djava.class.path=<path>` — Java classpath
- `<parent-dir>` — ignored/unused (typically `/system/bin`)
- `--nice-name=<name>` — sets process name (via argv[0] overwrite)
- `--zygote` / `--application` — launch mode
- `<class-name>` — Java class with `main()` to execute

### 3.2 What app_process Does NOT Do

- It does NOT exec native binaries
- It does NOT load ELF executables
- It is a Java runtime launcher, not a generic ELF loader

### 3.3 What app_process CAN Do for Us

Frida uses `app_process` to spawn a minimal Java process (the helper), then uses that process's ptrace capabilities. We could potentially:

1. Use `app_process` to spawn a process that runs in an app domain (not linker domain)
2. From that process, exec PRoot (now running in a domain that CAN exec app_data_file)

**Limitation**: Cannot pass a native binary as the class name. We'd need a Java wrapper that uses `Runtime.exec()` or JNI to launch PRoot.

### 3.4 app_process SELinux Implications

- `app_process64` has entrypoint `u:object_r:app_process_exec:s0`
- When exec'd by init, it transitions to `u:r:zygote:s0`
- When run from shell (non-init), the caller's domain is supposed to transition, but the precise behavior depends on policy

**Test**: Running `app_process` from our app context would depend on whether `untrusted_app` has `{ entrypoint }` or `{ execute }` on `app_process_exec`.

### 3.5 Android Compatibility

Works on Android 5.0–16. Present on all devices. The `--nice-name` option has been stable since early AOSP.

---

## Round 4: Alternative Approaches (Feasibility Assessment)

### 4.1 PROOT_LOADER in nativeLibraryDir (RECOMMENDED)

**Feasibility: HIGH**

**How it works**:
1. The PRoot loader (`loader.elf`) is placed in `jniLibs/arm64-v8a/` as `libproot-loader.so`
2. Set `android:extractNativeLibs="true"` in AndroidManifest.xml
3. `context.applicationInfo.nativeLibraryDir` returns the path (e.g., `/data/app/com.devenv.prootbuild-xyz/lib/arm64`)
4. Set `PROOT_LOADER=$nativeLibraryDir/libproot-loader.so`
5. PRoot finds this loader, execs it, and the loader maps target ELFs without further execve calls

**Why it works**: Files in nativeLibraryDir get `apk_data_file` SELinux type, which is executable by appdomain processes (including `untrusted_app` and its children).

**Implementation**:
- Build the PRoot loader: `make -C src loader.elf` → rename to `libproot-loader.so`
- The loader must be compiled for bionic (Android NDK) to avoid linker issues
- Alternatively, compile as static musl binary and place in nativeLibraryDir

### 4.2 termux-exec LD_PRELOAD Port (RECOMMENDED)

**Feasibility: HIGH**

**How it works**:
1. Port `libtermux-exec.so` from the termux-exec package
2. Compile for bionic (Android NDK) as `libdexec.so`
3. Set `LD_PRELOAD=$PROOT_DIR/lib/libdexec.so` when launching PRoot
4. The shim intercepts all execve() calls from PRoot and its children
5. Redirects `/bin/sh` → `/system/bin/linker64 /path/to/rootfs/bin/sh`

**Key changes needed**:
- Change hardcoded `PREFIX` from `/data/data/com.termux/files/usr` to our app's rootfs path
- The shebang rewriting must map Linux paths to our actual rootfs paths

**Why it works**: Same mechanism as Termux—kernel sees only linker64 being exec'd.

### 4.3 Musl-static PRoot

**Feasibility: MEDIUM**

**Build process**:
1. Toolchain: `aarch64-linux-musl-cross` from musl.cc or cross-tools/musl-cross
2. Build PRoot with `LDFLAGS="-static"` and `CC=aarch64-linux-musl-gcc`
3. No libtalloc dependency (statically linked)
4. No libandroid-shmem needed (musl has built-in shared memory)

**Expected size**: 800KB–2MB (larger than dynamic 200KB, but self-contained)

**Advantage**: No LD_LIBRARY_PATH or separate library files needed. Single binary.

**Disadvantage**: Still faces the same SELinux exec issue for child processes. PROOT_LOADER still needed.

### 4.4 Patching Termux PRoot Path Constants

**Feasibility: MEDIUM**

The Termux PRoot binary has hardcoded `/data/data/com.termux/files/usr` strings. These can be found with:
```bash
strings proot-arm64 | grep com.termux
```

**Known offsets** (v0.0.17 binary analysis):
- Various path strings at offsets throughout the binary
- String length constraints: replacement must be <= original length

**Our app path**: `/data/data/com.devenv.prootbuild/files/usr` — this is 43 chars vs Termux's 38 chars for `/data/data/com.termux/files/usr`. The Termux path is a substring of ours, so we need to ensure the target buffer is large enough, OR use a path that fits (e.g., `/data/data/com.devenv.prootbuild/u` = 36 chars, with symlink tricks).

### 4.5 LD_PRELOAD readlink("/proc/self/exe") Shim

**Feasibility: LOW-MEDIUM**

PRoot's loader discovery uses `readlink("/proc/self/exe", ...)` to find the running binary's directory. If we intercept this to return our proot path instead of linker64's path, PRoot would search for the loader in our app directory.

**Problem**: This only helps if the loader is findable—doesn't fix the exec permission issue.

**Implementation**:
```c
// libreadlink_shim.c
ssize_t readlink(const char *path, char *buf, size_t bufsiz) {
    static ssize_t (*real_readlink)(const char *, char *, size_t) = NULL;
    if (!real_readlink) real_readlink = dlsym(RTLD_NEXT, "readlink");
    
    if (strcmp(path, "/proc/self/exe") == 0) {
        return snprintf(buf, bufsiz, "/data/data/com.devenv.prootbuild/files/proot-arm64");
    }
    return real_readlink(path, buf, bufsiz);
}
```

### 4.6 app_process Java Wrapper

**Feasibility: LOW**

Create a minimal Java class that does:
```java
public class ProotLauncher {
    public static void main(String[] args) {
        Runtime.getRuntime().exec("/data/data/com.devenv.prootbuild/files/proot-arm64 ...");
    }
}
```

Then invoke: `app_process -Djava.class.path=/path/to/dex /system/bin --nice-name=proot ProotLauncher`

**Problem**: The app_process execs from our app's process, staying in `untrusted_app` domain. The child process inherits this domain. We're back to the same SELinux issue for child execs.

### 4.7 Combined Approach (ULTIMATE RECOMMENDATION)

**Feasibility: HIGHEST**

1. **PRoot binary**: Run via `/system/bin/linker64 $PROOT_DIR/proot-arm64` (already working)
2. **PROOT_LOADER**: Build loader, place in jniLibs → nativeLibraryDir, set `PROOT_LOADER=$nativeDir/libproot-loader.so`
3. **LD_PRELOAD**: Port termux-exec, preload for all PRoot children. Set `LD_PRELOAD=$PROOT_DIR/lib/libdexec.so`
4. **SELinux context**: Ensure all rootfs binaries are labeled appropriately or proxied through linker64
5. **PROOT_NO_SECCOMP** = 1 (already set — avoids seccomp ENOSYS on chmod/chdir)
6. **PROOT_TMP_DIR**: Set to a writable directory in our app data

---

## Decision Tree

```
Start: execve("/bin/sh"): Permission denied
│
├─ Is device rooted?
│   ├─ YES → Use Magisk module (app-data-file-exec) to inject SELinux allow rule
│   └─ NO  → Continue below
│
├─ Can we set targetSdk < 29?
│   ├─ YES → Use legacy exec permission (untrusted_app_28), simplest fix
│   └─ NO  → Continue below
│
├─ Does PROOT_LOADER point to executable binary?
│   ├─ NO → Move loader to nativeLibraryDir (extractNativeLibs + jniLibs)
│   └─ YES → Continue below
│
├─ Is LD_PRELOAD (termux-exec shim) active for PRoot children?
│   ├─ NO → Port termux-exec, preload for all sessions
│   └─ YES → Continue below
│
├─ Are rootfs binaries bionic-compiled?
│   ├─ NO → Rootfs uses glibc → may have additional compatibility issues
│   └─ YES → Continue below
│
└─ Still failing?
    ├─ Samsung DEFEX blocking ptrace → Try app_process wrapper to avoid ptrace
    ├─ seccomp blocking chmod/chdir → Already using PROOT_NO_SECCOMP=1
    └─ Unknown → Enable PRoot verbose (-v 5), check dmesg for AVC denials
```

---

## Appendix A: Key Environment Variables

| Variable | Purpose | Set by | Notes |
|----------|---------|--------|-------|
| `PROOT_LOADER` | Path to PRoot's custom ELF loader | App | Must point to executable binary (apk_data_file) |
| `PROOT_LOADER_32` | 32-bit loader path | App | For 32-on-64 scenarios |
| `PROOT_TMP_DIR` | Writable directory for tmp files | App | PRoot creates temp loader files here |
| `PROOT_NO_SECCOMP` | Disable seccomp acceleration | App | Set to 1 to avoid seccomp ENOSYS |
| `LD_LIBRARY_PATH` | Library search path | App | Point to PRoot dependency dir |
| `LD_PRELOAD` | Preload library for exec interception | App | termux-exec shim (`libdexec.so`) |
| `PROOT_UNBUNDLE_LOADER` | Alternative loader search | PRoot build | Compile-time option |

## Appendix B: SELinux Contexts Encountered

| Context | Type | When Seen |
|---------|------|-----------|
| `u:r:linker:s0` | Process | Running PRoot via linker64 prefix |
| `u:r:untrusted_app:s0` | Process | Our app's main process |
| `u:r:zygote:s0` | Process | Zygote daemon |
| `u:r:runas_app:s0` | Process | run-as tool |
| `u:r:shell:s0` | Process | ADB shell |
| `u:r:magisk:s0` | Process | Magisk root shell |
| `u:object_r:app_data_file:s0` | File | Files extracted from assets/ |
| `u:object_r:apk_data_file:s0` | File | Files from jniLibs (nativeLibraryDir) |
| `u:object_r:linker_exec:s0` | File | /system/bin/linker64 |
| `u:object_r:app_process_exec:s0` | File | /system/bin/app_process64 |

## Appendix C: References

1. [Termux termux-exec package](https://github.com/termux/termux-exec-package)
2. [PRoot source](https://github.com/proot-me/proot)
3. [UserLAnd](https://github.com/CypherpunkArmory/UserLAnd)
4. [Android SELinux Internals Part II (8kSec)](https://8ksec.io/android-selinux-internals-part-ii/)
5. [Android SELinux Internals Part IV (8kSec)](https://8ksec.io/android-selinux-internals-part-iv/)
6. [Android SELinux concepts (AOSP)](https://source.android.com/docs/security/features/selinux/concepts)
7. [app_data_file exec Magisk module](https://github.com/okyes/app-data-file-exec)
8. [Samsung Knox DEFEX](https://www.samsungknox.com/en/blog/this-is-protection-samsung-knox)
9. [Samsung RKP documentation](https://docs.samsungknox.com/admin/fundamentals/whitepaper/samsung-knox-mobile-security/system-security/real-time-kernel-protection/)
10. [Musl cross toolchains](https://musl.cc/)
11. [PRoot static build for AArch64](https://proot-me.github.io/blog/alpine-aarch64)
12. [proroot — zero-ptrace PRoot alternative](https://github.com/coderredlab/proroot)
13. [app_process source (AOSP)](https://android.googlesource.com/platform/frameworks/base/+/master/cmds/app_process/app_main.cpp)
