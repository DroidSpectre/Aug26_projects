# Running Linux on Android Without Root: Deep Research Comparison

**Generated:** 2026-07-21  
**Scope:** Termux + proot-distro, UserLAnd, LinuxDeploy, Andronix, AnLinux, Android Virtualization Framework  
**Target:** DevEnv-PRoot — a self-contained PRoot + Alpine environment manager as a single APK

---

## 1. Executive Summary

Five major approaches exist for running a full Linux userspace on Android without root. All rely on **PRoot** (a `ptrace`-based, user-space `chroot`/`mount --bind`/`binfmt_misc` implementation) — except LinuxDeploy's chroot mode (requires root) and Android 16's AVF (hardware VM).

| Approach | Status 2026 | Best For |
|---|---|---|
| **Termux + proot-distro** | **Active** — proot-distro 5.1.1 (May 2026) | Users who want a maintained, CLI-driven, offline-capable Linux container |
| **UserLAnd** | **Stalled** — v2.8.3 (Oct 2021, 995+ open issues) | Users needing a wizard UI and accepting abandonment risk |
| **LinuxDeploy** | **Stalled** — UI v2.5.3 (2020), CLI still functional | Rooted users wanting near-native chroot performance |
| **Andronix** | **Active** — v8.0 (2025), closed-source app | Beginners wanting guided setup with multiple DEs and Modded OS |
| **AnLinux** | **Abandoned** — v6.72 (2020) | Historical reference; simpler copy-paste workflow |
| **AVF (Android 16)** | **Experimental** — Pixel-only, canary | Future-proof native VM with GPU acceleration |

---

## 2. PRoot: The Core Technology

PRoot uses `ptrace(2)` to intercept every syscall made by guest processes, translating file paths and faking UID/GID. This enables:
- `chroot` without root (the guest rootfs is any directory)
- `mount --bind` without root (path translation on the fly)
- `binfmt_misc` via QEMU user-mode (`-q` flag) for cross-architecture

**Key PRoot flags used across all approaches:**

| Flag | Purpose | Used By |
|---|---|---|
| `-r <path>` | Set guest rootfs | All |
| `-0` | Fake root identity (return UID 0) | All |
| `-b <host>:<guest>` | Bind mount host path into guest | All |
| `--link2symlink` | Convert hardlinks to symlinks (Android FS compat) | Termux, Andronix |
| `--kill-on-exit` | Kill child processes when PRoot exits | Termux, Andronix |
| `--sysvipc` | Emulate SysV IPC | Termux |
| `-L` | Fix lstat for dpkg symlink warnings | Termux |
| `--kernel-release=<str>` | Fake `uname` release string | Termux |
| `--change-id=<uid>:<gid>` | Map host UID to guest UID | Termux |

---

## 3. Project Deep Dives

### 3.1 Termux + proot-distro (The Reference Implementation)

**Architecture:** Three-layer stack: `termux-app` (Android terminal) → `termux-packages` (build system) → `proot-distro` (Python container manager).

**PRoot Invocation (from proot-distro v5.x):**
```
proot --kill-on-exit --link2symlink --sysvipc \
  --kernel-release="\Linux\localhost\6.17.0-PRoot-Distro\#1 SMP PREEMPT_DYNAMIC..." \
  -L --change-id=0:0 --rootfs=<container_rootfs> --cwd=/root \
  --bind=/dev --bind=/proc --bind=/sys \
  --bind=/dev/urandom:/dev/random --bind=/proc/self/fd:/dev/fd \
  --bind=/storage --bind=/system --bind=/apex --bind=/vendor \
  --bind=<fake_proc_files> \
  /usr/bin/env -i HOME=/root LANG=C.UTF-8 PATH=... TERM=$TERM /bin/bash -l
```

**Key Innovations:**
1. **termux-exec LD_PRELOAD** — Intercepts `exec*()` calls to translate Linux paths (e.g., `/bin/bash` → `$PREFIX/bin/bash`) and bypass Android 10+ W^X restrictions via `/system/bin/linker64`
2. **OCI-native container management** — Pulls Docker images *without* Docker daemon; applies OCI layers with whiteout semantics
3. **Fake sysdata subsystem** — Creates synthetic `/proc/loadavg`, `/proc/stat`, `/proc/uptime`, `/proc/version`, `/proc/vmstat` since Android restricts access to real `/proc`
4. **Session registry via flock** — Uses POSIX file locks on session files (more robust than PID tracking)
5. **Clean environment** — Host environment explicitly NOT passed into guest; builds environment from scratch

**Filesystem Layout:**
```
/data/data/com.termux/files/usr/var/lib/proot-distro/
  containers/<name>/
    rootfs/          # Extracted Linux distribution
    manifest.json    # OCI image manifest
    .l2s/            # link2symlink backing store
  sessions/          # Active session registry (flock files)
  cache/
    oci_layers/      # Cached Docker layer blobs
    oci_manifests/   # Cached image manifests
```

**Linker/Exec Chain:**
```
Terminal → Runtime.exec() → exec*() → termux-exec(LD_PRELOAD)
  → path translation (Linux → Termux paths)
  → system_linker_exec check (Android 10+ W^X bypass)
  → execve("/system/bin/linker64", [..., "$PREFIX/bin/program", ...])
```

**Phantom Process Killer Handling:**
- `--kill-on-exit` enabled by default
- Session tracking via flock (auto-released on process death)
- Android 14+: Developer Options → "Disable child process restrictions"
- Android 12-13: `adb shell settings put global settings_enable_monitor_phantom_procs false`

**Performance:** UNIXBench shows **44% lower score** inside proot-distro vs native. I/O-heavy tasks (tar extract, app launch) most affected. CPU-bound tasks near-native. Custom minimal launchers (`mpd`) can reduce app launch from ~3-5s to ~1s.

---

### 3.2 UserLAnd (The Stalled Wizard)

**Architecture:** Kotlin app with sealed-class FSM (Finite State Machine) → `BusyboxExecutor` → `execInProot.sh` script → PRoot.

**PRoot Invocation:**
```bash
unset LD_PRELOAD
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
PROOT_TMP_DIR=$ROOTFS_PATH/support/ \
PROOT_LOADER=$LIB_PATH/loader \
PROOT_LOADER_32=$LIB_PATH/loader32 \
$PROOT -r $ROOTFS_PATH -v $PROOT_DEBUG_LEVEL $PROOT_ARGS \
  -b /sys -b /dev -b /proc -b /data -b /mnt \
  -b /system -b /apex -b /linkerconfig/ld.config.txt \
  -b /:/host-rootfs \
  -b $ROOTFS_PATH/support/:/support \
  -b $ROOTFS_PATH/support/nosudo:/usr/local/bin/sudo \
  -b $ROOTFS_PATH/support/userland_profile.sh:/etc/profile.d/userland_profile.sh \
  -b $ROOTFS_PATH/support/ld.so.preload:/etc/ld.so.preload \
  $EXTRA_BINDINGS $@
```

**Key Innovations:**
1. **Custom PROOT_LOADER / PROOT_LOADER_32** — Separate ELF loaders for Android 10+ compatibility (`.a10` suffixed variants)
2. **libdisableselinux.so** — LD_PRELOAD shim that stubs SELinux syscalls
3. **nosudo wrapper** — Custom sudo replacement using `su` (since sudo needs setuid)
4. **State machine architecture** — Sealed-class FSM with ~30 states for robust startup flow
5. **Apps meta-package system** — One-click install scripts fetched from GitHub

**Terminal Integration:** SSH via ConnectBot (port 2022), VNC via bVNC Free (port 5951), XSDL via XServer XSDL. **No embedded terminal.**

**Filesystem Layout:**
```
/data/data/tech.ula/files/
  support/              # PRoot binary, loaders, scripts (busybox, execInProot.sh, etc.)
  <distribution>/       # Rootfs tarballs and assets
  <filesystem_id>/      # Extracted rootfs (numeric ID, tied to Room DB)
    support/            # Copied distribution-specific support files
    [rootfs content]    # Full Linux filesystem
  staging/              # Temporary extraction directory
  apps/                 # Downloaded app scripts
```

**Status:** Last release October 2021. 995+ open issues. Community reports 2-10x slower than Termux proot setups due to more PRoot extensions enabled for multi-user emulation.

---

### 3.3 LinuxDeploy (Root-Chroot with PRoot Legacy)

**Architecture:** Java Android UI → `cli.sh` (1265-line Bash engine) → Plugin component system (50+ components).

**PRoot vs Chroot:**
- **Default METHOD:** `chroot` (requires root, near-native performance)
- **PRoot mode:** Removed from UI in v2.5.0 (2019) but still functional in CLI
- PRoot flags: `-r "${CHROOT_DIR}" -w / ${mounts} ${emulator} -0 -l -e`

**Key Innovations:**
1. **Image-based deployment** — Creates sparse loopback images (`dd seek` + `mke2fs`) for container rootfs
2. **Component dependency system** — 50+ components with `deploy.conf` (metadata + `DEPENDS`), resolved recursively
3. **Cross-arch via binfmt_misc** — Registers QEMU user-mode emulators with kernel's binfmt_misc
4. **unchroot escape** — Script inside container that escapes chroot via `/proc/1/cwd`
5. **Android UID/GID mapping** — `aid_` groups mapped into `/etc/group` and `/etc/passwd`
6. **Framebuffer + surfaceflinger stop** — Can freeze Android UI to reclaim GPU for desktop

**Targets:** file (loopback), directory, partition, RAM, custom  
**FS types:** ext2, ext3, ext4  
**Desktop:** XTerm, LXDE, Xfce, MATE via VNC, X11, or framebuffer

**Terminal Integration:** `xterm.js` via WebSocket → `busybox telnetd` → shell. Also SSH and VNC.

**Status:** Android UI unmaintained since 2020. CLI still functional. Fork "Linux Deploy Pro" exists with updated distro configs.

---

### 3.4 Andronix (The Commercial Product)

**Architecture:** Closed-source Kotlin app (MVVM) → generates shell scripts → Termux → PRoot. App is a command generator; all actual installation runs via scripts in Termux.

**PRoot Invocation (from generated start script):**
```bash
unset LD_PRELOAD
command="proot"
command+=" --kill-on-exit --link2symlink -0 -r $folder -w /root"
command+=" -b /dev -b /proc -b /sys -b /data -b /sdcard"
command+=" -b ubuntu22-fs/root:/dev/shm"
command+=" -b /proc/self/fd/2:/dev/stderr"
command+=" -b /proc/self/fd/1:/dev/stdout"
command+=" -b /proc/self/fd/0:/dev/stdin"
command+=" -b /dev/urandom:/dev/random"
command+=" -b /proc/self/fd:/dev/fd"
# Fake /proc files
command+=" -b ${cur}/${folder}/proc/fakethings/stat:/proc/stat"
command+=" -b ${cur}/${folder}/proc/fakethings/vmstat:/proc/vmstat"
command+=" -b ${cur}/${folder}/proc/fakethings/version:/proc/version"
command+=" -b /sdcard"
command+=" /usr/bin/env -i HOME=/root PATH=... TERM=$TERM LANG=C.UTF-8 /bin/bash --login"
```

**Fake /proc Infrastructure (unique to Andronix):**
Created under `<distro>-fs/proc/fakethings/`:
- `/proc/stat` — Hardcoded 8-CPU stats
- `/proc/version` — `"Linux version 5.4.0-faked (andronix@fakeandroid) (gcc 4.9.x)"`
- `/proc/vmstat` — Fake memory management stats

**Key Innovations:**
1. **Modded OS** — Pre-configured, themed, optimized distros (paid, $5-$15 one-time)
2. **Fake /proc filesystem** — Better compatibility for `ps`, `htop`, Java apps
3. **Custom bind mount system** — `<distro>-binds/` directory where users can add shell scripts to inject bind mounts
4. **Multi-distro coexistence** — Each in its own directory with independent start script
5. **Cloud command sync** — Cross-device sync of saved commands
6. **PulseAudio sound support** — Network audio from container to Android

**Distros:** 8 free (Ubuntu, Debian, Manjaro, Fedora, Kali, Void, Alpine, Arch) + 4 Modded OS paid  
**Desktop environments:** XFCE, LXDE, LXQt, KDE (Modded), i3, Awesome, Openbox

**Filesystem Layout:**
```
/data/data/com.termux/files/home/
  start-ubuntu22.sh     # Generated PRoot launch script
  ubuntu22-fs/          # Full rootfs
    root/
    etc/
    proc/fakethings/    # Fake /proc files
  ubuntu22-binds/       # Custom bind mount scripts
  ubuntu22-rootfs.tar.gz (deleted after extraction)
```

**Status:** Actively developed (v8.0 2025). 2.5M+ downloads. Freemium model ($140K+ revenue claimed).

---

### 3.5 AnLinux (The Abandoned Guide App)

AnLinux is the simplest of the group — a **guide app** that copies commands to the clipboard for pasting into Termux. It provides no embedded terminal, no PRoot management, and no UI beyond command generation.

**Supported Distros:** 14+ (Ubuntu, Debian, Kali, Parrot, Fedora, CentOS, openSUSE, Arch, Alpine, Void, more)  
**Status:** Last GitHub commit 2020. Still on Play Store but unmaintained.

---

### 3.6 Android Virtualization Framework (AVF) — The Future

Android 16 introduces a native Linux terminal using **AVF** (Android Virtualization Framework) with:
- **crosvm** (Rust VMM) + **pKVM** hypervisor
- Hardware VM (not PRoot) — near-native performance
- GPU acceleration via VirtIO-GPU
- Debian-based OS image downloaded from Google servers
- WebView-based terminal (ttyd over HTTP)

**Current Limitations:**
- Pixel 6+ only (Android 16 Developer Preview / Canary builds)
- Experimental — requires manual `vm_config.json` setup
- No OEM adoption yet (Samsung, Xiaomi, etc.)
- Docker requires custom guest kernel rebuild
- Clunky WebView terminal (reported keyboard issues)

**Implications for DevEnv-PRoot:** AVF may eventually make PRoot approaches obsolete on supported devices, but will take years to reach mass adoption. PRoot remains the only cross-device, cross-OEM solution.

---

## 4. Comparative Analysis

### 4.1 Architecture Comparison

| Dimension | Termux+proot-distro | UserLAnd | LinuxDeploy | Andronix |
|---|---|---|---|---|
| **App type** | Terminal emulator + container manager | Container manager with wizard | Container manager with settings | Command generator + script runner |
| **Core language** | Python (proot-distro), Java (app) | Kotlin | Java + Bash | Kotlin (closed source) |
| **Underlying platform** | Termux | Own environment (forks Termux terminal) | Own environment | Termux |
| **PRoot variant** | Termux fork (github.com/termux/proot) | Custom with PROOT_LOADER | Upstream (removed from UI) | Standard proot from Termux |
| **Terminal** | Built-in (VT100/xterm) | External (SSH/VNC only) | Web/xterm.js + SSH + VNC | External (Termux + VNC) |
| **State management** | Session flock files | Sealed class FSM | Component dependency graph | Script-based (no state) |
| **Database** | None (filesystem-based) | Room (SQLite) | SharedPreferences + flat files | Firebase + local |

### 4.2 PRoot Command Features Matrix

| Feature | Termux | UserLAnd | Andronix |
|---|---|---|---|
| `--kill-on-exit` | Yes | No (in scripts) | Yes |
| `--link2symlink` | Yes | No (in ext. args) | Yes |
| `--sysvipc` | Yes | No | No |
| `--kernel-release` | Yes (fabricated) | No | No |
| `-L` (fix lstat) | Yes | No | No |
| `--change-id` | Yes | No (uses -0) | No (uses -0) |
| `PROOT_LOADER` | No (uses termux-exec LD_PRELOAD) | Yes | No |
| Fake /proc stat | Yes | Dynamic (script) | Yes (static files) |
| Fake /proc version | Yes | Dynamic (script) | Yes (static files) |
| Fake SELinux | Yes (empty bind) | Yes (libdisableselinux.so) | Implicit |
| Custom bind mounts | `--bind` flag | `EXTRA_BINDINGS` env var | `<distro>-binds/` directory |
| Cross-arch QEMU | Yes | No | No |

### 4.3 Filesystem Layout Comparison

| Component | Termux | UserLAnd | Andronix |
|---|---|---|---|
| **PRoot binary** | `$PREFIX/bin/proot` | `$supportDir/proot` | `$PREFIX/bin/proot` (from Termux) |
| **Rootfs** | `containers/<name>/rootfs/` | `<filesystem_id>/` | `<distro>-fs/` |
| **Support scripts** | N/A (handled by proot-distro) | `support/` directory | `$PREFIX/bin/` (from Termux) |
| **Config** | `manifest.json` in container dir | Room DB + `userland_profile.sh` | `.bash_profile` inside rootfs |
| **Cache** | `cache/oci_layers/` + `oci_manifests/` | App cache (managed by Android) | Termux cache + GitHub downloads |
| **Sessions** | `sessions/` (flock files) | `ServerService` (foreground service) | Termux processes (no tracking) |

### 4.4 Phantom Process Killer Solutions

| Android Version | Termux | UserLAnd | Andronix | DevEnv-PRoot (Proposed) |
|---|---|---|---|---|
| **14+** | Settings toggle "Disable child process restrictions" | Not documented | Documented in guides | **In-app guidance** + auto-settings check |
| **12-13** | ADB: `settings put global settings_enable_monitor_phantom_procs false` | Not documented | ADB guide provided | **ADB command helper** in app |
| **12** | Also: `device_config put activity_manager max_phantom_processes 2147483647` | Not documented | ADB guide provided | **Auto-detect** version + show correct command |
| **11 and below** | Not affected | Not affected | Not affected | Not affected |

### 4.5 Linker/Exec Chain Approaches

| Project | Problem | Solution | Risk |
|---|---|---|---|
| **Termux** | Android 10+ W^X blocks exec of app data binaries | `termux-exec` LD_PRELOAD intercepts exec*(), rewrites argv to use `/system/bin/linker64` as interpreter | Depends on LD_PRELOAD; termux-exec version compatibility |
| **UserLAnd** | Same W^X restriction | `PROOT_LOADER` / `PROOT_LOADER_32` custom ELF loaders (with `.a10` variants) | Loaders may not work on all Android versions; `.a10` variants unmaintained since 2021 |
| **LinuxDeploy** | Avoids the issue | `targetSdkVersion 28` (Android 9 API) — bypasses scoped storage AND W^X restrictions | Cannot target modern API; Play Store may reject (August 2026 requirement: targetSdk 35+) |
| **Andronix** | Defers to Termux | Relies on Termux's termux-exec LD_PRELOAD | Version coupling; user must keep Termux updated |
| **DevEnv-PRoot** | Our `linker64` fix | Explicitly invokes `/system/bin/linker64 $PROOT_DIR/proot-arm64` in launcher script | Requires `/system/bin/linker64` — may fail on some OEMs |

---

## 5. Performance Data

### UNIXBench Score (from termux-packages discussion #29944)

| Environment | Score |
|---|---|
| **Native (outside proot)** | ~12,000 |
| **Inside proot-distro** | ~6,700 (44% lower) |
| **Docker/chroot** | ~12,000 (near-native) |

### I/O Performance (tar extract benchmark from proroot README)

| Operation | Native | PRoot | Slowdown |
|---|---|---|---|
| **tar extract (linux kernel)** | 6.7s | 13.5s | **2.0x** |
| **tar create** | 2.8s | 14.4s | **5.1x** |

### Application Launch Time (from termux-desktop issue #282)

| Launcher | Galaxy S26 Ultra | Mid-range device |
|---|---|---|
| **pdrun** (proot-distro login) | ~3s | ~4-5s |
| **mpd** (minimal proot) | ~1s | ~1s |

**Key takeaway:** Most proot overhead comes from excessive bind mounts and the shell-based proot-distro wrapper, not from PRoot itself. Creating a **minimal launcher with trimmed bind mounts** can dramatically improve startup time.

---

## 6. Known Issues & Mitigations

### 6.1 Phantom Process Killer (Android 12+)
- **Symptom:** `[Process completed (signal 9)]` — random session death
- **Root cause:** Android ActivityManager kills background (phantom) processes exceeding 32
- **Mitigation per version:**
  - **Android 14+:** Settings → Developer Options → "Disable child process restrictions" (persistent toggle)
  - **Android 12-13:** `adb shell settings put global settings_enable_monitor_phantom_procs false`
  - **All versions:** `adb shell device_config put activity_manager max_phantom_processes 2147483647`
- **Caveat:** Google Play Services (`gms`) may reset `device_config` values 3-4 minutes after boot. Disable sync: `adb shell device_config set_sync_disabled_for_tests persistent`

### 6.2 W^X / exec() Restriction (Android 10+)
- **Symptom:** `Permission denied` when executing binaries in app data
- **Solutions:**
  - `/system/bin/linker64` invocation (used by DevEnv-PRoot, Termux)
  - `PROOT_LOADER` custom loader (used by UserLAnd)
  - `targetSdkVersion < 29` (used by LinuxDeploy — no longer viable)
- **Recommended:** linker64 approach — most compatible with modern Android

### 6.3 Scoped Storage (Android 11+)
- **Symptom:** Cannot access `/sdcard` directly
- **Mitigation:** Use `getExternalFilesDir()` for scoped-compatible paths; bind-mount those instead of `/sdcard`

### 6.4 SELinux
- PRoot operates at user-space (ptrace), so SELinux generally doesn't block it
- Some distributions need SELinux-disabling shims (UserLAnd's `libdisableselinux.so`)
- Fake `/sys/fs/selinux` (empty bind) prevents guest tools from detecting SELinux state

### 6.5 No Hardware Acceleration
- **All PRoot approaches:** No GPU acceleration, no OpenGL/Vulkan, no Docker, no kernel modules
- **AVF (Android 16):** GPU acceleration via VirtIO-GPU (but Pixel-only, experimental)
- **Workaround:** Software rendering or cloud container

### 6.6 Loopback Image Size Limit
- LinuxDeploy's busybox `mke2fs` is limited to **2GB** images
- Solution: Use directory-based deployment instead of image files

---

## 7. Recommendations for DevEnv-PRoot

Based on this research, here are specific recommendations for the DevEnv-PRoot project:

### 7.1 Adopt What Works

| Pattern | Source | Recommendation |
|---|---|---|
| **linker64 exec chain** | Termux (our current approach) | Keep our `/system/bin/linker64` invocation — it's the most modern approach |
| **Fake /proc stubs** | Termux (setup_fake_sysdata) | Generate fake `/proc/stat`, `/proc/version`, `/proc/vmstat`, `/proc/uptime`, `/proc/loadavg` |
| **Clean env construction** | Termux (proot-distro) | Build environment from scratch; don't inherit host env |
| **FSM state machine** | UserLAnd (SessionStartupFsm) | Follow the sealed-class pattern for robust wizard state management |
| **Custom bind mount dir** | Andronix (`<distro>-binds/`) | Allow users to add bind mounts via scripts in a special directory |
| **Component architecture** | LinuxDeploy (50+ components) | If adding distro-specific setup logic, use a composable pattern |
| **Error reporting** | UserLAnd (Sentry + sealed class errors) | Structured error hierarchy + crash reporting |
| **Marker files for step verification** | UserLAnd (`.success_filesystem_extraction`) | Our current `verify()` approach is good — use marker files for idempotent checks |

### 7.2 Avoid What Doesn't Work

| Anti-pattern | Source | Why |
|---|---|---|
| **PROOT_LOADER custom loaders** | UserLAnd | Unmaintained since 2021; may break on Android 14+ |
| **targetSdkVersion 28** | LinuxDeploy | Will be rejected by Play Store; misses security patches |
| **Relying on external apps for terminal** | UserLAnd, Andronix | Requires SSH/VNC setup — adds friction. Our WebView-based terminal is better |
| **Overly aggressive bind mounts** | proot-distro default | Many bind mounts = slower startup. Keep minimal |
| **Shell-based container manager** | proot-distro (pre-v5) | Python/Java is more maintainable and testable |

### 7.3 Recommended Architecture for DevEnv-PRoot v1.x

```
+---------------------------------------------------------+
|                Android App (APK)                         |
|  WebView UI  <-->  InstallBridge (JSInterface)          |
|                      |                                   |
|  StepRunner.java     |  TarExtractor.java               |
|    Step 1: Extract PRoot (assets)                       |
|    Step 2: Extract Alpine rootfs (assets)               |
|    Step 3: Generate launcher + verify                   |
|    Step 4: Alpine init (apk update, bash install)       |
|    Step 5: Shell ready                                  |
|                      |                                   |
|  LogBuffer.java      |  ErrorReport.java                |
|  (500-line ring buffer) |  (device info + logs)         |
+---------------------------------------------------------+
                         |
                         v
+---------------------------------------------------------+
|  Filesystem ($filesDir/)                                |
|  proot/                                                 |
|    proot-arm64          (212K, from assets)             |
|    proot-launch.sh      (generated by StepRunner)       |
|  rootfs/alpine/          (extracted from .tar)          |
|    bin/, etc/, usr/...  (Alpine Linux aarch64)          |
+---------------------------------------------------------+
                         |
                         v
+---------------------------------------------------------+
|  PRoot Invocation (via /system/bin/linker64)            |
|  /system/bin/linker64 $PROOT_DIR/proot-arm64 \         |
|    -0 -r $ROOTFS \                                      |
|    -b /dev -b /proc -b /sys \                           |
|    -b /sdcard \                                         |
|    --link2symlink \                                     |
|    -b <fake_proc_files> \                               |
|    /bin/sh --login -c "$*"                              |
+---------------------------------------------------------+
```

### 7.4 Future-Proofing

1. **Monitor AVF adoption** — If OEMS start shipping Android 16+ with AVF support, consider adding an AVF backend option alongside PRoot
2. **Track proot-distro developments** — Their OCI pull, session management, and fake sysdata approaches set the standard
3. **Consider `proroot`** (github.com/emontiel-dev/proroot) — A drop-in proot replacement with **zero ptrace overhead** using LD_PRELOAD-based path translation instead of ptrace. Could give near-native performance. However, it's new and unproven.
4. **Phantom process killer handling** — Build this into the app UI directly (detect Android version, show the correct setting/command, optionally guide through Wireless Debugging setup)

---

## 8. References

### GitHub Repositories
| Project | URL |
|---|---|
| proot-distro | https://github.com/termux/proot-distro |
| termux-app | https://github.com/termux/termux-app |
| termux-packages | https://github.com/termux/termux-packages |
| PRoot (upstream) | https://github.com/proot-me/PRoot |
| PRoot (Termux fork) | https://github.com/termux/proot |
| UserLAnd | https://github.com/CypherpunkArmory/UserLAnd |
| LinuxDeploy | https://github.com/meefik/linuxdeploy |
| LinuxDeploy CLI | https://github.com/meefik/linuxdeploy-cli |
| Andronix (scripts) | https://github.com/AndronixApp/AndronixOrigin |
| AnLinux-App | https://github.com/EXALAB/AnLinux-App |

### Documentation & Articles
| Resource | URL |
|---|---|
| PRoot manual | https://github.com/termux/proot/blob/master/doc/proot/manual.txt |
| Termux wiki: PRoot | https://wiki.termux.com/wiki/PRoot |
| Termux wiki: proot-distro | https://termux-wiki.vercel.app/proot |
| proot-distro README | https://github.com/termux/proot-distro/blob/master/README.md |
| Android Virtualization Framework | https://source.android.com/docs/core/virtualization |
| AVF use cases (Linux terminal) | https://source.android.com/docs/core/virtualization/usecases |
| Debian wiki: ChrootOnAndroid | https://wiki.debian.org/ChrootOnAndroid |
| Comparison of OS emulation on Android (Wikipedia) | https://en.wikipedia.org/wiki/Comparison_of_OS_emulation_or_virtualization_apps_on_Android |
| Phantom process killer deep-dive | https://github.com/agnostic-apollo/Android-Docs/blob/master/en/docs/apps/processes/phantom-cached-and-empty-processes.md |
| Signal 9 fix guide | https://cosyra.com/guides/termux-signal-9-fix.html |
| Cosyra comparison: Linux containers on Android (2026) | https://cosyra.com/guides/android-linux-container.html |
| Don't Kill My App | https://dontkillmyapp.com |
| proroot (zero-ptrace-overhead PRoot alternative) | https://github.com/emontiel-dev/proroot |
| Termux Desktop (mpd minimal launcher) | https://github.com/sabamdarif/termux-desktop |

### Community Discussions
| Topic | URL |
|---|---|
| Differences between Termux, PRoot, Userland, LinuxDeploy, AnLinux | https://superuser.com/questions/1546024 |
| AnLinux questions | https://github.com/EXALAB/AnLinux-App/issues/225 |
| LinuxDeploy from scratch | https://github.com/meefik/linuxdeploy/issues/1262 |
| UserLAnd performance issue | https://github.com/CypherpunkArmory/UserLAnd/issues/419 |
| UserLAnd performance regression | https://github.com/CypherpunkArmory/UserLAnd/issues/600 |
| PRoot lstat caching (performance) | https://github.com/proot-me/PRoot/issues/124 |
| Reddit: chroot vs proot | https://www.reddit.com/r/termux/comments/144ju11/question_about_chroot_vs_proot/ |
| Reddit: AnLinux vs LinuxDeploy vs UserLAnd | https://www.reddit.com/r/termux/comments/jddv94/anlinux_vs_linux_deploy_vs_userland/ |
| Benchmark: proot-distro vs native | https://github.com/termux/termux-packages/discussions/29944 |
| mpd minimal proot launcher | https://github.com/sabamdarif/termux-desktop/issues/282 |
| PRoot performance roadmap | https://github.com/termux/proot/blob/master/doc/proot/roadmap.txt |

---

## 9. Appendix: Quick-Reference Tables

### A. PRoot Flag Reference

| Flag | Short | Description | Example |
|---|---|---|---|
| `--rootfs=<path>` | `-r` | Set guest root filesystem | `-r /data/data/.../rootfs` |
| `--bind=<src>[:<dst>]` | `-b` | Bind mount host path | `-b /sdcard:/mnt/sdcard` |
| `--cwd=<path>` | `-w` | Initial working directory | `-w /root` |
| `--change-id=<uid>:<gid>` | N/A | Map host UID to guest | `--change-id=0:0` |
| `--root-id` | N/A | Same as `-0` (fake root) | `--root-id` |
| `--kill-on-exit` | N/A | Kill children on exit | `--kill-on-exit` |
| `--link2symlink` | N/A | Convert hardlinks to symlinks | `--link2symlink` |
| `--sysvipc` | N/A | Emulate SysV IPC | `--sysvipc` |
| `--kernel-release=<str>` | N/A | Fake uname -r | `--kernel-release="..."` |
| `-L` | N/A | Fix lstat for dpkg | `-L` |
| `-0` | N/A | Fake root identity | `-0` |
| `-q <path>` | N/A | QEMU user-mode emulator | `-q /usr/bin/qemu-aarch64` |
| `-v <level>` | N/A | Verbose/debug level | `-v 5` |

### B. Environment Variables

| Variable | Purpose | Set By |
|---|---|---|
| `PROOT_NO_SECCOMP` | Disable seccomp (required on Android) | All |
| `PROOT_VERBOSE` | Debug logging level | UserLAnd |
| `PROOT_L2S_DIR` | link2symlink backing store directory | Termux, proot-distro |
| `PROOT_LOADER` | Custom ELF loader (64-bit) | UserLAnd |
| `PROOT_LOADER_32` | Custom ELF loader (32-bit) | UserLAnd |
| `PROOT_TMP_DIR` | PRoot temporary directory | UserLAnd |
| `LD_PRELOAD` | termux-exec intercept (explicitly **unset** before PRoot) | Terminal |
| `MOZ_FAKE_NO_SANDBOX=1` | Disable Firefox/Chromium sandbox (PRoot incompatible) | Andronix, proot-distro |

### C. Troubleshooting Checklist

| Symptom | Likely Cause | Fix |
|---|---|---|
| `proot: Permission denied` | Android 10+ W^X restriction | Use `/system/bin/linker64` or install termux-exec |
| `[Process completed (signal 9)]` | Phantom process killer (Android 12+) | Disable via Developer Options or ADB |
| `apt update` fails | No internet / DNS not configured | Inside guest: `echo 'nameserver 8.8.8.8' > /etc/resolv.conf` |
| `Can't execute: Permission denied` | Binary not executable | `chmod +x` or check mount permissions |
| `Failed to extract rootfs` | PAX header not handled / path traversal | Use pure-Java tar with PAX support (our TarExtractor) |
| `symbol lookup error` | Library path mismatch | Unset `LD_LIBRARY_PATH`, use clean env |
| `FUSE not available` | `/dev/fuse` permissions | Cannot be fixed in PRoot (Android restriction) |
| `systemd not found` | PRoot can't run PID 1 | Use sysvinit or run-parts instead |
| Desktop apps very slow | Software rendering | Use lightweight WM, enable Mesa Turnip if available |
| Session dies on screen lock | Android Doze / battery optimization | Exclude app from battery optimization, acquire wakelock |

---

*Research conducted July 2026 for the DevEnv-PRoot project. Sources include GitHub source code analysis, official documentation, community wikis, web searches, and community discussions. Full reference list in Section 8.*
