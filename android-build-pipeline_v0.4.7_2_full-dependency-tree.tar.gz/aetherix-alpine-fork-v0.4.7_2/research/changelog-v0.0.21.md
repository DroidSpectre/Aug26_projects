# v0.0.21 — Architecture Revision: untrusted_app Domain + LD_PRELOAD Exec Shim

**Date:** 2026-07-21  
**APK Size:** 3.6M (13 entries)  
**Native libs:** 3 (all STORED, auto-extracted by package manager)

---

## What Changed

### Root Cause of Previous Failures

All v0.0.10–v0.0.20 failures traced to ONE root cause: PRoot ran in the `linker` SELinux domain (`u:r:linker:s0`). The kernel neverallow rule 76 prohibits non-`appdomain` processes from executing files outside `/system`. Samsung Knox adds layer-2 restrictions that additionally block `apk_data_file:file execute` from `linker` domain.

| Version | Execution Domain | exec app_data? | exec apk_data? | exec system? | Result |
|---------|-----------------|----------------|----------------|--------------|--------|
| v0.0.10-17 | `linker` (via `/system/bin/linker64`) | ❌ | ❌ | ✅ | failed |
| v0.0.18 | `linker` (seccomp mode) | — | — | ✅ (but seccomp bug) | EPERM |
| v0.0.19-20 | `linker` + PROOT_LOADER (apk_data) | ❌ | ❌ (Samsung) | ✅ | EPERM |
| **v0.0.21** | **`untrusted_app`** (direct exec via nativeLibDir) | **✅** | **✅** | **✅** | **NEW** |

### Architecture

**v0.0.20 (old):**
```
App Java → exec /system/bin/sh
  → exec /system/bin/linker64 $PROOT_DIR/proot-arm64
    → PRoot runs in `linker` domain ← BLOCKED
```

**v0.0.21 (new):**
```
App Java → exec /system/bin/sh
  → exec $NATIVE_LIB_DIR/libproot.so  ← apk_data_file, untrusted_app domain
    → PRoot runs in `untrusted_app` domain ← CAN exec apk_data_file
      → LD_PRELOAD=libdexec.so active in all children
        → tracee calls execve → libdexec intercepts
          → redirects through /system/bin/linker64 (system file → ALLOWED)
```

### Changed Files

| File | Change |
|------|--------|
| `jniLibs/arm64-v8a/libproot.so` | NEW — Termux bionic proot binary renamed for native lib extraction |
| `jniLibs/arm64-v8a/libdexec.so` | NEW — Termux termux-exec LD_PRELOAD shim (prebuilt .deb → native lib) |
| `jniLibs/arm64-v8a/libproot-loader.so` | KEPT (unchanged from v0.0.19) |
| `assets/loader` | REMOVED (no longer manually extracted) |
| `AndroidManifest.xml` | KEPT `extractNativeLibs="true"` |
| `scripts/build-apk.sh` | Updated to auto-include all `.so` files from `jniLibs/arm64-v8a/` as STORED |
| `app/.../StepRunner.java:step1Proot()` | Rewritten — no longer extracts proot-arm64 or loader from assets. Only extracts libtalloc.so.2 + libandroid-shmem.so. Logs nativeLibraryDir path and libproot.so existence. |
| `app/.../StepRunner.java:step3Launcher()` | Rewritten — exec `$NATIVE_DIR/libproot.so` (no linker64 prefix), adds `LD_PRELOAD=$NATIVE_DIR/libdexec.so`, `TERMUX_EXEC__SYSTEM_LINKER_EXEC__MODE=1`, `TERMUX__PREFIX=$ROOTFS` |
| `app/.../StepRunner.java:verify(0)` | Updated — checks native libs: libproot.so, libproot-loader.so, libdexec.so all exist in nativeLibraryDir |

### Launcher Script (v0.0.21)

```bash
#!/system/bin/sh
PROOT_DIR=<filesDir>/proot
ROOTFS=<filesDir>/rootfs/alpine
SDK=<filesDir>/sdk
NATIVE_DIR=<nativeLibraryDir>
mkdir -p $SDK $PROOT_DIR/tmp
export PROOT_NO_SECCOMP=1
export PROOT_LINK2SYMLINK=1
export LD_LIBRARY_PATH=$PROOT_DIR/lib
export PROOT_TMP_DIR=$PROOT_DIR/tmp
export PROOT_LOADER=$NATIVE_DIR/libproot-loader.so
export LD_PRELOAD=$NATIVE_DIR/libdexec.so
export TERMUX_EXEC__SYSTEM_LINKER_EXEC__MODE=1
export TERMUX__PREFIX=$ROOTFS
exec $NATIVE_DIR/libproot.so \
  -0 -r $ROOTFS \
  -b /dev -b /proc -b /sys \
  -b /system:/system \
  -b $SDK:/opt/android-sdk \
  -b /sdcard:/mnt/sdcard \
  -w /root --link2symlink \
  /system/bin/sh --login -c "$*"
```

### Execution Chain (detailed)

```
1. App Java (untrusted_app)
2.   → exec /system/bin/sh (system file → ALLOWED)
3.     → shell script sets env vars
4.       → exec $NATIVE_DIR/libproot.so (apk_data_file → untrusted_app CAN exec)
5.         → kernel sees INTERP=/system/bin/linker64 → loads linker64
6.           → linker64 loads libproot.so from apk_data_file (/data/app/.../lib/arm64/)
7.             → PRoot runs in untrusted_app domain (NOT linker!)
8.               → LD_PRELOAD=libdexec.so active in PRoot process
9.               → PROOT_LOADER points to nativeLibraryDir/libproot-loader.so (apk_data_file)
10.              → PRoot fork tracee (inherits untrusted_app + LD_PRELOAD)
11.                → tracee calls execve("/system/bin/sh", ...)
12.                  → libdexec.so (LD_PRELOAD) intercepts execve
13.                    → translates to execve("/system/bin/linker64", ["linker64", ...])
14.                      → PRoot's ptrace sees execve of /system/bin/linker64
15.                        → system file, passes through
16.                          → kernel loads /system/bin/linker64 → ALLOWED
17.                            → linker64 executes the target binary
```

### Key Env Variables (termux-exec)

| Variable | Value | Purpose |
|----------|-------|---------|
| `LD_PRELOAD` | `$NATIVE_DIR/libdexec.so` | Intercepts all execve() calls |
| `TERMUX_EXEC__SYSTEM_LINKER_EXEC__MODE` | `1` | Redirects exec'd binaries through `/system/bin/linker64` |
| `TERMUX__PREFIX` | `$ROOTFS` | Overrides hardcoded Termux prefix path |

### What Might Still Fail

1. **termux-exec path translation conflicts with PRoot** — The LD_PRELOAD shim translates Linux paths (e.g., `/bin/sh`) before PRoot's ptrace handler sees them. If termux-exec tries to prepend `$TERMUX__PREFIX` to paths, it could break PRoot's path translation. We set `TERMUX__PREFIX=$ROOTFS` to mitigate this (rootfs has proper Linux paths).

2. **termux-exec not designed for PRoot** — The shim was designed for native Termux use, not for use inside a PRoot sandbox. Behavior is unknown.

3. **Samsung seccomp blocking execve even for system files** — If the Samsung kernel blocks ALL execve from untrusted_app children, even via linker64, this won't work.

### APK Contents

| Path | Size | Type |
|------|------|------|
| `classes.dex` | 28K | DEX |
| `lib/arm64-v8a/libproot.so` | 231K | Native lib (STORED) |
| `lib/arm64-v8a/libdexec.so` | 53K | Native lib (STORED) |
| `lib/arm64-v8a/libproot-loader.so` | 18K | Native lib (STORED) |
| `assets/...` | ~8.5M | Tarball, libs, web UI |
| Total APK | 3.6M | |

### Version History

| Version | Approach | Status |
|---------|----------|--------|
| v0.0.10 | Glibc proot + linker64 | `libtalloc.so.2 not found` |
| v0.0.11 | Bionic proot + LD_LIBRARY_PATH | `can't create temp dir` |
| v0.0.12 | +PROOT_TMP_DIR | `not executable` |
| v0.0.13 | Fixed TarExtractor perms | `interpreter not found` |
| v0.0.14 | +loader + linker64 | loader in wrong domain |
| v0.0.15 | +PROOT_NO_SECCOMP + linker64 | loader `not found` (hardcoded Termux path) |
| v0.0.16 | Direct exec (no linker64) | `Permission denied` (SELinux) |
| v0.0.17 | PROOT_LOADER via assets | loader exec `denied` (linker domain) |
| v0.0.18 | Seccomp + /system/bin/sh | `Operation not permitted` (seccomp bug) |
| v0.0.19 | PROOT_LOADER via nativeLibraryDir | loader exec `denied` (linker domain, Samsung) |
| v0.0.20 | ZIP_STORED + extractNativeLibs=true | Same (confirmed native lib exists but linker blocks exec) |
| **v0.0.21** | **untrusted_app + LD_PRELOAD shim** | **NEW — first version not in linker domain** |
