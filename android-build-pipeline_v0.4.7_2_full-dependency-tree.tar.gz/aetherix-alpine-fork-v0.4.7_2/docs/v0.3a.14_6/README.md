# Aetherix-Alpine Fork — Build v0.3a.14_6

- **Date:** 2026-08-07
- **VersionName:** v0.3a.14_6 · **versionCode:** 30146
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Docs/UX follow-up from 14_5. No engine changes — the welcome
  banner and the in-shell `module help` guide now point users at the
  single-source `sd` storage mapping and the llm build tools
  (`llm build-status`, `llm build-restart`, docked dock bar) that 14_5 added.

## Changes

- **FB-066 — Welcome banner + `module help` refresh**
  (`WelcomeScript.java`, `app/src/main/assets/tier/module.sh`,
  `config/modules/hello-module/tier/module`):
  - Banner: `sd mount` labeled "map device storage into ~/storage (one source)";
    while a detached build is active (state file = `building`) it prints a
    `llm build-status — llama.cpp building (dock bar below)` hint line.
  - `module help`: new "Device storage" section (`sd mount` clears stale links,
    `sd list | ext`, `cd ~/storage/shared && ls`) and per-module lines for
    `llm build-status` (STALE = dead) and `llm build-restart` (resume a build
    killed with the app); restored `core status | help` wording.
