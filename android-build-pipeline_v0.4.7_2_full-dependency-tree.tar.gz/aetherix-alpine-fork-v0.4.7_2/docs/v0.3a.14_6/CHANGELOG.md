# Aetherix-Alpine Fork — Changelog

## v0.3a.14_6 (fork)

UX follow-up: welcome splash + `module help` now teach single-source `sd`
storage mapping (clear stale links, browse ~/storage) and the llm build tooling
(`llm build-status` / STALE, `llm build-restart`) added in 14_4/14_5. No engine
changes; builds on d766542 (14_5).
