# Aetherix-Alpine Fork — Changelog

## v0.3a.1 (fork)

Package identity fix (FB-003): applicationId com.aetherix.alpine.a so the fork installs side-by-side with upstream.
