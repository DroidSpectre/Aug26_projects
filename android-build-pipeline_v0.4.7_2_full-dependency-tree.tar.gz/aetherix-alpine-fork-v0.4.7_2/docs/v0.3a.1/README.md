# Aetherix-Alpine Fork — Build v0.3a.1

- **Date:** 2026-08-04
- **VersionName:** v0.3a.1 · **versionCode:** 30001
- **Package (applicationId):** `com.aetherix.alpine.a` (was `com.aetherix.alpine`)
- **Summary:** Fixes the fork/upstream package-identity conflict so the fork APK
  installs side-by-side with the opencode-written app instead of updating it.

## Changes
- Renamed the app identity to `com.aetherix.alpine.a` (industry-standard variant
  suffix, cf. `com.termux.beta`): `applicationId` + `namespace` in
  `app/build.gradle`, manifest `package`, relative component names, the full Java
  package tree (`com.aetherix.alpine.*` → `com.aetherix.alpine.a.*`), all imports
  and fully-qualified refs, `Class.forName` strings, and the `pm path` string in
  `StepRunner` (launcher APK-location check).
- No functional behavior changes; build pipeline, versioning, docs, and export
  tree unchanged.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-003 | Fork APK updates the upstream app instead of installing side-by-side | fixed | Fork inherited applicationId `com.aetherix.alpine`, same as the opencode-written app; Android treats same-id APKs as the same app | Renamed applicationId/package to `com.aetherix.alpine.a` (build.gradle, manifest, Java package tree, `pm path` string) |

## Build & Verification Notes
- Compile: javac clean with the renamed package; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30001' versionName='v0.3a.1'`.
- Snapshot `Aetherix-Alpine-v0.3a.1-source.zip` contains the renamed source tree
  (no build artifacts), exported with the APK to the fork device tree.
- The v0.3a.0 APK/zip remain on the device for history.
