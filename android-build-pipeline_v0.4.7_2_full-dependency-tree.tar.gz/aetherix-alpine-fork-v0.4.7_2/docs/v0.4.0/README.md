# Aetherix-Alpine Fork — Build v0.4.0

- **Date:** 2026-08-10
- **VersionName:** v0.4.0
- **versionCode:** 40000
- **Summary:** Core-stable v0.4.0: gui archived; modules bundled/APK-only; numbered permission prompts; install-only dashboard; per-module cards; PRoot-safe CPU probe for llama.cpp; detached job CLI with a stacked 5-job dock

## What v0.4.0 is

v0.3a.14_14 is renamed **v0.4.0** and declared the **frozen core**: app +
Alpine distro + terminal. The core is what "does everything we throw at it"
(terminal stability, llm serving). Modules are no longer part of the core
version — each module carries its own version and is the update vehicle going
forward. The full project snapshot is exported as `Aetherix-Alpine_v0.4.0.zip`
(`archive/v0.4.0/` + `/sdcard/Download/Aetherix-Alpine-Fork/snapshots/`).

## Changes

- **v0.4.0 rebrand + core freeze** (`app/build.gradle`,
  `scripts/bump-version.sh`, `scripts/release-docs.sh`,
  `config/modules/hello-module/tests/verify-apk.sh`):
  - versionName `v0.4.0`, versionCode `40000` (scheme `40000 + <patch>`).
  - `bump-version.sh` / `release-docs.sh` / `verify-apk.sh` accept and validate
    the `v0.4.<p>` scheme alongside the legacy `v0.3a.<n>(_<k>)` line.
  - Module versions are independent now: `core-module` 1.1.0, `llm-module`
    1.2.0, `hello-module` 1.1.0; the app version only bumps when the core
    changes. Briefing recorded in `docs/v0.3-series/core-vs-modules.md` and
    `docs/v0.3-series/package-inventory.md`.

- **Modules ship inside the APK only** (`ModuleManager.java`,
  `app/src/main/assets/tier/module.sh`):
  - The device drop-folder module source is gone: `syncBundledModules()` now
    cleans any legacy drop tarballs, writes the sparse APK-bundled manifest
    (`/etc/aetherix/bundled-modules.txt`), and `module available` lists only
    what the app bundles. A fresh user never needs device files.
  - `gui-module` is retired: never listed, never installed; stale markers,
    registry entries and tier CLIs from older builds are cleaned up. The
    retired list (`RETIRED_MODULES`) keeps this forward-compatible.

- **FB-087 — llama.cpp can't see the device under PRoot**
  (`config/modules/llm-module/tier/llm`):
  - `GGML_NATIVE=ON` / `-mcpu=native` rely on SIGILL-based compiler probes that
    fail inside PRoot (in-app logs showed `HAVE_DOTPROD - Failed` while the
    same source probed fine in Termux). The tier now reads `/proc/cpuinfo`
    `Features`/`flags` text (passes through PRoot untouched) and derives an
    explicit `-march=armv8.2-a[+dotprod][+i8mm][+bf16][+sve2][+sve]` into
    `CMAKE_C_FLAGS`/`CMAKE_CXX_FLAGS` with `GGML_NATIVE=OFF`. The detected
    feature line is logged at `llm setup` ("cpu: detected ... from
    /proc/cpuinfo").

- **FB-088 — detached job CLI + stacked 5-job dock** (`job.sh`,
  `TerminalActivity.java`, `WelcomeScript.java`, `ModuleManager.java`):
  - New guest CLI `job run <id> <command...>` detaches the job (prompt returns
    immediately), tails the job log, translates apk `(N/M)` and cmake `[N/M]`
    markers into `/etc/aetherix/jobs/<id>.state` (`job list`, `job stop <id>`,
    `job log <id>`).
  - The app's activity dock is now a **stack of up to 5 job rows** (progress
    bar + `[N/M] task` line + spinner). Interactive `apk add` (e.g.
    `apk add gnome` = 480 tasks) is routed through the job runner when the app
    terminal is active; legacy `llm.build.state` / `llm-download.state` and
    module post-install progress render as stack rows too. Finished jobs stay
    visible ~20 s then the dock hides; stale "running" states whose pid is gone
    are ignored.

- **Numbered permission prompts + correct Samsung battery path**
  (`InstallBridge.java`): the three post-step dialogs are labeled **1/3 —
  Notification permission**, **2/3 — Battery optimization** (instructions now:
  App info → Battery → **Unrestricted**), and **3/3 — All files access**, so
  each system prompt can be told apart.

- **Install-only dashboard until verified** (`dashboard.html`): after a fresh
  install the dashboard shows only the Install button. Once all 7 steps report
  `tested`, the Open Terminal button, the Modules & Storage / Log / Share /
  Licenses action group, and the danger row appear. **Reset & Reinstall** is
  always the bottom-most button. The log toggle button now switches between
  "View Log" and "Hide Log".

- **Modules page: one card per module** (`modules.html`): each module renders
  as its own bordered card (name + Installed/Blocked/Available badge, version,
  description, requires hint, Install/Reinstall/Uninstall), matching the step
  cards look instead of flat rows.

- **Conditional helper visibility** (`WelcomeScript.java`):
  `aetherix-selftest` / `aetherix-smoke` lines only appear when
  `/etc/aetherix/hello-module.installed` exists (no more ghost commands in the
  banner).

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-087 | llama.cpp build can't detect the device under PRoot (all `HAVE_*` probes Failed; works in Termux) | fixed | SIGILL-based cmake `GGML_NATIVE` probes fail under PRoot; compiler falls back to a baseline build | cpuinfo-text probe derives explicit `-march=armv8.2-a+...` (`GGML_NATIVE=OFF`), logged at `llm setup` |
| FB-088 | Long jobs (apk add / builds / downloads) flood the terminal with progress; no way to stack multiple | fixed | per-process progress bars + a single legacy dock slot | `job` CLI detaches tasks (prompt returns), writes `/etc/aetherix/jobs/<id>.state`; activity dock stacks up to 5 rows (bar + `[N/M]` task + spinner); interactive `apk add` routes through it |
| FB-089 | Permission popups look identical; hard to tell which request changed | fixed | three confirm dialogs shared the same copy layout with no numbering | numbered 1/3 – 3/3 headers (Notification / Battery / All-files) |
| FB-090 | Battery-optimization instructions wrong for Samsung | fixed | generic "find the app, set Allow" text | explicit Samsung path: App info → Battery → Unrestricted |
| FB-091 | Dashboard shows every button before install; only Install should exist pre-install | fixed | actions row always rendered | `refreshInstallButton()` gates the action group + danger row on `tested >= 7`; only Install (and the chooser) exists before a verified setup |
| FB-092 | Reset & Reinstall not at the bottom of the button list | fixed | reset row sat inside the actions block | separate `#reset-row` rendered last (danger, hidden until verified) |
| FB-093 | View/Hide Log button doesn't update its label | fixed | `viewLog()` never touched the button text | label toggles "View Log"/"Hide Log" with the section |
| FB-094 | Modules list is flat rows; each module should be its own card | fixed | single `module-row` divider style | per-module bordered cards (badge, version, requires, actions) inside the Modules frame |
| FB-095 | Modules supposedly discovered from device drop tarballs | fixed | drop-folder source predated bundled assets | APK assets are the only module source; drop folder cleaned; sparse bundled manifest drives `module available` |
| FB-096 | Module versions never bumped while content changed | fixed | module.yml versions stuck at 1.0.0 | core-module 1.1.0, llm-module 1.2.0, hello-module 1.1.0; convention: bump per bundle change |
| FB-097 | `aetherix-selftest` appears in the banner before hello-module is installed | fixed | unconditional welcome lines | lines gated on `/etc/aetherix/hello-module.installed` |

## Build & Verification Notes

- Host: `verify-apk.sh v0.4.0` → **14/14 PASS** (badging 40000/v0.4.0, v2+v3
  signature, DEX markers, bundles core/hello/llm, no gui bundle, device
  export). `build-apk.sh` produced `Aetherix-Alpine-v0.4.0.apk` (4.0 MiB) and
  the source snapshot (323 entries).
- Snapshots: `archive/v0.4.0/Aetherix-Alpine-v0.4.0-source.zip` and
  `Aetherix-Alpine_v0.4.0.zip` (underscore name per the archive request),
  mirrored to `/sdcard/Download/Aetherix-Alpine-Fork/` (APK +
  `snapshots/` + `docs/v0.4.0/`).
- Guest flow to verify on device:
  - `apk add gnome` → prompt returns immediately; the dock stacks the
    `apk-add-*` job (480 tasks, one `[N/M] task` line under the bar); run two
    more jobs to see stacking; `job list` / `job stop apk-add-<id>` /
    `job log apk-add-<id>`.
  - `llm setup` → prints the `cpu: detected ...` line before building; the
    build appears as a stack row.
  - Fresh install → dashboard shows only Install; after Step 7 the action
    group + Reset appear (Reset last); permission dialogs read 1/3, 2/3, 3/3
    with the Samsung battery path.
  - Modules page → core/hello/llm each in their own card; versions 1.1.0 /
    1.1.0 / 1.2.0; no gui-module anywhere.
  - `module available` → lists only bundled modules from the manifest.
- Module update workflow (for downstream iterations): edit
  `config/modules/<name>/…`, bump its `module.yml` version, run
  `scripts/build-modules.sh`, rebuild the APK — the core stays byte-identical.
