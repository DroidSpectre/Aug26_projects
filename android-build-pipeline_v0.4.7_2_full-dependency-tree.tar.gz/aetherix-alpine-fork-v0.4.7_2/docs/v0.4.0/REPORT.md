# Aetherix-Alpine — v0.3a.0 → v0.4.0 Development Report

**Build under review:** v0.4.0 (versionCode 40000) · **Report date:** 2026-08-10
**Target device:** Samsung Galaxy A16 (SM-S166V), Android 16 (API 36), aarch64,
kernel 5.15.189-android13; secondary targets: generic Android 8+ (API 26), aarch64.
**Scope:** the fork line from its first fork build (v0.3a.0) through the
core-stable revision (v0.4.0, equivalently v0.3a.14_14).

---

## 0. Abstract

This report documents the full development arc of the Aetherix-Alpine fork from
its first fork build (v0.3a.0) to the core-stable v0.4.0 revision. The project
delivered a self-contained Alpine Linux sandbox on unrooted Android — a PRoot
user-space sandbox, a native PTY terminal, a 7-step setup engine, a device
storage tier, a module system, and an on-device llama.cpp LLM runtime — and
systematically hardened it through 98 tracked defects (FB-000…FB-097). The
result is a declared-stable **core** (app + Alpine distribution + terminal) that
runs the LLM tier end-to-end, with modules promoted to the versioned update
vehicle. The report enumerates what was accomplished per phase, what had to be
fixed and why, the current state and known limitations, and the forward plan.

## 1. Background and Methodology

### 1.1 Origin

The fork began as an independent working copy of the upstream Aetherix-Alpine
tree (`/root/android-dev-env`) at 2026-08-04. The upstream tree was
mid-refactor: it did not compile (a missing method declaration and two
telemetry symbols), and its `v0.3.3`/`v0.3a` plan called for seven "device
access layers" — StepRunner UX, storage tier, module system, telemetry,
elevation (loopback adb), a GUI tier, and an LLM tier — most of which were
roadmap-only. The fork's applicationId was moved to `com.aetherix.alpine.a`
(FB-003) so it could install side-by-side with the upstream app.

### 1.2 Constraints that shaped the design

- **Unrooted Android, no kernel modules.** Everything runs in userspace:
  Alpine runs under PRoot (host-side `libproot.so`), a custom
  fork/PTY/exec pipeline (`native/pty-*.c`, freestanding bridge + JNI ioctl
  shim) provides the terminal, and `/proc`, `/dev`, `/sys` plus storage
  volumes are bind-mounted into the guest.
- **PRoot quirks are the dominant failure class.** SIGILL-based feature probes
  fail under PRoot (compiler `-mcpu=native` detection, cmake `HAVE_*` tests);
  `/bin/sh` symlinks break under `apk upgrade`; `/dev/urandom` is absent from
  the minirootfs; broken symlinks defeat `File.exists()`.
- **Android process lifecycle is hostile to long jobs.** The system kills the
  app's cgroup on screen-off / memory pressure / Device Care, which originally
  killed 10–30 minute llama.cpp builds.
- **The device store is a first-class surface.** All-files access gates the
  storage tier; every release is exported to
  `/sdcard/Download/Aetherix-Alpine-Fork/`.

### 1.3 Method

Iterative build–verify loop: each build is produced by `scripts/build-apk.sh`
(aapt + javac + d8 + zipalign + apksigner, JNI aarch64 cross-build), verified
by `config/modules/hello-module/tests/verify-apk.sh` (badging, signatures, DEX
markers, asset/bundle presence, device export), exercised on-device through the
terminal and dashboard, and documented per build with a README, a changelog, a
source snapshot, and rows in a cumulative bug register (`docs/BUGS.md`).

## 2. Accomplishments by Phase

### 2.1 Phase A — fork baseline, identity, UX, telemetry (v0.3a.0–v0.3a.6)

| Build | Accomplishment |
|---|---|
| v0.3a.0 | Repaired the inherited compile breakage (FB-000…FB-002); established per-build docs, source snapshots, fork export tree, and git history |
| v0.3a.1 | Side-by-side package identity `com.aetherix.alpine.a` (FB-003) |
| v0.3a.2 | Made Step 7's final self-test honest under PRoot — the chain ran `proot --version` *inside* the guest where no host binary exists (FB-004) |
| v0.3a.3 | Dashboard-first boot, unified Install chooser, corrected step numbering, All-files permission folded into the Step-3 flow (FB-005, FB-006) |
| v0.3a.4 | Graceful exit handling (no false "killed by the system"), live package count on the dashboard (FB-007, FB-008) |
| v0.3a.5 | **Module system shipped**: `hello-module` bundled in the APK (FB-009), in-Alpine `device-info` CLI backing the telemetry tier (FB-010) |
| v0.3a.6 | Telemetry + storage expansion: Hardware card (RAM/storage/app/charging/network/CPU/GPU/NPU), notification tap action, Termux-style `~/storage` link tree with adaptive `sd mount`, rootfs readiness gate (FB-011…FB-015) |

### 2.2 Phase B — plan tiers + deploy reliability (v0.3a.7–v0.3a.10)

| Build | Accomplishment |
|---|---|
| v0.3a.7 | Storage cd aliases; in-terminal `module status`; **foundations for the elevation, GUI, and LLM tiers** (`elv`/`gui`/`llm` CLIs + dashboard cards) (FB-016…FB-020) |
| v0.3a.8 | Fixed on-device regressions: apk-db path, deploy triggers on refresh/step-completion (FB-021, FB-022) |
| v0.3a.9 | Hardened the "rootfs not ready" gate (broad evidence gate + `rootfsDiagnostics()`), true Reset & Reinstall (FB-023, FB-024) |
| v0.3a.10 | The on-device selftest exposed that `StorageTier.deploy()` silently did nothing → instrumented deploy logging, extra deploy triggers, and hello-module **self-healing** of helpers/links/aliases/state from the bundle (FB-025…FB-027) |

### 2.3 Phase C — module packaging, lifecycle, kill recovery (v0.3a.11–v0.3a.14)

| Build | Accomplishment |
|---|---|
| v0.3a.11 | App-switch keeps a live terminal; GUI/LLM promoted to standalone installable modules; `llm setup` builds llama-server from source (no Alpine packages exist) (FB-028…FB-030) |
| v0.3a.12 | GPU-polling UI lag removed; `/dev/urandom` bound so `git clone` works; TLS CA fallback wired (FB-031, FB-032) |
| v0.3a.13 | System-kill recovery notice + auto-reopen; single Install entry; collapsible Hardware card; toolbar Clear; first-digit warmup guard (FB-033…FB-038) |
| v0.3a.14 | UI polish: collapsed-by-default cards, badge color semantics, Termux-style welcome banner + cheatsheet (FB-039…FB-041) |

### 2.4 Phase D — stabilization, LLM runtime, docks (v0.3a.14_1–v0.3a.14_13)

The `v0.3a.14` line was the empirical debugging phase, driven by on-device
reports from the SM-S166V:

| Build | Accomplishment |
|---|---|
| 14_1 | Toolbar layout + labels; TLS cert.pem bootstrap; two-mode module uninstall (FB-042…FB-045) |
| 14_2 | Root-caused app/device lag (deploy retry stall + apk-db re-parse) via O(1) deploy gate + caching; healed `/bin/sh`; killed the drop-tarball downgrade; async module install with live progress; braille spinner (FB-046…FB-052) |
| 14_3 | Full-session wake lock (PARTIAL) so background builds survive screen-off; symlink-exists fix for the FileAlreadyExists spam; Licenses page (FB-053…FB-056) |
| 14_4 | **Module dependency system** — `core-module` bundles the shared base + toolchain; `requires`/`requires-pkgs`/`recommends-pkgs` metadata; guest `module available/deps`; detached, adaptive llama.cpp build (FB-057…FB-061) |
| 14_5 | Single-source `sd` storage mapping; async module install; stale-build detection + `llm build-restart`; **docked build progress bar** (FB-062…FB-066) |
| 14_6 | Docs/UX only (banner + module help lines) |
| 14_7 | Closed the last input bug: two-phase warmup that never deletes a user keystroke (FB-067) |
| 14_8 | **HuggingFace model downloads** (`llm hf list/get`, 5 curated Q4 models), SCREEN_DIM wake lock while terminal visible, build-log export, clear-persistence, `sd` from Java storage map (FB-068…FB-075) |
| 14_9 | Full-system wake lock owned by the foreground service (PARTIAL + SCREEN_DIM for the whole session) (FB-076) |
| 14_10 | `llm hf` dispatch fix + numbered curated-model menu; full `~/storage` tree seeded at app start (FB-077, FB-078) |
| 14_11 | `llm ask` prints only the reply; llama-server version in `build-status` (FB-079, FB-080) |
| 14_12 | **Docked LLM response window** (keybar REPLY; 3/5 rows) + `llm chat` multi-turn history (FB-081, FB-082) |
| 14_13 | **gui-module archived** (out of scope — project focuses on CLI/app functions); reply cap 512 + `LLM_MAX_TOKENS`; activity dock (bar + task line + spinner) replacing per-process progress bars; chat whitespace fix; reply dock 5/10 rows (FB-083…FB-086) |

### 2.5 v0.4.0 — core freeze and the archive convention

- Renamed v0.3a.14_14 → **v0.4.0** (versionCode 40000; scheme `40000+p`) and
  declared the core stable: app + Alpine distribution + terminal.
- **Modules are APK-bundled only** — the device drop-folder source is removed;
  retired `gui-module` leftovers are cleaned; `module available` reads the
  bundled manifest (FB-095).
- **Module versions became real** (core-module 1.1.0, llm-module 1.2.0,
  hello-module 1.1.0) — one bump per bundle change; the app version only moves
  when the core changes (FB-096).
- **PRoot-safe CPU detection for llama.cpp** (FB-087): replaced SIGILL-based
  `GGML_NATIVE` cmake probes with an explicit `-march=armv8.2-a[+dotprod][+i8mm][+bf16][+sve2][+sve]`
  derived from `/proc/cpuinfo` text.
- **Detached job CLI + stacked 5-job dock** (FB-088): `job run/list/stop/log`
  detaches long tasks (prompt returns immediately) and translates apk `(N/M)` /
  cmake `[N/M]` markers into polled state files; the activity dock stacks up to
  five progress rows. Interactive `apk add` (e.g. `apk add gnome`, 480 tasks)
  routes through it.
- **UX compliance batch** (FB-089…FB-094, FB-097): numbered 1/3–3/3 permission
  prompts with the real Samsung battery path (App info → Battery → Unrestricted);
  install-only dashboard until all 7 steps verify; Reset & Reinstall always the
  bottom button; View/Hide Log label toggle; one card per module; conditional
  `aetherix-selftest` banner lines.

## 3. What Had to Be Fixed

98 defects (FB-000…FB-097) were closed across the line. By dominant area
(keyword-classified from `docs/BUGS.md`):

| Area | Fixes | Representative IDs |
|---|---|---|
| Terminal / PTY / input | 24 | FB-004, FB-036, FB-038, FB-042, FB-051, FB-052, FB-067, FB-070, FB-072, FB-073 |
| Module system | 17 | FB-009, FB-022, FB-044, FB-048, FB-057, FB-063, FB-075, FB-095, FB-096 |
| LLM / llama.cpp / models | 10 | FB-030, FB-032, FB-060, FB-064, FB-068, FB-071, FB-083, FB-087 |
| UI / dashboard / UX | 9 | FB-035, FB-039, FB-040, FB-041, FB-089…FB-094, FB-097 |
| Storage tier | 8 | FB-014, FB-016, FB-056, FB-062, FB-074 |
| PRoot / sandbox / rootfs | 7 | FB-021, FB-023, FB-047, FB-054 |
| Telemetry / device info | 5 | FB-000…FB-002, FB-010, FB-013, FB-031 |
| Process lifecycle / wake locks | 3 | FB-033, FB-053, FB-069, FB-076 |
| Other / cross-cutting (docs, help, export, logging) | 15 | FB-008, FB-034, FB-050, FB-058, FB-066, FB-071, … |

Counts are keyword-classified for structure; rows may straddle areas (e.g. the
TLS/certificate fixes FB-032/FB-043 sit inside the LLM and PRoot families).

### 3.1 Recurring root-cause families

1. **PRoot breaks assumptions about the environment.** The self-test ran a
   host-only binary in-guest (FB-004); `apk upgrade` dropped `/bin/sh`
   (FB-047); `/dev/urandom` was missing (FB-032); SIGILL probes silently
   "Failed" (FB-087); broken symlinks defeated `File.exists()` (FB-054).
   Resolution pattern: probe text-readable state (`/proc/cpuinfo`, apk db,
   alpine-release), bind what the guest needs, and rebuild symlinks idempotently.
2. **Android kills the app, not just the job.** Screen-off and Device Care
   killed builds and sessions (FB-033, FB-053) → wake-lock ownership moved to
   the foreground service (FB-076), builds detach with `setsid` and resume via
   cmake, and stale state is detected by process liveness (FB-064).
3. **Terminal input races.** Warmup/resize handling could eat the user's first
   keystroke or spawn stray spaces (FB-036, FB-052, FB-067, FB-073); each
   generation made the injected-input guard more conservative until it could
   only erase its own injected SPACE.
4. **Progress could not be shown without polluting the terminal.** Multi-bar
   apk output and ghosted curl bars were replaced first by `--no-progress`/`-s`,
   then by a dedicated dock (FB-084), extended to a 5-row job stack (FB-088).
5. **Two writers for one state.** Storage mapping, `/bin/sh`, module sources —
   wherever app-side and guest-side writers touched the same artifact, drift
   appeared (FB-062, FB-048); the resolution was a single source of truth
   (Java-written storage map; APK assets only; hello-module self-heal).

## 4. Current State of the Project

| Component | State |
|---|---|
| **7-step setup** (PRoot bootstrap, Alpine extraction, diagnostics, launcher, package seed, PTY bridge, verify) | All 7 steps `tested` on the SM-S166V; component status table green |
| **Terminal** (native PTY, resize propagation, toolbar, warmup guard, clear persistence) | Declared stable; minor quirks tracked (see §5) |
| **Storage tier** (`sd mount`, `~/storage` tree, storage.map from Android volumes) | Stable; `sd list/ls/cp/ext`, aliases working |
| **Module system** (APK-bundled assets, dependency metadata, async install, uninstall) | Stable; core/hello/llm bundles ship; `gui-module` retired |
| **LLM tier** (llama-server built from source, CPU-only, HF downloads, `llm ask/chat`, docked replies) | Working end-to-end on device (SmolLM2-360M Q4 verified: ~4.5 tok/s); hallucination quality work remains |
| **Elevation tier** (`elv` loopback adb) | Foundation shipped; on-device verification still pending (kernel may block loopback pairing) |
| **GUI tier** | **Archived** at v0.3a.14_13 — out of project scope; removed from builds |
| **Dashboard / Modules pages** | Install-only pre-verification; per-module cards; numbered permission flow |

Build health: `verify-apk.sh v0.4.0` → **14/14 PASS**; APK 4.0 MiB; full
project snapshot exported as `Aetherix-Alpine_v0.4.0.zip` (323 entries).

## 5. Known Bugs and Limitations

1. **FB-052 — first-digit eat (open, mitigated).** Intermittent loss of the
   first typed character with BT keyboards / OSK resize. Mitigated by the
   two-phase warmup (FB-067); no reliable repro remains, but the defect is not
   formally closed.
2. **Terminal quirks (no blocking bugs).** The terminal "handles everything we
   throw at it"; observed quirks: occasional stray space artifacts around
   resizes, and keyboard grid-churn effects — tracked, none breaking.
3. **LLM hallucination quality.** The small Q4 models (360M–1B) hallucinate
   (e.g., invented `apt`-style Alpine instructions); improving prompt
   handling/model selection is the next LLM work item.
4. **Battery optimization prompt depends on OEM UX.** The wording now matches
   Samsung (App info → Battery → Unrestricted); other OEMs may differ.
5. **Deploy-time races.** Helpers/links are re-created across multiple triggers
   (app start, dashboard poll, terminal start, module install); self-healing
   makes this convergent, with a logged warning rather than a failure path.
6. **Screen-blackout during deep processing** (14_13 analysis): no GPU use was
   added (CPU-only build confirmed); hypothesis is screen dim/thermal under the
   long-wake-lock build. If it recurs, capture `dumpsys power | grep -i wake`
   before/after.

## 6. Current Plan

1. **Core is frozen at v0.4.x; modules are the update vehicle.** Module
   iteration = edit `config/modules/<name>/…` → bump its `module.yml` version →
   `scripts/build-modules.sh` → rebuild APK → install; the core stays
   byte-identical. Test one module at a time (core → hello → llm) against the
   frozen core.
2. **Per-version archive convention (from v0.4.0 on).** Every released version
   gets its own folder in the download tree:
   `/sdcard/Download/Aetherix-Alpine_v<version>/` containing **the source
   snapshot + the APK + the version docs (report/README/changelog)** — not just
   change logs. `scripts/build-apk.sh` emits this folder automatically from
   v0.4.0 onward; `docs/v0.3-series/VERSIONING.md` §3 records the convention.
3. **LLM workstream.** Address hallucination (better curated models/system
   prompts, context trims), chat UI in the dock, and model-download UX; keep
   the CPU-only constraint.
4. **Elevation tier.** Verify `elv` on-device (loopback adb pair/connect/shell);
   kernel blocking = record environmental limitation.
5. **Ongoing hardening.** Watch the open input quirks (FB-052), wake-lock
   battery cost, and any new on-device regressions through the same
   build–verify–document loop.

## 7. Appendix — Artifact and Version Inventory (v0.4.0)

| Artifact | Location |
|---|---|
| APK | `Aetherix-Alpine-v0.4.0.apk` (project root + `/sdcard/Download/Aetherix-Alpine_v0.4.0/`) |
| Full source snapshot (underscore name per archive request) | `archive/v0.4.0/Aetherix-Alpine_v0.4.0.zip` |
| Source snapshot (build default name) | `archive/v0.4.0/Aetherix-Alpine-v0.4.0-source.zip` |
| Core layer archive (modules excluded) | `archive/core-v1/aetherix-core-v1-source.zip` |
| Release docs | `docs/v0.4.0/{README,CHANGELOG,REPORT}.md`, `docs/BUGS.md` (FB-087…FB-097 rows) |
| Layer analysis + package inventory | `docs/v0.3-series/core-vs-modules.md`, `docs/v0.3-series/package-inventory.md` |
| Git | commit `b1279e7`, tag `v0.4.0` |

**Versioning scheme (current):** core = `v0.4.<p>` / `40000+p`; legacy wing =
`v0.3a.<n>(_<k>)` / `30000+n*10+k`; modules = independent semantic versions.
