# Aetherix-Alpine Fork — Changelog

## v0.4.0 (fork)

Core-stable v0.4.0 (= v0.3a.14_14): gui archived; modules bundled/APK-only; numbered permission prompts; install-only dashboard; per-module cards; PRoot-safe CPU probe for llama.cpp; detached job CLI with a stacked 5-job dock

- **v0.4.0 rebrand + core freeze**: versionName `v0.4.0` / versionCode `40000`;
  `bump-version.sh`, `release-docs.sh`, `verify-apk.sh` handle the `v0.4.<p>`
  scheme. The core (app + Alpine + terminal) is frozen; modules carry their own
  versions (core-module 1.1.0, llm-module 1.2.0, hello-module 1.1.0) and are the
  update vehicle.
- **Modules APK-only**: device drop-folder removed as a module source; the app
  cleans legacy drops and retired `gui-module` leftovers; `module available`
  reads the sparse `/etc/aetherix/bundled-modules.txt` manifest.
- **FB-087**: `llm setup` derives an explicit `-march=armv8.2-a[+dotprod][+i8mm][+bf16][+sve2][+sve]`
  from `/proc/cpuinfo` text (PRoot-safe) instead of SIGILL-based `GGML_NATIVE`
  probes; feature line logged.
- **FB-088**: new `job` CLI detaches tasks (`job run/list/stop/log`), writes
  `/etc/aetherix/jobs/<id>.state` from apk `(N/M)` / cmake `[N/M]` markers; the
  activity dock stacks up to 5 job rows; interactive `apk add` routes through
  it; legacy llm build/download states render as stack rows.
- **FB-089/FB-090**: permission dialogs numbered 1/3–3/3; battery instructions
  now the real Samsung path (App info → Battery → Unrestricted).
- **FB-091/FB-092/FB-093**: dashboard shows only Install until all 7 steps are
  `tested`, then the action group + Reset appear (Reset last); log toggle
  button label switches View/Hide Log.
- **FB-094**: Modules page renders one bordered card per module.
- **FB-095/FB-096**: no device-source modules; module versions bumped with
  content (1.1.0 / 1.2.0 / 1.1.0).
- **FB-097**: `aetherix-selftest`/`aetherix-smoke` banner lines gated on
  hello-module being installed.
- **Snapshot**: full project exported as `Aetherix-Alpine_v0.4.0.zip`
  (`archive/v0.4.0/` + device `snapshots/`).
