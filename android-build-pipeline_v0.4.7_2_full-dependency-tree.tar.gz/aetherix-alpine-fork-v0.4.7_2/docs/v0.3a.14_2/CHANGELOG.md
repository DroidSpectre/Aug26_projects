# Aetherix-Alpine Fork — Changelog

## v0.3a.14_2 (fork)

Fix build 2: lag root-cause (deploy gate + package-count cache), bin/sh symlink heal (helpers now deploy), bundled modules always from APK, gui setup progress, full module activity log, terminal spinner for silent commands
