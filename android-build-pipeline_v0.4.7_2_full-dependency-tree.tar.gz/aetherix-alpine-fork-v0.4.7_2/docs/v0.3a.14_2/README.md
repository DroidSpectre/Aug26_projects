# Aetherix-Alpine Fork — Build v0.3a.14_2

- **Date:** 2026-08-06
- **VersionName:** v0.3a.14_2 · **versionCode:** 30142
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Fix build 2 of the v0.3a.14 line. Root-causes the app/device lag
  (deploy retry loop + unbounded apk-db parsing) and the still-missing guest
  helpers after fresh install (`bin/sh` symlink loss under proot), guarantees
  bundled modules always come from the APK, makes `gui setup` show apk progress,
  prints the full module activity on the module page and in the error report,
  and adds a terminal activity spinner for commands that produce no output.

## Changes

- **FB-046 — Extreme app/device lag (white pages, ~3s toolbar delay, module page lag)**
  (`StorageTier.java`, `InstallBridge.java`):
  - Root cause A: the 14_1 deploy retry loop (`8 × 500 ms`) ran inside
    `StorageTier.deploy()` on every dashboard poll / module refresh / terminal
    start. When `/bin/sh` was broken (see FB-047) every poll blocked the bridge
    thread for seconds, stalling the UI (white pages before render, slow
    Copy All / Clear All / Exit presses).
  - Root cause B: `InstallBridge.countPackages()` re-parsed the whole apk db
    (grows with every installed package) on the 5 s dashboard poll.
  - Fix: deploy readiness gate is now O(1) (see FB-047) and package count is
    cached for 10 s.
  - Acceptance: toolbar buttons respond immediately; no white-page flash; no
    module-page stall with ~190 packages installed.
- **FB-047 — Guest helpers still missing after fresh install; `binSh:false` in
  Module Readiness; module install says "setup incomplete" despite 7/7**
  (`StorageTier.java`, `ModuleManager.java`):
  - Root cause: `apk upgrade` / large `apk add` runs under proot can drop the
    `/bin/sh -> busybox` symlink while bash keeps working. The old deploy gate
    checked only `bin/sh`, so every deploy silently skipped and
    `sd`/`device-info`/`elv`/`module` + `cert.pem` never reached the guest
    (`Module Readiness` showed `binSh:false`, which also drove the module-page
    "Setup incomplete" hint).
  - Fix: `healRootfsBasics()` recreates the `bin/sh -> busybox` symlink when
    busybox exists; the readiness gate accepts `bin/sh` OR `bin/busybox` OR
    `etc/alpine-release`; a post-deploy `verifyDeploy()` logs any missing
    helpers into the error report.
- **FB-048 — Stale drop-folder tarball downgrades bundled modules**
  (`ModuleManager.java`):
  - `installModule()` preferred `/sdcard/Download/Aetherix-Alpine-Fork/modules/<name>.tar.gz`
    over the APK-bundled asset, so an old pre-tier hello tarball could leave the
    helpers undeployed even after the app-side fixes.
  - Fix: bundled modules (hello/gui/llm) are always re-copied from APK assets at
    install time, overwriting any stale drop copy.
- **FB-049 — `gui setup` looks hung during package install**
  (`gui-module/tier/gui`):
  - `apk add xvfb x11vnc openbox xterm` redirected all output to
    `/dev/null`, so a ~1-2 min install showed nothing (the user pressed Ctrl-C
    thinking it stalled).
  - Fix: apk's own download/install progress is printed (matches the llm tier);
    failures still exit with a clear error.
- **FB-050 — Module screen logs only the success line, not the activity**
  (`ModuleManager.java`, `InstallBridge.java`, `modules.html`):
  - Every phase (helper deploy, source selection, extract, register,
    post-install) is now collected by `moduleStep()` and returned as `log` in
    the module result; the module page shows it under `--- activity ---` and
    `InstallBridge.appendModuleActivity()` mirrors it into the main app log so
    it appears in the error report too.
- **FB-051 — No feedback while a command runs without output**
  (`TerminalSession.java`, `TerminalActivity.java`):
  - A braille spinner chip (bottom-right overlay) appears when a submitted
    command has produced no output for ≥ 2 s (e.g. `sleep 4`, long `apk`
    resolve phases, `git clone` stalls) and clears when the shell repaints a
    fresh prompt (`.*:\S*[#$]`).
  - Purely visual: it never writes into the pty, so Copy All / Clear All /
    scrollback stay byte-for-byte clean.

## Bugs

| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-046 | Extreme app/device lag (white pages, ~3s toolbar delay, module page lag) | fixed | deploy retry loop stalled every poll when bin/sh broken; apk db re-parsed every 5s | O(1) deploy gate + rootfs heal; 10s cached package count |
| FB-047 | Helpers still missing after fresh install (`binSh:false`; "setup incomplete" despite 7/7) | fixed | apk upgrade under proot drops `/bin/sh -> busybox` while bash works; bin/sh gate skipped every deploy | healRootfsBasics recreates symlink; gate accepts bin/sh \| bin/busybox \| etc/alpine-release; post-deploy verify logs |
| FB-048 | Stale drop-folder tarball downgrades bundled modules | fixed | install preferred /sdcard drop tarball over bundled asset | bundled modules always re-copied from APK assets at install time |
| FB-049 | `gui setup` looks hung during package install | fixed | `apk add` output hidden by `>/dev/null 2>&1` | print apk progress (matches llm tier) |
| FB-050 | Module screen logs only success, not activity | fixed | single final message returned | every phase in `res.log`, shown on module page + mirrored to error report |
| FB-051 | No feedback while a command runs without output | fixed | no activity indicator in terminal | braille spinner overlay on ≥2s silence; cleared on fresh prompt; never writes to pty |
| FB-052 | First digit still eaten at random (BT keyboard / OSK shrink) | open | intermittent; warmup race partially addressed in FB-036; no deterministic repro | none yet — watch on 14_2; input/warmup path untouched |

## Build & Verification Notes

- Build: `bash scripts/build-apk.sh` → `Aetherix-Alpine-v0.3a.14_2.apk`
  (versionCode `30142`), auto-exported to
  `/sdcard/Download/Aetherix-Alpine-Fork/`.
- Verify: `bash config/modules/hello-module/tests/verify-apk.sh v0.3a.14_2`
  → **13/13 passed** (badging 30142, signature v2+v3, DEX markers, all assets
  incl. regenerated hello/gui/llm bundles, device export present).
- On-device acceptance for 14_2:
  - `aetherix-selftest` → **0 FAIL** after a fresh setup (helpers + TLS CA).
  - `git ls-remote https://github.com/ggml-org/llama.cpp HEAD` works (TLS).
  - `sleep 4` shows the spinner; `gui setup` prints apk progress.
  - No lag on toolbar buttons / module page; Copy All / Clear All respond at once.
