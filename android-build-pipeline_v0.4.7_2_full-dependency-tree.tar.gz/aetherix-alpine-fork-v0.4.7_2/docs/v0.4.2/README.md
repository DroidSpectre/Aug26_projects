# Aetherix-Alpine Fork — Build v0.4.2

- **Date:** 2026-08-10
- **VersionName:** v0.4.0 series — v0.4.2
- **versionCode:** 40002
- **Summary:** the llm tier becomes model- and context-aware: per-model
  profiles, `llm context`, auto-routing `llm ask`, a read-only `llm agent`
  tool loop, and a curated help corpus via the new help-module
  (FB-103..FB-108).

## What v0.4.2 is

v0.4.2 is the second patch release on the frozen v0.4.0 core. Architecture is
unchanged; the release upgrades the llm tier to answer with awareness of the
model, the terminal, the system, and the built-in docs, and ships the first
"downstream update" module (help-module) on top of v0.4.1's Tavily backend.
`llm-module` advances to 1.4.0; the core version stays on the v0.4.x line.

## Changes

- **Model profiles (FB-103)** — `model-profiles.conf` per-model
  ctx/batch/agent-round settings applied at every server spawn; env
  overrides; `llm status` shows the active profile.
- **Context (FB-104)** — app-written `/etc/aetherix/term.context` (last ~40
  terminal lines) + `llm context` system snapshot, injected into every
  prompt path.
- **Auto-router (FB-105)** — `llm ask` classifies plain/help/docs/web,
  synthesizes cited web answers via Tavily, `--plain` escape hatch.
- **Agent (FB-106)** — `llm agent` read-only tool loop (web/help/file),
  gated for tool-capable models.
- **Help corpus (FB-107)** — help-module v1.0.0, `llm docs find/add`,
  `llm ask-help`, corpus-backed routing.
- **Fixes** — docs search ranking semantics (FB-108). Details in
  `docs/v0.4.2/CHANGELOG.md`.

## Verification

`verify-apk.sh v0.4.2` → 14/14 PASS (badging, signatures, DEX markers, assets,
bundles, device export). Full snapshot in
`/sdcard/Download/Aetherix-Alpine_v0.4.2/` (APK + source zip + docs).

## Manual device checks (new)

1. `llm status` with a small model → profile row (e.g. Qwen2.5-0.5B:
   1024 ctx, tools disabled); `LLM_CTX=4096 llm start` overrides it.
2. Run a few commands, then `llm context` → terminal tail + system state.
3. `llm ask "what have I got installed?"` → help/docs routing cites the
   corpus; `llm ask "what's new with qwen?"` (key set) → cited web answer.
4. `llm agent "check the docs for llm setup, then summarize the terminal"` →
   tool loop ends in `done` and an answer.
5. `llm docs find "tavily key"` → exact-phrase docs (bug register /
   troubleshooting) rank first, keyboard/keybar docs last.
6. `llm ask-help "how do I install a desktop?"` → corpus answer; interactive
   mode exits only on `Exit`.
