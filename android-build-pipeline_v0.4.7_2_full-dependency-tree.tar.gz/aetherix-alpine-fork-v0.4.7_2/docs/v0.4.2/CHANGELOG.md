# Aetherix-Alpine Fork — Changelog

## v0.4.2 (fork)

Model-aware revision on the frozen v0.4.0 core: the llm tier now learns the
terminal + system state, runs per-model context profiles, routes `llm ask` by
intent, gains a read-only tool loop (`llm agent`), and answers help questions
from a curated corpus (help-module). Tavily (v0.4.1) is the search backend;
no SearXNG fallback by design.

- **FB-103 — per-model profiles**: the server always started with a fixed
  2048-token context regardless of model. `/etc/aetherix/model-profiles.conf`
  (glob → ctx/batch/agent rounds) now drives `--ctx-size`/`--batch-size` at
  every spawn site (start/chat/web archive) and gates the agent loop;
  `LLM_CTX`/`LLM_BATCH`/`LLM_AGENT` overrides win; `llm status` prints the
  active profile. Small models get a small window — the pi-agent lesson
  (match context to the model; user override wins).
- **FB-104 — terminal + system context**: the app writes the last ~40 visible
  terminal lines to `/etc/aetherix/term.context` on resume and after input
  settles; `llm context` composes a system snapshot (terminal tail, cwd/tty,
  core/module/job state, storage map, server + key status). The snapshot is
  injected into plain/help/docs/web prompts via `ctx_block()` so answers
  reference what the user is actually doing.
- **FB-105 — auto-router `llm ask`**: a classifier labels the query
  plain|help|docs|web (unknown → web when a Tavily key is set, else plain;
  `--plain` forces direct). The web path runs 1–2 generated Tavily queries
  via `web_answer()` and renumbers citations. Reply parsing fixed to pass the
  model body as an argument (not stdin) at all three synthesis sites.
- **FB-106 — `llm agent`**: read-only tool loop
  `web_search | help_lookup | file_read | done` (JSON `tool_calls` with a
  `tool:`-line fallback), history via `msg_json`, results via the BusyBox-safe
  `parse_tool_calls` awk. Rounds are gated by the model profile: sub-1B
  models get a clear "tools disabled" message and use the router instead.
- **FB-107 — help-module**: new curated corpus module (v1.0.0, requires
  llm-module) shipping 10 condensed docs + a keyword `.index` to
  `/etc/aetherix/help`; `llm docs find/add/help`, `llm docs help`, and
  one-shot or interactive `llm ask-help` (interactive exits only on `Exit`);
  install order is core → hello → llm → help.
- **FB-108 — docs semantic ranking**: `docs_top` ranked by raw hit count, so
  "tavily key" could let keyboard/keybar `key` hits outrank the exact-phrase
  doc. Ranking now scores exact-phrase match first, then distinct-term count,
  then total hits — still BusyBox-safe (no jq, awk-only parsing).
- **Versions**: app v0.4.2 / versionCode 40002; llm-module 1.3.0 → 1.4.0;
  help-module 1.0.0 (new; core 1.1.0, hello 1.1.0 unchanged).
- **Snapshot**: per-version folder `Aetherix-Alpine_v0.4.2/` (APK + source
  snapshot + docs) via `build-apk.sh`; verified 14/14.
