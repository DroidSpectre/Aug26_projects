# Aetherix-Alpine Fork — Build v0.3a.13

- **Date:** 2026-08-06
- **VersionName:** v0.3a.13 · **versionCode:** 30013
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Recovers from a system kill (Device Care) with a notice + fresh
  shell and explains the RAM gap (free/cached) (FB-033); one Install button
  with an Auto/Manual/Cancel chooser (FB-034); collapsible Hardware card
  (FB-035); BT-keyboard first-digit loss fixed at the warmup race (FB-036);
  `gui vnc` client instructions (FB-037); toolbar Clear that wipes scrollback
  (FB-038); login splash now lists installed modules + command cheatsheet.

## Changes

- **FB-033 — System kill while the terminal was active; RAM gap unexplained**
  (`MainActivity.java`, `TerminalActivity.java`,
  `terminal/TerminalSession.java`, `DevicePayload.java`, `dashboard.html`):
  - Kill recovery: `startShell()` persists `terminal_was_active=true`; clean
    ends (Exit button, exit code 0/143, close-to-dashboard) clear it. On
    `MainActivity.onCreate`, a true marker with no live session means the
    process was killed — the app clears the marker, toasts
    "Previous terminal session was killed — starting a fresh shell", and
    auto-reopens the terminal with a fresh shell. No process resume is
    possible (the PTY tree died with the process); this restores the user to
    the terminal, which was the accepted design.
  - RAM: `DevicePayload` parses `/proc/meminfo` for `MemFree`/`Cached`; the
    Hardware card's RAM row keeps `avail / total` and adds a sub-line
    `free X · cached Y`, explaining the gap vs. the OEM counter.
- **FB-034 — Two install paths; Manual Setup stays live after success**
  (`dashboard.html`):
  - The actions list now has one primary **Install Aetherix** button; it opens
    a modal chooser: **Auto install** (7-step wizard, as before), **Manual
    install** (existing setup page), or **Cancel**.
  - `refreshInstallButton()` still hides the whole button at 7/7 — there is no
    separate Manual button left to disable. Reset & Reinstall remains for
    re-runs.
- **FB-035 — Hardware card takes too much space**
  (`dashboard.html`):
  - The card title is now a toggle (cursor + chevron ▾/▸); tapping collapses
    or expands `#hw-rows`. No persistence required (state survives re-render).
- **FB-036 — First digit still lost (BT keyboard); confirmed a new hole**
  (`terminal/TerminalSession.java`):
  - Root cause: `warmUpReadline()` injects SPACE+DEL to force a readline
    redraw after resize. Its guards (alt-screen, 400 ms idle, non-empty line)
    miss input that arrives while the pty-bridge is still buffering stdin
    during the resize settle — the OSK shrink case — so the injected DEL eats
    the buffered first digit. The BUG-014 guard is intact and unchanged.
  - Fix: a `warmUpPending` flag is set when the prime is scheduled and cleared
    when it fires. `TerminalSession.write()` — the single funnel for all user
    input (keys, IME, paste) — cancels the scheduled prime on the first real
    keystroke. The prime only fires when nothing was typed after the resize.
- **FB-037 — `gui` docs / missing commands**
  (`config/modules/gui-module/tier/gui`, tests, bundle rebuilt):
  - `gui vnc` prints exact client instructions: phone VNC client →
    `127.0.0.1:5901`; PC `adb forward tcp:5901 tcp:5901` then VNC to
    `127.0.0.1:5901`; apps must run under `gui app <cmd>` or `DISPLAY=:1` —
    a bare `x11vnc` outside `gui start` has no display.
  - No fake aliases for nonexistent desktop environments; the splash notes
    desktop environments are optional `apk add` choices.
- **FB-038 — No way to wipe terminal history**
  (`TerminalActivity.java`, `terminal/TerminalEmulator.java`):
  - New **Clear** toolbar button calls `TerminalEmulator.clearScrollback()`
    (blank screen + wipe transcript, same net effect as ESC[2J + ESC[3J,
    buffer-only, never feeds the pty). Shell `clear` keeps its standard
    behavior; Select All still includes scrollback (industry standard).
- **Splash cheatsheet (feature)** (`WelcomeScript.java`, `StepRunner.java`,
  `StorageTier.java`):
  - New shared `WelcomeScript` renders the banner plus `Modules:` (from
    `/etc/aetherix/*.installed`), one-liners for gui/llm/hello, and the
    always-present helpers (`sd`, `module status`, `elv`).
  - Written on fresh installs (Step 5) and refreshed idempotently by
    `StorageTier.deploy()` on app start, so existing installs get it without a
    setup re-run.

## Bugs

| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-033 | System kill while terminal active leaves no trace; RAM gap vs. OEM counter | fixed | process kill destroys the PTY tree (nothing to resume); card showed `availMem` only | kill marker + relaunch notice + auto-reopen fresh shell; `/proc/meminfo` free/cached sub-line |
| FB-034 | Two install paths; Manual Setup stays live after success | fixed | separate buttons, no single entry point | one Install button → Auto/Manual/Cancel chooser; button hidden at 7/7 |
| FB-035 | Hardware card occupies too much screen | fixed | always expanded, not collapsible | title toggle collapses/expands rows (chevron) |
| FB-036 | First digit lost on BT keyboard (OSK shrink mid-typing) | fixed | warmup SPACE+DEL fires while pty-bridge buffers stdin during resize settle; guards can't see buffered input | `warmUpPending` flag; real user input cancels the scheduled prime |
| FB-037 | `gui` has no client instructions; users hit command-not-found for fake commands | fixed | no `vnc` subcommand; docs missing | `gui vnc` prints phone + PC VNC instructions; usage line updated |
| FB-038 | No way to clear terminal scrollback | fixed | only `clear` (visible screen) and Select All exist | toolbar Clear button → `TerminalEmulator.clearScrollback()` |

## Build & Verification Notes

- **Version:** `v0.3a.13` / 30013 (fork line, `scripts/bump-version.sh`).
- **Guest scripts:** `sh -n` passes on `config/modules/gui-module/tier/gui`
  and the generated `00-welcome.sh`; welcome renders the banner, module list
  and cheatsheet with all three module markers present and with none.
- **Kill recovery:** on-device — open Terminal, then `am kill
  com.aetherix.alpine.a` (or Device Care Clean Now); relaunching the app shows
  the notice and reopens a fresh terminal.
- **RAM:** dashboard Hardware card shows `RAM: <avail> avail / <total>` plus
  `free <X> · cached <Y>` from `/proc/meminfo`.
- **Warmup race:** on-device — shrink the OSK (or attach a BT keyboard)
  mid-typing; the first digit must land. `WARMUP: cancelled by user input` in
  the log when the prime is cancelled.
- **Clear:** toolbar Clear blanks the screen and scrollback; Select All still
  includes history.
- **Isolation:** built only with `scripts/build-apk.sh`; `/root/android-dev-env`
  (opencode) and `/root/Android` untouched.
