# v0.3a.13 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship v0.3a.13 with seven user-approved fixes: kill recovery + RAM breakdown, single install chooser, collapsible hardware card, warmup input race fix, `gui vnc` + GUI docs, clear-scrollback action, and a splash cheatsheet.

**Architecture:** All changes are fork-local (package `com.aetherix.alpine.a`). WebView UI in `app/src/main/assets/www/` (dashboard.html); app logic in `app/src/main/java/`; guest CLIs in `config/modules/*/tier/` rebuilt into `assets/modules/*.bundle` by `scripts/build-modules.sh`. Build is manual (`scripts/build-apk.sh`, no Gradle). No changes to `/root/android-dev-env` (opencode) or `/root/Android` (shared SDK, read-only).

**Tech Stack:** Android (minSdk 26, targetSdk 34), plain Java 8, WebView JS bridge, POSIX shell guest scripts (Alpine 3.19), PRoot. Verification: `verify-apk.sh` (13 checks), `sh -n` on shell scripts, Alpine chroot functional tests, on-device manual checks.

**Spec:** `docs/superpowers/specs/2026-08-06-v0.3a.13-design.md`

**Testing conventions (repo has no Java unit-test harness):** each Java change is validated by compile (`scripts/build-apk.sh` javac step) + DEX marker check + on-device manual repro; each shell change by `sh -n` + chroot execution. Commit once per version (repo convention), tag `v0.3a.13`.

---

### Task 1: Kill recovery marker + Dashboard notice + auto-reopen (F1a)

**Files:**
- Modify: `app/src/main/java/com/aetherix/alpine/a/TerminalActivity.java` (`startShell()` ~line 387; Exit/Close handlers ~lines 287-318; `onExit` clean-exit path)
- Modify: `app/src/main/java/com/aetherix/alpine/a/MainActivity.java` (`onCreate` ~line 60)

- [ ] **Step 1:** In `TerminalActivity.startShell()`, after the session starts, persist `aetherix_setup.terminal_was_active = true` (SharedPreferences, same store as `close_to_dashboard`).
- [ ] **Step 2:** Clear the marker on user-initiated clean end: Exit button handler and Close dialog handler set `terminal_was_active = false`; also in `onExit` when `exitCode == 0`.
- [ ] **Step 3:** In `MainActivity.onCreate` (after `setContentView`): if pref `terminal_was_active` is true AND `TerminalSessionManager.getInstance().isSessionActive()` is false → clear the pref, show a one-line Dashboard notice (Toast or a `notice` banner div) "Previous terminal session was killed — starting a fresh shell", then start `TerminalActivity` with `FLAG_ACTIVITY_REORDER_TO_FRONT`.
- [ ] **Step 4:** Verify compile + logic: marker set on startShell, cleared on clean end; onCreate only triggers on fresh process start (not on resume — resume path is FB-028's).

### Task 2: RAM breakdown from /proc/meminfo (F1b)

**Files:**
- Modify: `app/src/main/java/com/aetherix/alpine/a/DevicePayload.java` (`readBatteryMemory`)
- Modify: `app/src/main/assets/www/dashboard.html` (`renderHardware` RAM row ~line 305)

- [ ] **Step 1:** Add a small parser: read `/proc/meminfo`, extract `MemFree`, `MemAvailable`, `Cached` (kB). Add to the battery payload: `memory_free`, `memory_cached` (bytes = kB * 1024).
- [ ] **Step 2:** In `renderHardware`, RAM row stays `avail / total`; add a sub-line when free/cached present: `free X · cached Y` (reuse `fmtBytes`).
- [ ] **Step 3:** Guard all parsing in try/catch; return only when values exist.

### Task 3: Single install button with Auto/Manual/Cancel chooser (F2)

**Files:**
- Modify: `app/src/main/assets/www/dashboard.html` (actions block ~lines 179-185; JS `initiateInstall`, `openSetup`, `refreshInstallButton`)

- [ ] **Step 1:** Replace the `Initiate Install` + `Manual Setup` buttons with one `Install Aetherix` button (`id="btn-install"`, same primary style) whose onclick opens a chooser overlay instead of `initiateInstall()`.
- [ ] **Step 2:** Add a small modal (reuse the existing overlay styling) with three buttons: **Auto install** (calls `initiateInstall()`), **Manual install** (calls `openSetup()`), **Cancel** (hides modal). Copy explains the difference in one line each.
- [ ] **Step 3:** Keep `refreshInstallButton()` hiding `#btn-install` at 7/7 (no separate Manual button remains).
- [ ] **Step 4:** Verify: fresh state shows the chooser; 7/7 hides the install button; `openSetup()` still works from the chooser.

### Task 4: Collapsible Hardware card (F3)

**Files:**
- Modify: `app/src/main/assets/www/dashboard.html` (hw-card markup ~line 145; `renderHardware`)
- Modify: `app/src/main/assets/www/style.css` (`.card-title` cursor + chevron class)

- [ ] **Step 1:** Wrap `#hw-rows` so the card title toggles it: title becomes a clickable span with a chevron (`▾`/`▸`), `onclick` flips `#hw-rows.style.display`.
- [ ] **Step 2:** Add CSS cursor `pointer` on the toggle; initial state expanded.
- [ ] **Step 3:** Verify in WebView: click collapses/expands without breaking the 5s refresh.

### Task 5: Warmup input race fix (F4)

**Files:**
- Modify: `app/src/main/java/com/aetherix/alpine/a/terminal/TerminalSession.java` (`write()` ~line 99-111; `warmUpReadline()` ~line 171-214)

- [ ] **Step 1:** Add `private boolean warmUpPending = false;`. In `warmUpReadline()`, set `warmUpPending = true` when scheduling; in the runnable, set `warmUpPending = false` on execution (all paths).
- [ ] **Step 2:** In `write(byte[], int, int)` (the single funnel for key/IME/paste input), if `warmUpPending`, `warmUpHandler.removeCallbacks(warmUpRunnable); warmUpRunnable = null; warmUpPending = false;` before writing. The warmup injection calls `pty.write(...)` directly, so it never self-cancels.
- [ ] **Step 3:** Keep existing guards (alt-screen, non-empty line). Run `sh`-free compile + reasoning; verify via on-device BT-keyboard repro: digit typed immediately after OSK shrink must land.
- [ ] **Step 4:** Confirm debug logs show no `WARMUP: readline redraw consumed` immediately after an `INPUT` line in the same resize window.

### Task 6: `gui vnc` subcommand (F5)

**Files:**
- Modify: `config/modules/gui-module/tier/gui` (case statement)
- Rebuild: `scripts/build-modules.sh` (regenerates `gui-module.bundle`)

- [ ] **Step 1:** Add a `vnc)` case printing: phone client → `127.0.0.1:5901`; PC → `adb forward tcp:5901 tcp:5901` then VNC to `127.0.0.1:5901`; note apps must run via `gui app <cmd>` (or `DISPLAY=:1`) because a bare `x11vnc` outside `gui start` has no display. Update the `usage` line.
- [ ] **Step 2:** `sh -n` + chroot test: `gui vnc` prints instructions; `gui start`/`stop` still work.
- [ ] **Step 3:** Rebuild bundles; confirm `gui-module.bundle` contains the new case.

### Task 7: Clear scrollback toolbar action (F6)

**Files:**
- Modify: `app/src/main/java/com/aetherix/alpine/a/terminal/TerminalEmulator.java` (add public `clearScreenAndScrollback()` near line 349)
- Modify: `app/src/main/java/com/aetherix/alpine/a/terminal/TerminalSession.java` (expose `clearScrollback()`)
- Modify: `app/src/main/java/com/aetherix/alpine/a/TerminalActivity.java` (toolbar ~lines 101-184)

- [ ] **Step 1:** In `TerminalEmulator`, add `public void clearScreenAndScrollback()` → `blockClear(0, 0, mColumns, mRows); mMainBuffer.clearTranscript();` (mirrors the ESC[2J path at line 1622-1629).
- [ ] **Step 2:** In `TerminalSession`, add `public void clearScrollback() { if (emulator != null) emulator.clearScreenAndScrollback(); }`.
- [ ] **Step 3:** Add a **Clear** button to the toolbar (style like `selectBtn`), onclick calls `session.clearScrollback()` (guarded null).
- [ ] **Step 4:** Compile + verify on device: button wipes visible screen and scrollback; `Select All` afterwards shows only the prompt.

### Task 8: Splash cheatsheet (F7)

**Files:**
- Modify: `app/src/main/java/com/aetherix/alpine/a/StepRunner.java` (00-welcome.sh content ~lines 343-360)
- Modify: `app/src/main/java/com/aetherix/alpine/a/StorageTier.java` (deploy refresh of 00-welcome.sh, alongside `device-info`)

- [ ] **Step 1:** Extend the welcome script: after the banner, print `Modules:` names from `/etc/aetherix/*.installed`, then per-module one-liners (gui, llm, hello) and always-present helpers (`sd`, `module status`, `elv`) — ~12-16 lines total, guarded by `PROOT_WELCOME_SHOWN` as today.
- [ ] **Step 2:** Add idempotent `writeWelcomeScript(rootfs)` to `StorageTier` (same pattern as `writeDeviceInfo`) and call it from `deploy()` so existing installs get the new splash without re-running setup.
- [ ] **Step 3:** Verify in the Alpine chroot: source the script → banner + cheatsheet print; installed-marker listing works; script is idempotent.

### Task 9: Docs (BUGS register, per-build + series changelogs, spec/plan export)

**Files:**
- Modify: `docs/BUGS.md` (FB-033…FB-038 rows)
- Create: `docs/v0.3a.13/README.md`, `docs/v0.3a.13/CHANGELOG.md` (via `scripts/release-docs.sh`)
- Modify: `docs/v0.3-series/CHANGELOG.md`
- Modify: `scripts/release-docs.sh` — copy `docs/superpowers/specs/*.md` and `docs/superpowers/plans/*.md` into `$DOCS_DIR/` so plans/specs export to the device tree automatically

- [ ] **Step 1:** Patch `release-docs.sh` to copy specs + plans into the version docs dir.
- [ ] **Step 2:** Run `scripts/bump-version.sh` (→ v0.3a.13 / 30013) and `scripts/release-docs.sh v0.3a.13 -m "..."`.
- [ ] **Step 3:** Fill README/CHANGELOG (FB-033…FB-038 + splash), update BUGS.md and series changelog.
- [ ] **Step 4:** Copy the spec + plan into `/sdcard/Download/Aetherix-Alpine-Fork/docs/v0.3a.13/`.

### Task 10: Build + verify + export

**Files:**
- Run: `bash scripts/build-apk.sh`
- Run: `bash config/modules/hello-module/tests/verify-apk.sh v0.3a.13`

- [ ] **Step 1:** `bash scripts/build-modules.sh` (fresh bundles).
- [ ] **Step 2:** `bash scripts/build-apk.sh` — must compile clean (javac) and produce `Aetherix-Alpine-v0.3a.13.apk` (30013).
- [ ] **Step 3:** `verify-apk.sh v0.3a.13` → 13/13 PASS; confirm `assets/modules/{hello,gui,llm}-module.bundle` and new DEX markers present; device export tree updated (`/sdcard/Download/Aetherix-Alpine-Fork/`).

### Task 11: Commit + tag

- [ ] **Step 1:** `git add -A && git commit -m "v0.3a.13: ... (FB-033..FB-038)"`.
- [ ] **Step 2:** `git tag v0.3a.13`; verify clean tree; report to user with on-device test list.
