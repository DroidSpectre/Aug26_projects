# v0.3a.13 — Design: Kill recovery + RAM breakdown, install chooser, collapsible hardware card, warmup input race, GUI/terminal UX, splash cheatsheet

- **Date:** 2026-08-06
- **Build:** v0.3a.13 (versionCode 30013)
- **Package:** `com.aetherix.alpine.a` (unchanged)
- **Status:** approved by user (2026-08-06) — awaiting spec review before planning

## Scope

Seven user-approved items, all app-side / module-side, no Gradle/SDK changes, no
impact on the opencode tree:

1. Kill recovery + RAM breakdown (Device Care)
2. Single install button with Auto/Manual/Cancel chooser
3. Collapsible Hardware card
4. Terminal warmup race fix (BT-keyboard first-digit loss)
5. `gui vnc` subcommand + accurate GUI docs
6. "Clear scrollback" terminal action
7. Terminal splash: installed modules + command cheatsheet

**Out of scope (roadmap, unchanged):** in-app VNC viewer, in-app LLM chat UI,
LLM model manager, desktop environments (Xfce/GNOME — user-installed via apk),
USB-host peripherals, X-in-app GPU variant.

## F1 — Kill recovery + RAM breakdown

**Problem:** Samsung Device Care "Clean Now" kills the app (data survives; the
process doesn't). On relaunch the Dashboard opens with no trace of the terminal
that was running. RAM: the card shows `availMem` only, which differs from the
OEM counter and confuses users.

**Design:**
- Persist `aetherix_setup.terminal_was_active = true` when a terminal session
  starts (`TerminalActivity.onCreate` → `startShell`), and set it `false` on
  clean end (Exit button, exit code 0, or Close-to-dashboard).
- On `MainActivity.onCreate`: if the marker is `true` and no live in-memory
  session exists (i.e. the process died), show a one-line notice on the
  Dashboard ("Previous terminal session was killed — starting a fresh shell")
  and auto-start `TerminalActivity` (fresh session). No process resume is
  possible (PTY tree is gone); this restores the user to the terminal.
- RAM: `DevicePayload` additionally parses `/proc/meminfo` for `MemFree`,
  `MemAvailable`, `Cached` (kb). Dashboard RAM row keeps `avail / total` and
  adds a sub-line `free X · cached Y` so the gap vs. OEM counters is
  explainable. `/proc/meminfo` is readable by apps (not on the blocked list).

**Files:** `MainActivity.java`, `TerminalActivity.java`, `DevicePayload.java`,
`dashboard.html`.

## F2 — Single install button with chooser

**Problem:** "Initiate Install" and "Manual Setup" are separate buttons;
"Manual Setup" stays live after a successful install.

**Design:**
- Dashboard actions become: **Install Aetherix** (primary), Modules & Storage,
  View Log, Reset & Reinstall, Share Error Report.
- The single Install button opens a small modal chooser: **Auto install**
  (existing 7-step wizard + walkthrough), **Manual install** (existing setup
  page `index.html`), **Cancel**.
- `refreshInstallButton()` keeps hiding the whole install button at 7/7 (no
  separate Manual button left to disable). Reset & Reinstall remains available
  for re-runs.

**Files:** `dashboard.html` (buttons + chooser modal + JS).

## F3 — Collapsible Hardware card

**Design:** The Hardware card title becomes a toggle; clicking it hides/shows
`#hw-rows` (chevron ▸/▾). No persistence required.

**Files:** `dashboard.html`, `style.css` (cursor + chevron).

## F4 — Warmup input race (first-digit loss)

**Problem (root cause confirmed):** `TerminalSession.warmUpReadline()` injects
`SPACE+DEL` after a resize to force a readline redraw. Its guards (alt-screen,
400 ms idle, non-empty line) miss input that arrives while the pty-bridge is
buffering stdin during the resize settle — the BT-keyboard case: OSK shrink →
resize mid-typing → the buffered first digit is invisible to the guard → the
injected `DEL` consumes it. Same failure mode as upstream BUG-014 through a new
hole; the BUG-014 guard is intact and must stay.

**Design:**
- Track a pending-warmup flag: when `warmUpReadline()` schedules the runnable,
  set `warmUpPending = true`.
- In `TerminalSession.write(byte[], int, int)` (the single funnel for all user
  input — key events, IME, paste), if `warmUpPending`, cancel the scheduled
  runnable (`removeCallbacks` + null) and clear the flag. The warmup injection
  itself calls `pty.write(...)` directly, so it never self-cancels.
- Keep the existing guards (alt-screen, non-empty line) as a second line of
  defense; the 400 ms idle check becomes redundant but harmless.
- Result: the SPACE+DEL prime only fires when no keystroke arrived after the
  resize, closing the race completely.

**Files:** `TerminalSession.java`.

## F5 — `gui vnc` subcommand + accurate GUI docs

**Problem:** Users try `setup-desktop`, `setup-gui`, `vnc`, `ui`, `xfce`,
`xvfb` and hit command-not-found; a bare `x11vnc` run fails because `DISPLAY`
isn't set outside `gui start`.

**Design:**
- `gui` CLI gains a `vnc` subcommand that prints the exact working client
  instructions: phone-side VNC client → `127.0.0.1:5901`; PC-side
  `adb forward tcp:5901 tcp:5901` then VNC to `127.0.0.1:5901`; note that apps
  must be started with `gui app <cmd>` (or `DISPLAY=:1`) — a bare `x11vnc`
  outside `gui start` has no display.
- No fake aliases for nonexistent desktop environments; the splash (F7)
  documents that desktop environments are optional `apk add` choices.

**Files:** `config/modules/gui-module/tier/gui` (+ bundle rebuild).

## F6 — Clear scrollback action

**Problem:** `clear` only blanks the visible screen (standard); Select All
including scrollback is also standard and stays. Users want an explicit way to
wipe history.

**Design:**
- Add a **Clear** button to the `TerminalActivity` toolbar that clears the
  emulator's transcript: `TerminalEmulator.clearTranscript()` (already used for
  scrollback-erase sequences) + a visible-screen clear. Keeps `clear` semantics
  standard.
- Select All behavior unchanged (includes scrollback).

**Files:** `TerminalActivity.java`, `TerminalEmulator.java` (expose a
`clearScrollback()` wrapper), `TerminalSession.java` (expose method if needed).

## F7 — Splash: modules + command cheatsheet

**Problem:** The login splash shows only the version banner; users don't know
what's installed or what commands exist.

**Design:**
- Extend `etc/profile.d/00-welcome.sh` (written in Step 5; one-shot per login
  via `PROOT_WELCOME_SHOWN`). After the existing banner lines, print:
  - `Modules:` — names from `/etc/aetherix/*.installed` markers
    (hello-module / gui-module / llm-module), or "none".
  - Per-installed-module one-liners, e.g.:
    - gui: `gui setup && gui start` → VNC `127.0.0.1:5901` (`gui vnc` for client
      instructions)
    - llm: `llm setup` (builds llama.cpp, 10–30 min), `llm model ~/models/<f>.gguf`,
      `llm start`, `llm ask "…"`
    - hello: `aetherix-selftest`, `aetherix-smoke`
  - Always-present helpers: `sd` (storage), `module status` (modules), `elv`
    (adb elevation).
- Keep it ~12–16 lines total (a splash, not a manual).
- Upgrade path: also write/refresh `00-welcome.sh` from `StorageTier.deploy()`
  (idempotent, like `device-info`) so existing installs get it without a setup
  re-run.

**Files:** `StepRunner.java` (welcome script content), `StorageTier.java`
(deploy refresh), rebuilt `hello-module.bundle` if the hello post-install is
used for tests.

## Verification

- **F4:** host-level reasoning + on-device repro: BT keyboard, type a digit
  immediately after the OSK shrinks; the digit must land. Chroot test of the
  `gui vnc` output and splash rendering (`sh -n` + run the script in the
  Alpine chroot).
- **F2/F3/F6:** `verify-apk.sh` 13/13 + manual dashboard checks (chooser modal,
  card toggle, toolbar Clear).
- **F1:** fresh-install + kill simulation (am kill) → relaunch shows notice +
  auto-reopens terminal; RAM sub-line renders.
- Build only via `scripts/build-apk.sh`; export tree
  `/sdcard/Download/Aetherix-Alpine-Fork/` refreshed; version bump + docs
  (`docs/v0.3a.13/`, `BUGS.md`, series changelog, per-build changelog).

## Bug IDs

- FB-033 — kill recovery + RAM breakdown (F1)
- FB-034 — install chooser (F2)
- FB-035 — hardware card collapse (F3)
- FB-036 — warmup input race (F4)
- FB-037 — `gui vnc` + GUI docs (F5)
- FB-038 — clear scrollback action (F6)
- Splash cheatsheet (F7) is a feature, not a bug — recorded in the changelog.
