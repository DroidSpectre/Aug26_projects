# Aetherix-Alpine Fork — Changelog

## v0.3a.13 (fork)

Kill recovery + RAM breakdown, install chooser, collapsible hardware card, warmup input race fix, gui vnc docs, clear-scrollback action, splash cheatsheet
