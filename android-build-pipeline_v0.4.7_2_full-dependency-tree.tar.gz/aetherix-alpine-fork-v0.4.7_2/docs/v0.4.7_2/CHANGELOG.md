# Aetherix-Alpine Fork — Changelog

## v0.4.7_2 (fork sub-release)

Device UX re-cut of v0.4.7_1 (FB-132), from on-device terminal feedback.

- **FB-132 — wizard wait loop floods the screen**: `wf_build()` re-dumped the
  five data cards (06-setup, 25-llm, 27-llm-setup, 28-llm-models,
  17-io-dropbox; ~24 lines each) on every 30s poll while the detached
  llama.cpp build ran. Now the cards print once and each poll shows a live
  progress line (`tail -n 3` of the build log + elapsed minutes); the wizard
  prints a "build finished / build failed" summary when the wait ends.
  `WIZARD_SHOW_CARDS=0` skips the card dump.
- **FB-132 — scrollback cut short**: terminal transcript was 2000 rows;
  raised to 10,000 (`DEFAULT_TERMINAL_TRANSCRIPT_ROWS`).
- **FB-132 — menus/tour scattered and unreadable at 63 cols**: new `say()`
  helper folds UI text at the terminal width (word boundaries, 40–120 clamp,
  `SAY_WIDTH` override); applied across `tier/llm` + tier libs; wizard and
  `llm hf` model lists shortened to fit 63 cols unwrapped.
- **FB-132 — replies leak JSON tails**: `parse_reply`'s cleanup `sed` missed
  the standard `"},"finish_reason"` suffix, so normal completions ended with
  raw JSON; added `"},"finish_reason"` / `"},"index"` strip patterns.
- Sandbox suite: T27d/T27e (cards-once + live progress + show-cards=0),
  T41 (say folding), T42 (help/capabilities/context/wizard ≤63 cols) — now
  133 checks, 0 failed.
- Versions: app `v0.4.7_2` / versionCode `40072` (monotonic above 40071);
  llm-module `1.9.2`; help-module `1.6.0`; core-module `1.4.0`. Bundles
  regenerated; APK + export tarball re-cut.
