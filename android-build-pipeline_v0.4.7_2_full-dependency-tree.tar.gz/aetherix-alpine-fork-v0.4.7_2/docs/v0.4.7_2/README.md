# Aetherix-Alpine v0.4.7_2 — device UX re-cut (scrollback, wizard wait, 63-col wrapping)

One more correctness pass over v0.4.7 (FB-132), driven by on-device feedback:
the terminal scrollback was cut short, the wizard flooded the screen re-printing
help cards while llama.cpp built, and long help/tour lines hard-wrapped ragged
at the device's 63-column terminal.

## What changed
1. **`llm wizard` no longer floods the scrollback.** The old wait loop re-dumped
   all five data cards (~120 lines) every 30 seconds while the detached build
   ran. Now the cards print once, then each poll shows a short live-progress
   line: the last 3 build-log lines + elapsed minutes. `WIZARD_SHOW_CARDS=0`
   skips the cards entirely; Ctrl-C / `WIZARD_NO_WAIT=1` behave as before.
2. **Scrollback 2000 → 10,000 rows.** Long builds and chat sessions no longer
   push history out of reach (still only a few MB at phone widths).
3. **63-column wrapping everywhere.** A new `say()` helper folds help, tour,
   status, capabilities, and context text at the terminal width (word
   boundaries; 40–120 col clamp; `SAY_WIDTH` override). The wizard model menu
   and `llm hf` menu were shortened/reformatted so they fit a 63-col terminal
   without wrapping at all.
4. **Reply JSON-tail leak fixed.** `parse_reply` now strips the standard
   `"},"finish_reason"` suffix, so normal replies no longer end with raw JSON
   (the wizard's sample answer showed this on-device).

## Verification
Sandbox suite grown to 133 checks (was 118): T27d/T27e assert the wizard
prints each card once + live progress + done marker, and that
`WIZARD_SHOW_CARDS=0` skips cards; T41 asserts `say()` folding; T42 asserts
`llm help` / `llm capabilities` / `llm context` / the wizard tour all fit a
63-col terminal.

## Versions
- App: v0.4.7_2 / versionCode 40072 (monotonic above v0.4.7_1's 40071).
- Modules: core 1.4.0, llm 1.9.2, help 1.6.0.
