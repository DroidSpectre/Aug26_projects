# Aetherix-Alpine Fork — Build v0.3a.3

- **Date:** 2026-08-05
- **VersionName:** v0.3a.3 · **versionCode:** 30003
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** UX completion batch — dashboard-first boot, Initiate Install
  walkthrough + fully automatic 7-step install (one step, one test, in order),
  storage access moved into the Step 3 permission chain, step-label audit
  (FB-005), storage-permission flow fix (FB-006), and the v0.3.3 telemetry
  dashboard card that was missing from the plan.

## Changes
- **Dashboard-first boot** (`MainActivity`): app now always loads
  `www/dashboard.html`. The manual setup page stays available as "Manual Setup".
- **Initiate / Resume Install button** (`dashboard.html`): shows "Initiate Install"
  on fresh setup, "Resume Install" on partial progress, and swaps to a primary
  "Open Terminal" once all 7 steps are tested.
- **Walkthrough modal**: greeting + app purpose, one page per step (name,
  description, why it matters, what it needs — sourced from a new
  `InstallBridge.getStepInfo()` so walkthrough, setup page, and error report
  share one source of truth), then a final Start page. The per-step `INFO:`
  popups are no longer shown during the automatic flow (they remain on the
  manual setup page).
- **Automatic install engine** (`InstallBridge.startAutoInstall()`): runs steps
  1–7 in order, each install followed by its test, never skipping; live log is
  auto-shown and polled on the dashboard; only real confirmations pause it
  (internet test + permission prompts). On failure it stops, logs the failed
  step, and the button becomes "Resume Install" (restarts from the failed step).
- **Step 3 permission chain** (`InstallBridge`): now 3 prompts — notification
  permission (API 33+), battery-optimization settings, then All-files storage
  access (API 30+). The manual "Grant All-files Access" button was removed from
  `modules.html` (grant state is still displayed there).
- **Step-label audit** (`StepRunner`): fixed all hard-coded labels that didn't
  match the display step numbers (see FB-005).
- **Telemetry card** (`dashboard.html` + `InstallBridge.getTelemetry()`): new
  Hardware card showing battery %, temperature, voltage, memory used/total, SoC
  platform, GPU vendor, and CPU temp from `DevicePayload` + the rootfs
  `device.conf` (this closes the v0.3.3 plan item that was never wired up).

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-005 | Step labels/logs reference wrong step numbers | fixed | Hard-coded "Step N" strings drifted from the display names after the BUG-010/BUG-011 rename (internet dialog said Step 4; step4Launcher logged "Step 3 complete"; step5AlpineInit logged "Step 4 complete"; step6PtyBridge/step7ShellVerify prerequisites referenced the wrong step; step 7 logged "Verifying Shell Environment" instead of "Test & Verify") | Corrected all six label sites in `StepRunner.java` to match display step numbers (Step 5 = Alpine Init, Step 6 = PTY Bridge, Step 7 = Test & Verify) |
| FB-006 | Storage access only reachable via the module-page button | fixed | All-files request was not part of the Step 3 permission flow; module page had the only trigger | Added storage as the 3rd post-Step-3 prompt (after notification + battery) via `showStoragePrompt()`; removed the manual button from `modules.html` |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30003' versionName='v0.3a.3'`.
- DEX verified: `startAutoInstall`, `getStepInfo`, `getTelemetry`,
  "Step 5 (Alpine Init)…", "Step 6 (PTY Bridge)…", "Step 6 must complete first",
  "Step 7/7: Test & Verify" present; old strings ("Step 4 (Alpine Init)",
  "Step 5/6 (PTY Bridge)", "Verifying Shell Environment") absent.
- `dashboard.html` asset contains walkthrough/auto-install/telemetry handlers;
  `modules.html` no longer contains "Grant All-files Access".
- Snapshot `Aetherix-Alpine-v0.3a.3-source.zip` exported with the APK + docs to
  `/sdcard/Download/Aetherix-Alpine-Fork/`.
- On-device verification still required: fresh install → boots to dashboard →
  Initiate Install → walkthrough → automatic 1-install/1-test per step with
  visible log → Step 3 prompts (internet, notification, battery, storage) →
  all tested → Open Terminal; Manual Setup page still works; Hardware card
  populated.
