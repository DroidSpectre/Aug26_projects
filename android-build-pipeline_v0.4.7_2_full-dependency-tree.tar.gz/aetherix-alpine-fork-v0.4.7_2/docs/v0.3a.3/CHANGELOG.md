# Aetherix-Alpine Fork — Changelog

## v0.3a.3 (fork)

UX completion batch:
- Dashboard-first boot; Initiate/Resume Install button on the dashboard; Open
  Terminal becomes primary when all 7 steps are tested.
- Walkthrough modal (greeting, app purpose, 7 step pages, start) fed by a single
  `getStepInfo()` source of truth.
- `startAutoInstall()` runs steps 1-7 automatically, one install + one test per
  step, in order, with a live visible log; stops on failure and resumes from the
  failed step.
- Storage access moved into the Step 3 permission chain (notification → battery
  → All-files); manual module-page button removed.
- FB-005: step-label audit fixed all hard-coded "Step N" mismatches in
  StepRunner (internet dialog, complete messages, prereq skips, step-7 name).
- FB-006: storage permission flow fixed (was module-page-only).
- v0.3.3 telemetry tier UI: Hardware card (battery/temp/voltage/memory/SoC/GPU)
  on the dashboard via `getTelemetry()`.
