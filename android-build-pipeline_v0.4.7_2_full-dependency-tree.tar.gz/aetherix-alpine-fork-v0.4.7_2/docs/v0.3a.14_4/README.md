# Aetherix-Alpine Fork — Build v0.3a.14_4

- **Date:** 2026-08-06
- **VersionName:** v0.3a.14_4 · **versionCode:** 30144
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Module dependency system: a new `core-module` bundles the shared
  base + build toolchain, every module declares `requires:` in `module.yml`, and
  the app + guest CLI gate availability and installs on dependency satisfaction.
  Expands help text across the tiers (`module help`, `llm help`, `gui help`,
  `elv help`, `core help`). The `llm` tier now builds llama.cpp **adaptively**
  (device CPU-feature probes, RAM-aware parallelism, OpenMP fallback) and
  **detached** (survives screen-off and terminal resizes). Setup Step 5 installs
  the base Alpine package set (openrc, openssh, nano, htop, iproute2, ...).

## Changes

- **FB-057 — Module dependencies + core-module**
  (`config/modules/core-module/*`, `config/modules/{hello,gui,llm}-module/module.yml`,
  `ModuleManager.java`, `InstallBridge.java`):
  - New `core-module` bundles the shared dependency set: base packages
    (`bash coreutils ncurses-terminfo ca-certificates-bundle`) plus the build
    toolchain (`build-base cmake git curl linux-headers openssl-dev ccache ninja`)
    and optional `libomp` (best-effort). `linux-headers` fixes the hard
    `linux/limits.h` build failure found in the Alpine llama.cpp baseline.
  - `module.yml` gains `description`, `requires` (module deps), `requires-pkgs`
    and `recommends-pkgs`. `hello/gui/llm` all declare `requires: core-module`.
  - `listModules()` returns `description`, `requires`, `blocked`, `missingRequires`;
    a module is **available only when its deps are installed**. The Modules page
    shows Blocked modules with the missing deps and no Install button.
  - `installModule()` refuses installs with unmet deps; `uninstallModule()`
    refuses to remove a module other installed modules depend on (reverse-dep
    guard); the installed `info` file records `requires:`.
  - Post-install timeout raised 3 min → 10 min (core-module's apk add is large).
- **FB-058 — Help text and user instructions**
  (`app/src/main/assets/tier/module.sh`, `config/modules/{llm,gui}-module/tier/*`,
  `app/src/main/assets/tier/elv.sh`, `config/modules/core-module/tier/core`,
  `WelcomeScript.java`):
  - `module help` = full install guide (install order, dependency rules,
    per-module quick reference); `module help <name>` = per-module help.
  - `module available` lists every bundle in the drop folder with dependency
    status (`ready` / `blocked (install first: ...)` / `installed`); `module deps <name>`
    checks an installed module's dependencies.
  - `llm help`, `gui help`, `elv help`, `core help` subcommands with setup,
    usage and troubleshooting; welcome banner now leads with `module help` and
    lists `core status` once core-module is installed.
- **FB-059 — Bundled modules mirrored to the drop folder**
  (`ModuleManager.syncBundledModules()`, `InstallBridge.java`):
  - On every app start the APK's bundled modules are copied into
    `Download/Aetherix-Alpine-Fork/modules/`, so the guest `module available`
    CLI works on a fresh install and the bundles are visible in file managers.
    APK copies always win over stale drop tarballs (FB-048 policy).

- **FB-060 — Adaptive, detached llama.cpp build**
  (`config/modules/llm-module/tier/llm`):
  - The build now runs **detached** (`setsid`, own session) with output to
    `/var/log/llm-build.log`, so terminal resize signals (the session-wide
    SIGWINCH chain) and session teardown can never interrupt compilers — the
    failure mode found in the 14_3 baseline testing.
  - Build flags are adaptive like llama.cpp itself: `-DGGML_NATIVE=ON` probes
    the device's CPU (dotprod/SVE/FMA/i8mm) and enables only what is supported;
    `-DCMAKE_BUILD_TYPE=RelWithDebInfo` (-O2) lowers peak RAM on the huge TUs;
    Ninja + ccache (both installed by core-module) speed the compile and make
    resumes cheap; final binary is stripped.
  - Parallelism scales with the device: jobs = 2 on <6 GiB RAM, else min(nproc,
    4); `LLM_JOBS=<n> llm setup` overrides.
  - Configure falls back across generator/OpenMP differences (existing build
    dir from an older setup, toolchain without OpenMP) before failing.
  - New state machine + commands: `llm build-status`, `llm build-log [n]`;
    `llm setup` reports a running build and finishes the install when done.
    `llm help` documents all of it.
- **FB-061 — Setup Step 5 base packages**
  (`StepRunner.java`, `InstallBridge.java`):
  - Step 5 now also installs `alpine-base alpine-conf openrc tzdata util-linux
    shadow procps nano htop bash-completion openssh iproute2` so a fresh
    environment has a real base OS (init scripts, user tools, sshd, networking).
  - Licenses page lists the new Step-5 packages; step-info strings updated.

## Research — PRoot vs bionic (decision)

Asked: does the app need to be rebuilt to use bionic, or is the PRoot approach
actually good? Decision: **keep PRoot; no rebuild.** The app is already a native
Android app (Java/ART + JNI PTY bridge); "bionic" would only change the *guest*
userspace. A bionic-linked guest is what Termux does, but it requires building
and maintaining a full Termux-style package repo (thousands of build scripts) —
not feasible for this fork. PRoot gives the whole Alpine ecosystem via `apk`,
real root semantics inside the sandbox, and per-module bundles without porting
anything. Its cost is syscall-trace overhead (matters for *builds*; negligible
for inference) and app-lifecycle coupling (mitigated by the session wakelock +
detached build strategy). The Termux speed gap seen in the baselines was
flags/parallelism/ccache, not libc. If native speed is ever needed for llama
specifically, ship a prebuilt static musl binary (works under PRoot, no bionic).
