# Aetherix-Alpine Fork — Changelog

## v0.3a.14_4 (fork)

Module dependency system: core-module bundles the shared base + build toolchain,
modules declare requires in module.yml, app UI + install path + guest `module`
CLI gate availability on installed deps (blocked modules are not installable;
uninstall refuses while dependents exist). Expanded help text (module help /
available / deps, llm help, gui help, elv help, core help, welcome banner).
Bundled modules mirrored to the drop folder on app start.
llm build is now adaptive (CPU-feature probes, RAM-aware jobs, OpenMP/Ninja
fallbacks, -O2) and detached (setsid + log) with llm build-log/build-status;
setup Step 5 installs the base Alpine package set (openrc, openssh, nano, htop,
iproute2, ...).
