# Aetherix-Alpine Fork — Changelog

## v0.3a.2 (fork)

FB-004: Step 7 self-test fix. Removed the invalid in-guest `proot --version` check
(PRoot is a host-side binary, not in the Alpine rootfs PATH, so the chain exited 127
before `SELF_TEST_PASS`). Self-test now verifies `bash`, `apk`, and `coreutils`
inside the guest and keeps stderr visible for future diagnosis. PRoot itself remains
verified by every launcher invocation.
