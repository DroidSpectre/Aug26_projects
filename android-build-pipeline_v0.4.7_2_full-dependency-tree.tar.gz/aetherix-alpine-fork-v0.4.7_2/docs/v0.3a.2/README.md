# Aetherix-Alpine Fork — Build v0.3a.2

- **Date:** 2026-08-04
- **VersionName:** v0.3a.2 · **versionCode:** 30002
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged from v0.3a.1)
- **Summary:** Fixes Step 7's final self-test, which always failed on-device
  because it ran `proot --version` *inside* the prooted Alpine guest, where no
  `proot` binary exists in PATH.

## Changes
- **FB-004** — `step7ShellVerify` self-test chain rewritten
  (`app/src/main/java/com/aetherix/alpine/a/StepRunner.java`):
  - Removed `proot --version >/dev/null 2>&1` from the chain. The PRoot binary is
    a host-side library (`libproot.so` in the app native lib dir) that the
    launcher `exec`s; it is **not** present in the Alpine rootfs PATH, so inside
    the guest `proot --version` exited 127 (`proot: not found`) and short-circuited
    the `&&` chain before `SELF_TEST_PASS` could be echoed. PRoot is already
    exercised by every launcher invocation (the shell test and the self-test
    itself both run through `proot-launch.sh`).
  - Replaced the invalid check with in-guest checks of the components actually
    installed in Step 4/5: `bash --version`, `apk --version`, `which coreutils`.
  - Kept stderr visible (`>/dev/null` without `2>&1`): `execStreaming` merges
    stderr into the captured output, so a future missing component will show
    `not found` in the error report instead of failing silently like this one did.
  - Marker unchanged: step passes only when output contains `SELF_TEST_PASS`.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-004 | Step 7 self-test always fails: no `SELF_TEST_PASS` on device | fixed | Self-test chain ran `proot --version` inside the guest; PRoot is a host-side binary (`libproot.so`) absent from the Alpine rootfs PATH, so the chain exited 127 before the marker; `>/dev/null 2>&1` hid the cause | Self-test now checks in-guest `bash`, `apk`, `coreutils` (all installed in Step 4/5); stderr kept visible for diagnosis; PRoot itself remains verified by every launcher run |

## Upstream Cross-Reference
- The faulty chain exists in the current opencode tree
  (`/root/android-dev-env/app/src/main/java/com/aetherix/alpine/StepRunner.java`,
  added as BUG-010 in v0.3.1). The 15x release (`v0.2.25_15x`) had **no** self-test.
- Fix applied on the fork only; upstream tree untouched.

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30002' versionName='v0.3a.2'`.
- Self-test chain (as compiled): `echo VERSION=$AETHERIX_VERSION && bash --version >/dev/null && apk --version >/dev/null && which coreutils >/dev/null && echo SELF_TEST_PASS`.
- Snapshot `Aetherix-Alpine-v0.3a.2-source.zip` contains the fixed source tree
  (no build artifacts), exported with the APK to the fork device tree.
- On-device verification still required: install v0.3a.2 and confirm Step 7
  reaches "All steps complete!" (`SELF_TEST_PASS` in the log).
