# Aetherix-Alpine Fork — Changelog

## v0.3a.7 (fork)

Final tweaks + all remaining tiers in one build: storage cd aliases, module status CLI, elevation (adb self-connect), GUI (X+VNC), LLM (llama.cpp)
