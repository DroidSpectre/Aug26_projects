# Aetherix-Alpine Fork — Build v0.3a.7

- **Date:** 2026-08-05
- **VersionName:** v0.3a.7 · **versionCode:** 30007
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Finishes the current tweaks and ships all remaining plan tiers
  in one build: storage cd aliases, in-terminal `module status`, and the
  elevation / GUI / LLM foundations (Parts 5–7) as install-testable CLIs +
  dashboard cards.

## Changes
- **FB-016 — storage cd aliases** (`StorageTier.deployAliases`):
  - The guest `.bashrc` now defines `storage`, `shared`, `external`, `usb` as
    cd aliases, so instead of `cd ~/storage/shared` you can type `shared`.
- **FB-017 — `module status` CLI** (`assets/tier/module.sh`):
  - New in-terminal `module status` / `module list` prints installed modules +
    versions + total (plan Part 3 carryover). Installs still happen from the
    Modules page.
- **FB-018 — Elevation tier foundation (plan Part 5)** (`assets/tier/elv.sh`):
  - `elv setup` installs `android-tools` (real `adb`) in the guest; `elv pair
    <port> <pin>` pairs over loopback wireless debugging; `elv connect`,
    `elv shell <cmd>` (uid 2000), `elv status`, `elv disconnect`. State in
    `/etc/aetherix/elevation.{state,conf}`.
  - Dashboard **Elevation (adb)** card: Wireless Debugging shortcut, pairing
    port/PIN inputs, Install/Connect/Status/Disconnect buttons.
  - Degrades gracefully: if the kernel blocks loopback adb, status shows
    `error` and the app stays sandboxed.
- **FB-019 — GUI tier foundation (plan Part 6)** (`assets/tier/gui.sh`):
  - `gui setup` installs `xvfb x11vnc openbox xterm`; `gui start` runs Xvfb :1
    + openbox + x11vnc (loopback, 127.0.0.1:5901); `gui stop`, `gui status`,
    `gui app <cmd>` launches an app on the X display.
  - Dashboard **GUI (X + VNC)** card with Install/Start/Stop/Status.
  - In-app VNC viewer remains roadmap; from a PC:
    `adb forward tcp:5901 tcp:5901` + any VNC client.
- **FB-020 — LLM tier foundation (plan Part 7)** (`assets/tier/llm.sh`):
  - `llm setup` installs `llama.cpp` + `curl`; `llm model <path.gguf>`,
    `llm start` runs the OpenAI-compatible server on 127.0.0.1:8080;
    `llm ask "<q>"` queries it; `llm stop`, `llm status`. Models live in
    `~/models/`.
  - Dashboard **LLM (llama.cpp)** card: Install/Start/Stop/Status + model path
    input.
  - In-app chat UI remains roadmap.
- **Tier plumbing** (`StorageTier`, `InstallBridge`, `dashboard.html`):
  - `assets/tier/*.sh` are copied idempotently to `/usr/local/bin` on every
    app start (content-hash compare), so upgrades pick up script fixes.
  - Bridge: `getTierStatus()` (state files + rootfs readiness),
    `runTier(cli, args)` (whitelisted CLI + sanitized args, 60s/300s timeouts),
    `openWirelessDebugging()`.
  - Dashboard: three new cards shown once setup completes, 10s auto-refresh,
    output console for tier commands.
- **Plan reconciliation:** Parts 5–7 marked "shipped foundation" (on-device
  verification pending); Part 3 `module status` marked shipped; note added
  explaining the deliberate one-build condensation.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-016 | No short way to jump to device storage from the prompt | fixed | mapping existed only as full paths | `storage`/`shared`/`external`/`usb` cd aliases in guest `.bashrc` |
| FB-017 | No in-terminal module status (plan Part 3) | fixed | only dashboard showed module state | `module status/list` CLI reading `/etc/aetherix/modules.d` |
| FB-018 | Elevation tier (Part 5) not implemented | fixed (foundation) | roadmap | `elv` CLI + dashboard card; loopback adb pair/connect/shell |
| FB-019 | GUI tier (Part 6) not implemented | fixed (foundation) | roadmap | `gui` CLI (Xvfb+openbox+x11vnc) + dashboard card |
| FB-020 | LLM tier (Part 7) not implemented | fixed (foundation) | roadmap | `llm` CLI (llama.cpp server) + dashboard card |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30007' versionName='v0.3a.7'`.
- All `assets/tier/*.sh` + regenerated `sd`/`device-info` pass `sh -n`;
  selftest script `sh -n` clean; dashboard JS passes `node --check`.
- Host-side `verify-apk.sh` passes 13/13.
- On-device verification still required (T11–T13 in the bundled TESTPLAN):
  1. `shared` alias jumps to device storage; `module status` lists modules.
  2. Elevation: install adb, pair/connect/shell with wireless debugging.
  3. GUI: start, verify VNC port, launch an app.
  4. LLM: install, set a GGUF model, start, `llm ask`.
