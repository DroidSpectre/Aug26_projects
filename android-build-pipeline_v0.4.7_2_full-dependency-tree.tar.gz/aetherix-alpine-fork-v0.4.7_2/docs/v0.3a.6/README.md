# Aetherix-Alpine Fork — Build v0.3a.6

- **Date:** 2026-08-05
- **VersionName:** v0.3a.6 · **versionCode:** 30006
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Hardware card expansion (RAM/storage/app size/charging/network/CPU/GPU/NPU),
  notification tap-to-open, Termux-style `~/storage` mapping, module UX fixes
  (version/count/setup hint), plus a stronger rootfs-ready gate.

## Changes
- **FB-011 — module list UX** (`ModuleManager`, `modules.html`):
  - Bundled and drop-folder modules now show their real version from
    `module.yml` before install (was "unknown" unless installed).
  - Modules badge now counts **available** modules and shows a separate
    **installed** badge (was counting installed as "available" -> showed 0).
  - Each entry exposes `setupReady`; the UI shows an amber "Setup not finished"
    hint when the rootfs isn't ready.
- **FB-012 — notification tap did nothing** (`TerminalService`):
  - Root cause: foreground notification had no content intent.
  - Fix: tap opens the app to its current state — `TerminalActivity` when a
    session is active, else the dashboard (`MainActivity`), with
    `NEW_TASK|SINGLE_TOP|CLEAR_TOP` + `FLAG_IMMUTABLE`. Text now says
    "… — tap to open".
- **FB-013 — Hardware card gaps** (`DevicePayload`, `dashboard.html`,
  `AndroidManifest.xml`):
  - RAM row relabeled to `RAM: avail / total`.
  - New rows: `Storage: avail / total` (+ one row per removable/USB volume),
    `App: <data size> data / <apk size> apk`, `CPU: N cores · model`,
    `GPU: vendor · busy`, `NPU`, `Thermal`, `Network: Wi-Fi/Cellular (LTE)/…`.
  - Battery row now includes charging state (`Charging (AC/USB/Wireless)`,
    `Full`, `Not charging`) via the `ACTION_BATTERY_CHANGED` sticky intent.
  - Network transport read via `ConnectivityManager`/`NetworkCapabilities` —
    new `ACCESS_NETWORK_STATE` (normal) permission only.
  - NPU is reported honestly (`n/a` unless a public sysfs node exists).
- **FB-014 — no in-guest storage mapping** (`StorageTier`):
  - Termux-style `~/storage/` tree seeded in the guest home: `shared`,
    `downloads`, `dcim`, `pictures`, `music`, `movies`, `documents` ->
    `/mnt/sdcard/…` (already PRoot-bound), plus `external` -> `/mnt/sd-ext1`.
  - New `sd mount` command re-derives the mapping adaptively (enumerates bound
    `/mnt/sd-ext*` volumes): `external` = first removable, `usb` = last
    (e.g. USB OTG), `external1..N` numbered; `sd list`/`ext` also refresh links.
  - Device-agnostic: internal + removable + USB are all discovered from
    `StorageManager`/launcher binds at runtime, nothing hard-coded per device.
- **FB-015 — module install error UX** (`ModuleManager`):
  - `rootfsReady()` now requires `bin/sh` **and** the apk database
    (`var/lib/apk/db/installed`), so it reflects real setup completion.
  - Install error now says "run Initiate Install on the dashboard first (all 7
    steps must pass)" instead of the bare "run setup first".

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-011 | Bundled module shows "version unknown"; badge shows 0 while listed | fixed | version read only from install bookkeeping; badge counted installed | peek `module.yml` from the bundle/drop tarball at list time; badges count available + installed; `setupReady` hint |
| FB-012 | Notification tap does nothing | fixed | foreground notification built with no content intent | `PendingIntent` opening TerminalActivity (session active) or MainActivity, `FLAG_IMMUTABLE` |
| FB-013 | Hardware card lacks RAM label, storage, app size, charging, network, CPU/GPU/NPU | fixed | telemetry payload + dashboard rows predated the tier | expanded `DevicePayload` (charging, storage, app sizes, CPU/GPU/NPU/thermal, network) + `renderHardware` rows |
| FB-014 | No Termux-style storage access in the guest | fixed | storage was bind-mounted but not surfaced in the home dir | `~/storage` link tree + adaptive `sd mount` (external1..N / usb) |
| FB-015 | Module install blocked with unhelpful rootfs error | fixed | readiness check weak; message terse | `bin/sh` + apk-db gate; actionable message; UI setup hint |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30006' versionName='v0.3a.6'`.
- `sd`/`device-info` generated scripts `sh -n` clean.
- Host-side `verify-apk.sh` (bundled module) passes 13/13.
- On-device verification still required:
  1. Notification tap opens the app (terminal when session active, else dashboard).
  2. Hardware card: RAM avail/total, Storage avail/total, App data/apk, charging
     state, CPU/GPU/NPU, Network rows match `device-info`.
  3. In-terminal `sd mount` then `cd ~/storage/shared && ls` shows the device
     store; insert SD/USB -> `sd mount` shows `external`/`usb`.
  4. Modules: hello-module shows version 1.0.0 + counts; Install works after
     setup (amber hint appears before setup).
