# Aetherix-Alpine Fork — Changelog

## v0.3a.6 (fork)

Hardware card expansion (RAM/storage/app size/charging/network/CPU/GPU/NPU), notification tap-to-open, ~/storage Termux-style mapping, module UX fixes (version/count/setup hint)
