# Aetherix-Alpine Fork — Changelog

## v0.4.1 (fork)

Post-freeze feature + fix revision on the frozen v0.4.0 core: Tavily web
search wired end-to-end (Dashboard key entry → encrypted at-rest storage →
guest key sync → `llm web`), plus four fixes from the 10-point review batch.

- **FB-098**: interactive `apk add` detach bug — the job runner was invoked as
  `/sbin/apk add add …` (wrapper duplicated the leading `add`), so every
  detached install failed with `required by: world[add]`. Now
  `/sbin/apk "$@"`.
- **FB-099**: `llm hf` download watcher printed `can't open …gguf.tmp` to
  stderr before the temp file existed; the size probe is now guarded.
- **FB-100**: keybar `REPLY` label replaced with the ✨ glyph; the toggle
  callback is unchanged.
- **FB-101**: `llm chat` exits only on exact-case `Exit` (`quit` no longer
  exits); banner text updated to `type Exit or Ctrl-D to leave`.
- **FB-102 — Tavily key management** (this release's headline):
  - Dashboard gains a `Tavily Key` button (post-install only, between
    Modules & Storage and View Log) opening a centered dialog with show/hide
    input, Save / Cancel / Remove, masked status, and live key testing on save.
  - New `SecretStore` uses an Android Keystore AES-256-GCM key; ciphertext
    (IV + tag + data) lives in app-private `aetherix_secrets` prefs — no
    plaintext on the host, no AndroidX dependency added to the raw build.
  - `StorageTier.deploy()` mirrors the decrypted key to
    `/etc/aetherix/tavily.key` (owner-only) and removes it on clear/reset, so
    tier CLIs stay in sync; `resetSetup`/`factoryReset` clear it too.
  - `llm web "<question>"` (Tavily primary, strict): live search, quoted
    result parsing (BusyBox-safe awk, no jq), cited synthesis through the
    local llama-server into the docked reply window; `llm web status` and
    `llm web --test` report backend/server state. No key → clear guidance to
    add one from the Dashboard.
- **Versions**: app v0.4.1 / versionCode 40001; `llm-module` 1.2.0 → 1.3.0
  (core 1.1.0, hello 1.1.0 unchanged).
- **Snapshot**: per-version folder `Aetherix-Alpine_v0.4.1/` (APK + source
  snapshot + docs) via `build-apk.sh`; verified 14/14.
