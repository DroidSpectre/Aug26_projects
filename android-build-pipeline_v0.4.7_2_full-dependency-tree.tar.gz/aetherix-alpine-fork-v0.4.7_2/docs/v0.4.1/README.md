# Aetherix-Alpine Fork — Build v0.4.1

- **Date:** 2026-08-10
- **VersionName:** v0.4.0 series — v0.4.1
- **versionCode:** 40001
- **Summary:** Tavily web search ships end-to-end: Dashboard `Tavily Key`
  button + dialog (live-tested save, encrypted at-rest storage), guest key
  sync, `llm web` with cited answers, plus FB-098..FB-101 fixes.

## What v0.4.1 is

v0.4.1 is the first patch release on the frozen v0.4.0 core. The core (app +
Alpine distro + terminal) is unchanged in architecture; the release adds the
Tavily-backed websearch tier and repairs the four defects found in the
10-point review batch. `llm-module` advances to 1.3.0 while the core version
stays on the v0.4.x line (modules remain the update vehicle).

## Changes

- **Tavily Key management (FB-102)** — Dashboard button + dialog + encrypted
  storage (`SecretStore`, Android Keystore AES-GCM, no AndroidX), guest sync
  to `/etc/aetherix/tavily.key` (0600), strict Tavily-primary `llm web` with
  status/--test subcommands; details in `docs/v0.4.1/ANALYSIS.md`.
- **Fixes** — detached `apk add` argument duplication (FB-098), model-download
  stderr spam (FB-099), ✨ keybar label (FB-100), `Exit`-only chat (FB-101).

## Verification

`verify-apk.sh v0.4.1` → 14/14 PASS (badging, signatures, DEX markers, assets,
bundles, device export). Full snapshot in
`/sdcard/Download/Aetherix-Alpine_v0.4.1/` (APK + source zip + docs).

## Manual device checks (new)

1. Dashboard → `Tavily Key` → enter a `tvly-…` key → Save (live test) →
   masked "Saved" state; Remove clears it.
2. Terminal → `llm web "what is Aetherix-Alpine?"` → cited answer in the
   response dock; `llm web status` shows `tavily (key set)`; remove the key
   and `llm web` explains how to add it.
