# Aetherix-Alpine — v0.4.1 Direction: System Review, Websearch, Agents, Help Docs

**Date:** 2026-08-10 · **Build:** v0.4.0 (versionCode 40000) + post-freeze fixes
**Scope:** answers the 10-point review batch: system status, Reply-key cosmetics,
LLM/terminal awareness + websearch architecture, grok-build analysis
(gBuild-module), OSS agent survey, SearXNG / Perplexica–Vane / Tavily
assessments, websearch flow options, curated help documentation for the LLM,
and the `llm chat` exit convention.

---

## 1. System status ("how's our system looking?")

**Evidence from the on-device session (2026-08-10):**

| Check | Result |
|---|---|
| `aetherix-smoke` | `SMOKE_OK` — T3/T4/T6/T8/T9 all pass |
| `aetherix-selftest` | `ALL CHECKS PASSED` (18/18, incl. version, arch, bind mounts, CA cert, tty) |
| `core status` | OK (bash, coreutils, cmake, git, curl, gcc, ccache, ninja) |
| llama.cpp build | **completed** `[315/315]` in ~61 min (jobs=2, dotprod+FMA enabled, SVE off) |
| Model | Qwen2.5-0.5B-Instruct Q4_K_M downloaded, 491,400,032 bytes, set active |
| `llm build-log export` | works (27,551-byte log to `~/storage/downloads`) |
| Job system | `apk add …` detaches, `job list`/`job log` work; apk progress `(N/M)` parsed |
| Module state | core-module 1.1.0, hello-module 1.1.0, llm-module 1.2.0, gui retired |

**Verdict:** the frozen core (app + Alpine + terminal) is healthy and the LLM
tier works end-to-end on the device. The terminal handled everything thrown at
it (setup, builds, detach/resume, IME, resize storms, chat) with no breakage.
The remaining rough edges are the ones fixed this batch plus minor polish:

- **Fixed in this batch (FB-098..FB-101):**
  - `apk add gnome` failed with `required by: world[add]` — the detached job
    runner received `/sbin/apk add add gnome` because the wrapper re-added the
    leading `add`. Now `/sbin/apk "$@"`.
  - Model download printed `can't open …gguf.tmp` stderr spam — the progress
    watcher ran `wc -c < file` before the temp file existed. Now guarded.
  - Keybar `REPLY` label → `\u2728` (item 2).
  - `llm chat` now exits only on exact `Exit` (item 10).
- **Worth noting, not yet addressed:** `device-info` reports `device/board/soc
  unknown` and `battery_pct n/a` under PRoot (reads Android props the guest
  cannot see). We can source these via the app-side launcher (host
  `Build.*`/`getprop` bridged into `/etc/aetherix/device.conf`, which already
  exists) — low priority. Finished module-install jobs linger in `job list`
  (the dock hides them after 20s; the CLI could prune them).

## 2. Function-key "Reply" → ✨

**Done.** `TerminalActivity.java` defaultKeys now use `"\u2728"`; the toggle
callback is unchanged. The sparkle reads as "the model replies here" without
the English label.

## 3. Making the LLM aware of the terminal + wiring in websearch

The LLM needs three things to "see" the terminal:

1. **Context** — what the user is doing. We already have the pieces:
   - The app keeps the live terminal screen/scrollback
     (`getScreen().getSelectedText(...)`) — we can have it write a rolling
     guest file `/etc/aetherix/term.context` (last ~40 lines) each resume.
   - `llm chat` already persists `/etc/aetherix/llm-chat.log`.
   - A new `llm context` command can assemble the environment snapshot:
     `pwd`, `stty size`, `core status`, `aetherix-selftest` summary,
     `job list`, model + server state.
2. **An instruction contract** — a reusable system prompt that says "you are
   the Aetherix assistant; here is the terminal state; answer in N lines".
   The 0.5B–1B models follow this reliably when the contract is short and the
   answer is capped (512 tokens, existing `LLM_MAX_TOKENS`).
3. **A search tool** — see §8. Two-stage "query → context → answer" runs on
   the current model; a tool-calling loop is the later upgrade.

**Recommended shape for v0.4.x (deterministic, no agent loop yet):**

```
llm ask-help <question>   # §9: curated docs into context, Help-Assistant persona
llm web <question>        # §8: query-plan → Tavily/SearXNG → cite → synthesize
llm ask <question>        # today: plain completion (optionally + term.context)
llm context               # print the terminal/environment snapshot
```

All three reuse the docked response window (`llm_reply`), so the terminal
stays usable while the answer renders above the keyboard.

## 4. grok-build deep dive + gBuild-module plan + OSS agent survey

### 4.1 grok-build

Clone source: `xai-org/grok-build` (SpaceXAI's public repo; commit
`b13fa52`, SOURCE_REV `a51a1dc`). **Rust workspace, 64 crates, ~202K LoC,
~115 MB source, Rust 1.94 (pinned), aarch64 target built-in, MIT/THIRD-PARTY
NOTICES, full-screen TUI + Agent Client Protocol (ACP) agent runtime.**

**Data harvesting / reporting to strip (the audit):**
- `crates/codegen/xai-grok-telemetry` — the telemetry engine: **Mixpanel**
  product-event emission, **Sentry** error reporting, **OpenTelemetry** traces
  exported to `https://cli-chat-proxy.grok.com/v1/traces`, plus session
  metrics and a structured log. Toggles exist (`[telemetry] enabled`,
  `GROK_EXTERNAL_OTEL`, `GROK_TELEMETRY_TRACE_UPLOAD`) and it is a Cargo
  feature (`[features]`) + optional workspace dep, but Mixpanel is also keyed
  off **baked build tokens** — stripping must remove the crate edge and the
  baked prod config, not just flip a feature.
- `crates/codegen/xai-grok-auth` — OAuth `grok login` / API-key / deployment
  key flows against `api.x.ai/v1` (the default model provider). Replace with
  no-auth local provider.
- `crates/codegen/xai-grok-config` `managed_config.rs` — remote managed
  config polling (team/managed principals); `xai-grok-announcements` — remote
  banner fetch; `xai-grok-.../relay` — event sync cursor; `xai-file-utils`
  GCS/storage clients. All outbound-cloud, all strip candidates.
- Plugin registry discovers an `mcp.sentry.dev/mcp` server and a Sentry MCP
  manifest — remove from the default plugin set.

**Why it can still work locally (good news):** custom model config supports
OpenAI-compatible endpoints and even `api_backend` choices:

```toml
[model.aetherix]
model = "qwen2.5-0.5b"
base_url = "http://127.0.0.1:8080/v1"   # llama-server
api_backend = "chat_completions"
context_window = 2048
```

**Sizing reality:** not lightweight. Rust 1.94 + ~200K LoC + tokio/reqwest/
async-openai graph is far heavier than llama.cpp — hours of build on a 3.5 GB
RAM phone, likely 1 GB+ of build artifacts, and a ~50–150 MB binary. It is a
desktop-class agent.

**Verdict / plan (gBuild-module):**
- **Do not port the full Rust tree on-device in v0.4.x.** Instead:
  1. Keep the audit as the strip-list above (telemetry, auth, managed config,
     announcements, relay, GCS, Sentry MCP plugin).
  2. Port the *behavioral contract* we actually want (session-scoped permission
     prompts, diff-style edits, web-search tool, task management) as a
     `gBuild-lite` shell module layered on `llm` — a constrained tool loop that
     the 0.5B model can actually run (§8 Option B).
  3. Defer the Rust binary to a desktop-assisted build when we want a
     heavyweight agent; at that point the strip-list + `[model.aetherix]`
     config make it a true drop-in gBuild-module bundle.

### 4.2 OSS agent survey (verified repos, 2026-08-10)

| Agent | Runtime | Form factor | Local/OpenAI-compatible endpoint | Weight on phone |
|---|---|---|---|---|
| **OpenClaw** (`openclaw/openclaw`) | Node 22+ | gateway + daemon + TUI, channels (WhatsApp/Telegram/…) | hosted + local providers | Heaviest; assistant/chat focus, not a lean coder |
| **OpenCode** (`opencode-ai/opencode`) | Go | single static binary, TUI, SQLite sessions | OpenAI, Anthropic, Gemini, Bedrock, Groq, Azure, OpenRouter (OpenAI-compatible set) | Light runtime; "early development" warning at HEAD |
| **Codex CLI** (`openai/codex`) | Rust | single binary (this environment runs it) | `model_providers` + `wire_api = "chat"` + custom `base_url` → works with llama.cpp-style servers | Light binary, desktop-class agent; strong-model-oriented |
| **Kimi Code CLI** (`MoonshotAI/kimi-code`) | TS → single binary | single-binary CLI, ACP support | Kimi default, "other compatible providers" | Single binary; kimi-cli (Python) is being wound down in its favor |
| **Hermes Agent** (`NousResearch/hermes-agent`) | Python 3.11 + bundled Node/uv/ripgrep/ffmpeg/git | CLI + gateway + TUI, subagents, Termux supported | multi-provider converging on local endpoints | Heavy runtime stack on Alpine |
| **Pi** (`earendil-works/pi`) | TypeScript (npm) | modular: `pi-ai` (multi-provider), `pi-agent-core`, `pi-coding-agent`, `pi-tui`, `pi-telemetry` | OpenAI/Anthropic/Google + custom; telemetry is an explicit, separable package | Node needed; modular — easy to take only what we want |

**Recommendation for the lightweight system:**
1. **Now (0.5B–1B models):** adopt **no full harness**. The bottleneck is
   model capability, not the harness; a full loop produces drift with these
   models. Ship the deterministic `llm web` / `llm ask-help` runbooks (§8
   Option A) — they are the "narrow agent" that matches the hardware.
2. **Next step (when running a 3–8B local model):** two realistic candidates
   — **OpenCode** (Go, single static binary — lightest operational footprint;
   verify exact custom-`base_url` syntax at that point) or **Pi** (most
   structurally aligned: separable telemetry package to cut, unified provider
   layer, agent-core we can trim). 
3. **Codex** is the most capable but assumes a strong model and more cloud
   surface; **Hermes** is research-grade (subagents, trajectory capture) but
   its installer bundles a whole runtime; **OpenClaw** is an assistant gateway,
   not a good coding-agent fit for the phone. **grok-build** informs the
   design (permissions, sessions, diff application) but stays desktop-class.

## 5. SearXNG — worth wiring in?

**What it is:** free, self-hosted metasearch (Python/Flask, ~120 MB source,
35K★). Aggregates upstream engines with no API keys; exposes the JSON API the
rest of the ecosystem uses — Vane calls `GET $SEARXNG/search?format=json&q=…`
and reads `{results:[{title,url,content}], suggestions}` directly.

**Assessment for the phone:**
- Running SearXNG *on-device* is not worth it: a Python service + engine load
  + an always-on port costs RAM/CPU, and upstream engines rate-limit mobile
  egress IPs.
- Using a **public instance as a keyless fallback** is trivial: it is one
  `curl` in the tier CLI. Keep `SEARXNG_URL` configurable and treat outages as
  expected (public instances throttle).
- **Verdict:** wire it as the keyless secondary backend behind Tavily
  (primary, §7). Do not bundle it.

## 6. Perplexica / Vane — what to harvest

Perplexica has been renamed/absorbed into **Vane** (`ItzCrazyKns/Vane`, MIT,
TypeScript/Next.js) — a privacy-focused "AI answering engine" on your own
hardware: SearXNG search + local LLM (Ollama) or cloud providers, plus answer
synthesis with cited sources.

**Harvestable parts (this is a small, well-factored surface):**
- `src/lib/searxng.ts` — the entire SearXNG search client (~60 lines, JSON
  format, 10s timeout). Directly translatable to a curl function in the tier.
- `src/lib/agents/search/` + `src/lib/prompts/search/` — the pipeline:
  **classifier** (which search mode) → **researcher** (parallel queries) →
  **writer** (final answer with `[n]` citations). The prompts and the
  two/three-stage flow are the gold; copy the *pattern*, not the Next.js app,
  and keep it to one search + one synthesis for our model size.
- Not useful on-device: the web UI, uploads/embedding search, widgets, the
  Next.js server, Docker packaging.

**Verdict:** yes — harvest the SearXNG client pattern and the
classify→research→write prompt structure into `llm web` (§8). Do not port the
application.

## 7. Tavily — best primary search backend for a light system

**Docs (docs.tavily.com, 2026-08-10):** Tavily is "the web layer for AI
agents": real-time search, extract, crawl, map, research — returned
**LLM-ready** (truncated content + optional `answer` summary), not raw HTML.

- **API:** `POST https://api.tavily.com/search`, `Authorization: Bearer
  tvly-…`, JSON body (`query`, `search_depth` basic/advanced, `max_results`,
  `include_answer`, `topic`, …). A plain curl works — no SDK needed on Alpine.
- **Free tier:** 1,000 credits/month, no credit card; **keyless mode**
  (`X-Tavily-Access-Mode: keyless`) for Search/Extract with no account at all.
- **Ecosystem:** official CLI (`tvly`), remote MCP
  (`https://mcp.tavily.com/mcp/?tavilyApiKey=…`), Python/JS SDKs.

**Assessment:** for a 360M–1B model, Tavily's `include_answer` + snippet-ready
results are the *best* fit of everything surveyed — the model summarizes
already-clean context instead of resisting raw pages, and the phone runs zero
infrastructure (one curl). Free tier is more than enough for personal use.
**Verdict:** Tavily = primary wired backend now; public SearXNG instance =
keyless fallback; local SearXNG = defer. Exa appears in Vane's stack as another
sponsored option — can be a later `llm hf`-style alternative, not needed now.

## 8. How websearch actually works + our options

**The standard flow (what a "search-synthesis" system does):**
1. **Plan:** the user question (optionally plus `llm context` terminal state)
   is turned into 1–3 concrete search queries — either by the LLM up front or
   by a fixed rule (take the question verbatim for v1).
2. **Search:** the backend runs the queries (Tavily curl, or SearXNG JSON).
3. **Context:** titles/URLs/content snippets (or Tavily's `answer`) are packed
   into the prompt as `[1] title — url — snippet` lines with an instruction
   to cite them.
4. **Synthesize:** the model writes the final answer with citation markers in
   N lines; the docked response window displays it.

**Our options, in ascending complexity:**

| Option | What it is | Model fit now | When |
|---|---|---|---|
| **A. Runbook (`llm web`, two-stage)** | fixed pipeline: query → search → one-shot synthesis. No tool loop, no agent state | ✓ 0.5B–1B do this well | ship in v0.4.1 |
| **B. Tool-call loop (`llm agent`, N-step)** | repo-style loop: model emits `tool:search("…")`/`tool:read("…")` JSON, CLI executes, feeds result back, repeats ≤N | needs a model with solid tool/JSON discipline (Qwen2.5/Qwen3 family is the floor) | v0.4.2+ |
| **C. Full harness (OpenCode / Pi / Codex)** | §4.2 — real agent with permissions, diffs, sessions | needs 3–8B-class model | later, desktop-assisted |

**Recommendation:** ship **A** now with one upgrade path to **B** — the tier
CLI can expose `search()` and `webget()` as shell functions that **B** later
reuses, so the tools outlive the runbook. Tavily's `include_answer` makes A's
synthesis step tiny; SearXNG fallback keeps it keyless.

## 9. `llm ask-help`: curated docs DB + Help-Assistant persona

**Goal:** one help surface instead of 12 overlapping help commands — the model
answers questions by reading the *curated* documentation, citing the doc path.

**Corpus to curate (source → `$AETHERIX_HELP` = `/etc/aetherix/help/`):**
- In-app docs: `module help`, `llm help`, `sd help`, `job help`, `elv help`;
  welcome banner text; `aetherix-selftest`/`aetherix-smoke` output semantics.
- Repo docs: `docs/v0.3-series/*` (device-layers, core-vs-modules,
  package-inventory, CHANGELOG), `docs/v0.4.0/*` (README/CHANGELOG/REPORT),
  `docs/BUGS.md`.
- Alpine quick refs: `apk` usage, `openrc` vs Android lifecycle caveats we
  learned the hard way (PRoot quirks, `/dev/urandom`, `apk upgrade` symlink
  issue), plus the device.conf/elv/job expected behaviors.

**Indexing (no embeddings at 360M–1B scale):** v1 = plain-text corpus + a
keyword/trigram scorer in shell (`grep -il` over section titles + a small
`grep -w` term count), returning the top 3–5 matching sections as context.
Embeddings/vector search over local docs is a later upgrade (and would need a
real embedding model, not the chat Q4s).

**UX:**
- `llm ask-help <question>` → Help-Assistant persona prompt + top-K sections +
  terminal context (`llm context`) → capped answer in the dock, with `Doc:
  /etc/aetherix/help/<file>` citations.
- `llm ask-help` with no args → interactive help chat (same `Exit`-only
  convention).
- Existing per-tool `help` commands stay as the raw fallback (`module help`
  still lists them).

**Packaging:** ship the corpus + `ask-help` in a small `help-module` v1.0.0
(no deps; docs are static text). Keep llm-module focused on inference.
`help-module` can then be updated downstream as a pure-docs update vehicle —
exactly the module-as-update model from v0.4.0.

## 10. `llm chat` exit command

**Done.** Only `Exit` (exact-case) leaves chat; `quit` is no longer treated as
an exit word. Ctrl-D still ends chat at EOF (shell semantics) and the banner
now says `type Exit or Ctrl-D to leave`.

---

## Proposed v0.4.1 work list

1. Ship FB-098..FB-101 (done locally: apk wrapper arg, hf-download stderr,
   ✨ key, Exit-only chat) — rebuild APK + verify (done), deploy to device.
2. `llm context` — environment/terminal snapshot command (llm-module 1.3.0).
3. `llm web` — Tavily primary + SearXNG fallback, two-stage runbook
   (llm-module 1.3.0; `TAVILY_KEY` stored in `/etc/aetherix/`).
4. `help-module` v1.0.0 — curated corpus + `llm ask-help`/`--persona` help chat.
5. `llm agent` (tool-call loop) — v0.4.2 stretch, reusing the `search()`/
   `webget()` primitives from `llm web`.
6. Deferred: full gBuild-module Rust port (strip-list in §4.1), device-info
   via host bridge, `job list` pruning.

**Open question for the user:** Tavily needs an account (free, 1,000
credits/mo) — with your API key `llm web` ships immediately; without one,
`llm web` falls back to a public SearXNG instance.
