# Aetherix-Alpine Fork — Changelog

## v0.3a.14 (fork)

UI polish: default-minimized persistent Hardware/System cards, module page color semantics (Installed green / Available blue / Uninstall blue), Termux-style terminal splash
