# Aetherix-Alpine Fork — Build v0.3a.14

- **Date:** 2026-08-06
- **VersionName:** v0.3a.14 · **versionCode:** 30014
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** UI polish pass on top of v0.3a.13: Hardware and System cards are
  now minimized by default and stay that way across state changes, page swaps
  and app restarts (FB-039); the Modules page now uses consistent color
  semantics — Installed is green, Available is blue, and Uninstall is the same
  blue as Available (FB-040); the terminal login splash was rewritten in a
  compact Termux style with the installed modules and the command cheatsheet
  (FB-041).

## Changes

- **FB-039 — Cards open fully expanded and re-expand on every refresh**
  (`dashboard.html`):
  - The Hardware card and the System card are static info blocks that rarely
    change after setup; both now default to **collapsed**.
  - Each card title is a toggle (chevron ▸/▾). The collapsed/expanded choice is
    persisted in `localStorage` (`aetherix.hwCollapsed`,
    `aetherix.sysCollapsed`; missing key = collapsed) and re-applied on every
    render (`init()`, `renderHardware()`, `loadDashboard()`), so the state
    survives the 5 s telemetry refresh, page swaps, app state changes, and
    process restarts.
- **FB-040 — Module page color semantics inverted/ambiguous**
  (`modules.html`):
  - New `.badge-available` (blue `#1f6feb`) for the Available label; Installed
    stays green (`badge-granted`).
  - Uninstall buttons switch from red (`btn-danger`) to blue (`btn-info`) —
    same color as Available, per request. Install/Reinstall stays green
    (primary action).
  - The card-header count badges now match: "N available" is blue,
    "N installed" is green. Storage grant badges are unchanged.
- **FB-041 — Terminal splash unchanged; user wants Termux-style**
  (`WelcomeScript.java`):
  - `etc/profile.d/00-welcome.sh` rewritten as a compact welcome banner with a
    "What would you like to do?" quick-start list: `sd` (storage), `module
    status`, `aetherix-selftest`, `elv` (adb elevation, shown when present),
    plus per-installed-module hints for gui (VNC desktop), llm (llama.cpp
    chat), and hello (smoke test). Installed module names are listed under the
    banner.
  - One-shot per login via `PROOT_WELCOME_SHOWN`; refreshed idempotently by
    `StorageTier.deploy()` so existing installs get it without a setup re-run.
  - Generated script validated with `sh -n`.

## Bugs

| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-039 | Hardware/System cards start expanded and re-expand on refresh | fixed | no default-minimized state; re-render wiped inline collapse | default collapsed + `localStorage` persistence re-applied on every render |
| FB-040 | Module labels/actions use misleading colors (Available green) | fixed | single green badge for installed state, red for uninstall | blue `badge-available`, green Installed, blue Uninstall |
| FB-041 | Terminal splash not informative/Termux-style | fixed | banner-only splash | compact welcome + module list + quick-start cheatsheet |

## Build & Verification Notes

- Built with `scripts/build-apk.sh` (fork build, no Gradle).
- `bash config/modules/hello-module/tests/verify-apk.sh v0.3a.14` → **13/13 pass**.
- Splash syntax: `sh -n` on the generated `00-welcome.sh` passes.
- Device export refreshed: `/sdcard/Download/Aetherix-Alpine-Fork/`
  (APK + source snapshot + docs).
