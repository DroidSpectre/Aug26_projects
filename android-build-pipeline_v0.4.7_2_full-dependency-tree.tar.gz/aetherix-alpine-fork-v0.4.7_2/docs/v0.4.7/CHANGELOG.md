# Aetherix-Alpine Fork — Changelog

## v0.4.7 (fork)

The "cleanup + CRT UI" release. Two v0.4.x-series plans merged into one
build and one export: module cleanup (Stage 1) and the in-terminal menus +
CRT look (Stage 2).

- **FB-126 — module cleanup**: core-module becomes base-only; the llama.cpp
  toolchain moves to llm-module (lazy `llm setup` install); Step 5 stops
  re-asserting openssh/nano/htop/bash-completion/iproute2.
- **FB-127 — CRT terminal UI**: 36dp amber category bar + status dot +
  compact timer; `aetherix-menu` dropdowns for llm/modules/files/system/help;
  keybar MENU + ▶ keys, amber/green palette; System menu owns
  close/exit/copy/clear through `/etc/aetherix/app.request`.
- **FB-128 — 8k context floor with native clamp**: every profile row 8192+
  (16384 for 13B+), clamped to the GGUF's own `context_length` (SmolLM2 =
  2048); cached parse; `LLM_CTX` forces; status/capabilities print the
  clamped profile + 512-token max response.
- **FB-129 — Tavily answers-first**: `include_answer: true`, short answer on
  top, ~200-char snippets, second query only when needed, 3000-char merged
  cap.
- **FB-130 — broken intermediate edit repaired**: web.sh `tavily_extract`
  had orphaned awk fragments; base.sh clamp diagnostics were hoisted to
  source time. Restored: answer/truncation in `tavily_extract`, native-ctx
  clamp in `model_profile`, diagnostics in `capabilities`/`llm status`.

Cards: new 58 MENU hub; 21/27/28/31/33/36/37/53/56 refreshed. Docs:
`21-packages.md`, `30-llm.md`, `50-versions.md`, root README, BUGS.md.
Sandbox suite extended (T1e native clamp, T2b include_answer, menu tests).
