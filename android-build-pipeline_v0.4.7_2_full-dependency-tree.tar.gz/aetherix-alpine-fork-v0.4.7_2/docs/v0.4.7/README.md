# Aetherix-Alpine v0.4.7 — cleanup + CRT terminal UI

The "make it usable" release. Two locked plans merged into one build:
**Stage 1 (module cleanup)** fixes what the terminal UI sat on — fat
modules, an uneven context floor, Tavily snippets eating the window — and
**Stage 2 (CRT UI)** replaces the raw shell + old toolbar with an amber
category bar, keybar menus, and in-terminal dropdowns.

## What changed
- **Modules are single-purpose** (FB-126): core-module is the shared base
  only (bash, coreutils, ncurses-terminfo, ca-certificates-bundle, findutils,
  gawk, best-effort libomp). The llama.cpp toolchain (build-base, clang,
  cmake, git, curl, linux-headers, openssl-dev, ccache, ninja) belongs to
  llm-module and installs lazily with `llm setup`. Step 5 drops the
  conveniences minirootfs already provides (openssh, nano, htop,
  bash-completion, iproute2).
- **Context 8192+, clamped to the model** (FB-128): every profile row is
  8192 (16384 for 13B+). `model_profile()` reads the active GGUF's native
  `llama.context_length` with a streaming `od|awk` walker (cached in
  `/etc/aetherix/llm.gguf.ctx`) and clamps the window down when the model
  was trained on less (SmolLM2 → 2048). `LLM_CTX` still forces. Max response
  stays 512 tokens (`LLM_MAX_TOKENS`).
- **Tavily answers-first** (FB-129): `include_answer: true`, the short
  summary prints first, snippets truncate at ~200 chars, a second query runs
  only when the first has no answer, and merged material caps at 3000 chars.
- **CRT terminal UI** (FB-127): the 48dp toolbar is a 36dp amber category
  bar — `LLM │ MODULES │ FILES │ SYSTEM │ HELP` with a live status dot and a
  compact timer. Tapping a category (or the keybar MENU key) writes
  `aetherix-menu <cat>` into the pty; `aetherix-menu` (core tier, pure ANSI)
  renders boxed dropdowns with ↑/↓ navigation, adaptive state, and Enter to
  run. The System menu holds Close/Exit/Copy/Clear via
  `/etc/aetherix/app.request`. The keybar is near-black with amber keys, a
  green active color, MENU and ▶ reply keys; the ANSI color scheme is a CRT
  amber/phosphor palette.
- **New knowledge card 58 MENU** (12th hub); cards 21/27/28/31/33/36/37/53/56
  and docs `21-packages.md`, `30-llm.md`, `50-versions.md` updated.

## Releases / bugs
- Bug IDs: FB-126..FB-130 (`docs/BUGS.md`).
- Module versions: core 1.4.0, llm 1.9.0, help 1.6.0.
- App: v0.4.7 / versionCode 40007.

## For developers
- `bash tests/sandbox/run-llm-tests.sh` — the llm tier sandbox (112 checks:
  native-ctx clamp, answers-first Tavily, CRT menu items + selftest).
- `aetherix-menu --items <cat>` and `--selftest <cat>` are the non-TTY
  surfaces for the in-terminal menu.
