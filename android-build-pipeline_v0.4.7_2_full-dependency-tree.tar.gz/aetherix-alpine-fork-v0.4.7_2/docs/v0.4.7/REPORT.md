# v0.4.7 — Cleanup and CRT UI report

## 1. Module cleanup (Stage 1)

### The problem
core-module installed the full llama.cpp build toolchain on every device, and
Step 5 re-asserted convenience packages (openssh, nano, htop,
bash-completion, iproute2) that the Alpine minirootfs expansion already
provides. The UI layered on top of this was raw: one fat toolbar
(Close/Copy/Clear/Exit) and no way to discover workflows without typing.

### The dependency audit
Step 5 + core-module were the only dependency installers. Per past issues:
- FB-112/FB-117/FB-118: the build needs clang/cmake/ninja/ccache, OpenMP
  runtime (libomp best-effort, gcc+libgomp fallback), linux-headers
  (FB: linux/limits.h), openssl-dev, git, curl, CA certs.
- FB-121/term_run: the terminal bridge itself needs only the base shell
  tools — no toolchain.
- help/hello modules: zero packages.

Resolution — **one owner per concern**:
- Step 5: `alpine-base tzdata util-linux shadow procps` (+ bash, coreutils,
  ncurses-terminfo, ca-certificates-bundle) — the OS closure.
- core-module v1.4.0: bash, coreutils, ncurses-terminfo,
  ca-certificates-bundle, findutils, gawk (+ best-effort libomp). findutils/
  gawk lock GNU semantics for the awk-heavy llm tier.
- llm-module v1.9.0: owns the toolchain; `need_llama` installs it lazily on
  `llm setup` (build-base, clang, cmake, git, curl, ca-certificates-bundle,
  linux-headers, openssl-dev, ccache, ninja, recommends libomp).

## 2. Context math (FB-128)

The data cards are small (≤ ~25 lines ≈ 256 tokens at ~10 B/token). The
guided router is a binary letter-picker per hop; a full 6-hop small-world
walk costs ~6 × (card + instruction) ≈ 3-4k tokens. An 8k window leaves the
router prompt + Tavily/dropbox material + history room, with ~512 tokens
reserved for the final synthesis (max response). Lowering the floor to a
model's native GGUF context prevents OOB truncation (SmolLM2 trains at
2048), while `LLM_CTX` still lets a power user force a window.

- Profiles: `*smollm2* 8192 256 6`, `*1b* 8192 512 6`, `*3b* 8192 1024 6`,
  `*13b* 16384 2048 6`, fallback `* 8192 512 6`.
- Clamp: `model_profile()` parses `llama.context_length` from the GGUF
  header (od|awk streaming walker; skips the tokenizer vocab; cached per
  path/mtime/size in `/etc/aetherix/llm.gguf.ctx`); only clamps DOWN; a
  numeric `LLM_CTX` skips the clamp.
- Diagnostics: `llm status` and `llm capabilities` print the clamped profile
  (e.g. "ctx 2048 (clamped from model native 2048)") plus the 512-token max
  response.

## 3. Tavily answers-first (FB-129)

Raw snippets were the token hog: 4-5 full result bodies blew the context and
responses felt cut off. Now:
- `include_answer: true` gets Tavily's own short summary; it prints first.
- Result content truncates at ~200 chars + "…".
- `web_gather` runs query 2 only when query 1's response has no answer
  summary.
- Merged material caps at 3000 chars (re-renumbered `[n]` citations).

## 4. CRT terminal UI (Stage 2)

- **Category bar** (TerminalActivity): 36dp near-black bar, amber monospace
  tabs `LLM │ MODULES │ FILES │ SYSTEM │ HELP`, live status dot
  (green = server up, amber = build running, dim = idle), compact timer.
  Tap → `session.write("aetherix-menu <cat>\n")`.
- **aetherix-menu** (core-module tier): pure-ANSI, ash-safe dropdown. Alt
  screen enter/leave, ↑/↓ + Enter + Esc/q, adaptive item lists (start vs
  stop server, Tavily key, installed modules), System menu actions write
  `/etc/aetherix/app.request` (close|exit|copy|clear) which the app polls
  like the existing dock.request channel.
- **Keybar** (ExtraKeysView): near-black bg `0xff0d0d0d`, amber keys
  `0xffffb000`, phosphor-green active `0xff00ff41`; `MENU` key (the old
  ✨ slot) opens the LLM menu; `▶` toggles the reply dock.
- **Color scheme** (TerminalColorScheme): ANSI 0-15 remapped to a CRT
  amber/phosphor palette matched to the bar and keybar.

## 5. Validation
- The sandbox suite is green at 112 checks: the 87 pre-v0.4.7 checks stay
  green after the repairs (Stage 1 broke web.sh/base.sh/llm mid-edit —
  FB-130), plus new checks for the native-ctx clamp (2048 synthetic GGUF),
  LLM_CTX force, `include_answer` payload, single-search skip when an
  answer exists, and the menu `--items`/`--selftest` surface.
- `verify-apk.sh` asserts the new DEX markers (openMenu/handleAppRequest/
  MENU_KEY/REPLY_KEY) and the absence of SPARKLE_REPLY_KEY.
