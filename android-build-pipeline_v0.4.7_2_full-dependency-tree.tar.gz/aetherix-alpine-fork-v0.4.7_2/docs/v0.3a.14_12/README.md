# Aetherix-Alpine Fork — Build v0.3a.14_12

- **Date:** 2026-08-09
- **VersionName:** v0.3a.14_12
- **versionCode:** 30152
- **Summary:** docked LLM response window (REPLY key) + llm chat

## Changes

- **FB-081 — docked LLM response window**
  (`TerminalActivity.java`, `terminal/ExtraKeysView.java`,
  `StepRunner.java`, `config/modules/llm-module/tier/llm`):
  - `llm ask`/`llm chat` replies no longer print into the terminal scrollback.
    The llm tier appends a timestamped `you:`/`llm:` transcript to
    `/etc/aetherix/llm-chat.log`; the app tails that file in a scrolling
    dock between the terminal frame and the function-key row (same slot as
    the FB-065 build-progress bar), capped at the last 200 lines guest-side.
  - The keybar `REPLY` button (replacing `PASTE`, which stays available via
    the long-press selection menu) toggles the dock; the button highlights
    while the dock is visible. The dock polls every 750 ms while visible,
    auto-scrolls to the newest entry, and is 3 terminal lines tall with the
    keyboard open, 5 when closed (keyboard state derived from grid rows).
  - The launcher now exports `AETHERIX_DOCK=1`; outside the app (env unset)
    `llm ask` prints inline exactly like 14_11.

- **FB-082 — `llm chat` interactive mode**
  (`config/modules/llm-module/tier/llm`):
  - `llm chat` starts the server if needed, then loops a `chat> ` prompt;
    `exit`/`quit`/Ctrl-D leaves. History keeps the last 20 messages (~10
    turns) so the prompt window stays bounded, and each turn lands in the
    transcript (`you:` and `llm:` lines) for the dock to render.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-081 | LLM replies clutter the terminal scrollback | reply text printed inline into the pty | docked response window: llm tier writes `/etc/aetherix/llm-chat.log`, app tails it in a scrolling dock under the grid; keybar REPLY toggles (replaces PASTE, still on long-press menu); `AETHERIX_DOCK=1` from the launcher, inline fallback otherwise |
| FB-082 | No multi-turn chat; ask is one-shot only | single-request ask with no history | `llm chat` loop with last-10-turn history, replies to the same docked transcript; `exit`/`quit`/Ctrl-D ends |

## Build & Verification Notes

- Host: `verify-apk.sh v0.3a.14_12` → 14/14 PASS.
- Guest flows exercised with a stubbed curl/llama-server:
  `AETHERIX_DOCK=1 llm ask` writes `you:`/`llm:` transcript and prints
  nothing; unset env prints inline; `llm chat` (piped stdin) produces a
  4-line transcript + history file and exits cleanly; inline chat prints
  replies.
- Device: `llm ask "hi"` → reply in dock, terminal stays clean; keybar
  `REPLY` shows/hides; keyboard open = 3-line dock, closed = 5-line;
  `llm chat` multi-turn; long-press paste still works; regressions from
  14_10/14_11 (`llm hf` menu, `build-status`, selftest) unchanged.
