# Aetherix-Alpine Fork — Changelog

## v0.3a.14_12 (fork)

docked LLM response window (keybar REPLY) + llm chat multi-turn mode (FB-081, FB-082)
