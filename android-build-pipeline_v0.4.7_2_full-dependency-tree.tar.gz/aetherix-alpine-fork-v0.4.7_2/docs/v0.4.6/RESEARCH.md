# Research — one AI command: how the model decides chat vs tools vs search

Question from the project: with a sub-1B model, five overlapping commands
(`llm ask`, `llm chat`, `llm web`, `llm agent`, `llm ask-help`) made the
"how do I talk to the AI?" question harder than it should be. We need ONE
conversational surface that, per user message, itself decides the answer
style (chat / tools / search / docs) — and we need it to work on 135M–1B
models that were never trained for tool-calling.

## Findings

- **Vane (Perplexica successor) uses a fixed 3-stage pipeline, not a
  free-form agent.** `docs/v0.4.1/ANALYSIS.md` §6: classifier (which search
  mode) → researcher (parallel queries) → writer (final answer with `[n]`
  citations). The decision is made BEFORE any tool runs, by a small prompt;
  the app never lets the model interleave arbitrary tool calls.
- **Perplexity-style systems do the same per query.** The UI picks a mode
  (web / code / academic / "all") once, then runs search + synthesis. The
  mode pick is a bounded choice; the answer synthesis is a separate step.
  Nothing in either system requires the model to emit JSON `tool_calls`.
- **A one-token mode pick is what small models are actually good at.**
  v0.4.4 proved the guided router on 135M–1B: a hardwired A/B/C/D/E menu,
  one letter per hop, the tier executes the tool, ≤6 hops (small-world).
  Free-form `tool_calls` JSON (assembly, escaping, correct function names)
  is unreliable under ~2B params and burns prompt budget on syntax.
- **The context window was the real blocker, not the router.** Profiles
  gave `*smollm2*`/`*0.5b*` → 1024 ctx and 1B/fallback → 2048, with a
  512-token output cap and a fat router prompt — the window blew up and
  answers truncated (FB-122). The correct fix is a context floor: router +
  history + material must fit.
- **OODA + small-world is the right framing.** Each user turn is a tight
  loop: **Observe** (terminal context + recent chat history + material
  gathered so far) → **Orient** (one-letter menu) → **Decide** (the tier
  runs the chosen tool) → **Act** (synthesize the final answer). The
  small-world card network (58 nodes, ≤6 hops) is the same shape: bounded
  single-token decisions, hub-and-spoke navigation.

## Decision (v0.4.6)

- **One command: `llm chat`.** Interactive chat, plus one-shot flags
  (`--once <q>` routed, `--plain <q>` direct, `--web <q>/status/--test`,
  `--docs <q>`, `--task <task>`). The old `ask` / `web` / `agent` /
  `ask-help` commands are deleted, not aliased.
- **Universal router on every model.** Every turn runs the same letter menu
  per hop (A web / B docs / C file / D knowledge / E terminal / F final).
  Material accumulates across hops; the loop ends at F or the hop budget
  (`LLM_ROUTER_MAX`, default 6, reset each turn). History (last ~8 turns,
  compacted) feeds Observe and the final synthesis, so follow-ups stay in
  chat — this is Vane's classifier→research→write mapped onto per-turn
  decisions, with the terminal context as our unique "sense" input.
- **Native tool loop deleted.** `agent_run`, `run_tool`, `agent_tools_json`,
  `parse_tool_calls`, `msg_json`, `classify_question`, `router_ask` and the
  `TOOL_CAPABLE`/`AGENT_LOOP` gating are gone. Capabilities reports
  `guided router: ON (universal)`; `LLM_ROUTER=0` = strict no-tools.
- **Context floor raised (FB-122).** tiny (<0.6B) 4096, 1–8B 8192, 13B+
  16384, fallback 8192 (`model-profiles.conf`), so router prompt + history +
  material always fit. No rope overrides — llama.cpp handles the window.

## Verification

- Sandbox (87 checks): profile resolution at the new sizes, `chat --plain/--
  once/--web/--docs/--task` paths, multi-hop (web → final), file hop reads
  the INPUT dropbox, terminal hop (E → confirm → `pwd` → synthesized),
  `LLM_ROUTER=0` fallback, legacy commands exit non-zero, capabilities
  reports the universal router, no native-loop strings remain.
- On-device: `llm chat` (interactive), `llm chat --task "find the bug in
  bug.py"` with a file in INPUT, `llm chat --web "latest qwen news"`, and
  `llm status` showing ctx 4096/8192 instead of 1024/2048.
