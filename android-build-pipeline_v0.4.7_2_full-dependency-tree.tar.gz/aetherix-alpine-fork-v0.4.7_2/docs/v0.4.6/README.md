# Aetherix-Alpine v0.4.6 — One AI command, router on every model

Lay-person summary: instead of five different ways to ask the AI (ask, chat,
web, agent, ask-help), this release makes `llm chat` the ONE way — and each
question decides for itself whether it needs the web, the built-in docs, a
file on your phone, a terminal check, or just the model's own knowledge. It
also fixes the reason answers kept getting cut off: the AI's memory window
was only ~1,000 tokens (about a page); it's now 4,000–8,000+ depending on the
model, so full answers fit.

## What changed
- **`llm chat` is the only AI command.** Type a message and the AI routes
  it: web search (Tavily), built-in docs, a file from the INPUT dropbox, a
  safe terminal command, or its own knowledge. Need one question, not a
  conversation? `llm chat --once "question"`. Want it to search the web?
  `llm chat --web "question"`. Give it a task (`llm chat --task "..."`) and
  it works through it step by step with tools, just like before — but now on
  every model, not just the big ones.
- **The router works on every model.** Small models are rarely trained for
  "tool calling", so instead of free-form tool JSON the AI picks one letter
  per hop (A web / B docs / C file / D knowledge / E terminal / F final) and
  the phone runs the tool. Any task finishes within six hops — the same
  "small-world" idea as the knowledge cards. `LLM_ROUTER=0` switches tools
  off completely if you ever want plain answers only.
- **The memory window is fixed.** Tiny models now get 4,096 tokens of
  context, 1–8B models 8,192, and 13B+ models 16,384 (was 1,024/2,048).
  This is why answers were truncating before — there simply wasn't room for
  the question, the router instructions, the search results and the answer.

## Important
- The old commands (`llm ask`, `llm web`, `llm agent`, `llm ask-help`) are
  gone. Their jobs all live inside `llm chat` now.
- Nothing else changes: replies still land in the docked response window and
  are saved, `llm export` still writes into the OUTPUT folder, and the
  INPUT/OUTPUT dropbox workflow is exactly the same.

## For developers
- Chat surface: `tier/llm` dispatcher (`chat` arm) + `tier/lib/chat.sh`
  (`chat_cli`, `chat_loop`, `chat_turn`, history rollup).
- Universal router: `tier/lib/agent.sh` (`route_hops`, menu helpers,
  `safe_file_read`, `term_run`); `tier/lib/base.sh` (`model_profile` exports
  `CTX_SIZE/BATCH_SIZE/ROUTER_HOPS/ROUTER_ENABLED`, `capabilities`).
- Profiles: `profiles/model-profiles.conf` (4-col: glob ctx batch hops).
- Full design rationale: `docs/v0.4.6/RESEARCH.md`.
