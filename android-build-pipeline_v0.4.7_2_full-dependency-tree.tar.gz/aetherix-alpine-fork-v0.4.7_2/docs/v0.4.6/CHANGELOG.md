# Aetherix-Alpine Fork — Changelog

## v0.4.6 (fork)

The "one AI command" release. `llm chat` replaces every other way to talk to
the model; every model — 135M up — drives the same hardwired letter router;
and the context floor is finally large enough (4–8k) for real answers.

- **FB-122 — context floor raised to 4–8k**: `model-profiles.conf` now gives
  tiny (<0.6B) models 4096 ctx, 1–8B models 8192, 13B+ 16384, fallback 8192
  (was 1024/2048). The router prompt + history + Tavily/dropbox material now
  fit the window, so models stop truncating mid-answer; the wizard's model
  reasons show the sizes. `LLM_CTX`/`LLM_BATCH` overrides still win.
- **FB-123 — unified `llm chat`**: one conversational surface with flags
  `--once "<q>"` (routed one-shot), `--plain "<q>"` (direct), `--web "<q>"`
  / `--web status` / `--web --test` (Tavily + key checks), `--docs "<q>"`
  (corpus answer), `--task "<task>"` (multi-hop task). Interactive mode
  keeps the Exit/Ctrl-D convention and rolls the last ~8 turns into the next
  turn's context. `ask`, `web`, `agent` and `ask-help` are deleted across
  the dispatcher, help text, help corpus, data cards, module hints and the
  app's reply-dock hint.
- **FB-124 — universal router (native tool loop deleted)**: every model
  uses the same one-token letter menu per hop (A web / B docs / C file /
  D knowledge / E terminal / F final, ≤6 hops, budget resets per turn).
  `agent_run`, `run_tool`, `agent_tools_json`, `parse_tool_calls`,
  `msg_json`, `classify_question` and `router_ask` are removed; capabilities
  reports `guided router: ON (universal)`; `LLM_ROUTER=0` = strict no-tools.
  Design rationale (Vane/Perplexity mode-pick + OODA/small-world):
  `docs/v0.4.6/RESEARCH.md`.
- **Cards/docs updated for the single surface**: cards 17/24/25/26/29/30/31/
  32/33/34/35/37/56/57 + the card index, corpus docs (20-modules, 30-llm,
  31-help, 50-versions), module READMEs, wizard next-steps, `llm-selftest`,
  TESTPLAN.md and the root README all describe `llm chat` only.
