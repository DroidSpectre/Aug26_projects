# Aetherix-Alpine Fork — Build v0.3a.14_3

- **Date:** 2026-08-06
- **VersionName:** v0.3a.14_3 · **versionCode:** 30143
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Fix build 3 of the v0.3a.14 line. Keeps long guest jobs (llama.cpp
  builds) alive through screen-off via a session wakelock, fixes the broken-symlink
  idempotency bug that spammed `FileAlreadyExistsException` every 5s, removes the
  last user-facing Termux mention + duplicate `download`/`downloads` storage link,
  and adds a Dashboard **Licenses** page that states Aetherix-Alpine's own code is
  **proprietary (not open source)** while citing every bundled open-source component.

## Changes

- **FB-053 — Long terminal jobs die on screen-off (llama.cpp build killed at 22%)**
  (`TerminalService.java`, `AndroidManifest.xml`, `llm-module/tier/llm`):
  - Root cause: Android freezes the app process on screen-off; the app held no
    wakelock, so the `c++`/`gmake` children were interrupted
    (`Interrupted system call` → `ERROR: llama.cpp build failed`).
  - Fix: a `PARTIAL_WAKE_LOCK` is held exactly while a terminal session is online
    (acquired on session start, released on session exit / service destroy; the
    static `setOnline()` and `onStartCommand` paths both sync it). Manifest gains
    `WAKE_LOCK`.
  - `llm setup` failure message now says the build is incremental and rerunning
    `llm setup` resumes it, and reminds the user the wakelock is active only while
    the terminal session is running.
- **FB-054 — `FileAlreadyExistsException` spam every 5s (heal, storage links, cert.pem)**
  (`StorageTier.java`):
  - Root cause: `File.exists()` follows symlinks, so a broken symlink reports
    `exists()==false` yet still occupies the path; `createSymbolicLink` then threw
    `FileAlreadyExistsException` on every deploy poll for `/bin/sh`, each
    `~/storage/*` link, and `etc/ssl/cert.pem` — flooding the error report.
  - Fix: `healRootfsBasics()`, `homeLink()` and `ensureCertPem()` now inspect the
    symlink entry itself (`Files.isSymbolicLink`) and delete the stale entry before
    recreating, making all three idempotent and silent when already correct.
  - Acceptance: error report shows no repeated `StorageTier:` exceptions; `Module
    Readiness` heals to `binSh:true` when busybox exists.
- **FB-055 — Dashboard licenses & citations page**
  (`assets/www/licenses.html`, `dashboard.html`):
  - New **Licenses** button on the Dashboard opens a page stating the app's own
    unique methods/code/implementation are **proprietary and not open source**
    (all rights reserved, DroidSpectre), then cites every bundled open-source
    component with license + upstream source: Termux terminal engine (GPL-3.0),
    PRoot (GPL-2.0-or-later), PRoot loader/exec-utils (GPL-3.0), Alpine minirootfs
    (per-package), libtalloc (LGPL-3.0), libandroid-shmem (Apache-2.0), CA bundle
    (MPL-2.0), android-tools (Apache-2.0), plus on-demand guest packages
    (llama.cpp MIT, Xvfb/xterm MIT, x11vnc GPL-2.0, openbox GPL-2.0) and a GPL
    source-availability note.
- **FB-056 — Last user-facing Termux mention + duplicate storage link**
  (`config/modules/hello-module/tier/sd`, `StorageTier.java`):
  - The `sd` usage line no longer says "(like Termux)". Guest + app-side link
    creation are unified on `downloads` (singular `download` removed on the next
    `sd mount`), so `~/storage` shows one Download link instead of two.

## Bugs

| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-053 | Long terminal jobs die on screen-off (llama build killed) | fixed | no wakelock; Android freezes the app on screen-off, interrupting compile children | PARTIAL_WAKE_LOCK while session online; incremental-build resume hint |
| FB-054 | `FileAlreadyExistsException` spam every 5s | fixed | `File.exists()` false for broken symlinks; `createSymbolicLink` threw on the stale entry | symlink-entry check + delete before recreate (heal, homeLink, cert.pem) |
| FB-055 | No licenses/citations in-app; proprietary status unstated | fixed | no licenses page existed | Dashboard Licenses page: proprietary notice + per-component citations + GPL source note |
| FB-056 | `sd` says "like Termux"; duplicate download/downloads link | fixed | leftover branding string; two link creators disagree on the name | drop Termux mention; unify on `downloads`, prune stale `download` |

## Build & Verification Notes

- Build: `bash scripts/build-apk.sh` → `Aetherix-Alpine-v0.3a.14_3.apk`
  (versionCode `30143`), auto-exported to
  `/sdcard/Download/Aetherix-Alpine-Fork/`.
- Verify: `bash config/modules/hello-module/tests/verify-apk.sh v0.3a.14_3`
  → **13/13 passed** (badging 30143, signature v2+v3, DEX markers, all assets
  incl. regenerated hello/gui/llm bundles, device export present).
- On-device acceptance for 14_3:
  - Run `llm setup`, let the build proceed, then turn the screen off and back on:
    the compile continues (no `Interrupted system call`).
  - Error report shows no repeated `StorageTier:` `FileAlreadyExistsException`.
  - Dashboard → Licenses opens the citations page; back returns to the Dashboard.
  - `sd` usage line has no Termux mention; `~/storage` shows `downloads` once.
