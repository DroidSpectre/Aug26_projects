# Aetherix-Alpine Fork — Changelog

## v0.3a.14_3 (fork)

Fix build 3: session wakelock keeps long builds alive (llama.cpp), broken-symlink idempotency (no more 5s exception spam), proprietary notice + Dashboard Licenses page with citations, drop last Termux mention, unify downloads link
