# Aetherix-Alpine Fork — Changelog

## v0.3a.14_7 (fork)

Input fix: the readline warmup is now two-phase (SPACE, verify, DEL). The DEL
only fires when the emulator line is exactly SPACE longer, so a user keystroke
in the gap can never be deleted by the warmup — closing the last surviving
"first digit eaten" vector (FB-052 → FB-067). Reviews confirm ENV-001/ENV-002
need no code change (existing pty-bridge bypass; `/proc/stat` unused in fork).
