# Aetherix-Alpine Fork — Build v0.3a.14_7

- **Date:** 2026-08-09
- **VersionName:** v0.3a.14_7 · **versionCode:** 30147
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** closes the last open input bug. The resize warmup stopped
  injecting a blind `SPACE+DEL` burst that could let the DEL erase a character
  the user typed mid-redraw — the suspected "first digit eaten" flip behind
  FB-052. Everything else in the register is either fixed, environmental, or a
  documented mitigation (PRoot stays; `/proc/stat` is not read anywhere in the
  fork).

## Changes

- **FB-067 / FB-052 — Verified two-phase warmup**
  (`app/.../terminal/TerminalSession.java`):
  - Warmup now sends SPACE alone, waits 40 ms, re-reads the emulator line, and
    sends DEL **only** when the sole visible addition is the injected SPACE
    (line length exactly +1). A character typed in the gap makes the length
    check fail, so DEL never fires — eliminating the last known path where the
    first digit could be eaten by the resize redraw.
  - Keeps all existing guards (alt-screen, non-empty command line, recent
    write). Logs now distinguish `WARMUP: injected space reverted with DEL`
    from `WARMUP: readline consumed SPACE - user input untouched`.

## Reviewed, no change needed

- **ENV-001 (Samsung `TIOCSWINSZ`/`TIOCSIG`)**: already mitigated by the
  pty-bridge userspace bypass (session-wide SIGWINCH chain + libfaketty); the
  14_4 device logs show "debounced resize signal sent / session-wide SIGWINCH
  procs" working. Nothing else implementable from user space.
- **ENV-002 (`/proc/stat` denied)**: `rg proc/stat` finds zero reads in the
  fork — the telemetry that wanted it lives only upstream (FB-031 removed GPU
  usage polling in 14_3). Nothing to fix.
- **Hypothesized 14_5 latents re-checked**: async install leaves the drop
  folder unaffected; the build-progress poll reads a 64 KB tail (bounded); the
  llm `build_alive()` check picks up `cmake --build` even if a zombie script
  lingers. No additional code change warranted for this pass.
