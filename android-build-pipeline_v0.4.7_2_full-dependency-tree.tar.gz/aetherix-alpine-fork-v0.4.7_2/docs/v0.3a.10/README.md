# Aetherix-Alpine Fork — Build v0.3a.10

- **Date:** 2026-08-05
- **VersionName:** v0.3a.10 · **versionCode:** 30010
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** The v0.3a.9 on-device selftest proved the module system works
  (hello-module marker PASS) but showed **every** tier helper missing (`sd`,
  `device-info`, `elv`, `gui`, `llm`, `module`), no `~/storage` links and no
  aliases — i.e. `StorageTier.deploy()` silently did nothing on that device.
  This build makes deploy visible, reliable, and self-healing (FB-025..FB-027).

## Changes
- **FB-025 — `StorageTier.deploy()` silently skipped/failed with zero helpers
  deployed** (`StorageTier.java`):
  - Root cause: deploy ran only at app start (rootfs missing on fresh
    installs → early bail), on the 5s dashboard poll, and on Step-7 success;
    any failure was swallowed by `catch (Exception ignored) {}`, so the app
    could not report why nothing was deployed.
  - Fix: every deploy step is logged to `BridgeLogBuffer` (visible in the
    error report log tail) on failure; the skip reason is logged once per
    streak; the blanket catch now surfaces the exception. Extra deploy
    triggers were added so it runs at moments writes are known to work:
    - end of Step 5 (packages — right after the app writes `.bashrc` and the
      profile scripts into the same rootfs),
    - terminal start (`TerminalActivity.startShell`), and
    - module install (`ModuleManager.installModule`).
- **FB-026 — `device.conf` never written on fresh installs**
  (`StepRunner.writeDeviceConf`):
  - Root cause: `FileOutputStream` was pointed at
    `rootfs/etc/aetherix/device.conf` without creating `etc/aetherix` first;
    on a fresh rootfs that directory does not exist, so the write threw
    `FileNotFoundException` and was silently logged away. The selftest's
    `device.conf` check failed as a result.
  - Fix: `conf.getParentFile().mkdirs()` before writing.
- **FB-027 — environment does not self-heal if app-side deploy cannot run**
  (`hello-module` v1.1.0):
  - The guest-side post-install (which provably runs — the v0.3a.9 marker
    PASS) now also installs the tier helpers from the bundle's `tier/` dir
    (`sd`, `device-info`, `elv`, `gui`, `llm`, `module`), creates the
    Termux-style `~/storage` link tree, appends the `storage`/`shared`/
    `external`/`usb` aliases, and writes `storage.state` + `device.conf`
    fallbacks. App-side deploy overwrites the same files, so the two paths
    are complementary and idempotent.
  - `scripts/build-hello-module.sh` now syncs `app/src/main/assets/tier/*.sh`
    into the module's `tier/` dir automatically (single source of truth for
    the tier CLIs). Module version bumped to 1.1.0.
- **Consolidation:** v0.3a.10 is a level-1 build; per the 5-build policy the
  docs for v0.3a.5–v0.3a.9 were copied into
  `docs/v0.3a.10/consolidation/level1/` with a synthesis note.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-025 | Tier helpers (`sd`/`device-info`/`elv`/`gui`/`llm`/`module`) missing on device despite passing setup | fixed | `deploy()` silently bailed/skipped and only ran at app start, dashboard poll, Step-7 success; failures swallowed | instrumented deploy logging (error report visible), extra triggers (Step 5 end, terminal start, module install) |
| FB-026 | `device.conf` missing after fresh install (selftest fail) | fixed | `FileOutputStream` to `etc/aetherix/device.conf` without creating the parent dir | `getParentFile().mkdirs()` before write |
| FB-027 | No guest-side fallback when app-side deploy can't run | fixed | helpers existed only as app-side Java writes | hello-module v1.1.0 post-install self-heals helpers, `~/storage` links, aliases, `storage.state`, `device.conf` from the bundle |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30010' versionName='v0.3a.10'`.
- Host-side `verify-apk.sh` passes 13/13.
- Guest-side post-install verified in a chroot of the bundled minirootfs: all
  tier helpers + `~/storage` links + aliases + `storage.state`/`device.conf`
  land correctly.
- On-device verification required:
  1. Fresh install (or Reset & Reinstall) → Initiate Install → all 7 steps
     pass → terminal: `aetherix-selftest` should now pass ALL checks,
     `ls` shows `storage`, `shared` alias cd's.
  2. Modules & Storage → hello-module shows 1.1.0 → Install → re-run
     `aetherix-selftest` (T14).
  3. If any helper is still missing, the error report's log tail now names the
     exact deploy step + exception — paste it back.
