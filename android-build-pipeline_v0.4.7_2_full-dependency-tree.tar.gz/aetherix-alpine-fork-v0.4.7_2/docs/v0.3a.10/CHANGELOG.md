# Aetherix-Alpine Fork — Changelog

## v0.3a.10 (fork)

deploy reliability: instrument StorageTier.deploy, extra triggers, device.conf parent fix, guest-side tier self-heal (FB-025..FB-027)
- FB-025: `StorageTier.deploy()` failures now logged to BridgeLogBuffer (error report visible); extra triggers at Step 5 end, terminal start, and module install.
- FB-026: `device.conf` write now creates `etc/aetherix` first (was FileNotFoundException on fresh rootfs).
- FB-027: hello-module v1.1.0 post-install self-heals tier helpers, `~/storage` links, aliases, `storage.state`, `device.conf` from the bundle; build script syncs `assets/tier/*.sh` into the module.
