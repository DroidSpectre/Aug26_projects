# Aetherix-Alpine Fork — Build v0.4.3

- **Date:** 2026-08-11
- **VersionName:** v0.4.0 series — v0.4.3
- **versionCode:** 40003
- **Summary:** device-workflow release: the keybar sparkle opens the reply
  dock, model downloads run detached, llama.cpp builds with clang + Release
  at Termux-parity speed, and the app owns unified INPUT/OUTPUT folders with
  `io` + `llm export/replies` (FB-109..FB-114).

## What v0.4.3 is

v0.4.3 is the third patch release on the frozen v0.4.0 core. Architecture is
unchanged; the release fixes the sparkle key so it toggles the response dock,
moves model downloads onto the detached job runner, closes the in-app build
speed gap versus Termux (clang + Release + jobs=min(cores,4)), and introduces
a device-agnostic file exchange: the app creates
`Download/Aetherix-Alpine_INPUT` (user dropbox) and
`Download/Aetherix-Alpine_OUTPUT` (exports), and the llm tier saves every
reply to disk with `llm export`/`replies`/`chat-log` to get them back from
the terminal.

## Changes

- **Sparkle key (FB-109)** — ✨ (U+2728) now routes to the reply callback
  like `REPLY` and shows active-highlight; it opens the response window
  instead of typing the emoji.
- **Detached downloads (FB-110)** — `llm hf get` runs through `job run`
  (dock progress bar, prompt returns); inline fallback kept.
- **Build-log export (FB-111)** — defaults to the unified OUTPUT dropbox.
- **Build speed + thermal (FB-112)** — clang + `-DCMAKE_BUILD_TYPE=Release`,
  `-march=<probe> -pipe` CFLAGS, jobs = min(cores,4); `build-status` shows
  thermal zones + cgroup hint.
- **Responses (FB-113)** — per-reply `.md` saves, `llm replies`/`chat-log`,
  `llm export`; auto-open reply dock via `/etc/aetherix/dock.request`.
- **I/O dropbox (FB-114)** — `Downloads/Aetherix-Alpine_INPUT`/`_OUTPUT` on
  all volumes + `~/storage/input|output` links, `AETHERIX_*_DIR` exports,
  `io env|in|out|clean`; INPUT files appear in `llm context`.
- **Fixes** — details in `docs/v0.4.3/CHANGELOG.md`.
  Modules: llm 1.5.0, core 1.2.0 (clang), hello 1.2.0 (io), help 1.1.0.

## Verification

`verify-apk.sh v0.4.3` → 16/16 PASS (badging, signatures, DEX markers, assets,
bundles, hello-bundle helper content, device export). Sandbox llm-tier suite 44/44 (23 v0.4.2 + 21 new:
hf_get detach, io, export/replies/chat-log, build-log export, llm_jobs=4).
Full snapshot in `/sdcard/Download/Aetherix-Alpine_v0.4.3/` (APK + source zip
+ docs).

## Manual device checks (new)

1. Tap the keybar ✨ → the docked response window opens (no emoji inserted);
   tap again to close. Press-and-hold still has the old key.
2. Place `code.py` in `Download/Aetherix-Alpine_INPUT`, run
   `llm ask "review INPUT/code.py for bugs"` → the file is listed in context
   and the fix is suggested; then `llm export` → report lands in
   `Download/Aetherix-Alpine_OUTPUT`.
3. `llm hf get <repo> <file>` → the prompt returns immediately and the job
   dock shows the `[N/M]` download bar.
4. `llm setup` on a fresh rootfs → clang line in the detected toolchain;
   `llm build-status` during a build shows jobs and thermal zones.
5. `llm replies 1` / `llm chat-log 20` from the terminal → saved responses
   and the docked transcript print inline.
6. `io env` → prints the two `AETHERIX_*_DIR` exports the launcher set.
