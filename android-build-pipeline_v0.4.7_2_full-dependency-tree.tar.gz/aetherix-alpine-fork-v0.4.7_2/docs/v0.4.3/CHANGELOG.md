# Aetherix-Alpine Fork — Changelog

## v0.4.3 (fork)

Device-workflow release on the frozen v0.4.0 core: the keybar sparkle opens
the reply dock instead of typing the emoji, model downloads run detached
through the job dock, llama.cpp builds use clang + Release with
jobs=min(cores,4) (Termux-parity speed), and the app owns two device-agnostic
folders — `Download/Aetherix-Alpine_INPUT` (user dropbox) and
`Download/Aetherix-Alpine_OUTPUT` (exports) — backed by an `io` helper and
`llm export`/`replies`/`chat-log` for response export.

- **FB-109 — sparkle reply key**: the keybar ✨ (U+2728) only inserted the
  emoji; pressing it never toggled the LLM response dock. `ExtraKeysView`
  now treats the sparkle as the REPLY key — it routes to the same callback
  and shows the active highlight, so tapping it opens the docked response
  window exactly like the old `Reply` label.
- **FB-110 — detached model downloads**: `llm hf get` blocked the prompt
  while curl ran. It now generates `/opt/aetherix/llm-hf-dl.sh` (per-file,
  content-length aware) and runs it through `job run`, so the dock shows the
  `[N/M]` progress bar and the prompt returns immediately; an inline fallback
  remains for environments without the `job` CLI.
- **FB-111 — build-log export target**: `llm build-log export` wrote to the
  old per-project `~/llama.cpp` dir. It now defaults to the unified OUTPUT
  dropbox (`Downloads/Aetherix-Alpine_OUTPUT`); a third argument still lets
  you override the destination.
- **FB-112 — Termux-parity builds + thermal readout**: in-app builds were
  ~4.5 TU/min on the device while Termux clang/Release/-j4 finished far
  faster. `llm setup` now uses clang (when present) with
  `-DCMAKE_BUILD_TYPE=Release`, exports `CFLAGS/CXXFLAGS` built from the
  PRoot-safe `-march` probe plus `-pipe`, and `llm_jobs()` caps at 4 threads
  (2 only below 3 GiB RAM) instead of a fixed 2. `build-status` also prints
  thermal zone temps + a background-cgroup hint so throttling is visible.
- **FB-113 — response export + auto-open dock**: replies are saved one-file-
  per-reply under `/etc/aetherix/responses/<timestamp>.md`; `llm replies [n]`
  and `llm chat-log [n]` print them inline, and `llm export [path]` copies a
  reply (or any file) into the OUTPUT dropbox. The llm tier also writes
  `/etc/aetherix/dock.request`, which the app polls and clears — a reply
  opens the docked response window automatically from the terminal.
- **FB-114 — unified INPUT/OUTPUT**: the app creates
  `Downloads/Aetherix-Alpine_INPUT` + `_OUTPUT` on the primary and every
  present removable volume (and binds them as `~/storage/input|output`), the
  launcher exports `AETHERIX_INPUT_DIR`/`AETHERIX_OUTPUT_DIR`, and the
  hello-module `io` helper supports `env | in [path] | out <src> [name] |
  clean`. INPUT files are listed with sizes in `llm context`, so
  "llm ask 'review INPUT/foo.py for bugs'" works with no extra setup and the
  report can be exported straight to OUTPUT.
- **Versions**: app v0.4.3 / versionCode 40003; llm-module 1.4.0 → 1.5.0;
  core-module 1.1.0 → 1.2.0 (clang); hello-module 1.1.0 → 1.2.0 (io + sd
  env); help-module 1.0.0 → 1.1.0 (corpus for the new verbs).
- **Snapshot**: per-version folder `Aetherix-Alpine_v0.4.3/` (APK + source
  snapshot + docs) via `build-apk.sh`; sandbox llm suite 44/44.
