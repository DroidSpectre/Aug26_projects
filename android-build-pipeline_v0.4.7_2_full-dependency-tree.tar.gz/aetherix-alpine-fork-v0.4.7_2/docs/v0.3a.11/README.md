# Aetherix-Alpine Fork — Build v0.3a.11

- **Date:** 2026-08-05
- **VersionName:** v0.3a.11 · **versionCode:** 30011
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** App switching no longer drops a live terminal back to the
  dashboard (FB-028); the GUI and LLM tiers are reconfigured from pre-installed
  dashboard add-ons into standalone, installable modules with real functional
  tests (FB-029); `llm setup` is fixed to build llama.cpp from source because
  Alpine ships no llama.cpp package in any branch (FB-030).

## Changes

- **FB-028 — App switch reverts terminal to dashboard while the session is
  still alive** (`MainActivity.java`, `TerminalActivity.java`):
  - Observation: pressing Home / switching apps while a terminal session ran
    in the background restored the Dashboard on return, even though the
    session itself had been preserved.
  - Fix: `MainActivity.onResume()` checks `TerminalSessionManager`
    `.isSessionActive()` and, unless the user explicitly closed the session to
    the dashboard, starts `TerminalActivity` with
    `FLAG_ACTIVITY_REORDER_TO_FRONT` so the live terminal comes back.
  - The "Close (keep running in background)" dialog now persists
    `aetherix_setup.close_to_dashboard = true` so a deliberate close returns
    to the dashboard; the "Exit" action and every fresh `onCreate` consume
    the flag (set `false`) so a genuinely dead session never bounces.

- **FB-029 — GUI + LLM were dashboard add-ons, not installable modules**
  (`dashboard.html`, `assets/tier/`, `config/modules/`, `scripts/`):
  - Both tiers are now standalone modules: `gui-module` (Xvfb + openbox +
    x11vnc, loopback VNC on 127.0.0.1:5901) and `llm-module` (llama.cpp
    OpenAI-compatible server on 127.0.0.1:8080), each shipping `module.yml`,
    a `tier/<cli>` script, `post-install.sh`, README, TESTPLAN, and
    `*-selftest.sh` / `*-smoke.sh` functional tests.
  - Removed the GUI and LLM cards from the dashboard and the `llmModelSet()`
    helper; the elevation card is the only tier card left. `renderTiers()`
    iterates only `elevation`. `InstallBridge.runTier` still whitelists
    `gui|llm` so installed modules can be driven once present.
  - Deleted `app/src/main/assets/tier/gui.sh` + `tier/llm.sh`, so
    `StorageTier.deployTierScripts()` no longer force-installs them; the
    module loader (`ModuleManager.bundledNames()`) auto-discovers all three
    bundled modules (`hello-module`, `gui-module`, `llm-module`) from
    `assets/modules/*.bundle`.
  - New generic `scripts/build-modules.sh` regenerates every bundle from
    `config/modules/*`; hello-module keeps syncing its shared tier CLIs
    (`elv`, `module`) from `app/src/main/assets/tier` and prunes stale
    `gui`/`llm` copies; `scripts/build-hello-module.sh` is now a thin wrapper.
  - `modules.html` empty-state copy updated to name all three bundled modules.

- **FB-030 — `llm setup` always failed: Alpine has no llama.cpp package**
  (`config/modules/llm-module/tier/llm`, `config/modules/gui-module/tier/gui`):
  - Root cause: confirmed against Alpine 3.19–3.22 + edge/testing — no
    `llama.cpp` package exists in any branch, so `apk add llama.cpp` always
    failed on device.
  - Fix: `llm setup` now installs `build-base cmake git curl`, clones
    `https://github.com/ggml-org/llama.cpp` (depth 1) to `/opt/llama.cpp`,
    configures with `-DGGML_NATIVE=OFF -DGGML_OPENMP=OFF -DGGML_BLAS=OFF`
    (portable, no phone-specific tuning), builds only the `llama-server`
    target (`-j2`), and installs it to `/usr/local/bin`. Build takes ~10–30
    min on a phone and needs internet. Verified end-to-end in a throwaway
    chroot + host build of the exact recipe (see notes below).
  - Bonus fix in `gui stop`: stale X sockets are removed
    (`rm -f /tmp/.X11-unix/X$DISP`) so a restart never trips over them.

## Bugs

| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-028 | App switch drops live terminal back to dashboard | fixed | `MainActivity` restored on resume with no knowledge of the running session | `onResume()` reorders `TerminalActivity` to front unless the user closed to dashboard (`close_to_dashboard` pref) |
| FB-029 | GUI + LLM are dashboard add-ons, not installable modules; not working | fixed | tiers auto-deployed from `assets/tier`, no module packaging, no tests | standalone `gui-module` / `llm-module` bundles with CLIs, post-install, selftest/smoke; dashboard cards removed |
| FB-030 | `llm setup` fails — llama.cpp unavailable in Alpine repos | fixed | no llama.cpp package in any Alpine branch | `llm setup` builds `llama-server` from source (build-base + cmake + git, portable flags) |

## Build & Verification Notes

- **Version:** `v0.3a.11` / 30011 (fork line, `scripts/bump-version.sh`).
- **Bundle check:** `scripts/build-modules.sh` → `app/src/main/assets/modules/`
  contains exactly `gui-module.bundle`, `hello-module.bundle`,
  `llm-module.bundle`; `app/src/main/assets/tier/` contains only `elv.sh` +
  `module.sh` (gui/llm no longer force-installed).
- **Guest CLI check (chroot, Alpine 3.19):** `gui setup` (installs xvfb /
  x11vnc / openbox / xterm), `gui start` (X socket `/tmp/.X11-unix/X1` +
  x11vnc on 5901), `gui stop` (socket removed) — all PASS. `pgrep` status in
  the throwaway container shows `stopped` while running only because the
  container has no `/proc` bind; on-device proot binds `/proc`.
- **llama.cpp recipe check:** `apk add build-base cmake git curl` PASS in the
  chroot; network + DNS PASS; full `llama-server` build (clone + configure +
  `cmake --build -j2 --target llama-server`) PASS on an aarch64 host with the
  module's exact flags. On-device `llm setup` is expected to take 10–30 min
  (build from source, internet required).
- **On-device tests:** install hello-module → `aetherix-selftest` (all PASS);
  install gui-module → `gui-selftest`; install llm-module → `llm setup`,
  `llm model ~/models/<file>.gguf`, `llm-selftest` (needs a downloaded
  Qwen3.5-0.8B-IQ4_XS.gguf or SmolLM2-360M-IQ4_XS.gguf in `~/models/`).
- **Isolation:** built only with `scripts/build-apk.sh` (no Gradle CLI);
  `/root/android-dev-env` (opencode) and `/root/Android` untouched.
