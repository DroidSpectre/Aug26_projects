# Aetherix-Alpine Fork — Changelog

## v0.3a.11 (fork)

app-switch returns to live terminal; GUI + LLM become standalone installable modules; llama.cpp builds from source (FB-028..FB-030)
- FB-028: `MainActivity.onResume()` reorders `TerminalActivity` to front when a session is active, unless the user closed it to the dashboard (`close_to_dashboard` pref set by Close/Exit and consumed on `onCreate`).
- FB-029: `gui-module` + `llm-module` standalone bundles (module.yml, tier CLI, post-install, selftest/smoke, TESTPLAN, README); dashboard GUI/LLM cards and `llmModelSet()` removed; `assets/tier` now only `elv.sh` + `module.sh`; new generic `scripts/build-modules.sh`; `modules.html` copy updated.
- FB-030: `llm setup` source-builds `llama-server` (build-base + cmake + git, clone ggml-org/llama.cpp, portable cmake flags, `-j2`); `gui stop` removes stale `/tmp/.X11-unix/X<display>` sockets.
