# Aetherix-Alpine Fork — Build v0.3a.14_13

- **Date:** 2026-08-10
- **VersionName:** v0.3a.14_13
- **versionCode:** 30153
- **Summary:** gui-module archived; LLM reply cap 512 + activity dock (clean apk/curl/build output); chat whitespace fix; reply dock 5/10 rows

## Changes

- **gui-module archived (out of project scope)**
  (`config/archive/`, `scripts/build-modules.sh`, `InstallBridge.java`,
  `WelcomeScript.java`, `StorageTier.java`, `module.sh`, `licenses.html`,
  `hello/core` docs, `device-layers plan`):
  - The X11/VNC desktop tier is retired. `config/modules/gui-module` moved to
    `config/archive/gui-module` (never built — the bundler globs only
    `config/modules/*`) and `assets/modules/gui-module.bundle` was deleted from
    the APK. Part 6 of the v0.3-series device-layers plan is marked ARCHIVED;
    history is retained.
  - Removed every live reference: splash line, dashboard telemetry
    (`data.gui`), `runTier` whitelist (`elv|llm|module|sd`), tier `module.sh`
    guide rows, licenses page entries (Xvfb/xterm/x11vnc/openbox), selftest,
    and core/hello README + TESTPLANs. The project now focuses on the CLI and
    in-app functions (LLM usage, device access).

- **FB-083 — LLM replies truncated at ~200 tokens**
  (`config/modules/llm-module/tier/llm`):
  - `llm ask` and `llm chat` sent `max_tokens:200`, cutting replies mid-thought
    (observed `predicted_n:182`, 51). Default is now **512** with an override:
    `LLM_MAX_TOKENS=<n> llm ask ...` (also honored by `llm chat`). `llm help`
    prints the active cap.

- **FB-084 — clean terminal during package/model/build output**
  (`config/modules/llm-module/tier/llm`, `TerminalActivity.java`):
  - `apk add` in `need_llama` now uses `--no-progress` (Alpine 3.19 apk v2).
  - `llm hf get` no longer runs `curl --progress-bar`. curl runs `-s`; a
    background watcher writes `download: <file> N% (MB/MB)` to
    `/etc/aetherix/llm-download.state` (HEAD `Content-Length` + file-size poll,
    MiB-only fallback when the size is unknown) and cleans it up on success and
    failure.
  - The FB-065 build-progress dock became an **activity dock**: a progress bar
    plus a single current-task line with a braille spinner. While
    `llm.build.state=building` it shows the bar and the last `[N/M]` line from
    `var/log/llm-build.log` (or the latest cmake configure line during probing);
    while `llm-download.state` exists it shows the download percent bar instead.
    No more multi-bar/ghosted progress spam in the pty.

- **FB-085 — `llm chat` whitespace lines reached the model**
  (`config/modules/llm-module/tier/llm`):
  - `    quit` was sent to the model instead of ending the session, and a bare
    space line was treated as a question. Input is now trimmed of leading/
    trailing whitespace before the `exit|quit` match and the empty/skip check.

- **FB-086 — reply dock too short**
  (`TerminalActivity.java`):
  - Dock heights adjusted per device report: **5 lines with the keyboard open,
    10 with it closed** (was 3/5). Keyboard state continues to derive from grid
    rows (`<=35` = IME up on the SM-S166V).

- **Screen-blackout analysis (no code change, CPU-only confirmed)**
  - llama.cpp is already built CPU-only (`GGML_BLAS=OFF`), so no GPU paths were
    added and the blackout is not from GPU use. Documented root-cause candidates
    for deep processing: screen dim under the long-running foreground-service
    wake lock (thermal/doze dim) and thermal throttling during the 10-30 min
    build. If it recurs on-device, capture `dumpsys power | grep -i wake` + the
    error report's TerminalService lines before/after.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-083 | LLM replies truncated ~200 tokens | fixed | `max_tokens:200` hard-coded in ask and chat | default 512 + `LLM_MAX_TOKENS` override, applied to both paths |
| FB-084 | apk/curl/build progress bars clutter the terminal | fixed | apk progress bars + `curl --progress-bar` wrote multiple/ghosted bars into the pty | `apk add --no-progress`; curl `-s` + `/etc/aetherix/llm-download.state` watcher; app activity dock shows one bar, one current task line + spinner for build/download |
| FB-085 | `llm chat` sends `    quit`/whitespace lines to the model | fixed | exit/empty checks ran on raw input | trim leading/trailing whitespace before `exit\|quit` and empty checks |
| FB-086 | Reply dock too short (3 lines) | fixed | 3/5-line heights under-used the closed-keyboard grid | 5 lines keyboard-open / 10 closed (grid rows <=35 = IME up) |

## Build & Verification Notes

- Host: `verify-apk.sh v0.3a.14_13` → 14/14 PASS (badging 30153, v2+v3
  signature, DEX markers, bundles core/hello, no gui bundle, device export).
- Guest flow tests (stubbed curl/apk/llama-server harness):
  - `LLM_MAX_TOKENS=777 llm ask` → request body carries `max_tokens:777`.
  - `llm chat` with `    quit` → leaves cleanly, zero transcript / zero model
    calls; bare-space line skipped while a real line still gets answered
    (exactly 1 curl call, transcript has `you:` + `llm:`).
  - `llm hf get` → no `--progress-bar`, quiet download, `llm-download.state`
    observed during a slow download (`download: slow.gguf 0% (0/0 MiB)`) and
    removed on completion; model saved + set active.
- Java: full source javac-pass clean (with generated R).
- Device checklist (see final report): reply dock 5/10, activity dock during a
  real build + during `llm hf get`, chat whitespace, reply length, selftest
  passes without gui tier.
