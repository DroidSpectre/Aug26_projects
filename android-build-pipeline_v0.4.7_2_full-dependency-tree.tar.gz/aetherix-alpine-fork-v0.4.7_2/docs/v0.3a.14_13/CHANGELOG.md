# Aetherix-Alpine Fork — Changelog

## v0.3a.14_13 (fork)

gui-module archived; LLM reply cap 512 + activity dock (clean apk/curl/build output); chat whitespace fix; reply dock 5/10 rows

- gui-module moved to `config/archive/` + bundle removed; all live references
  dropped (splash, telemetry, runTier whitelist, module guide, licenses,
  selftest, core/hello docs); device-layers Part 6 marked archived.
- FB-083: `llm ask`/`llm chat` reply cap 200 → 512 default, `LLM_MAX_TOKENS=<n>`
  override.
- FB-084: `apk add --no-progress`; `llm hf get` downloads quietly and tracks
  progress via `/etc/aetherix/llm-download.state`; build-progress dock became an
  activity dock (bar + current task line + spinner) for both llama.cpp builds
  and model downloads.
- FB-085: `llm chat` trims whitespace before `exit|quit`/empty checks.
- FB-086: reply dock is 5 lines (keyboard open) / 10 lines (closed).
- Screen-blackout: no code change (CPU-only build confirmed); root-cause
  candidates documented in README.
