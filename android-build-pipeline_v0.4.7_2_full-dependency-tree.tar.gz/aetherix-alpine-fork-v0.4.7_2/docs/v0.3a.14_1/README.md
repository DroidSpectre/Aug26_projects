# Aetherix-Alpine Fork — Build v0.3a.14_1

- **Date:** 2026-08-06
- **VersionName:** v0.3a.14_1 · **versionCode:** 30141
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** First fix build of the v0.3a.14 line. Fixes the terminal toolbar
  (spacing + `Copy All`/`Clear All` labels), the docked-key layout (single row,
  TAB first), the module uninstall path (two-mode popup + marker cleanup), the
  missing guest helpers (deploy retry + verify + PATH), and the llm clone
  failure (root cause: the minirootfs ships no `/etc/ssl/cert.pem`, which is
  git/curl's default CA path — now created as a symlink at setup and in every
  self-heal path). Version scheme: `versionCode = 30000 + major*10 + patch`
  (`v0.3a.14_1` = `30141`).

## Changes

- **FB-042 — Terminal toolbar smushed; labels say Select All/Clear**
  (`TerminalActivity.java`):
  - Toolbar buttons now get uniform 4dp horizontal margins
    (`toolbarButtonParams()`), so `← Close`, timer, `Select All`, `Clear` and
    `✕ Exit` no longer touch each other.
  - `Select All` → `Copy All`, `Clear` → `Clear All` (behavior unchanged:
    Copy All includes the active scrollback transcript; Clear All wipes screen +
    scrollback).
  - Docked keys are now a single row `TAB ESC CTRL ALT ← → ↑ ↓ PASTE`
    (chosen layout: minimal 1-row with TAB before ESC). ALT is the same
    sticky meta toggle as before: cyan when on; letters get an ESC prefix
    (Alt+X → `ESC X`), Enter → `ESC\r`, arrows become xterm modifier-3
    sequences (`ESC[1;3A` etc.) which readline/bash treat as word-wise movement.
- **FB-043 — `git clone` fails: `error setting certificate file: /etc/ssl/cert.pem`**
  (rootfs `StepRunner.java`, `StorageTier.java`, `hello-module/post-install.sh`,
  `llm-module/tier/llm`, `aetherix-selftest.sh`):
  - Root cause: the Alpine minirootfs ships no `/etc/ssl` at all; git/libcurl
    default their CA file to `/etc/ssl/cert.pem`, which never existed, so the
    clone aborted before connecting (this is the error the `llm setup` clone
    retries hid behind `/var/log/llm-clone.log`).
  - Fix: `etc/ssl/cert.pem` is created as a symlink to
    `etc/ssl/certs/ca-certificates.crt` at Step 2 (rootfs build), by
    `StorageTier.deploy()` on every app/terminal start, and self-healed by the
    hello-module post-install and the llm tier before cloning. The llm tier now
    surfaces `apk add` failures instead of hiding them and fails fast with a
    clear message if the CA file is still missing.
  - `aetherix-selftest` gains a `TLS CA cert (/etc/ssl/cert.pem)` check.
  - Manual fix for an existing install:
    ```
    ln -sfn /etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem
    git clone --depth 1 https://github.com/ggml-org/llama.cpp /opt/llama.cpp
    tail -n 40 /var/log/llm-clone.log
    ```
- **FB-044 — Uninstalling a module leaves it on the splash / in `module status`**
  (`ModuleManager.java`, `InstallBridge.java`, `modules.html`):
  - Root cause: uninstall only deleted `var/lib/aetherix-modules/<name>` and
    `etc/aetherix/modules.d/<name>`; the `/etc/aetherix/<name>.installed`
    marker that the splash and `module status` read was never removed.
  - Fix: uninstall now shows a two-choice popup — **Full Erase** (removes the
    module dir, registry, installed marker, state/conf, tier CLIs and
    `/opt/aetherix-tests`; warns that `sd`/`device-info`/`elv`/`module` are
    app-tier and return on the next app start) or **Just Module Code** (removes
    the entry + marker so the module disappears from the UI while keeping the
    installed tools). The installed marker is removed in both modes.
- **FB-045 — Guest helpers missing after fresh setup (`sd`, `device-info`,
  `elv`, `module`)**
  (`StorageTier.java`, `StepRunner.java`):
  - `StorageTier.deploy()` retries for up to ~4s when the rootfs is still
    mid-extraction instead of immediately skipping, then verifies
    `sd`/`device-info`/`elv`/`module` exist and logs a `MISSING helpers` line
    to the error report if any are absent.
  - A defensive `etc/profile.d/01-path.sh` prepends `/usr/local/bin` to PATH
    for login shells (the minirootfs `/etc/profile` already does this; the
    profile.d script covers variants).
  - Acceptance: `aetherix-selftest` reports **0 FAIL** after a fresh setup.

## Bugs

| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-042 | Toolbar buttons smushed; `Select All`/`Clear` labels | fixed | WRAP_CONTENT buttons with no margins; terse labels | 4dp button margins; rename to `Copy All`/`Clear All`; 1-row dock `TAB ESC CTRL ALT ← → ↑ ↓ PASTE` |
| FB-043 | `git clone` fails with `error setting certificate file: /etc/ssl/cert.pem` | fixed | minirootfs ships no `/etc/ssl`; git/curl default CA path missing | create `/etc/ssl/cert.pem` symlink at Step 2, deploy, module self-heal + llm tier; surface `apk add` errors; selftest TLS check |
| FB-044 | Uninstall leaves module on splash / `module status` | fixed | `.installed` marker never removed; single confirm() | two-mode popup (Full Erase / Just Module Code); marker removed in both modes; guest cleanup via launcher |
| FB-045 | Guest helpers missing after fresh setup | fixed | deploy could skip while rootfs mid-extraction; no verification | deploy retry (~4s) + post-deploy verify logged; defensive profile.d PATH script |

## Build & Verification Notes

- Version scheme locked: `versionCode = 30000 + major*10 + patch`
  (`v0.3a.14_1` = `30141`); `scripts/bump-version.sh`, `verify-apk.sh` and
  `release-docs.sh` accept `v0.3a.<n>` and `v0.3a.<n>_<k>`.
- Built with `scripts/build-apk.sh` (fork build, no Gradle).
- `bash config/modules/hello-module/tests/verify-apk.sh v0.3a.14_1` → full pass.
- Device export: `/sdcard/Download/Aetherix-Alpine-Fork/`
  (APK + source snapshot + docs).
- Device acceptance to run:
  ```
  aetherix-selftest          # expect 0 FAIL (sd, device-info, elv, module, TLS CA)
  module status              # must resolve
  sd                         # must resolve (~/storage links)
  git ls-remote https://github.com/ggml-org/llama.cpp HEAD   # TLS works
  ```
