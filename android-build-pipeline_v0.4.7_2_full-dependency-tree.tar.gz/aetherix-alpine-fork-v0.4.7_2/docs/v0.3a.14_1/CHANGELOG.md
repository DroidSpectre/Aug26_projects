# Aetherix-Alpine Fork — Changelog

## v0.3a.14_1 (fork)

Fix build for v0.3a.14: toolbar spacing + Copy All/Clear All labels, 1-row docked keys (TAB ESC CTRL ALT arrows PASTE), two-mode uninstall (Full Erase vs Just Module Code) with marker cleanup, deploy reliability (retry + verify + PATH), and the llm clone TLS fix (`/etc/ssl/cert.pem` symlink). Version scheme now 30000 + major*10 + patch.
