# Aetherix-Alpine Fork — Build v0.3a.0

- **Date:** 2026-08-04
- **VersionName:** v0.3a.0 · **versionCode:** 30000
- **Line:** fork `v0.3a.x` (policy: `docs/v0.3-series/VERSIONING.md` §6)
- **Summary:** First fork release. Resolves the inherited v0.3.3 telemetry compile
  blockers so the fork builds end-to-end, and establishes per-build docs, source
  snapshots, the fork export tree, and git history.

## Changes
- Reconstructed the missing `step4Launcher(...)` method declaration inherited from
  the upstream mid-refactor state (`executeStep` case 3 referenced it; body was
  orphaned at what is now the method header).
- Added `StepRunner.getSystemProperty(String)` hidden-property helper (FB-001).
- Fixed `DevicePayload` battery reads (FB-002).
- Build pipeline: per-build source snapshot zips, fork export tree
  `/sdcard/Download/Aetherix-Alpine-Fork/`, fork-local `archive/` mirror,
  `bump-version.sh` + `release-docs.sh` helpers, Gradle isolation guardrails.
- Fork-only divergence from upstream: version line, export/module paths, and the
  fixes above (see `FORK-NOTES.md` for the snapshot provenance).

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-000 | `StepRunner` missing `step4Launcher` declaration | fixed | Upstream refactor lost the method header while keeping its body; `executeStep` case 3 called it | Reconstructed `private StepResult step4Launcher(Context, LogBuffer, LogCallback)` mirroring sibling step methods |
| FB-001 | `getSystemProperty(String)` undefined in `writeDeviceConf` | fixed | v0.3.3 telemetry WIP referenced a hidden-property helper that did not exist yet | Added private static helper via reflection on `android.os.SystemProperties` |
| FB-002 | `DevicePayload` battery reads fail to compile | fixed | `getSystemService(BATTERY_SERVICE)` returned `Object` uncast; `BATTERY_PROPERTY_VOLTAGE/TEMPERATURE` are hidden from the android-34 SDK stub jar | Cast to `BatteryManager`; `readBatteryProperty()` reflection helper with `-1` fallback |

## Build & Verification Notes
- Toolchain: `aarch64-linux-gnu-gcc` (native), javac 8 target vs
  `platforms/android-34`, d8 `--min-api 26`, apksigner v2/v3.
- Verified: `Aetherix-Alpine-v0.3a.0.apk` (package `com.aetherix.alpine`,
  versionCode 30000 / v0.3a.0), v2+v3 signed, 22 APK entries with native libs.
- Snapshot: `Aetherix-Alpine-v0.3a.0-source.zip` (full buildable source, no
  build artifacts) exported with the APK to the fork device tree.
- Inherited environmental limits (not fork bugs): ENV-001 (Samsung kernel blocks
  TIOCSWINSZ/TIOCSIG — userspace bypass in place), ENV-002 (`/proc/stat` denied;
  btop-style tools fail).
- Interference guard: fork builds write only inside the fork, `/tmp`, and
  `/sdcard/Download/Aetherix-Alpine-Fork/`.
