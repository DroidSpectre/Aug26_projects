# Aetherix-Alpine Fork — Changelog

## v0.3a.14_8 (fork)

HF model downloader + verified Q4 links, full-system wake lock, spinner/prompt/scrollback fixes, device-agnostic storage map (FB-068..FB-075)
