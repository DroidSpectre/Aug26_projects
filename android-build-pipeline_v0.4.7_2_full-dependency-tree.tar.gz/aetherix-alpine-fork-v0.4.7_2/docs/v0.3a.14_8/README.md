# Aetherix-Alpine Fork — Build v0.3a.14_8

- **Date:** 2026-08-09
- **VersionName:** v0.3a.14_8 · **versionCode:** 30148
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** delivers the 14_8 register: HuggingFace model downloads with five
  verified Q4 links, a full-system wake lock while the terminal is visible, no
  more phantom spinner / ghost prompt spaces / cleared-text resurrection, and a
  device-agnostic storage map that replaces the hard-coded `sd` layout.

## Changes

- **FB-068 — HuggingFace Hub module** (`config/modules/llm-module/tier/llm`):
  - `llm hf list <owner/repo>` lists `.gguf` files (with sizes) via the HF
    files API; `llm hf get <owner/repo> <file>` downloads through the public
    `resolve/main` URL into `~/models/` and sets it as the active model.
  - `llm hf` prints five verified phone-friendly Q4 downloads:
    `ggml-org/Qwen3-0.6B-GGUF` (Q4_0), `Qwen/Qwen2.5-0.5B-Instruct-GGUF` and
    `Qwen2.5-1.5B-Instruct-GGUF` (Q4_K_M), `bartowski/SmolLM2-360M-Instruct-GGUF`
    (Q4_K_M), `unsloth/Llama-3.2-1B-Instruct-GGUF` (Q4_K_M),
    `unsloth/gemma-3-1b-it-GGUF` (Q4_K_M). All five resolve URLs were checked
    live (HTTP 206 with redirects).

- **FB-069 — Full-system wake lock** (`TerminalService.java`, `TerminalActivity.java`):
  - New `SCREEN_DIM_WAKE_LOCK` is held while the terminal activity is visible
    (acquired in `onResume`, released in `onPause`/`onDestroy`). The whole
    device stays awake (CPU + dimmed screen) while you work; the existing
    partial wake lock still covers background sessions without pinning the
    screen on.

- **FB-070 — Random idle spinner** (`TerminalSession.java`):
  - `onOutputBytes()` now calls `detectFreshPrompt()`: once the emulator shows a
    prompt at rest (`isPromptAtRest`), `commandPending` clears immediately
    instead of waiting for the 1s UI tick. The spinner can no longer linger at
    an idle prompt after a command finishes.
  - Toolbar Clear calls `markCleared()` so a blank screen never spins.

- **FB-071 — Build log accessible + exportable** (`config/modules/llm-module/tier/llm`):
  - `llm build-log export [dest]` copies the full log to
    `~/storage/downloads/Aetherix-Alpine-Fork/llm-build-<timestamp>.log` by
    default (any path accepted) and prints the destination + size.
  - `llm build-status` and the setup success path now print
    `log: /var/log/llm-build.log   export:  llm build-log export`.

- **FB-072 — Cleared text resurrection** (`TerminalActivity.java`):
  - The toolbar Clear records `lastClearMs`; on resume within 60 s the clear is
    re-applied, so bytes that arrive after Clear (still-running build log, a
    late alt-screen restore) cannot rebuild the cleared transcript.

- **FB-073 — Prompt grows spaces** (`TerminalSession.java`):
  - The resize warmup polls 3× (40/100/160 ms) instead of one 40 ms check. If
    bash paints our injected SPACE late, the poll sees it and sends DEL, so the
    prompt can't accumulate ghost blanks; the instant a user keystroke lands
    the poll aborts (never erases typed input — FB-067 guarantee preserved).

- **FB-074 — Device-agnostic storage** (`StorageTier.java`):
  - Java writes `/etc/aetherix/storage.map` from the exact `StorageManager`
    volumes bound by the launcher (PRIM + one EXT row per SD/USB bind, labelled
    with the volume description).
  - The `sd` helper derives `~/storage` from that map only: sub-folder links
    exist only when the folder exists, removable volumes are skipped when empty
    or stale (no phantom `usb` unless a USB volume is really present), and a
    new `sd env` exports `AETHERIX_STORAGE_PRIMARY` / `AETHERIX_STORAGE_EXTn`.
  - Generated script validated with `bash -n` and a functional smoke test
    (mapping, list, env all correct).

- **FB-075 — Self-test no longer fails on fresh installs**
  (`config/modules/hello-module/tests/aetherix-selftest.sh`):
  - `gui`/`llm` helper checks are conditional on their module-installed
    markers; uninstalled modules report a skip instead of a FAIL. Fixes the
    14_7 `FAIL gui tier helper missing`.

## Reviewed, no change needed

- **STALE builds (14_4-14_5)**: `build_alive()` + `llm build-restart` already
  detect and resume a dead build after an app kill — the 14_7 report showed the
  fix working; no further change.
- **ENV-001 / ENV-002**: unchanged environmental constraints (documented).
- **duplicated `sd`/`dir` browsing**: the terminal tree is the same `~/storage`
  subtree, now single-sourced from `storage.map`; Java binds primary + volumes
  on launch, so "full file access before sd" holds — `sd` only (re)creates
  links.

## Build & Verification Notes

- `scripts/build-apk.sh` → `Aetherix-Alpine-v0.3a.14_8.apk` (4.0 MB, signed
  v2+v3); `verify-apk.sh v0.3a.14_8` → 14/14 PASS; exported to
  `/sdcard/Download/Aetherix-Alpine-Fork/` (APK + source snapshot + docs).
