# Aetherix-Alpine Fork — Changelog

## v0.4.7_1 (fork sub-release)

Correctness re-cut of v0.4.7: no feature changes. Fixes the wizard-tour and
`llm help` redirection errors that users hit on-device (FB-131).

- **FB-131 — unquoted placeholders in the tour/help text**: sample lines
  such as `llm chat --task "<task>"` were emitted with the inner quotes
  unbalanced (`"  ... --task "` closes the string), so busybox ash parsed
  `<task>` / `<q>` / `<question>` as input redirections and printed
  `can't open task: no such file` (and q / question) inside the wizard tour
  and `llm help`. All four sample lines now escape the placeholder quotes.
- Sandbox suite grows T27b/T27c: the wizard tour and `llm help` must contain
  no `can't open` / `cannot open` errors, and placeholders must print quoted.
- Versions: app `v0.4.7_1` / versionCode `40071` (40000 + 7*10 + 1; monotonic
  above v0.4.6_1's 40061); llm-module `1.9.1`; help-module `1.6.0`;
  core-module `1.4.0`. Bundles regenerated; APK + export tarball re-cut.
