# Aetherix-Alpine v0.4.7_1 — wizard/help quoting fix

One-line correctness re-cut of v0.4.7 (FB-131). On-device users running
`llm wizard` (Step 3 tour) or `llm help` saw stray shell errors:

```
/usr/local/bin/llm: line 395: can't open task: no such file
/usr/local/bin/llm: line 396: can't open q: no such file
/usr/local/bin/llm: line 406: can't open question: no such file
```

## Root cause
Sample command lines in the tour/help text had unbalanced quoting:

```sh
echo "  llm chat --task "<task>"    routed multi-hop tool task"
```

The closing `"` ends the string before `<task>`, so busybox ash treats
`<task>` as an input redirection and fails when no file named `task` exists
(same for `<q>` and `<question>`). The `--once "<q>"` line was already
escaped, which is why only three errors showed.

## Fix
Escaped the placeholder quotes on all four sample lines (`--task`, `--web`,
`--docs` in the tour; `--docs` in `llm help`). Verified with the sandbox
suite: new checks T27b/T27c assert the tour and help output contain no
redirection errors and print the placeholders quoted (118 checks, 0 failed).

## Versions
- App: v0.4.7_1 / versionCode 40071 (also restores monotonic installs over
  v0.4.6_1's 40061).
- Modules: core 1.4.0, llm 1.9.1, help 1.6.0.
