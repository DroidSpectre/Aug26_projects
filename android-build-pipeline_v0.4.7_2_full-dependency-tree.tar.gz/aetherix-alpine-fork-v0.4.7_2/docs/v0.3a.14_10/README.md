# Aetherix-Alpine Fork — Build v0.3a.14_10

- **Date:** 2026-08-09
- **VersionName:** v0.3a.14_10
- **versionCode:** 30150
- **Summary:** llm hf dispatch fix + curated model menu; full ~/storage tree seeded at app start

## Changes

- **FB-077 — `llm hf` dispatch fixed + curated model menu**
  (`config/modules/llm-module/tier/llm`):
  - The `list`/`get` subcommands ran `shift 2` inside the `case`, so the repo
    and file args were read from the already-shifted `$2`/`$3` — every
    `llm hf get <owner/repo> <file>` fell into the usage error
    (`usage: llm hf get <owner/repo> <file>`). The dispatch now passes the
    positional args straight through (`list` → `$3`, `get` → `$3`/`$4`).
  - New `llm hf` (no args) interactive menu: numbers 1-5 over the five curated
    phone Q4 models (Qwen3-0.6B, Qwen2.5-0.5B, SmolLM2-360M, Llama-3.2-1B,
    Gemma-3-1B), showing approximate sizes; picking a number downloads into
    `~/models/` and sets the file active. `0`/`q`/Enter cancels. Re-picking an
    already-downloaded file only re-links it (no re-download).
  - Help text updated: `llm hf` = menu, `llm hf list/get` remain explicit.

- **FB-078 — full `~/storage` tree seeded at app start (no `sd mount` needed)**
  (`app/src/main/java/com/aetherix/alpine/a/StorageTier.java`):
  - `deployHomeStorageLinks` previously seeded only `shared` + `downloads`; the
    rest of the tree appeared only after the user ran `sd`/`sd mount`. The Java
    deploy now writes `storage.map` first, then derives the complete link set
    from it on every app start: `shared`, `downloads`, `dcim`, `documents`,
    `music`, `movies`, `pictures`, plus `external`/`externalN` per removable
    volume and `usb` only when the volume label says USB.
  - It wipes only derived symlinks (same name set as `sd`'s `do_mount`) before
    rebuilding, so the tree cannot drift from the map; real files/dirs are
    never touched. `sd mount` remains as a manual refresh/print helper.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-077 | `llm hf get/list` unusable; no guided model picker | `shift 2` inside the `hf` subcommand case moved past the args | pass `$3`/`$4` straight through; `llm hf` no-args = numbered curated menu (auto-download + set active) |
| FB-078 | `~/storage` incomplete until user runs `sd mount` | deploy seeded only `shared`/`downloads` | Java seeds the full tree from `storage.map` on every app start; derived symlinks wiped/rebuilt to the map |

## Build & Verification Notes

- Host: `verify-apk.sh v0.3a.14_10` → 14/14 PASS.
- APK: `Aetherix-Alpine-v0.3a.14_10.apk` (versionCode 30150, signed v2+v3).
- `llm hf` dispatch exercised with a stubbed `curl`: `get` reaches the correct
  resolve URL with repo+file, `list`/shorthand render the file table, no-args
  shows the menu and cancels on `0`.
- Device: fresh shell → `ls ~/storage` shows the full tree before any `sd` run;
  `llm hf` → pick `3` (SmolLM2-360M) → `llm start` chats. Regression surface
  from 14_8/14_9: spinner, warmup, wake lock, `llm build-log export`,
  `aetherix-selftest`.
