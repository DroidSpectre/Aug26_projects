# Aetherix-Alpine Fork — Changelog

## v0.3a.14_10 (fork)

llm hf dispatch fixed + curated model menu; full ~/storage tree seeded at app start (FB-077, FB-078)
