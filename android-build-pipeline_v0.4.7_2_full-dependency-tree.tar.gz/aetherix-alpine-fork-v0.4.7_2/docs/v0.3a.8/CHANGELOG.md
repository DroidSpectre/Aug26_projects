# Aetherix-Alpine Fork — Changelog

## v0.3a.8 (fork)

Fix module rootfs-ready check (wrong apk db path) + deploy storage links/aliases/tier CLIs after setup completes
