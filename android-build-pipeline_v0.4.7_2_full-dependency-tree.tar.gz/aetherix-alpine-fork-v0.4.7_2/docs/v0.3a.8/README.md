# Aetherix-Alpine Fork — Build v0.3a.8

- **Date:** 2026-08-05
- **VersionName:** v0.3a.8 · **versionCode:** 30008
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Fixes the two regressions found on-device after v0.3a.7: module
  install blocked by a wrong apk-db path in the readiness check, and storage
  links/aliases/tier CLIs not appearing until the app was restarted.

## Changes
- **FB-021 — module install still blocked after a fresh setup**
  (`ModuleManager.rootfsReady()`):
  - Root cause: the v0.3a.6 readiness gate required
    `var/lib/apk/db/installed`, but Alpine's apk database lives at
    `lib/apk/db/installed` (the exact path the dashboard package counter
    reads — which is why "Packages: 96" worked while the module install
    failed).
  - Fix: `rootfsReady()` now requires `bin/sh` **and**
    `lib/apk/db/installed`. hello-module installs after the 7-step setup as
    intended.
- **Model guidance:** the LLM tier recommends light, device-friendly models:
  `Qwen3.5-0.8B-IQ4_XS.gguf` or `SmolLM2-360M-IQ4_XS.gguf` in `~/models/`
  (replaces the earlier heavier qwen2.5-1.5b suggestion).
- **FB-022 — `~/storage` links + aliases + tier CLIs missing until app restart**
  (`InstallBridge`):
  - Root cause: `StorageTier.deploy()` only ran in the `InstallBridge`
    constructor (app open) and bailed early when the rootfs did not exist
    yet — so a fresh install opened the app, ran setup, and never deployed
    the `~/storage` link tree, bash aliases, or `elv/gui/llm/module` CLIs
    until the app was killed and reopened.
  - Fix: deploy is now also triggered (idempotent) from `getDashboardData()`
    (the 5s dashboard refresh — once the rootfs exists the links/CLIs appear
    without a restart) and immediately when the final setup step passes.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-021 | Module install says "rootfs not ready" after fresh setup | fixed | readiness gate checked `var/lib/apk/db/installed`; Alpine stores the db at `lib/apk/db/installed` | check `lib/apk/db/installed` (same path the working package counter uses) |
| FB-022 | `~/storage` links / aliases / tier CLIs absent until app restart | fixed | `StorageTier.deploy()` ran only at app open (before setup) | lazy idempotent deploy on 5s dashboard refresh + on final-step completion |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30008' versionName='v0.3a.8'`.
- Host-side `verify-apk.sh` passes 13/13.
- On-device verification still required:
  1. Fresh install → run setup → Modules & Storage: hello-module shows
     version 1.0.0 + available badge; Install succeeds.
  2. Terminal prompt: `ls` shows `storage`; `shared` alias jumps to device
     storage (no app restart needed — wait ~5s on the dashboard after setup).
  3. `module status`, `elv status`, `gui status`, `llm status` all respond.
