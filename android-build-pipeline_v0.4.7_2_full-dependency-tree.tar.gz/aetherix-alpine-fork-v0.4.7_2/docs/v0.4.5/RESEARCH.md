# Research — letting the LLM use the terminal as the user

Question from the project: the read-only agent loop (web/docs/file) never
touches the shell, so the model cannot answer "how full is the disk?" or
"what's eating my battery?" from the device itself. Can the LLM be allowed to
run real Linux commands safely, on a phone, without becoming a root-equivalent
foot-gun?

## Findings
- **The terminal is the highest-value tool on the device.** Small models
  hallucinate when asked about live state (disk %, running processes, file
  sizes). One `df -h` or `ps` answers what a dozen grounded docs cannot.
- **Full shell = full root-equivalent power inside the guest.** The guest runs
  Alpine under PRoot, but from inside it `rm -rf /opt`, `dd of=/dev/block/*`,
  or `reboot` are real. A raw `sh -c "$cmd"` tool is a remote code execution
  primitive, not a tool.
- **Hardwired binary options beat per-command cards.** The guided router
  (v0.4.4) proved that constrained one-token choices are reliable on
  sub-1B models; free-form JSON tool calls are not. Per-command data cards
  would also explode the card network (60+ commands). Instead: ONE card
  ("TERM-TOOLS") that names the shape of the gate plus a packed allowlist the
  tier checks locally — the model only ever picks a command line from its
  short memory, and the tier enforces the policy deterministically.
- **Small-world theory still binds.** The card set stays at 57 nodes / 10 hubs
  with the new 57 TERM-TOOLS hub reachable from 25 LLM and 11 TERMINAL in one
  hop; any "can it run X?" question resolves in ≤6 hops. The router's hop
  count for a terminal task is classify (E) → confirm → command → synthesize =
  ≤4 hops, inside the existing `LLM_ROUTER_MAX` default.
- **Approval model is a hybrid, not a binary.** Three tiers, not one:
  1. read-only/status allowlist (auto-run, zero friction): `ls cat pwd df du
     ps free uname uptime echo printf grep wc stat file head tail find mount
     date id whoami env readlink which basename dirname realpath sha256sum`,
     plus `git status|log`, `llm status|context|docs find`.
  2. everything else needs a per-command yes/no at the terminal; with no TTY
     (a prompt-driven request) it is declined, never silently skipped.
  3. hard denylist, refused always: shell metacharacters (`; | & \` $() > < *
     ? ~ { } [ ]`), redirection, and destructive targets (`rm -rf /`, mkfs,
     dd to `/dev/`, recursive chmod/chown of `/`, reboot/poweroff/halt,
     writes outside `$HOME` and the OUTPUT dropbox).
- **Failure modes are observable by design.** Every refusal prints a reason
  (`refused`/`declined`), the router degrades to a knowledge answer instead of
  hanging, and output is capped (60 lines / 4 KB, 30s timeout) so a runaway or
  noisy command cannot flood the context window.
- **Why allowlist + confirm and not an LLM "judgment" gate?** Sub-1B models
  are poor judges of "is this destructive?"; a pattern match is exact and
  cheap. The user stays the authority on the gray zone (the confirm prompt).

## Decision
- Ship `term_run` as a fifth agent tool and as option E in the guided router.
- Gate it behind `LLM_TERM` (default on; `LLM_TERM=0` removes the tool from
  the native tool JSON, hides option E, and the router degrades to knowledge).
- Keep the user-visible trust story honest: one data card (57 TERM-TOOLS),
  `llm capabilities` prints the ON/OFF state, refusals explain themselves.

## Verification
- Sandbox: allowlist auto-run (`echo`), metachar refuse (`echo hi; poweroff`),
  non-TTY decline (`top`), denylist refuse (`rm -rf /`), `LLM_TERM=0` removes
  the tool, router E path drives step1=E → confirm → `pwd` → synthesized
  disk-space answer. On-device: `llm agent "how full is the disk?"` with a
  small model; expect the guided menu, one confirm (or auto-run df), then a
  cited/grounded answer.
