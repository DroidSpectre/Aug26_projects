# Aetherix-Alpine Fork — Changelog

## v0.4.5 (fork)

Setup-wizard release on the frozen v0.4.0 core: `llm setup`, model picking and
first-run guidance collapse into one guided `llm wizard` flow (splash →
engine build → curated model with RAM-tier reasoning → first-run tour), and
the agent finally gets a gated terminal bridge (`term_run`) — read/status
commands auto-run, everything else asks the user first, destructive/unsafe
shapes are refused outright.

- **FB-120 — LLM setup wizard**: `llm wizard` consolidates the llm-module
  (setup/hf) and help-module (cards/docs) onboarding that was previously
  scattered across `llm setup`, `llm hf`, `llm help` and the app Dashboard.
  It prints a welcome splash with module state, runs the engine install
  (`need_llama`; walks the relevant data cards every ~30s while the detached
  build compiles), offers a curated 5-model picker with size/RAM-tier reasons
  (auto-recommendation from `/proc/meminfo`; non-interactive via
  `WIZARD_MODEL=<1-5>`), then tours first-run usage — start, sample ask,
  context snapshot, capabilities and next-steps (INPUT/OUTPUT dropboxes).
  Tests/fast paths: `WIZARD_SKIP_BUILD=1`, `WIZARD_NO_WAIT=1`.
- **FB-121 — gated terminal bridge (Q5)**: `term_run` gives the agent (native
  loop) and the guided router (option E) safe shell access. Hybrid approval:
  a read-only/status allowlist (`ls cat pwd df du ps free uname uptime echo
  printf grep wc stat file head tail find mount date id whoami env readlink
  which basename dirname realpath sha256sum`, plus `git status|log`,
  `llm status|context|docs find`) auto-runs; everything else asks
  `Run? [y/N]` at the terminal and is declined without a TTY. Hard refusals:
  shell metacharacters, redirection, and destructive targets (`rm -rf /`,
  mkfs, dd to `/dev/`, recursive chmod/chown of `/`, reboot/poweroff, writes
  outside `$HOME`/OUTPUT). Output capped at 60 lines/4 KB with a 30s timeout.
  `LLM_TERM=0` removes the tool from the agent JSON, hides router option E,
  and `llm capabilities` reports `term_run: OFF`.
- **Card 57 TERM-TOOLS**: the on-device data-card set grows to 57 cards /
  10 hubs; the new hub card explains the terminal gate (allowlist, confirm,
  denylist) and updates the hub map (`llm context`) plus cards 56/32/27 to
  reflect the gated bridge and the wizard.
