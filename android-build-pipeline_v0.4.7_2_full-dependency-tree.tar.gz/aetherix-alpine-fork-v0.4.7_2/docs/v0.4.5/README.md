# Aetherix-Alpine v0.4.5 — Setup wizard + gated terminal access

Lay-person summary: this release makes first-time setup a single guided
walkthrough and lets the on-device AI safely inspect the phone's own terminal
when it needs to answer a question.

## What changed
- **`llm wizard` — one guided setup flow.** Instead of jumping between
  `llm setup`, `llm hf`, and the app Dashboard, a new command walks you
  through everything: a welcome screen, "Step 1" building the AI engine,
  "Step 2" picking a phone-sized model (with a recommendation based on your
  phone's RAM and a plain-language reason for each option), and "Step 3" a
  first-run tour (start the engine, ask a sample question, see the context
  snapshot and capabilities, then a next-steps summary with the INPUT/OUTPUT
  dropboxes). While the engine compiles in the background the wizard shows
  the relevant knowledge cards every ~30 seconds, so the wait teaches.
- **`term_run` — the AI can now check the terminal itself.** The agent can
  run safe, read-only/status commands automatically (`ls`, `pwd`, `df`,
  `free`, `echo`, `grep`, ...). For anything else it asks you on-device
  (`Run? [y/N]`), and dangerous shapes (shell tricks, redirection, wiping
  commands) are refused outright. The model can answer "how full is the
  disk?" by actually running `df` instead of guessing.
- **New data card 57 TERM-TOOLS** explains the terminal bridge in the
  on-device help; `llm capabilities` now prints `term_run: ON/OFF`, and
  `LLM_TERM=0` turns the whole bridge off.

## Important
- `term_run` is a phone-shaped safety gate, not full shell access: the model
  never gets a raw prompt. Writes are limited to your home folder and the
  OUTPUT dropbox, output is capped, and every confirmation is per-command.
- `llm wizard` is the recommended entry point; `llm setup` / `llm hf` still
  work standalone for power users.

## For developers
- Wizard: `tier/lib/build.sh` (`wf_splash`, `wf_build`, `wf_model_pick`,
  `wf_firstrun`, `wizard`), dispatched from `tier/llm`.
- Bridge: `tier/lib/agent.sh` (`term_run` + allow/deny policy, router option
  E), `tier/lib/base.sh` (`TERM_ENABLED` in `model_profile`/`capabilities`).
- Full threat model and design rationale: `docs/v0.4.5/RESEARCH.md`.
