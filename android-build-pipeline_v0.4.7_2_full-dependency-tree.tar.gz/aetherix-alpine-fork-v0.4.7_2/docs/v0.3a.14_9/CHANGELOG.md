# Aetherix-Alpine Fork — Changelog

## v0.3a.14_9 (fork)

full-system wake lock owned by foreground service + notification for the whole session lifetime (FB-076)
