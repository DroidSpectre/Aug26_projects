# Aetherix-Alpine Fork — Build v0.3a.14_9

- **Date:** 2026-08-09
- **VersionName:** v0.3a.14_9 · **versionCode:** 30149
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** full-system wake lock is now owned by the foreground service and
  notification, not the terminal activity. The device stays awake (screen
  dimmed + CPU) for the entire lifetime of a terminal session — open,
  backgrounded via Close-to-dashboard, or mid-build — and only sleeps again
  when the session is explicitly exited.

## Changes

- **FB-076 — Session-scoped full-system wake lock**
  (`TerminalService.java`, `TerminalActivity.java`):
  - `TerminalService.setOnline(true)` now acquires BOTH the partial (CPU) and
    the `SCREEN_DIM` (full-system) wake locks; `setOnline(false)` and
    `onDestroy` release both. `syncWakeLock` (service `onCreate`) does the
    same so startup ordering can never drop the lock.
  - `TerminalActivity` no longer acquires/releases the dim lock in
    `onResume`/`onPause`/`onDestroy` — the `onPause` override added in 14_8 was
    removed. A Close-to-dashboard (session still running) or an app switch no
    longer releases the screen lock; only Exit (session destroyed) or service
    destroy does.
  - The notification remains the always-visible indicator of the session's
    awake state (`● Online — duration`).

## Test Plan (host + device)

- Host: `verify-apk.sh v0.3a.14_9` → 14/14 PASS.
- Device: open terminal → screen stays on past timeout; Close-to-dashboard →
  notification `Online`, screen still awake; app switch → awake; Exit → screen
  sleeps normally again. Regression: `llm hf`, `llm build-log export`,
  `aetherix-selftest`, spinner/warmup/storage from 14_8 all unchanged.

## Build & Verification Notes

- `scripts/build-apk.sh` → `Aetherix-Alpine-v0.3a.14_9.apk`; exported to
  `/sdcard/Download/Aetherix-Alpine-Fork/` (APK + source snapshot + docs).
