# Aetherix-Alpine — Versioning Policy (v0.3+)

**Effective:** 3 August 2026 · Supersedes the `v0.2.25_15x` letter-suffix scheme.

## 1. Scheme

From **v0.3.0** onward the project uses semantic versioning without build-letter
suffixes:

```
vMAJOR.MINOR.PATCH
```

| Component | Policy |
|---|---|
| MAJOR | Product-phase milestones (Phase 2/3 gates, breaking architecture changes). |
| MINOR | Backward-compatible feature additions (one per planned release, e.g. v0.3.1). |
| PATCH | Bug fixes, micro-iterations during development, stabilization builds. |

The old `_15x`-style letter suffixes are retired. Iteration within an unreleased
PATCH is tracked only by `versionCode` and build notes; a shipped fix bumps PATCH
(v0.3.0 → v0.3.1 → …).

## 2. versionCode policy

- `versionCode` increments by exactly **+1 per built APK** (current baseline:
  23 = v0.2.25_15x; v0.3.0 = 24).
- The number is the single ordering source for installs; never reuse it.

## 3. Artifact naming

```
Aetherix-Alpine-v0.3.0.apk
Aetherix-Alpine-v0.3.0-snapshot.zip   (only when a snapshot is cut)
```

**Per-version download folders (from v0.4.0 on).** Every released version is
exported to its own folder in the device download tree —
`/sdcard/Download/Aetherix-Alpine_v<version>/` — containing the **source
snapshot and its APK together** (not just change logs), plus the version docs
(README/CHANGELOG/REPORT) and the cumulative register. `scripts/build-apk.sh`
emits this folder automatically; the legacy `Aetherix-Alpine-Fork/` tree
carries the same artifacts for continuity.

## 4. Where the version lives

- Single source of truth: `app/build.gradle` → `versionName` / `versionCode`.
- Runtime consumers read it via `PackageInfo.versionName` (dashboard footer,
  error report header, launcher `AETHERIX_VERSION` env in
  `StepRunner.buildLauncherScript()`), so no other file needs editing per bump.
- `scripts/build-apk.sh` defaults are kept in sync with the current release;
  override per build via `VERSION_NAME=` / `VERSION_CODE=` env vars.

## 5. Release cadence & artifacts


- Each release: APK exported to the external project directory
  (`/sdcard/Download/Aetherix-Alpine/`), CHANGELOG entry appended to
  `CHANGELOG.md`, version row added to the version map.
- Per-build snapshot dirs (`releases/v0.2.25_*`) are **retired**. History is kept
  by: (a) this archive (single full-project snapshot), (b) CHANGELOG.md, (c) the
  roadmap/report docs in `DOCS/`.
- **Recommended (not yet implemented):** `git init` the project at v0.3.0 so
  future history does not depend on archives alone.

## 6. Renumber map (old plan labels → new scheme)

| Old label | New label | Content |
|---|---|---|
| v0.2.26–v0.2.30 (condensed) | **v0.3.1** | StepRunner UX completion: BUG-009 (step count), BUG-011 (internal renames), BUG-010 ('Test & Verify'), BUG-012 (log PASS/FAIL), BUG-013 (info popups) + BUG-014 (warm-up guard) |
| — | **v0.3.2** | Storage tier + module system |
| — | **v0.3.3** | Telemetry tier |
| — | **v0.3.4** | Elevation tier (local adb self-connect) |
| — | **v0.3.5** | GUI tier (Xvfb + VNC in-app) |
| — | **v0.3.6** | LLM tier (llama.cpp CPU build + model manager) |

The five PATCH-sized plans (v0.2.26…v0.2.30) were condensed into a single v0.3.1
so the MINOR slots carry the device-access layers.

Formal plan: `DOCS/plans/aetherix-v0.3-series-device-layers/aetherix-v0.3-series-device-layers-plan.md`.

## 7. Build & verification

- Build: `scripts/build-apk.sh` (sets `VERSION_NAME`, `VERSION_CODE`; signs
  v2/v3; produces `Aetherix-Alpine-v<ver>.apk`).
- Verify before shipping: `versionName`/`versionCode` present in the APK
  (aapt/aapt2 dump), fresh install + 7-step setup passes, dashboard shows the
  correct version, error report header matches.


## 6. Fork line (v0.3a.x) — THIS TREE

Effective: 4 August 2026 · This working copy is a FORK (Codex agent), independent
of the opencode-owned tree at `/root/android-dev-env`.

- Fork version line: `v0.3a.<n>`
- Fork applicationId: `com.aetherix.alpine.a` (upstream uses `com.aetherix.alpine`) — distinct package so fork and upstream apps install side-by-side.
 — baseline `v0.3a.0`, forked from the upstream
  v0.3.3 WIP (versionCode 27).
- versionCode: `30000 + n` (`v0.3a.0` = 30000, `v0.3a.1` = 30001, …). Always
  distinct from upstream codes (≤ 27) so fork and upstream APKs can never be
  mistaken for each other at install time.
- Artifacts: `Aetherix-Alpine-v0.3a.<n>.apk`, exported to the fork tree
  `/sdcard/Download/Aetherix-Alpine-Fork/` — never the upstream
  `/sdcard/Download/Aetherix-Alpine/` tree.
- App module drop folder: `/sdcard/Download/Aetherix-Alpine-Fork/modules/`.
- All other rules in this policy apply unchanged.
