# Aetherix-Alpine: Condensed UX Release + Storage & Module Tier (v0.3.1–v0.3.2)

**Project:** Aetherix-Alpine
**Versions:** v0.3.1 (versionCode 25) → v0.3.2 (versionCode 26), Aug 3–4, 2026
**Device:** Samsung Galaxy A16 5G (SM-A166x, Android 16 / API 36, 4 GB RAM + 4 GB OS swap)
**Prerequisite Reports:** project-report-v0.0.1-v0.2.25_15x (v0.0.1–v0.2.25_15x)

---

## 1. Scope

Two releases under the v0.3 MINOR scheme (one feature per release, versionCode +1):

- **v0.3.1** — condensed StepRunner UX completion (BUG-009…013) + terminal warm-up guard (BUG-014).
- **v0.3.2** — storage tier (All-files access, full-storage binds, `sd` CLI) + first-of-series module loader.

---

## 2. v0.3.1 — Condensed UX + Warm-Up Fix

### 2.1 What Changed

| Bug | Change |
|-----|--------|
| BUG-009 | Dashboard step count is dynamic (`completedCount/stepCount`), no more hard-coded 6/6. |
| BUG-010 | Final step renamed **"Test & Verify"**; runs a real self-test (`VERSION=…`, `proot --version`, `bash --version`, `SELF_TEST_PASS` marker) before passing. |
| BUG-011 | Internal step methods renamed to match display order (`step3Diagnostics` … `step7ShellVerify`); stale "Fix 1–3" names removed. |
| BUG-012 | Main log records `Step N [PASS]/[FAIL]: <output>` for every install and test run. |
| BUG-013 | Per-step info popups: each step explains why it matters before running (60 s latch, `.btn-info` styling). |
| BUG-014 | Warm-up fix: `warmUpReadline()` no longer injects SPACE+DEL when the command line has typed content (the deferred WINCH redraw swallowed the SPACE and the DEL backspaced the user's last digit). New pure-Java `TerminalPromptGuard` with a 9-assertion host test suite — all PASS. |

### 2.2 What Worked

- 9/9 host test assertions for `TerminalPromptGuard` (prompt terminus `:`/`#`/`>`/`%` recognized; typed content detected; null fails safe).
- Build pipeline produced v2/v3-signed APK with the guard, `SELF_TEST_PASS`, `[PASS]:` strings verified inside the dex.

### 2.3 What to Watch

- Field regression (needs the phone): typed digit preserved across keyboard popup; `nano`/`vim` alt-screen guard; 7× `[PASS]` lines in the log.

---

## 3. v0.3.2 — Storage Tier + Module System

### 3.1 What Changed

- **Permission flow:** `MANAGE_EXTERNAL_STORAGE` declared (`usesPermissionFlags="neverForLocation"`); dashboard/modules UI shows grant state; "Grant All-files Access" opens the All-files settings page directly.
- **Launcher binds:** `-b /sdcard:/mnt/sdcard` → `-b /storage/emulated/0:/mnt/sdcard` (writable primary store) plus one dynamic `-b <volume>:/mnt/sd-ext<n>` per removable volume (`StorageManager.getStorageVolumes()` + `getExternalFilesDirs()` fallback). `ensureLauncher()` re-derives binds on every app start.
- **`sd` CLI** (deployed idempotently into the rootfs on every start by `StorageTier.deploy()`): `sd list`, `sd ext`, `sd ls <path>`, `sd cp <src> <dst>`; all fail with a clear message until All-files is granted (gate on `/etc/aetherix/storage.state`).
- **Module loader** (`ModuleManager`): module = gzip tar at `/sdcard/Download/Aetherix-Alpine/modules/<name>.tar.gz` with `module.yml` (name, version) + optional `post-install.sh`. Install validates name/version (tar peek without full extraction), extracts atomically via staged dir into `var/lib/aetherix-modules/<name>/`, records `etc/aetherix/modules.d/<name>/info`, chmods and runs `post-install.sh` through the normal launcher shell (180 s timeout). Re-install overwrites; uninstall removes both trees.
- **Frontend:** new `modules.html` (storage card + module list with Install/Reinstall/Uninstall, gated by grant state); dashboard gains "Modules & Storage" button, Storage Access and Modules-installed rows.
- **Sample module:** `hello-module.tar.gz` (module.yml 0.1.0 + post-install writing `/etc/aetherix/hello-module.installed`) exported to the phone for field testing.

### 3.2 What Worked

- Fresh APK build (22 entries, v2/v3 signed) with `StorageTier`, `ModuleManager`, and all new JS bridge methods verified in the dex; `MANAGE_EXTERNAL_STORAGE` in the manifest; `modules.html` in assets.
- Sample module tarball created and exported (`md5 b5d9642419064120117f77b84e580560`).

### 3.3 What to Watch

- Field regression (needs the phone): grant All-files → `sd list` shows primary + SD; `sd cp` both directions; install `hello-module` from the dashboard, `module status` shows it, post-install marker exists; uninstall cleans; modules page behaves when grant is blocked.
- Binding `/storage/emulated/0` without the grant keeps the FUSE scoped view — `sd` commands intentionally refuse until granted (no silent partial access).

---

## 4. Release Logistics

- Builds: `scripts/build-apk.sh` (manual javac + d8 + apksigner, no gradle dependency resolution), versions read from `app/build.gradle` (25 → 26).
- Exports: `/sdcard/Download/Aetherix-Alpine/Aetherix-Alpine-v0.3.1.apk` (md5 acf93dba…), `Aetherix-Alpine-v0.3.2.apk` (md5 e9963532…), `modules/hello-module.tar.gz`.
- Docs: plan `DOCS/plans/aetherix-v0.3-series-device-layers/`, CHANGELOG, VERSIONING §6 renumber map; archive zip refreshed with new docs.
- No git repository exists at the dev-env root — commit steps skipped by adaptation.

---

## 5. Next

v0.3.3 telemetry tier (device-info, SoC capture at install, Mali/Adreno-detected GPU line, hardware dashboard card). Field regression sets for v0.3.1 and v0.3.2 are pending on-device execution.
