# Aetherix-Alpine — v0.3 Series Implementation Plan: Device-Access Layers

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans / subagent-driven-development. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the prooted Alpine environment behave like a real OS with layered, self-contained device/Android access (storage, hardware telemetry, shell-uid elevation without a PC, GUI, LLM runtime) across the v0.3.x series.

**Architecture:** Pure-userspace capability tiers built on the existing PRoot + JNI bridge core. Each tier is a bind-mount expansion + an in-app JNI/bridge capability + an in-Alpine CLI, shipped independently so every release is install-testable on the target device. Elevation is opt-in, swappable (local adb self-connect today; Shizuku/root later), and degrades gracefully to app-sandbox-only.

**Tech Stack:** Java (manual javac + d8 + apksigner — **no gradle dependency resolution**), WebView (HTML/JS), alpine-minirootfs, PRoot, pty-bridge; in-Alpine: apk, bash, tmux, Xvfb + x11vnc, android-tools (adb), llama.cpp (CPU backend).

## Global Constraints

- Build pipeline is `scripts/build-apk.sh` only: manual javac + d8 + apksigner; `-classpath "$PLATFORM/android.jar"`. Any new Java dependency must be vendored into `app/libs/` and added to both javac and d8 classpaths. External jars (Shizuku) are avoided on principle — the only third-party Java this series adds, if any, lands only after a full build-script impact review.
- Versioning per `VERSIONING.md`: MINOR = one feature per release, versionCode +1 each. v0.3.0 base = versionCode 24 / versionName "v0.3.0".
- No root, no bootloader work, no system writes. Everything in userspace or app-uid.
- Regression set must pass every release: 7-step setup, terminal session, resize (`nano`/`vim`), first keystroke after keyboard popup, error-report header, dashboard count.
- `/sdcard/Download/Aetherix-Alpine/Reports/` is **user-owned and must never be deleted**; treat as non-empty regardless of FUSE listing.
- **Target device: Samsung Galaxy A16 5G** (SM-A166x) — **4 GB RAM + 4 GB OS swap**, Android 16 (API 36), aarch64. SoC (verify at install time via `getprop ro.board.platform` / `ro.soc.model`): **Exynos 1330** (2×Cortex-A78 @2.4 GHz + 6×Cortex-A55 @2.0 GHz, **Mali-G68-MP3**) in most regions; some units ship **Dimensity 6300** (2×Cortex-A76 + 6×A55, Mali-G57). Both: **ARMv8.2-A, no SVE, DOTPROD + FP16 yes, i8mm no**. GPU is **Mali** (never Adreno/KGSL) — all GPU telemetry and Vulkan design must be vendor-detected.

---

---

## Fork status (v0.3a.x line)

The fork implements this plan under its own version line — `v0.3a.<n>`,
versionCode `30000+n`, package `com.aetherix.alpine.a` — fully isolated from
the opencode-owned upstream tree (see `FORK-NOTES.md`). Map of plan parts to
shipped fork builds:

| Plan part | Fork build(s) | Status |
|---|---|---|
| Part 2 — v0.3.1 StepRunner UX (BUG-009…014) | carried from upstream v0.3.1 into the fork baseline | shipped (FB-004 corrected the self-test for PRoot-in-guest) |
| Part 3 — v0.3.2 storage tier + module system | fork baseline + v0.3a.3 storage-permission flow, v0.3a.5 bundled hello-module | shipped |
| Part 4 — v0.3.3 telemetry tier | v0.3a.0 (DevicePayload), v0.3a.3 (dashboard Hardware card), v0.3a.5 (in-Alpine `device-info` CLI) | shipped |
| Part 5 — v0.3.4 elevation tier | v0.3a.7 (foundation: `elv` CLI + dashboard card) | shipped foundation — on-device verification pending (kernel may block loopback adb) |
| Part 6 — v0.3.5 GUI tier | v0.3a.7 (foundation: `gui` CLI + dashboard card, Xvfb+openbox+x11vnc) | **ARCHIVED at v0.3a.14_13** — out of project scope; module moved to `config/archive/gui-module` and removed from future builds (history retained, VNC viewer roadmap dropped) |
| Part 7 — v0.3.6 LLM tier | v0.3a.7 (foundation: `llm` CLI + dashboard card, llama.cpp server) | shipped foundation — in-app chat UI still roadmap |

Checked boxes below are shipped; unchecked are roadmap. History is retained —
nothing was deleted.

**v0.3a.7 note:** at the user's request, the remaining tier foundations
(Parts 5–7) were condensed into one fork build (v0.3a.7) as install-testable
CLIs + dashboard cards, deviating from the upstream one-feature-per-release
rule. In-app VNC viewer (Part 6) and chat UI (Part 7) remain roadmap; each tier
degrades gracefully when packages/network/kernel support is absent.

## Part 1 — Roadmap condensation (v0.3.1–v0.3.5 → one)

The previously planned five consecutive PATCH releases (BUG-009…013) are all small edits to the same three files (`InstallBridge.java`, `StepRunner.java`, and the dashboard HTML/JS/CSS). They share one regression set and have no independently usable value ⇒ **condense into a single v0.3.1**, adding the terminal warm-up fix (BUG-014). This frees the MINOR slots for the device-access series:

| Release | Content | versionCode |
|---|---|---|
| **v0.3.1** | Condensed StepRunner UX (BUG-009…013) + warm-up command-line guard (BUG-014) | 25 |
| **v0.3.2** | Storage tier + module system | 26 |
| **v0.3.3** | Telemetry tier | 27 |
| **v0.3.4** | Elevation tier (local adb self-connect, no 3rd-party) | 28 |
| **v0.3.5** | GUI tier (Xvfb + VNC in-app) | 29 |
| **v0.3.6** | LLM tier (llama.cpp CPU build + model manager) | 30 |
| v0.3.7+ | USB-host peripherals, X-in-app GPU variant, research items | 31… |

---

## Part 2 — v0.3.1: Condensed StepRunner UX + terminal fix (BUG-009…013, BUG-014)

**Release goal:** finish the StepRunner quality-of-life work and the typed-digit-erasure fix in one install-testable build.

### File map

- `app/src/main/assets/www/dashboard.html` — dynamic step count (BUG-009), info-popup styling (BUG-013).
- `app/src/main/assets/www/script.js` — info-popup flow (BUG-013).
- `app/src/main/assets/www/style.css` — info-popup (blue) button variant (BUG-013).
- `app/src/main/java/com/aetherix/alpine/InstallBridge.java` — `STEP_INFO[7]` (BUG-013); PASS/FAIL log lines (BUG-012).
- `app/src/main/java/com/aetherix/alpine/StepRunner.java` — method renames (BUG-010); final-step rename + self-test (BUG-011).
- `app/src/main/java/com/aetherix/alpine/terminal/TerminalPromptGuard.java` — **new** pure-Java line classifier (BUG-014).
- `app/src/main/java/com/aetherix/alpine/terminal/TerminalSession.java` — warm-up guard wiring (BUG-014).
- `tools/WarmUpGuardTest.java` — **new** host-run class test for the guard.
- `app/build.gradle` — versionCode 25 / versionName "v0.3.1".

### Task T1 — BUG-009: dynamic step count

**Files:** `app/src/main/assets/www/dashboard.html`

- [x] **Step 1** — Replace the two hard-coded `6` literals:
  - line 76: `6/6 steps complete` → `–/– steps complete` (static fallback until JS fills it),
  - line 109: `data.completedCount + '/6 steps complete'` → `data.completedCount + '/' + data.stepCount + ' steps complete'`.
- [x] **Step 2 —** Verify no other stale literal survives: `grep -n "6/6\|/6 steps" app/src/main/assets/www/` returns nothing.

### Task T2 — BUG-011: step-name alignment (internal renames)

**Files:** `app/src/main/java/com/aetherix/alpine/StepRunner.java`

- [x] **Step 1** — Rename (behavior-identical, dispatch table `executeStep()` cases update):
  `step25FunctionTest` → `step3Diagnostics`,
  `step3Launcher` → `step4Launcher`,
  `step4AlpineInit` → `step5AlpineInit`,
  `step5PtyBridge` → `step6PtyBridge`,
  `step6ShellReady` → `step7ShellVerify`,
  and update every call site in `executeStep()`.
- [x] **Step 2** — Remove the stale extra entries at the tail of `getStepName(int)` ("Fix 1: Terminal Background Color", "Fix 2: Keyboard Popup", "Fix 3: ExtraKeysView") so the 7-step name list matches `STEP_NAMES[]`.
- [x] **Step 3** — Verify: `grep -rn "step25FunctionTest\|Fix 1:\|Fix 2:\|Fix 3:" app/src/main/java/` returns nothing.

### Task T3 — BUG-010: "Test & Verify" final step

**Files:** `StepRunner.java`, `InstallBridge.java`

- [x] **Step 1** — In `StepRunner.step7ShellVerify` (`case 6` in `executeStep`), after the existing `SHELL_READY` readback, run a second launched-shell self-test and require its marker:

```java
StepResult selftest = execStreaming(context,
    "/system/bin/sh " + launcher + " 'echo VERSION=$AETHERIX_VERSION && proot --version >/dev/null 2>&1 && bash --version >/dev/null 2>&1 && echo SELF_TEST_PASS'",
    log, cb);
if (!selftest.success || !selftest.output.contains("SELF_TEST_PASS")) {
    log.append("ERROR: self-test failed: " + selftest.output.trim());
    return new StepResult(false, "", "Self-test not passed");
}
```

- [x] **Step 2** — In `InstallBridge` rename `STEP_NAMES[6]` → `"Test & Verify"` and `STEP_DESCS[6]` → `"Full shell test plus a version self-test, then final verify"`.
- [x] **Step 3** — Verify: dashboard final card reads `tested` `Test & Verify`; the main log shows the `SELF_TEST_PASS` marker.

### Task T4 — BUG-012: PASS/FAIL rows in the main log

**Files:** `InstallBridge.java` (small)

- [x] **Step 1** — In the step `onFinished(...)` callback, before `pushStepResult`, append to `log`: `Step N [PASS]: <output>` or `[FAIL]: <output>` (trim `output`, drop empty). Do the same in the `checkStep` completion path.
- [x] **Step 2** — No change needed elsewhere; `verify()` already writes per-check lines.
- [x] **Step 3** — Field: a full setup run's log shows exactly 7 `Step N [PASS]` lines.

### TASK T5 — BUG-013: per-step info popups

**Files:** `InstallBridge.java`, `index.html`/`style.css`/`script.js` (one small each)

- [x] **Step 1** — Add to `InstallBridge` a parallel `STEP_INFO[7]` array (≤140 chars each; why the step matters, not the mechanics):
  1. "Installs the PRoot layer Alpine runs on; required before anything else."
  2. "Creates the Alpine root filesystem from the bundled minirootfs."
  3. "Checks SELinux, shell, proot, storage, rootfs health and internet reachability."
  4. "Builds the launch command with all Android bind mounts and helper libs."
  5. "Initializes the package manager and installs bash/coreutils; first internet use."
  6. "Connects the PTY bridge so the terminal can run inside the sandbox."
  7. "Confirms the whole environment with a shell and self-test."
- [x] **Step 2** — In `installStep(int index)`, before `runner.runStep(...)`, show the info dialog for that step using the existing `showConfirmDialog` latch, then proceed. Prefix the message `INFO:` so the confirm dialog `Continue` button is styled `.btn-info`.
- [x] **Step 3** — `style.css`: add `.btn-info { background: #1f6feb; color:#fff; }`; `script.js`: set that class when the dialog message starts with `INFO:`.
- [x] **Step 4** — Verify: launching step 6 shows its blue info popup once, then the actual confirm dialog; no double-run.

### Task T6 — BUG-014: warm-up must not erase typed input (TDD)

**Root cause (field):** `TerminalSession.updateSize()`→`warmUpReadline(300)` injects `0x20 0x7f` (SPACE DEL) after **every** resize. When the keyboard pops up mid-typing, bash's deferred SIGWINCH redraw swallows the `0x20`, and the `0x7f` then backspaces the user's last typed digit.

**Fix principle:** never inject SPACE+DEL when the current command line is non-empty (DEL would eat real characters). Prompt-only rows are safe.

- [x] **Step 1 — Write the failing host test** (`tools/WarmUpGuardTest.java`, run by system `javac`/`java`; the class under test has no Android imports):

```java
package com.aetherix.alpine.terminal;

/**
 * Decides whether a visible prompt line holds typed content, so the SPACE+DEL
 * resize primer never overwrites/erasures a running command line. bash prompts
 * end in a terminator char (':', '#', '$', '%', '>'); typed text appends
 * characters that do not. null / empty lines = no content (safe to prime).
 */
final class TerminalPromptGuard {
    private static final String PROMPT_TERMINATORS = ".#$%>";

    private TerminalPromptGuard() {}

    /** @return true if the line holds typed input (priming must be skipped) */
    static boolean hasTypedContent(String line) {
        if (line == null) return true;
        String t = line.replaceAll("[ \\t\\r]*$", "");
        if (t.length() == 0) return false;
        return PROMPT_TERMINATORS.indexOf(t.charAt(t.length() - 1)) < 0;
    }
}
```

```java
import com.aetherix.alpine.terminal.TerminalPromptGuard;

public class WarmUpGuardTest {
    private static int fails;

    private static void check(boolean got, boolean expect, String name) {
        System.out.println((got == expect ? "PASS " : "FAIL ") + name + " got=" + got);
        if (got != expect) fails++;
    }

    public static void main(String[] args) {
        check(TerminalPromptGuard.hasTypedContent(""), false, "empty line");
        check(TerminalPromptGuard.hasTypedContent("   "), false, "whitespace only");
        check(TerminalPromptGuard.hasTypedContent("root@A16:"), false, "prompt terminus ':'");
        check(TerminalPromptGuard.hasTypedContent("root@A16:~#"), false, "prompt terminus '#'");
        check(TerminalPromptGuard.hasTypedContent(">>>  "), false, "python repl prompt");
        check(TerminalPromptGuard.hasTypedContent("root@A16:~# l"), true, "typed letter");
        check(TerminalPromptGuard.hasTypedContent("ls -la /"), true, "typed command");
        check(TerminalPromptGuard.hasTypedContent("rm -rf ~/.cach" + "e"), true, "trailing non-terminator");
        check(TerminalPromptGuard.hasTypedContent(null), true, "null -> skip (fail safe)");
        System.exit(fails == 0 ? 0 : 1);
    }
}
```

- [x] **Step 2 — Run, expect red:** `javac -d tools/out tools/WarmUpGuardTest.java app/src/main/java/com/aetherix/alpine/terminal/TerminalPromptGuard.java && java -cp tools/out WarmUpGuardTest`. With the class missing, javac fails (red). Then write the class below; the red→green loop is real: a naive implementation (e.g., only `isEmpty()` checks) fails the `"root@A16:~# l"` case, and the final implementation passes all 9 assertions.
- [x] **Step 3 — Implement exactly the class above (final), re-run:** all 9 assertions PASS, exit 0.
- [x] **Step 4 — Wire into TerminalSession** — in `warmUpReadline`'s `postDelayed` runnable, insert before `pty.write(...)`:

```java
// BUG-014: never prime a non-empty command line — the deferred WINCH
// redraw swallows the SPACE, and the DEL backspaces the user's last char.
try {
    int row = emulator.getCursorRow();
    String line = emulator.getScreen().getSelectedText(0, row, emulator.mColumns, row + 1);
    if (TerminalPromptGuard.hasTypedContent(line)) {
        BridgeLogBuffer.append("WARMUP: skip (command line non-empty)");
        return;
    }
} catch (Exception e) {
    return;
}
```

- [x] **Step 5 — Field regression:** type at the prompt → summon the keyboard → the last digit is preserved; new prompt + popup still warms up (the `#` / `:` class stays fixed). Verify `nano`/`vim` alt-screen guard still applies.
- [x] **Step 6 — Commit:** `git add app/src/main/java/com/aetherix/alpine/terminal/TerminalPromptGuard.java app/src/main/java/com/aetherix/alpine/terminal/TerminalSession.java tools/WarmUpGuardTest.java` — message `fix(terminal): never warm a non-empty command line (BUG-014)`.

### Task T7 — v0.3.1 release

- [x] **Step 1** — `app/build.gradle`: `versionCode 25`, `versionName "v0.3.1"`.
- [x] **Step 2** — `./scripts/build-apk.sh`; assert the header prints `versionCode=25 versionName='v0.3.1'`; APK name `Aetherix-Alpine-v0.3.1.apk`.
- [x] **Step 3** — Run the full regression set (see Global Constraints); export APK to `/sdcard/Download/Aetherix-Alpine/`.
- [x] **Step 4** — CHANGELOG entry + VERSIONING.md §6 map; archive manifest/zip refresh if docs changed.

---

## Part 3 — v0.3.2: Storage tier + module system

> **Fork status:** shipped across v0.3a.0/v0.3a.3 (All-files flow, full-storage binds, `sd` CLI, `ModuleManager`, `modules.html`); v0.3a.5 adds the bundled `hello-module` in `assets/modules/` so the sample is installable without sideloading a tarball.


**Goal:** full storage as a user sees it: All-files access; bind shared storage + the active SD and let Alpine traverse/copy them; first-of-series **module loader** so later GPU/LLM/elevate bundles upgrade without any APK rebuild.

### Design

- **Permission flow:** `MANAGE_EXTERNAL_STORAGE` request → the All-files settings page in the app (dashboard "Storage" card shows granted/blocked).
- **Binds (`StepRunner.buildLauncherScript()`):** replace `-b /sdcard:/mnt/sdcard` with `-b /storage/emulated/0:/mnt/sdcard` (writable), plus one dynamic bind per removable volume found via `StorageManager.getVolumeList()`/`context.getExternalFilesDirs()`. `ensureLauncher()` re-derives binds every app start.
- **`sd` CLI:** 4 `sh` scripts in `/usr/local/bin/` (`sd list`, `sd ext`, `sd ls <path>`, `sd cp <src> <dst>`); fail with a clear message when All-files not granted.
- **Module loader (core reusable component):**
  - `app/src/main/java/com/aetherix/alpine/module/ModuleManager.java` — `@JavascriptInterface listModules(): String` and `installModule(String uri)`; JS-visible dashboard "Modules" panel.
  - Module = a gzip tar renamed-plain at `/sdcard/Download/Aetherix-Alpine/modules/<name>.tar.gz` with a `module.yml`(`name`, `version`, optional `post-install.sh`) at its root.
  - Install = atomically extract into `rootfs/var/lib/aetherix-modules/<name>/`, write `/rootfs/etc/aetherix/modules.d/<name>/info`, `chmod +x post-install`, then run `post-install.sh` through the launcher with the env of the normal shell.
  - Versioning: re-install overwrites; counts and `module status` on the dashboard (shipped: in-terminal `module status` CLI in v0.3a.7).
- **Frontend:** new `modules.html` + storage access panel, both gated by the grant state.

### Verification

1. All-files granted → in-Alpine `sd list` shows the primary store; insert SD → second entry; copy a file both directions.
2. A sample `gui-min` tarball installs, `module status` shows it, `post-install` ran, `rm -rf` uninstall cleans it.

---

## Part 4 — v0.3.3: Telemetry tier

> **Fork status:** shipped across v0.3a.0 (DevicePayload), v0.3a.3 (step-3 SoC capture + `device.conf`, dashboard Hardware card via one `getTelemetry()` JS bridge — covers the planned getBattery/getMem/getThermal/getSoC/getGpu surface), and v0.3a.5 (idempotent in-Alpine `device-info` CLI in `/usr/local/bin`).


**Goal:** Alpine reads real device state — battery / thermal / RAM / GPU / SoC — with a one-shot `device-info` and matching dashboard card. No new permission (public APIs + world-readable sysfs/proc).

### Files

- `app/src/main/java/com/aetherix/alpine/DevicePayload.java` — pure JVM: sticky `BatteryManager` intent (level, tempC, voltage, status), `ActivityManager.getMemoryInfo()`, `/proc/meminfo`; returns one JSON blob.
- SoC/version capture: at install time (`StepRunner.step3Diagnostics`) run `getprop ro.board.platform`, `getprop ro.soc.model`, `getprop ro.product.cpu.abi`; write `/etc/aetherix/device.conf` in the rootfs.
- **Vendor-detected GPU:** in-Alpine script `device-info gpu` globs `/sys/kernel/gpu/` for `gpu_busy`/`gpu_clock` (Mali — the likely hardware here), then `/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage` (Adreno — other devices), then prints `GPU: Mali "busy N/A"` otherwise. No crash on missing paths.
- Dashboard card "Hardware": filled by new JS bridge methods `getBattery`, `getMem`, `getThermal`, `getSoC()`, `getGpu()` (thermal zones parsed in Java).
- In-Alpine `device-info` (sh) — single command printing `battery/temp/mem/thermal/gpu/soc` in `key: value` lines; reads the JSON from the bridge if the caller passes `--via-bridge`, else from `/sys` directly.

### Verification

Fresh install shows battery %, temperature, memory used/total, thermal zones, GPU line (honest "N/A" on this SoC if unknown), SoC name from `device.conf`. `device-info` in terminal matches dashboard.

---

## Part 5 — v0.3.4: Elevation tier — local adb self-connect (no Shizuku, no PC)

### Design — "Alpine acts as the laptop" (your model, proven)

Android's **wireless-debugging adbd accepts loopback connections** from the device itself. The app is its own "laptop": it pairs over `127.0.0.1` with the on-screen 6-digit PIN, then every `adb shell` run inside Alpine executes as Android's **shell user (uid 2000)** — more than the sandbox, less than root. This is exactly the mechanism LADB / AdbShellTool / Shizuku-wireless rely on. **No computer, no third-party app:** the real `adb` binary comes from Alpine's own `android-tools` package.

Requirements: Developer options + Wireless debugging toggled on, a WiFi association (a router without internet works; a mobile hotspot works; internet not needed), one-time pairing with the PIN, session drops on lock/app-switch/reboot and re-elevates with one tap (pairing persists).

**Hardware risk (2026, honest):** CVE-2026-0073. adbd TLS-verify bug (Android 14–16) has Google weighing a loopback-block. If it lands: elevation degrades to the sandbox provider. The adapter keeps this painless.

### Files

- `app/src/main/java/com/aetherix/alpine/elevate/ElevationManager.java` — state machine `IDLE → WAITING_FOR_USER_SWITCH → PAIRING → CONNECTED`; uses `NsdManager` to discover `_adb-tls-pairing._tcp` and `_adb-tls-connect._tcp` next.
- `app/src/main/java/com/aetherix/alpine/elevate/AdbPeer.java` — minimal adb client bits (SPAKE2 pairing + TLS session). Priority: **use the real adb binary** in Alpine for the heavy lifting; the app only automates discovery, captures the PIN, and keeps `adb connect 127.0.0.1:port` alive.
- `assets/www/elevate.html` + dashboard link — guided flow with status text; one-tap reconnect.
- `StepRunner`/setup — a new (re)install step or module ensures `apk add android-tools`, and a mount helper writes `/usr/local/bin/` wrappers: `aadb-shell`, `a-pm`, `a-dumpsys`, `a-settings`, `a-service` that exec `adb shell <args>`.
- **Provider adapter (design-lock for later):**

```java
public interface ElevationProvider {
    boolean isAvailable();
    boolean isElevated();
    void elevate(Activity activity, Callback<ElevationSession> cb);
}
public interface ElevationSession {
    String exec(String command);   // shell-uid; returns merged out
    void close();
}
```

`SandboxElevationProvider` implements the same interface with public APIs only (passive fallback). Future `ShizukuProvider`/`RootProvider` slot in without UI changes.

### Verification (safe, on-device)

1. Elevate reaches ACTIVE with no PC; from Alpine `proot` run `a-dumpsys battery | head -5` prints real lines; `id -u` inside proot still shows 0 (fake root) — elevation is verified via command capability, not UID.
2. After use, `adb_wifi_enabled` returns to 0 (auto-disable), sleeps; re-elevate from the app reconnects without re-pairing.
3. Reboot → "Re-elevate" path works; with wireless debug off → manager reports `sandbox only`; nothing crashes.

---

## Part 6 — v0.3.5: GUI tier — X server + VNC (lightweight, self-contained)

- **Ships:** module `gui-min` = `apk add xvfb openbox x11vnc ttf-dejavu`, launcher `/opt/aetherix-gui/start.sh` runs `Xvfb :0 -screen 0 1280x800x24 & openbox & x11vnc -display :0 -forever -shared -ncache 10`.
- `app/src/main/java/com/aetherix/alpine/gui/VncActivity.java` — RFB client (raw/hextile/ZRLE) over a local socket `127.0.0.1:5900` (no open ports on the network), Canvas renderer (reuse the terminal codec pattern), touch→pointer/scroll mapping.
- Dashboard "Desktop" button once the module is present.
- **Research track B (documented, later):** full in-app X server — the app renders the X desktop directly via EGL/GLES surfaces (XSDL/Termux:X11-style) dropping the VNC hop and enabling GPU-accelerated GLES inside proot; to be designed after v0.3.5 ships.

### Verification

Desktop button opens; guest shows the X11 desktop; open a window in the guest; rotate the phone → pointer/scroll sane; closing stops openbox/x11vnc.

---

## Part 7 — v0.3.6: LLM tier — llama.cpp CPU build + model manager

**Device-corrected facts:** CPU = 2×A78 (Exynos 1330) or 2×A76 (Dimensity 6300); both plain ARMv8.2-A: DOTPROD + FP16 yes, SVE no, i8mm no ⇒ `-march=armv8.2-a+dotprod+fp16`. RAM = 4 GB + 4 GB swap ⇒ ~2.5–3 GB usable for a model; realistic sizing **0.5–1.5 B Q4_K_M**, 3 B with noticeable swap pressure. GPU = Mali → **CPU backend is the default universal route**; Vulkan/OpenCL experimental behind a flag.

### llama.cpp build (module `llm-runtime`, native CPU)

```bash
apk add clang cmake git build-base python3
cd llama.cpp
cmake -B build \
  -DGGML_NATIVE=OFF \
  -DGGML_CPU_ARM_ARCH=armv8.2-a+dotprod+fp16 \
  -DGGML_OPENMP=OFF -DGGML_LLAMAFILE=OFF \
  -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
# contingency: sed -i 's/sched_getaffinity_np/sched_getaffinity/g' <ggml sources> if sched_getaffinity_np is missing on Alpine musl
```

- **Detection truth, not guesses:** add `hwcaps` helper that prints `dotprod fp16 sve i8mm` from `AT_HWCAP` (`/proc/self/auxv` or a tiny C "getauxxval" helper). Never trust `/proc/cpuinfo` or `/sys/devices/system/cpu/possible` (empty/masked for apps).
- **Model manager** (`assets/www/llm.html` + Java): download URL → `/sdcard/Download/Aetherix-Alpine/models/` (bind-compatible), a TUI prompt to `start llama-server -m <model> --port 8080 --n-gpu-layers 0` and `llama-bench`.
- **Knowledge baseline from issues:** #402 (illegal instruction from `-mcpu=native` on ARM), #10952 (CMake "failed to get ARM features"), #11488 (empty CPU list), #12452; Vulkan: #5186/#9664/#10406/#11248/#16881 — tl;dr the CPU default is the right default; update the mapping only when direct experimental evidence flips it.

### Research list (roadmap; no commitment)

1. Vulkan-in-proot for musl (Termux ships a loader wrapper — portability study; llama.cpp Vulkan backend quality on Mali/Adreno now).
2. Qualcomm NPU / Mali-CL FGLNS paths — async; document for other devices.
3. In-app X server / EGL passthrough (§6 path B) and whether it can credit regular GLES apps in the guest.

---

## §8 — Release procedure (every release)

1. `app/build.gradle` versionCode/version bump mandatory; `scripts/build-apk.sh` must print `GRADLE_VERSION_CODE`/`GRADLE_VERSION_NAME`.
2. Build, `Aetherix-Alpine-v0.3.x.apk`, export, field regression against the release's test set.
3. CHANGELOG + VERSIONING.md §6 map + project report sync in `DOCS/reports/`.
4. `ARCHIVE-MANIFEST`/archive zip refresh only when `docs/` or `DOCS/` change (per the bug register).

## References

- Android 16 sepolicy `app_neverallows.te`: untrusted apps blocked from `/proc/version`, `/proc/stat`, `/proc/mounts`, `/proc/uptime`, `/proc/slabinfo`, `/proc/vmstat` — the reason llama / tooling must not rely on them.
- llama.cpp issues 402, 10952, 11488, 12452, 5186/9664/10406/11248/16881, PR #348.
- adb wireless: mDNS `_adb-tls-pairing._tcp` / `_adb-tls-connect._tcp`, SPAKE2 pairing + TLS sessions; LADB / AdbShellTool / `claude-code-android` self-connect flows; Shizuku internals; CVE-2026-0073 loopback-block discussion.