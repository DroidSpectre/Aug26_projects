# Aetherix-Alpine — Package Inventory

What gets installed, where in the process, and why. Two install paths exist:
the app's **7-step setup** (Steps 5–6 seed the Alpine rootfs), and the
**module system** (each module's `post-install.sh` / tier adds its own set).
Module installs are the update vehicle going forward; the core package set is
frozen at `core-v1` (see `core-vs-modules.md`).

## A. App-bundled binaries (from the APK assets / native libs — no apk)

| Artifact | Where | Purpose |
|---|---|---|
| `assets/alpine-minirootfs.tar` | bundled, extracted in Step 2 | Bootstrap Alpine 3.19 rootfs (empty package DB beyond the minirootfs base) |
| `assets/proot-arm64` + `libproot.so`/`loader` | bundled, deployed in Step 3 | PRoot — runs a foreign rootfs tree as the app user; the whole sandbox depends on this |
| `native/libpty-jni.so` | bundled `jniLibs` | PTY ioctl shim (TIOCSWINSZ) called from the app process |
| `native/libpty-bridge.so` | bundled, used in Step 6 | Freestanding fork/PTY/exec "bridge" binary that proves the pty pipeline end-to-end |
| `assets/libfaketty.so` | bundled, deployed to `/usr/lib` in Step 5 | LD_PRELOAD shim so in-guest programs see a tty device (isatty tricks) |
| `assets/libandroid-shmem.so` | bundled, in setup | POSIX shared-memory shim for Android bionic |
| `assets/libtalloc.so.2` | bundled, in setup | Runtime lib for PRoot's talloc dependency |
| `assets/ca-certificates.crt` | bundled, in setup | Mozilla CA bundle fallback (`SSL_CERT_FILE`) before apk installs its own |

## B. Step 5 — Initializing Alpine Packages (`StepRunner.java`)

| Command | Purpose |
|---|---|
| `apk update` (3 retries) | Refresh the Alpine repo index (network check happens here) |
| `apk upgrade` (3 retries) | Bring the minirootfs base up to the current Alpine 3.19 point release |
| `apk add ca-certificates-bundle` | Alpine's CA bundle → system TLS trust (`/etc/ssl/cert.pem`) |
| `apk add bash coreutils ncurses-terminfo` | Interactive shell, GNU core utils (ls/cp/…), terminfo db (stty/clear work) |
| `apk add alpine-base alpine-conf openrc tzdata util-linux shadow procps nano htop bash-completion openssh iproute2` | OS glue: init/service framework (openrc), timezone data, mount/parted-style util-linux tools, user management (useradd), `ps`/proc tools, editors, ssh, `ip` networking |

## C. core-module (`config/modules/core-module/post-install.sh`)

| Package | Purpose |
|---|---|
| `bash coreutils ncurses-terminfo` | Idempotent re-assertion of the Step-5 base (module may be installed on a rootfs that skipped it) |
| `ca-certificates-bundle` | TLS trust (same as Step 5) |
| `build-base` | Full compile toolchain: gcc/g++, binutils, make, musl-dev headers |
| `clang` | Fast C/C++ compiler used by `llm setup` (Termux-parity builds; gcc stays as the fallback) |
| `cmake` `ninja` | llama.cpp build system (CMake + Ninja generator) |
| `git` | Clones llama.cpp source |
| `curl` | HuggingFace Hub downloads + general HTTP |
| `linux-headers` | Kernel UAPI headers — required for llama.cpp (`linux/limits.h`) |
| `openssl-dev` | TLS dev headers — llama-server HTTPS |
| `ccache` | Compile cache — speeds up build restarts massively |
| `libomp` (optional, best-effort) | OpenMP runtime for parallel llama.cpp CPU inference |

## D. llm-module (`config/modules/llm-module/tier/llm` — fallback only)

`apk add --no-progress build-base clang cmake git curl ca-certificates linux-headers
openssl-dev ccache ninja` + best-effort `libomp` — the identical toolchain as
core-module, installed only when core-module is missing/uninstalled so `llm
setup` stays self-sufficient. Everything else the llm tier uses comes from the
module bundle itself (llama.cpp built from source, models in `~/models/`).

## E. hello-module + help-module

No apk packages — pure content modules deployed from their own bundles:
- **hello-module** — shell scripts (`aetherix-selftest`, `aetherix-smoke`,
  tier helpers: `job`, `sd` with input/output links) and the `~/storage` link
  tree; since v0.4.3 the `io` helper (env/in/out/clean) ships here too.
- **help-module** (since v0.4.2, requires llm-module) — curated help corpus:
  10 condensed docs + keyword `.index` deployed to `/etc/aetherix/help`,
  consumed by `llm docs find/add` and `llm ask-help`. No packages.

## F. gui-module (ARCHIVED at v0.3a.14_13 — no longer built)

`apk add xvfb x11vnc openbox xterm` (~86 packages incl. X11 stack + mesa).
Retired as out of project scope; kept in `config/archive/gui-module` for
history.
