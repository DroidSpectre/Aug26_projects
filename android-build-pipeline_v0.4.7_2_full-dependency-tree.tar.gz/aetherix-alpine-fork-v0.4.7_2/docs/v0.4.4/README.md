# Aetherix-Alpine v0.4.4 — Capabilities, guided agent, faster builds

Lay-person summary: this release reorganizes the AI behind the app so a *whole
family* of phone-sized models can use tools, and it makes the on-device build
run closer to Termux speed.

## What changed
- **The AI code is now organized by job.** One big script became seven small
  libraries: talk to the model, search the web, use tools, chat, read your
  docs, export reports, and build the engine. Same commands as before
  (`llm ask`, `llm chat`, ...), same settings — just easier to maintain and
  to know what the app can do.
- **Small models can now "use tools" too.** Tiny models (135M–1B) usually
  cannot call tools by themselves. Instead the app shows them a menu
  (`A) web, B) docs, C) a file, D) answer`) and — following the knowledge-card
  "six hops or less" idea — runs the chosen tool for them. Try:
  `llm agent "check the bug in this file"` after dropping the file into
  `Download/Aetherix-Alpine_INPUT`.
- **`llm capabilities` tells you what the AI can and cannot do** — read
  files? yes (read-only). Run commands? no. See the live terminal? only a
  ~40-line snapshot. This matches the new card 56 CAPABILITIES in the on-device
  help.
- **Faster on-device builds.** Two fixes: half-precision (FP16) math kernels
  are now enabled when the phone's chip advertises them (they were silently
  left off), and the compiler is chosen so parallel (OpenMP) computing stays
  on even when the optional `libomp` package cannot be installed. Run
  `llm build-status` to see compiler, OpenMP, -march and probe results.

## Important
- After updating, run `llm build-restart` once so llama-server is rebuilt with
  the FP16/OpenMP fixes (`llm build-status` shows `HAVE_FP16_VECTOR_ARITHMETIC
  - Success` when done).
- Web answers still need a Tavily key from the Dashboard; there is no keyless
  web fallback (SearXNG stays deferred).
