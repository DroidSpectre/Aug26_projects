# Aetherix-Alpine Fork — Changelog

## v0.4.4 (fork)

Capability-release on the frozen v0.4.0 core: the monolithic llm tier is split
into capability libraries (base / web / agent / chat / rag / docgen / build)
behind the same `llm` dispatcher, small models get a guided agent router
(hardwired A/B/C/D tool menu, small-world ≤6-hop reasoning — no native
tool-calling training needed), and the on-device build finally enables FP16
vector kernels while keeping OpenMP on when `libomp` cannot be installed.

- **FB-115 — capability split (Q6)**: `tier/llm` was a 1,600+ line monolith.
  It is now a thin dispatcher (config + subcommand switch) that sources
  `tier/lib/*.sh` — base (lifecycle/context/profiles/routing), web (Tavily),
  agent (native loop + router), chat (help assistant), rag (corpus), docgen
  (replies/export/chat-log), build (setup/hf/diagnostics). Same commands, same
  env vars, zero behavior change — verified by the 63-check sandbox suite.
- **FB-116 — guided agent router (small models)**: 135M–1B models are rarely
  trained for function calling, so `llm agent` no longer dead-ends with "tools
  disabled". The tier drives a hardwired decision tree: one-letter choices
  (web / docs / file / knowledge), the tier runs the chosen tool, and the
  result feeds a final synthesis — ≤3 hops + answer on every profile
  (`LLM_ROUTER_MAX` caps hops, `LLM_ROUTER=0` restores the old block). Web hop
  stays on the Tavily pipeline with Vane-style [n] citations (no SearXNG).
- **FB-117 — FP16 vector kernels (Q8)**: `cpu_march()` derived an explicit
  `-march=armv8.2-a+dotprod…` from `/proc/cpuinfo` but never mapped
  `fphp/asimdhp` → `+fp16`, so ggml compiled scalar FP16 kernels
  (`HAVE_FP16_VECTOR_ARITHMETIC - Failed`). The mapping is added (feature order
  dotprod/i8mm/fp16/bf16/sve2/sve); the sandbox probe confirms
  `__ARM_FEATURE_FP16_VECTOR_ARITHMETIC` is now set.
- **FB-118 — OpenMP-aware compiler (Q8/libomp)**: clang needs the LLVM OpenMP
  runtime, and `apk add libomp` reports unavailable on the device — so the
  clang build was silently falling back to `-DGGML_OPENMP=OFF`. `pick_compiler`
  now chooses clang only when libomp is present, otherwise gcc (+libgomp) so
  OpenMP stays on. `LLM_USE_CLANG=1` forces clang, `=0` forces gcc;
  `llm build-status` prints compiler/OpenMP/march/probes.
- **FB-119 — capabilities manifest**: `llm capabilities` prints the can/cannot
  list (tools, model gates, file access, build readout) and help-module ships
  card 56 CAPABILITIES; `file_read` also accepts the INPUT dropbox by root so
  the guided router can analyze dropbox files reliably.
