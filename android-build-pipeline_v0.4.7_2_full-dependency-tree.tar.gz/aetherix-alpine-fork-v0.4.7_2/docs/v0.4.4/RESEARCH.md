# Research — applying the agent loop to 135M–1B models

Question from the project: the native tool loop was gated to "tool-capable"
models (2B+ per `model-profiles.conf`); 135M–1B models got "tools disabled".
Can small models use the toolbox without being trained for function calling?

## Findings
- **Native tool-calling is a trained capability.** OpenAI-compatible `tool_calls`
  parsing (the tier's `parse_tool_calls` + `AGENT_TOOLS` JSON) is reliable on
  models that were tuned for it. Sub-1B instruct models frequently emit
  malformed JSON, omit `arguments`, repeat tools in a loop, or answer instead
  of calling — burning the ctx budget on garbage tool-call turns.
- **Small models are good at one-token choices.** Constrained prompts
  ("reply with a single letter") have far higher compliance than JSON
  generation, even on 135M–360M Q4 models — same reason classifiers work at
  tiny scale (`classify_question` already depends on this).
- **The heavy lifting can live in the tier, not the model.** The shell already
  has the tool runners (`run_tool`: Tavily search, corpus lookup, safe file
  read). The missing piece was a *policy* that picks the tool deterministically
  and only asks the model to choose between 2–4 labelled options.
- **Small-world theory maps directly.** The knowledge-card set is designed so
  any answer is reachable in ≤6 hops through hub cards. The router mirrors it:
  classify (web/docs/file/knowledge) → execute → synthesize; file reads add
  one hop (pick a file number). Practical cap: ≤4 hops by default
  (`LLM_ROUTER_MAX`), file list capped at 10, reads capped at 60 lines/4KB.
- **No SearXNG needed.** The web hop keeps the Tavily pipeline (search →
  extract numbered results → [n]-cited synthesis, the Vane pattern). A keyless
  fallback still is not required for small models; if web fails (no key), the
  router degrades to a knowledge answer instead of a dead end.

## Decision
- Keep the native loop for `TOOL_CAPABLE=1` (profile rounds > 0).
- Route every other profile through `router_run()`: hardwired binary options,
  tier-executed tools, single final synthesis. `LLM_ROUTER=0` restores the old
  hard block (still available as an escape hatch / strict mode).

## Verification
- Sandbox fixtures drive the router over both the file path (INPUT dropbox →
  read → answer: "division by zero") and the web path (step 1 → A → Tavily →
  cited answer), plus `LLM_ROUTER=0` restoring the block. On-device: run
  `llm agent` with a 360M/1B Q4 model and a file in `Aetherix-Alpine_INPUT`;
  expect the guided menu line, then a cited/grounded answer.
