# Aetherix-Alpine Fork — Build v0.3a.14_11

- **Date:** 2026-08-09
- **VersionName:** v0.3a.14_11
- **versionCode:** 30151
- **Summary:** llm ask prints only the reply; llama-server version visible in build-status

## Changes

- **FB-079 — `llm ask` prints only the assistant reply**
  (`config/modules/llm-module/tier/llm`):
  - `llm ask` previously dumped the raw `chat.completions` JSON
    (`{"choices":[{"finish_reason":...,"usage":...}}` with `\n` escapes) —
    noise on a phone screen. The reply is now parsed and printed as plain
    text: JSON escapes (`\n`, `\t`, `\"`) are rendered, and both server
    shapes are handled (with and without the `refusal` field).
  - Fallbacks: a non-content body (e.g. an OpenAI error object) prints up to
    2000 bytes raw; an empty response prints
    `no response - is the server running? (llm start)`.

- **FB-080 — `llm build-status` shows the llama-server version**
  (`config/modules/llm-module/tier/llm`):
  - The status line read `llama-server: installed ()` because llama.cpp prints
    its version banner to stderr. `--version` now captures `2>&1`, so the
    line reads `llama-server: installed (version: 1 (9369185))` after a build.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-079 | `llm ask` floods the terminal with raw JSON | `llm ask` streamed the whole chat.completions body | parse out `content`, unescape `\n`/`\t`/`\"`, print only the reply; raw/error/empty fallbacks |
| FB-080 | `llm build-status` shows `installed ()` | llama.cpp prints its version to stderr; `2>/dev/null` hid it | capture stderr: `llama-server --version 2>&1 \| head -1` |

## Build & Verification Notes

- Host: `verify-apk.sh v0.3a.14_11` → 14/14 PASS.
- APK: `Aetherix-Alpine-v0.3a.14_11.apk` (versionCode 30151, signed v2+v3).
- `llm ask` parser exercised locally with canned server JSON: single-line
  (observed device shape), multi-line with `\n`/`\"` escapes + `refusal`
  field, and error-object fallback.
- Device context from 14_10: `llm hf` menu download of SmolLM2-360M works,
  `llm start` + `llm ask` chat verified on-device, and the STALE-build
  recovery path (`llm build-restart`) resumed and completed the llama.cpp
  build. 14_11 only changes the ask/status output formatting.
