# Aetherix-Alpine Fork — Changelog

## v0.3a.14_11 (fork)

llm ask prints only the reply (no raw JSON); llama-server version shown in build-status (FB-079, FB-080)
