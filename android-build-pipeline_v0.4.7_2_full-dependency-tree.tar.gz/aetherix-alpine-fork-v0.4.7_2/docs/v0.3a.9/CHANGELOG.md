# Aetherix-Alpine Fork — Changelog

## v0.3a.9 (fork)

harden module rootfs-ready check with diagnostics (FB-023); true factory reset (FB-024)
- FB-023: `rootfsReady()` accepts broad evidence (alpine-release/bin/sh + apk db or setup_complete.marker written on Step 7 success); `rootfsDiagnostics()` added to dashboard/tier status/error report/modules page.
- FB-024: `factoryReset()` kills proot, wipes rootfs/proot/sdk + marker, clears prefs/logs; dashboard Reset & Reinstall confirms the wipe.
