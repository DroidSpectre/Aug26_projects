# Aetherix-Alpine Fork — Build v0.3a.9

- **Date:** 2026-08-05
- **VersionName:** v0.3a.9 · **versionCode:** 30009
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Hardens the module-system "rootfs not ready" gate with broad
  evidence + on-device diagnostics so it can never block modules after a
  completed install (FB-023), and makes Reset & Reinstall a true factory
  reset that wipes the Alpine environment back to first-install state
  (FB-024).

## Changes
- **FB-023 — module install still blocked even after all 7 steps pass**
  (`ModuleManager`, `InstallBridge`, `ErrorReport`, `modules.html`):
  - Context: on-device reports kept showing `Alpine rootfs not ready - run
    Initiate Install on the dashboard first` after a fully passing setup.
    Static verification showed the gate path was correct (Alpine's db lives
    at `lib/apk/db/installed` and exists even in the fresh minirootfs), so
    the failure had to come from an on-device state we could not see.
  - Fix: `rootfsReady()` now accepts the broadest correct evidence —
    extracted rootfs directory **plus** an Alpine marker (`etc/alpine-release`
    or `bin/sh`) **plus** the apk database **or** a new persisted
    `setup_complete.marker`. The marker is written the moment Step 7 passes
    (and by the manual Step 7 run), so a transient file check can no longer
    block modules after a completed install.
  - Diagnostics: new `ModuleManager.rootfsDiagnostics()` reports `filesDir`,
    rootfs path, and the result of every check (`dir`, `alpineRelease`,
    `binSh`, `apkDb`, `setupMarker`, `ready`). It is exposed on the dashboard
    storage card (`getStorageInfo`), tier status (`getTierStatus`), shown
    verbatim in the error report under a new `--- Module Readiness ---`
    section, and used by the Modules page to say exactly what is missing
    instead of a generic hint.
  - When not ready, a one-per-streak diagnostic line is added to
    `BridgeLogBuffer` so the error report's log tail shows the failing check.
- **FB-024 — Reset & Reinstall does not reset the app to first-install state**
  (`InstallBridge.factoryReset()`, `dashboard.html`):
  - Root cause: `resetSetup()` only cleared the SharedPreferences step flags;
    the rootfs, proot libs, launcher, SDK bind and module bookkeeping all
    survived, so "reset + reinstall" re-ran steps over the old environment.
  - Fix: new `factoryReset()` kills any running proot/PTY processes, deletes
    `files/rootfs`, `files/proot`, `files/sdk`, and `setup_complete.marker`,
    clears setup prefs and the bridge log, then returns to the manual setup
    page. The dashboard button now warns explicitly that the Alpine
    environment (rootfs, packages, modules, launcher) is erased; shared files
    under `Download/Aetherix-Alpine-Fork/` are kept.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-023 | Module install says "rootfs not ready" even after a passing 7-step setup | fixed | readiness gate could fail on a single file check with no visibility into why | broad evidence gate (`alpine-release`/`bin/sh` + apk db **or** `setup_complete.marker` written on Step 7 success) + `rootfsDiagnostics()` surfaced in UI, tier status and error report |
| FB-024 | Reset & Reinstall keeps old rootfs/packages/modules (not a true reset) | fixed | `resetSetup()` only cleared prefs | `factoryReset()` kills proot, wipes `rootfs`/`proot`/`sdk` + marker, clears prefs/logs; dashboard confirms the wipe |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30009' versionName='v0.3a.9'`.
- Host-side `verify-apk.sh` passes 13/13.
- On-device verification required:
  1. Fresh install → Initiate Install (all 7 steps pass) → Modules & Storage:
     hello-module Install succeeds; Modules page no longer shows a setup hint.
  2. If the hint ever reappears, the row now names the exact missing check
     (rootfs not extracted / packages not initialized / rootfs incomplete)
     and the error report's `--- Module Readiness ---` section shows the
     paths + booleans to send back.
  3. Reset & Reinstall: confirm wipe → dashboard returns to first-install
     state; `ls files/` has no rootfs/proot/sdk; re-running Initiate Install
     rebuilds from scratch.
