# Aetherix-Alpine Fork — Build v0.3a.12

- **Date:** 2026-08-05
- **VersionName:** v0.3a.12 · **versionCode:** 30012
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** The Hardware card stops polling GPU usage (which lagged the UI
  on the main thread) and now shows GPU make + model identified once per
  process (FB-031); `llm setup`'s silent clone failure is fixed at the root —
  the guest git could not read `/dev/urandom`, so the launcher now binds it
  explicitly, and the module surfaces real errors with retries (FB-032).

## Changes

- **FB-031 — GPU usage polling lags the dashboard UI**
  (`DevicePayload.java`, `dashboard.html`, `StorageTier.java`):
  - Root cause: `getTelemetry()` is a `@JavascriptInterface` that runs on the
    main thread every 5 s dashboard refresh. `readGpuBusy()` blocked on sysfs
    nodes (`/sys/kernel/gpu/gpu_busy`, `kgsl gpu_busy_percentage`,
    `gpu_clock`) — a usage-percentage poll that slows the whole card.
  - Fix: the `gpu_busy` field is gone entirely (no usage %, ever). GPU
    identity is now `gpu` = make + model, queried **once per process and
    cached**:
    1. EGL `GL_RENDERER` via a throwaway pbuffer context ("Adreno (TM) 750",
       "Mali-G78", …) — the industry-standard identity string;
    2. fallback sysfs model (`/sys/kernel/gpu/gpu_model` etc.);
    3. fallback vendor (`Mali` / `Adreno`) as before.
  - Dashboard renders `GPU: <make model>`; the guest `device-info` CLI now
    prints the model too (no busy read).

- **FB-032 — `llm setup` fails at "cloning llama.cpp…" with no real error**
  (`StepRunner.java`, `config/modules/llm-module/tier/llm`):
  - Root cause: the error report only shows the module's catch-all message
    because the old script swallowed git output (`>/dev/null 2>&1`).
    Reproduced in a clean Alpine 3.19 guest: git fails with
    `unable to get random bytes for temporary file: No such file or
    directory` because git writes pack temp files using random bytes from
    `/dev/urandom`, and the minirootfs `/dev` is empty. The same clone
    succeeds the moment `/dev/urandom` is readable.
  - Fix:
    1. The launcher (`StepRunner.buildLauncherScript`) now adds explicit
       `-b /dev/urandom:/dev/urandom` and `-b /dev/random:/dev/random` binds
       (on top of `-b /dev`), regenerated on next app start.
    2. `llm setup` installs `ca-certificates` alongside the build tools,
       warns if `/dev/urandom` is not readable, retries the clone 3× with
       partial-clone cleanup (`rm -rf` before each attempt), logs to
       `/var/log/llm-clone.log`, and prints the real git output plus hints
       on final failure.

## Bugs

| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-031 | Hardware card lags: GPU usage polling blocks the UI thread | fixed | `gpu_busy` sysfs reads run in `getTelemetry()` on the main thread every 5 s | removed usage polling; GPU make+model from cached EGL `GL_RENDERER` (once per process), sysfs/vendor fallbacks |
| FB-032 | `llm setup` clone fails silently ("could not clone llama.cpp") | fixed | git needs `/dev/urandom` for pack temp files; empty minirootfs `/dev`; error swallowed by `>/dev/null 2>&1` | launcher binds `/dev/urandom` + `/dev/random`; module retries 3×, cleans partial clones, surfaces `/var/log/llm-clone.log`, adds ca-certificates |

## Build & Verification Notes

- **Version:** `v0.3a.12` / 30012 (fork line, `scripts/bump-version.sh`).
- **llm clone (chroot, Alpine 3.19):** with `/dev/urandom` unreadable the
  updated script fails visibly after 3 attempts and prints git's real error +
  hints; a re-run retries again (no stale-partial-clone skip); with a readable
  `/dev/urandom` the identical script clones `ggml-org/llama.cpp` fully and
  proceeds into the build. `sh -n` passes on the tier script.
- **GPU:** `DevicePayload` no longer reads `gpu_busy`; `gpu` is computed once
  (static cache) via EGL on the telemetry thread; dashboard falls back to
  `gpu_vendor` only if identity is unknown.
- **On-device:** update → app restart regenerates the launcher with the urandom
  binds; reinstall `llm-module` from Modules & Storage, then `llm setup`
  (10–30 min source build; if it still fails, the exact git error is now
  printed). Hardware card should show e.g. `GPU: Adreno (TM) 750` with no lag.
- **Isolation:** built only with `scripts/build-apk.sh`; `/root/android-dev-env`
  (opencode) and `/root/Android` untouched.
