# Aetherix-Alpine Fork — Changelog

## v0.3a.12 (fork)

GPU card: make/model only (cached EGL identity, no usage polling); llm setup clone fixed: urandom binds + visible errors + retries (FB-031, FB-032)
- FB-031: removed `gpu_busy` polling from the main-thread telemetry; `gpu` identity (make + model) queried once per process via EGL GL_RENDERER with sysfs/vendor fallbacks; dashboard + guest `device-info` show the model.
- FB-032: launcher binds `/dev/urandom` + `/dev/random` into the guest (git needs urandom for pack temp files); `llm setup` installs ca-certificates, retries the clone 3× with partial-clone cleanup, and prints `/var/log/llm-clone.log` on failure.
