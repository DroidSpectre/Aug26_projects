# Aetherix-Alpine Fork — Changelog

## v0.3a.14_5 (fork)

Operational feedback pass: `sd` is now the single source for the ~/storage
mapping (stale removable links cleared each `sd mount`; app seeder + hello
post-install pruned to stable links / delegation). Module installs are async
(background thread) with live progress events streamed to the Modules page, so
installs never freeze the app and you can watch core-module's toolchain install
in real time. The llm build detects when it died with the app (stale state),
auto-restarts on `llm setup`, and gains `llm build-restart` + STALE reporting in
`llm build-status`. A docked progress bar under the terminal shows the llama.cpp
`[N/M]` while building and hides when idle.
