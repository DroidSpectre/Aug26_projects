# Aetherix-Alpine Fork — Build v0.3a.14_5

- **Date:** 2026-08-07
- **VersionName:** v0.3a.14_5 · **versionCode:** 30145
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Stability + feedback fixes from the 14_4 field pass. `sd` becomes
  the single source of truth for device-storage mapping (no more drifting link
  tree). Module installs move off the UI thread with live progress streaming, so
  the Modules page never freezes again and you can watch core-module's toolchain
  install in real time. A docked build-progress bar under the terminal shows
  llama.cpp `[N/M]` while the detached build runs. The llm tier detects a
  build that died with the app (stale state) and auto-restarts it, plus a new
  `llm build-restart`.

## Changes

- **FB-062 — `sd` storage mapping de-duplicated**
  (`config/modules/hello-module/tier/sd`, `StorageTier.java`,
  `config/modules/hello-module/post-install.sh`):
  - `sd do_mount` is now the single writer of `~/storage`: it first clears stale
    `download`/`usb`/`external*` links, then re-derives the static folders
    (shared/downloads/dcim/pictures/music/movies/documents) and the removable
    volumes (`external`, `external1..N`, `usb`). A second `sd mount` no longer
    leaves a different `dir` listing.
  - The app-side seeder (`StorageTier.deployHomeStorageLinks`) is reduced to the
    two always-valid links (`shared`, `downloads`) so the tree is discoverable
    before the first `sd mount`; removable links are owned by `sd`.
  - hello-module `post-install.sh` stops inlining links and delegates to
    `sd mount` (with a two-link fallback when storage isn't granted yet).
- **FB-063 — Async module install with live progress**
  (`ModuleManager.java`, `InstallBridge.java`, `app/src/main/assets/www/modules.html`):
  - New `AndroidBridge.installModuleAsync(name)` returns immediately; the
    install (including core-module's multi-minute post-install) runs on a
    background thread so the Modules page, dashboard and back button stay
    responsive.
  - `ModuleManager.installModule(name, progressCallback)` streams each phase
    line; post-install output is streamed line-by-line via a new
    `runLauncher` line pump.
  - The Modules page receives `AetherixModuleProgress(...)` (appended live to
    the log area, capped at 300 lines) and the final `AetherixModuleResult(...)`,
    which prints the OK/error and refreshes the module list. A status line
    explains that installs run in the background.
- **FB-064 — Stale build detection + restart for the llm build**
  (`config/modules/llm-module/tier/llm`):
  - `build_alive()` treats a build as live only while the detached
    `/opt/aetherix/llm-build.sh` (or its `cmake --build` child) actually exists.
  - On `llm setup`, a `building` state with no live process is reported as
    interrupted, cleared, and auto-restarted (`cmake` resumes from where it
    stopped).
  - New `llm build-restart` explicitly resumes (or reports that llama-server is
    already installed). `llm build-status` now prints `STALE` with a fix hint
    when the build died; `llm setup` and `llm help` cover the recovery steps.
- **FB-065 — Docked background-build progress bar**
  (`TerminalActivity.java`):
  - A thin horizontal dock sits between the terminal frame and the extra-keys
    row: a progress bar + `llama.cpp build N/M (pct%)` label.
  - It polls `etc/aetherix/llm.build.state` + `var/log/llm-build.log` (last
    64 KB, `[N/M]` parser) every 2 s and is hidden whenever no build is running,
    so it never floods the prompt or the scrollback — it only shows activity.

## Research — rebranded for 14_5

No new library decisions. The PRoot-vs-bionic determination from 14_4 stands
(keep PRoot; no rebuild — see the 14_4 README "Research — PRoot vs bionic"
section). The 14_5 work is all operational hardening on that foundation.
