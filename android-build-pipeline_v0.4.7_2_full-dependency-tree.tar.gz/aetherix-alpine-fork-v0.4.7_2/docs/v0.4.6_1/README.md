# Aetherix-Alpine v0.4.6_1 — correctness re-cut

Sub-release that fixes stale help/build text surfaced by the v0.4.6 `llm
wizard` on-device walkthrough, and commits the sandbox test suite so it
survives container resets.

## What changed
- **Build export hint fixed**: `llm build-log export` now tells you it saves
  to `Downloads/Aetherix-Alpine_OUTPUT` (it already did — the message was
  stale from before FB-111).
- **Data cards corrected** (deployed to the phone with the re-cut bundles):
  - 27 LLM-SETUP: compiler policy now matches reality — gcc by default
    (OpenMP via libgomp), clang only when libomp is installed.
  - 28 LLM-MODELS: profiles are ctx/batch/**router-hops** with the new
    context floor (4096/8192/16384).
  - 23 LLM-MODULE: current version (1.8.1) and the unified `llm chat`
    command list (no more removed `ask`/`web`/`agent`).
  - 25 LLM hub: wording cleaned up.
- **Sandbox tests committed**: `tests/sandbox/` — harness + fakebin +
  fixtures, kept separate from `app/` and `config/modules/` so nothing here
  ever ships in a bundle or the APK.

## For developers
- `tests/sandbox/README.md` explains how to run the 87 checks.
- Versioning note: sub-releases follow `v0.4.6_N` with `versionCode 40006+N`
  (this one: `v0.4.6_1` / `40061`).
