# Aetherix-Alpine Fork — Changelog

## v0.4.6_1 (fork sub-release)

Correctness re-cut of v0.4.6: no feature changes. Fixes the stale on-device
text that the `llm wizard` walkthrough exposed, and moves the sandbox test
suite into the repo under `tests/sandbox/` (separate from app/module source,
so it can never ship in bundles or the APK).

- **FB-125 — stale on-device help/build text after v0.4.6**: the wizard/build
  output still pointed `llm build-log export` at `~/storage/downloads`
  (pre-FB-111); cards 27 LLM-SETUP, 28 LLM-MODELS, 23 LLM-MODULE and 25 LLM
  still described the removed `ask`/`web`/`agent` commands, the clang-only
  compiler policy (pre-FB-118), and the old ctx/batch/agent profiles. All
  fixed to the v0.4.6 reality (OUTPUT dropbox export, gcc-via-libgomp
  default, ctx/batch/router-hops with the 4096/8192/16384 context floor,
  unified `llm chat` command list, module version 1.8.1).
- **Sandbox suite committed**: `tests/sandbox/` now holds the llm-tier
  harness (87 checks), `fakebin/` stubs and `fixtures/` JSON, kept outside
  `app/` and `config/modules/` by construction. The harness resolves the
  repo root from its own path instead of a hardcoded container path.
- Versions: app `v0.4.6_1` / versionCode `40061`; llm-module `1.8.1`;
  help-module `1.5.1`. Bundles regenerated; APK + export tarball re-cut.
