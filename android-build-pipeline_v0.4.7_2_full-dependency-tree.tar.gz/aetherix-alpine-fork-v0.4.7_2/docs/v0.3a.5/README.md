# Aetherix-Alpine Fork — Build v0.3a.5

- **Date:** 2026-08-05
- **VersionName:** v0.3a.5 · **versionCode:** 30005
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Bundles the `hello-module` test suite into the APK so it can be
  installed from the Modules page without sideloading a tarball (FB-009); adds
  the planned in-Alpine `device-info` telemetry CLI (Part 4 / v0.3.3 item,
  FB-010); reconciles the device-layers plan doc with shipped fork work.

## Changes
- **FB-009 — bundled hello-module (module system, plan Part 3):**
  - Editable module source at `config/modules/hello-module/` (`module.yml`
    v1.0.0, `post-install.sh`, `README.md`, and `tests/`: `aetherix-selftest.sh`
    — in-guest suite, exit 0 = pass; `aetherix-smoke.sh` — T3/T4/T6/T8/T9 dump;
    `TESTPLAN.md` — the 10 on-device checks T1–T10; `verify-apk.sh` — host APK
    checks).
  - `scripts/build-hello-module.sh` regenerates
    `app/src/main/assets/modules/hello-module.bundle` (idempotent; `module.yml`
    at tar root, matching the loader's `peekModuleYaml`). Stored with a
    `.bundle` extension because aapt strips `.tar.gz` from asset names.
  - `ModuleManager` gains `bundledNames()` (lists `assets/modules/*.tar.gz`)
    and `copyBundledToSource()` (copies the bundle into
    `/sdcard/Download/Aetherix-Alpine-Fork/modules/`); `listModules()` merges
    bundled entries ("bundled with app"), and `installModule()` falls back to
    the bundled copy when no external tarball exists. Install still requires
    the All-files grant (existing guard).
  - `modules.html` empty-state now mentions the bundled module and the drop
    folder.
  - Result: user opens Modules & Storage → sees `hello-module` (Available) →
    Install → in-terminal `aetherix-selftest` / `aetherix-smoke` / `device-info`.
- **FB-010 — in-Alpine `device-info` CLI (plan Part 4 / v0.3.3):**
  - `StorageTier.writeDeviceInfo()` deploys an idempotent
    `/usr/local/bin/device-info` inside the rootfs on every app start (content
    hashed; rewritten only if changed).
  - Prints `key: value` lines: device/board/soc/abi, battery %, battery temp C,
    memory total, GPU (Mali busy → Adreno → n/a), first thermal zone. Backs the
    dashboard Hardware card and the plan's `device-info` verification step.
- **Plan reconciliation (`docs/v0.3-series/...-device-layers-plan.md`):**
  - Added a "Fork status (v0.3a.x line)" section mapping plan parts to shipped
    fork builds; Parts 2–4 marked shipped, Parts 5–7 (elevation, GUI, LLM)
    remain roadmap.
  - Marked all 25 Part 2 task checkboxes `[x]` (StepRunner UX, BUG-009…014 —
    shipped upstream in v0.3.1 and carried into the fork baseline; FB-004
    corrected the self-test for PRoot-in-guest).
  - Added per-part fork-status notes to Parts 3 and 4. History retained; no
    deletions.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-009 | hello-module requires sideloading a tarball to test | fixed | module loader only scanned `/sdcard/Download/Aetherix-Alpine-Fork/modules/`; no bundled sample | `ModuleManager` bundled-asset fallback (`bundledNames()` + `copyBundledToSource()`); `hello-module.bundle` shipped in `assets/modules/` |
| FB-010 | No in-Alpine CLI backing the telemetry tier | fixed | Part 4 (v0.3.3) `device-info` script existed only in the plan | `StorageTier.writeDeviceInfo()` deploys idempotent `/usr/local/bin/device-info` (key: value lines) on app start |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30005' versionName='v0.3a.5'`.
- DEX verified: `bundledNames`, `copyBundledToSource`, `writeDeviceInfo`
  present; `device-info` shell script `sh -n` clean.
- Assets verified: `assets/modules/hello-module.bundle` present in the APK
  (`module.yml` at tar root); aapt renames `.tar.gz` assets, so the bundle is
  stored as `.bundle`.
- Host-side `verify-apk.sh` (shipped inside the module): **13/13 PASS** — APK
  exists, badging `com.aetherix.alpine.a`/30005/`v0.3a.5`, signature v2+v3,
  DEX feature markers, no stale step labels, all core assets (www, proot,
  rootfs, bundled module, native libs), device export present.
- On-device verification still required:
  1. Fresh install → Modules & Storage shows `hello-module` (Available) after
     All-files grant → Install → `cat /etc/aetherix/hello-module.installed`,
     run `aetherix-selftest` (expect ALL CHECKS PASSED, exit 0).
  2. In-terminal `device-info` matches the dashboard Hardware card.
  3. Regression: 7-step setup passes, dashboard package counter updates,
     manual Exit shows no false-kill popup (FB-007 still holds).
