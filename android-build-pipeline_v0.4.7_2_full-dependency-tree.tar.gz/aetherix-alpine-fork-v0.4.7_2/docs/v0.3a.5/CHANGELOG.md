# Aetherix-Alpine Fork — Changelog

## v0.3a.5 (fork)

Bundle hello-module (on-device test suite) for in-app install; in-Alpine device-info telemetry CLI; plan-doc reconciliation (Parts 2-4 marked shipped)
