# Aetherix-Alpine Fork — Changelog

## v0.3a.4 (fork)

- FB-007: manual Exit no longer triggers the "killed by the system" popup.
  `PtySession.destroy()` waits up to 2s for a clean exit before the SIGTERM
  fallback, and `TerminalSession.onExit` treats exit code 143 (app-initiated
  teardown) as clean.
- FB-008: dashboard "Packages installed" row, counted from the rootfs apk db
  (`P:` stanzas), refreshed on load, on auto-install completion, and every 5s —
  tracks `apk add`/`apk del` in the terminal.
