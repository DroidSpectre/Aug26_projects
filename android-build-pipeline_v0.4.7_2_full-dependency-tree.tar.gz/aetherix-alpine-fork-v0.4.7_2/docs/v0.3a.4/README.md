# Aetherix-Alpine Fork — Build v0.3a.4

- **Date:** 2026-08-05
- **VersionName:** v0.3a.4 · **versionCode:** 30004
- **Package (applicationId):** `com.aetherix.alpine.a` (unchanged)
- **Summary:** Fixes the false "previous terminal session was killed by the
  system" popup after a manual Exit (FB-007) and adds a live "Packages
  installed" counter to the dashboard that updates after setup and after
  `apk add` in the terminal (FB-008).

## Changes
- **FB-007 — false kill popup on manual Exit** (`PtySession`, `TerminalSession`):
  - Root cause: the ✕ Exit button called `Watchdog.markClean()` and then
    `session.destroy()`, whose `process.destroy()` sent SIGTERM to the PTY
    bridge. The bridge then exited with code 143 and `TerminalSession.onExit`
    classified any non-zero exit as "killed by the system"
    (`Watchdog.markDead(143)`), overwriting the clean mark — so the next
    terminal open showed the kill popup for a user-initiated exit. (A real
    Android kill takes the whole app process, so `onExit` never runs for it.)
  - Fix: `PtySession.destroy()` now writes `exit\n`, waits up to 2s for the
    bridge to exit naturally (clean exit 0), and only SIGTERMs as a fallback;
    `TerminalSession.onExit` treats exit code 143 (SIGTERM, i.e. the app's own
    teardown) as a clean close via `Watchdog.markClean()`.
- **FB-008 — dashboard package counter** (`InstallBridge`, `dashboard.html`):
  - Dashboard now shows a "Packages installed" row on the System card, counted
    directly from the rootfs apk database (`lib/apk/db/installed`, one `P:`
    stanza per package — matches the terminal banner's `apk list --installed
    | wc -l`).
  - Refreshes on dashboard load, when auto-install completes, and every 5s
    (light touch — only rewrites the value when it changes), so it tracks
    `apk add`/`apk del` inside the terminal.

## Bugs
| ID | Title | Status | Root cause | Fix |
|----|-------|--------|------------|-----|
| FB-007 | "Killed by the system" popup after manual Exit | fixed | Exit button → `session.destroy()` → SIGTERM → bridge exit 143 → `onExit` `markDead(143)` overwrote the preceding `markClean` | graceful destroy (exit\\n + 2s wait, SIGTERM fallback) + treat 143 as clean in `onExit` |
| FB-008 | Dashboard has no live installed-package count | fixed | Dashboard never exposed the rootfs package count; banner-only `Packages: N` | `getDashboardData().packageCount` from apk db `P:` stanzas + "Packages installed" row with 5s refresh |

## Build & Verification Notes
- Compile: javac clean; APK badging reports
  `package: name='com.aetherix.alpine.a' versionCode='30004' versionName='v0.3a.4'`.
- DEX verified: `packageCount` present; `onExit` 143 branch compiles.
- On-device verification still required:
  1. Open terminal → tap ✕ Exit → Exit → back on dashboard → Open Terminal:
     no "killed by the system" popup.
  2. Dashboard shows Packages installed = banner count (28 after setup);
     `apk add` a package in the terminal, return to dashboard → count
     increments within ~5s.
  3. Genuine kill detection still works (e.g. leave a session backgrounded
     until the app process is trimmed → popup appears with heartbeat-stale
     wording).
