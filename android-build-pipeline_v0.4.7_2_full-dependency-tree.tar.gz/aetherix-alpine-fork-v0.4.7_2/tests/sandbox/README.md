# Sandbox test harness (separate from app/module source)

The Aetherix-Alpine llm-tier sandbox: a stubbed, offline test suite that
drives the real `llm` dispatcher and `tier/lib/*.sh` code with fake curl /
llama-server / job binaries and canned model responses.

## Why it is a separate top-level folder
`tests/` deliberately lives OUTSIDE `app/` and `config/modules/`, so it can
never be packed into a module bundle, shipped in the APK, or deployed to the
phone. It is a developer-only artifact for this container.

## Layout
- `run-llm-tests.sh` — the harness (133 checks, v0.4.7_2 surface: 8k profile
  floor with native-GGUF clamp, answers-first Tavily, CRT menu category
  listing + selftest). Resolves the repo root from its own path, so it runs
  from anywhere.
- `fakebin/curl` — inspects the request payload for router markers
  (`ROUTER STEP 1/2`, `ROUTER FILE`, `ROUTER CMD`, `ROUTER CMD TEXT`,
  `ROUTER FINAL`, `web search queries`, project-assistant persona, ...) and
  returns the matching fixture; env overrides pick specific fixtures
  (`ROUTER_STEP1_FIXTURE`, `TAVILY_FIXTURE`, `COMPLETION_FIXTURE`, ...).
- `fakebin/llama-server` — records spawn args so tests can assert
  `--ctx-size` / `--batch-size`.
- `fakebin/job` — simulates the detached job dock (`job run`) for `hf get`.
- `fixtures/*.json` — canned completions: router letter picks (A/B/C/E/F,
  file number, terminal command), final syntheses, Tavily search results,
  query generation, docs/help answers, plain completions.

## Run
```
bash tests/sandbox/run-llm-tests.sh   # expect: 133 passed, 0 failed
```

## Caveats
- Writes fixture state to `/etc/aetherix` and `/root/*` — dev-container only,
  requires root. Never run on a device.
- The harness asserts the CURRENT contact surface (e.g. profile sizes
  4096/8192, unified `llm chat`); when the surface changes, update the
  harness and fixtures with it.
