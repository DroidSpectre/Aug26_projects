#!/bin/bash
# Aetherix llm tier sandbox tests (stubbed curl/llama-server) - v0.4.7_2 surface (FB-131 wizard/help quoting, FB-132 scrollback/wrapping/wizard-no-flood).
# Lives in tests/sandbox/ - separate from app/module source so it never ships
# in bundles or the APK. Writes fixture state into /etc/aetherix and /root
# (dev-container only, needs root; never run on-device).
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TIER="$ROOT/config/modules/llm-module/tier/llm"
export PATH="$ROOT/tests/sandbox/fakebin:$PATH"
export HOME=/root
FAIL=0; PASS=0
ok()   { PASS=$((PASS+1)); echo "PASS  $1"; }
bad()  { FAIL=$((FAIL+1)); echo "FAIL  $1"; }
chk()  { if [ "$2" -eq 0 ]; then ok "$1"; else bad "$1"; fi; }
contains() { case "$2" in *"$1"*) return 0;; esac; return 1; }

# ---- fixtures: sync repo fixtures into /tmp so env overrides always see
# the current (v0.4.7) canned responses ----
rm -rf /tmp/fixtures && cp -r "$ROOT/tests/sandbox/fixtures" /tmp/fixtures

# ---- fixture state ----
mkdir -p /etc/aetherix /root/models /root/storage
echo "model=/root/models/test.gguf" > /etc/aetherix/llm.conf
touch /root/models/test.gguf /root/models/smollm2.gguf /root/storage/dummy
echo "test-key" > /etc/aetherix/tavily.key
echo stopped > /etc/aetherix/llm.state
rm -f /etc/aetherix/model-profiles.conf
cat > /etc/aetherix/model-profiles.conf <<'PROF'
*smollm2*       8192  256  6
*0.5b*          8192  256  6
*1b*            8192  512  6
*1.5b*          8192  512  6
*3b*            8192  1024 6
*               8192  512  6
PROF
cat > /etc/aetherix/term.context <<'TC'
localhost:~# llm status
state: stopped
localhost:~# echo hello terminal
hello terminal
localhost:~# 
TC
rm -rf /etc/aetherix/help && mkdir -p /etc/aetherix/help
cat > /etc/aetherix/help/20-modules.md <<'DOC'
# Modules

Modules install from the Dashboard > Modules & Storage page in this order:
core-module, hello-module, llm-module, help-module.
DOC
cat > /etc/aetherix/help/30-llm.md <<'DOC'
# LLM commands

Use llm setup, llm hf, llm model, llm start, llm chat (--once/--plain/--web/
--docs/--task), llm docs. Tavily key: Dashboard > Tavily Key.
DOC

# ---- functions-only (the capability libs; the dispatcher loader needs a
# real $0 path, which sourced tests cannot provide, so feed the libs directly)
: > /tmp/llm-funcs.sh
for _lf in "$(dirname "$TIER")/lib"/*.sh; do
  [ -f "$_lf" ] && cat "$_lf" >> /tmp/llm-funcs.sh
done

# T1: model profile resolution (v0.4.7 8k floor + native clamp)
sh -c '. /tmp/llm-funcs.sh; model_profile; echo "$CTX_SIZE $BATCH_SIZE $ROUTER_HOPS $ROUTER_ENABLED"' > /tmp/t1.txt 2>&1
chk "profile default=8192/512/6hops/router-on" "$(grep -q '8192 512 6 1' /tmp/t1.txt; echo $?)"
echo "model=/root/models/smollm2.gguf" > /etc/aetherix/llm.conf
sh -c '. /tmp/llm-funcs.sh; model_profile; echo "$CTX_SIZE $BATCH_SIZE $ROUTER_HOPS $ROUTER_ENABLED"' > /tmp/t1b.txt 2>&1
chk "profile smollm2=8192/256/6hops/router-on" "$(grep -q '8192 256 6 1' /tmp/t1b.txt; echo $?)"
LLM_CTX=4096 sh -c '. /tmp/llm-funcs.sh; model_profile; echo "$CTX_SIZE"' > /tmp/t1c.txt 2>&1
chk "profile LLM_CTX override=4096" "$(grep -q '^4096$' /tmp/t1c.txt; echo $?)"
LLM_ROUTER=0 sh -c '. /tmp/llm-funcs.sh; model_profile; echo "$ROUTER_ENABLED"' > /tmp/t1d.txt 2>&1
chk "profile LLM_ROUTER=0 disables router" "$(grep -q '^0$' /tmp/t1d.txt; echo $?)"
echo "model=/root/models/test.gguf" > /etc/aetherix/llm.conf

# T1e: a model whose GGUF says native ctx 2048 clamps the 8192 floor down
python3 - <<'PY'
import struct
data = b"GGUF" + struct.pack("<IQ", 3, 0) + struct.pack("<Q", 1)
k = b"llama.context_length"
data += struct.pack("<Q", len(k)) + k
data += struct.pack("<I", 4) + struct.pack("<I", 2048)
open("/root/models/native2048.gguf", "wb").write(data)
PY
echo "model=/root/models/native2048.gguf" > /etc/aetherix/llm.conf
sh -c '. /tmp/llm-funcs.sh; model_profile; echo "$CTX_SIZE $CLAMP_NATIVE"' > /tmp/t1e.txt 2>&1
chk "profile native-ctx clamp 2048 (CLAMP_NATIVE set)" "$(grep -q '^2048 2048$' /tmp/t1e.txt; echo $?)"
# T1f: a forced LLM_CTX skips the native clamp
LLM_CTX=4096 sh -c '. /tmp/llm-funcs.sh; model_profile; echo "$CTX_SIZE"' > /tmp/t1f.txt 2>&1
chk "profile LLM_CTX force skips native clamp" "$(grep -q '^4096$' /tmp/t1f.txt; echo $?)"
echo "model=/root/models/test.gguf" > /etc/aetherix/llm.conf
# T2: tavily_search + tavily_extract (answers-first, compact snippets)
. /tmp/llm-funcs.sh
code=$(TAVILY_FIXTURE=/tmp/fixtures/tavily-search.json tavily_search "llm hf" 4 /tmp/tavily-t.json)
chk "tavily_search HTTP 200" "$([ "$code" = "200" ]; echo $?)"
res=$(tavily_extract < /tmp/tavily-t.json)
contains "Aetherix hf docs" "$res"; chk "tavily_extract parses title" $?
case "$res" in ANSWER:*"Aetherix hf docs"*) ok "tavily_extract answers-first";; *) bad "tavily_extract answers-first";; esac
case "$res" in *"...") ok "tavily_extract truncates long snippets";; *) bad "tavily_extract truncates long snippets";; esac

# T2b: v0.4.7 Tavily calls include_answer and skip the second query when an
# answer summary is present
rm -f /tmp/curl-calls.log
TAVILY_FIXTURE=/tmp/fixtures/tavily-search.json sh -c '. /tmp/llm-funcs.sh; web_gather "q1" "q2"' > /tmp/t2b.txt 2>&1
contains '"include_answer":true' "$(cat /tmp/curl-calls.log 2>/dev/null)"; chk "web_gather sends include_answer:true" $?
n=$(wc -l < /tmp/curl-calls.log 2>/dev/null | tr -d ' ')
[ "$n" = "1" ]; chk "web_gather single search when answer present" $?
rm -f /tmp/curl-calls.log

# T3: docs_find / docs_snippets
out=$(docs_find modules)
contains "20-modules.md" "$out"; chk "docs_find finds module doc" $?
sn=$(docs_snippets "tavily key")
contains "30-llm.md" "$sn"; chk "docs_snippets returns llm doc" $?

# T4: llm chat --plain direct completion
rm -f /tmp/agent-seq /tmp/llama-server.args
COMPLETION_FIXTURE=/tmp/fixtures/completion.json sh "$TIER" chat --plain "hello" > /tmp/t4.txt 2>&1
contains "Plain answer text." "$(cat /tmp/t4.txt)"; chk "chat --plain prints reply" $?

# T5: chat --once routes web (step1=A -> tavily -> final synthesis)
rm -f /tmp/agent-seq /tmp/llama-server.args
ROUTER_STEP1_FIXTURE=/tmp/fixtures/router-step1-web.json \
ROUTER_FINAL_FIXTURE=/tmp/fixtures/router-final-web.json \
TAVILY_FIXTURE=/tmp/fixtures/tavily-search.json \
  sh "$TIER" chat --once "whats new with qwen?" > /tmp/t5.txt 2>&1
contains "hop 1 - web results gathered" "$(cat /tmp/t5.txt)"; chk "chat --once web hop gathers" $?
contains "qwen models were updated" "$(cat /tmp/t5.txt)"; chk "chat --once web final synthesized" $?
contains "--ctx-size" "$(cat /tmp/llama-server.args 2>/dev/null)"; chk "llama-server args have ctx" $?

# T6: chat --once routes docs (step1=B -> corpus -> final)
rm -f /tmp/agent-seq /tmp/llama-server.args
ROUTER_STEP1_FIXTURE=/tmp/fixtures/router-step1-docs.json \
ROUTER_FINAL_FIXTURE=/tmp/fixtures/router-final-docs.json \
HELP_FIXTURE=/tmp/fixtures/help-answer.json \
  sh "$TIER" chat --once "how do modules install?" > /tmp/t6.txt 2>&1
contains "hop 1 - docs gathered" "$(cat /tmp/t6.txt)"; chk "chat --once docs hop gathers" $?
contains "20-modules.md" "$(cat /tmp/t6.txt)"; chk "chat --once docs final cites corpus" $?

# T7: chat --task file route (step1=C -> ROUTER FILE -> INPUT read -> final)
rm -f /tmp/agent-seq /tmp/llama-server.args
mkdir -p /tmp/io-test/in && printf 'def bug():\n    return 1/0\n' > /tmp/io-test/in/code.py
ROUTER_STEP1_FIXTURE=/tmp/fixtures/router-step1.json ROUTER_FILE_FIXTURE=/tmp/fixtures/router-file.json \
ROUTER_FINAL_FIXTURE=/tmp/fixtures/router-final.json AETHERIX_INPUT_DIR=/tmp/io-test/in \
  sh "$TIER" chat --task "find the bug in code.py" > /tmp/t7.txt 2>&1
contains "file 'code.py' read" "$(cat /tmp/t7.txt)"; chk "chat --task reads INPUT file" $?
contains "division by zero" "$(cat /tmp/t7.txt)"; chk "chat --task final answers from file" $?
# T7b: LLM_ROUTER=0 -> strict no-tools, knowledge answer
LLM_ROUTER=0 ROUTER_FINAL_FIXTURE=/tmp/fixtures/router-final.json \
  sh "$TIER" chat --once "hello" > /tmp/t7b.txt 2>&1
contains "tools disabled" "$(cat /tmp/t7b.txt)"; chk "LLM_ROUTER=0 blocks tools" $?
# T7c: multi-hop per turn (step1=A web, step2=F final)
ROUTER_STEP1_FIXTURE=/tmp/fixtures/router-step1-web.json \
ROUTER_STEP2_FIXTURE=/tmp/fixtures/router-step2-final.json \
ROUTER_FINAL_FIXTURE=/tmp/fixtures/router-final-web.json \
TAVILY_FIXTURE=/tmp/fixtures/tavily-search.json \
LLM_ROUTER_MAX=2 sh "$TIER" chat --task "research current qwen news" > /tmp/t7c.txt 2>&1
contains "hop 1 - web results gathered" "$(cat /tmp/t7c.txt)"; chk "multi-hop gathers web" $?
contains "qwen models were updated" "$(cat /tmp/t7c.txt)"; chk "multi-hop final synthesized" $?

# T8: chat --task terminal route (step1=E -> confirm -> cmd -> term_run -> final)
rm -f /tmp/agent-seq /tmp/llama-server.args
echo "model=/root/models/smollm2.gguf" > /etc/aetherix/llm.conf
ROUTER_STEP1_FIXTURE=/tmp/fixtures/router-step1-term.json ROUTER_CMD_FIXTURE=/tmp/fixtures/router-cmd.json \
ROUTER_CMD_TEXT_FIXTURE=/tmp/fixtures/router-cmd-text.json ROUTER_FINAL_FIXTURE=/tmp/fixtures/router-final-term.json \
  sh "$TIER" chat --task "how full is the disk?" > /tmp/t8.txt 2>&1
contains "terminal output captured" "$(cat /tmp/t8.txt)"; chk "chat --task term hop captures output" $?
contains "Disk space answer" "$(cat /tmp/t8.txt)"; chk "chat --task term final synthesized" $?
echo "model=/root/models/test.gguf" > /etc/aetherix/llm.conf

# T9: llm context prints terminal + state
sh "$TIER" context > /tmp/t9.txt 2>&1
contains "terminal (last visible lines)" "$(cat /tmp/t9.txt)"; chk "context includes terminal tail" $?
contains "hello terminal" "$(cat /tmp/t9.txt)"; chk "context includes term.context lines" $?

# T10: docs find CLI + docs add
sh "$TIER" docs find modules > /tmp/t10.txt 2>&1
contains "20-modules.md" "$(cat /tmp/t10.txt)"; chk "llm docs find CLI" $?
mkdir -p /tmp/custom-docs && echo "# My custom doc" > /tmp/custom-docs/custom.md
sh "$TIER" docs add /tmp/custom-docs > /tmp/t10b.txt 2>&1
contains "added 1 doc" "$(cat /tmp/t10b.txt)"; chk "llm docs add CLI" $?
sh "$TIER" docs find custom > /tmp/t10c.txt 2>&1
contains "custom.md" "$(cat /tmp/t10c.txt)"; chk "added doc searchable" $?

# T11: chat --docs one-shot over the corpus
rm -f /tmp/agent-seq /tmp/llama-server.args
HELP_FIXTURE=/tmp/fixtures/help-answer.json sh "$TIER" chat --docs "what does gui do?" > /tmp/t11.txt 2>&1
contains "20-modules.md" "$(cat /tmp/t11.txt)"; chk "chat --docs cites corpus" $?

# T12: chat --web status + --test + no-key guard
sh "$TIER" chat --web status > /tmp/t12.txt 2>&1
contains "tavily (key set)" "$(cat /tmp/t12.txt)"; chk "chat --web status prints backend" $?
sh "$TIER" chat --web --test > /tmp/t12b.txt 2>&1
contains "OK (HTTP 200)" "$(cat /tmp/t12b.txt)"; chk "chat --web --test ok" $?
mv /etc/aetherix/tavily.key /tmp/tavily.key.bak
sh "$TIER" chat --web "x" > /tmp/t12c.txt 2>&1
contains "needs a Tavily API key" "$(cat /tmp/t12c.txt)"; chk "chat --web no-key guard" $?
mv /tmp/tavily.key.bak /etc/aetherix/tavily.key

# T13: hf_get detaches through the job dock
rm -rf /root/models/test-dl.gguf /opt/aetherix/llm-hf-dl.sh /tmp/fake-job.log \
  /etc/aetherix/jobs/hf-test-dl.gguf.state
sh "$TIER" hf get ggml-org/Test-Repo test-dl.gguf > /tmp/t13.txt 2>&1
contains "set active automatically" "$(cat /tmp/t13.txt)"; chk "hf_get detaches (message)" $?
contains "hf-test-dl.gguf" "$(cat /tmp/fake-job.log 2>/dev/null)"; chk "hf_get routes through job run" $?
[ -f /opt/aetherix/llm-hf-dl.sh ] && grep -q "test-dl.gguf" /opt/aetherix/llm-hf-dl.sh; chk "hf_get generates dl script" $?
[ -f /etc/aetherix/jobs/hf-test-dl.gguf.state ]; chk "hf_get job state visible to dock" $?

# T14: llm_jobs caps at 4 (sandbox fixture: 7 cores, 3.45 GiB RAM)
sh -c '. /tmp/llm-funcs.sh; llm_jobs' > /tmp/t14.txt 2>&1
chk "llm_jobs caps cores at 4" "$(grep -q '^4$' /tmp/t14.txt; echo $?)"
LLM_JOBS=1 sh -c '. /tmp/llm-funcs.sh; llm_jobs' > /tmp/t14b.txt 2>&1
chk "llm_jobs LLM_JOBS override=1" "$(grep -q '^1$' /tmp/t14b.txt; echo $?)"

# T15: io helper (env/in/out)
rm -rf /tmp/io-test && mkdir -p /tmp/io-test/in /tmp/io-test/out
printf 'def bug():\n    return 1/0\n' > /tmp/io-test/in/code.py
IOENV="AETHERIX_INPUT_DIR=/tmp/io-test/in AETHERIX_OUTPUT_DIR=/tmp/io-test/out"
sh -c "$IOENV sh "$ROOT/app/src/main/assets/tier/io.sh" env" > /tmp/t15.txt 2>&1
contains "AETHERIX_INPUT_DIR=/tmp/io-test/in" "$(cat /tmp/t15.txt)"; chk "io env prints INPUT" $?
contains "AETHERIX_OUTPUT_DIR=/tmp/io-test/out" "$(cat /tmp/t15.txt)"; chk "io env prints OUTPUT" $?
sh -c "$IOENV sh "$ROOT/app/src/main/assets/tier/io.sh" in" > /tmp/t15b.txt 2>&1
contains "code.py" "$(cat /tmp/t15b.txt)"; chk "io in lists dropbox" $?
sh -c "$IOENV sh "$ROOT/app/src/main/assets/tier/io.sh" out /tmp/io-test/in/code.py" > /tmp/t15c.txt 2>&1
contains "exported:" "$(cat /tmp/t15c.txt)"; chk "io out copies into OUTPUT" $?
[ "$(ls -1 /tmp/io-test/out 2>/dev/null | wc -l)" -ge 1 ]; chk "io out file landed" $?

# T16: llm replies / export / chat-log
rm -rf /etc/aetherix/responses && mkdir -p /etc/aetherix/responses
printf '# Q: q1\n\nANSWER-ONE\n' > /etc/aetherix/responses/20260811-000001.md
touch -d '2026-08-10 19:00:00' /etc/aetherix/responses/20260811-000001.md
printf '# Q: q2\n\nANSWER-TWO\n' > /etc/aetherix/responses/20260811-000002.md
touch -d '2026-08-10 19:01:00' /etc/aetherix/responses/20260811-000002.md
printf '[09:00:01] you: hi\n[09:00:02] llm: hello there\n[09:00:03] you: explain\n' > /etc/aetherix/llm-chat.log
sh "$TIER" replies 1 > /tmp/t16.txt 2>&1
contains "ANSWER-TWO" "$(cat /tmp/t16.txt)"; chk "llm replies prints newest" $?
sh "$TIER" chat-log 2 > /tmp/t16b.txt 2>&1
contains "hello there" "$(cat /tmp/t16b.txt)"; chk "llm chat-log tail" $?
AETHERIX_OUTPUT_DIR=/tmp/io-test/out sh "$TIER" export > /tmp/t16c.txt 2>&1
contains "exported:" "$(cat /tmp/t16c.txt)"; chk "llm export writes reply" $?
[ "$(ls -1 /tmp/io-test/out/*llm-response* 2>/dev/null | wc -l)" -ge 1 ]; chk "llm export file in OUTPUT" $?

# T17: build-log export lands in OUTPUT
mkdir -p /var/log
printf '[ 42/315] Building CXX object src/llama.cpp.o\n' > /var/log/llm-build.log
AETHERIX_OUTPUT_DIR=/tmp/io-test/out sh "$TIER" build-log export > /tmp/t17.txt 2>&1
contains "exported:" "$(cat /tmp/t17.txt)"; chk "build-log export copies" $?
[ "$(ls -1 /tmp/io-test/out/*llm-build-* 2>/dev/null | wc -l)" -ge 1 ]; chk "build-log export file in OUTPUT" $?

# T18: context lists INPUT dropbox + save_reply requests dock
AETHERIX_INPUT_DIR=/tmp/io-test/in sh "$TIER" context > /tmp/t18.txt 2>&1
contains "user input dropbox" "$(cat /tmp/t18.txt)"; chk "context has dropbox section" $?
contains "code.py" "$(cat /tmp/t18.txt)"; chk "context lists INPUT files" $?
rm -f /etc/aetherix/dock.request
sh -c 'AETHERIX_DOCK=1 . /tmp/llm-funcs.sh; save_reply "q" "dock-answer"'
contains "show" "$(cat /etc/aetherix/dock.request 2>/dev/null)"; chk "save_reply requests dock" $?
grep -q "dock-answer" /etc/aetherix/responses/*.md; chk "save_reply persisted reply" $?

# T19: knowledge cards are found by docs search
mkdir -p /etc/aetherix/help/cards
cat > /etc/aetherix/help/cards/00-home.md <<'CARD'
# CARD 00 · HOME - Aetherix-Alpine knowledge map
TAG: hub
WHAT: entry card
RELATED: 25 LLM
CARD
sh "$TIER" docs find CARDGRIDZZ > /tmp/t19.txt 2>&1
contains "00-home" "$(cat /tmp/t19.txt)"; chk "docs find returns cards" $?

# T20: llm context advertises the card hubs
sh "$TIER" context > /tmp/t20.txt 2>&1
contains "knowledge cards" "$(cat /tmp/t20.txt)"; chk "context has cards section" $?
contains "25 LLM" "$(cat /tmp/t20.txt)"; chk "context lists llm hub" $?

# T21: card source set is complete (59 cards + README)
n=$(ls "$ROOT/config/modules/help-module/docs/cards/"*.md | wc -l)
[ "$n" -eq 60 ]; chk "cards source set = 59 cards + README" $?

# T22: cpu_march maps fphp/asimdhp -> +fp16
cat > /tmp/cpuinfo-fp16 <<'CPU'
Features : fp asimd evtstrm aes pmull sha1 sha2 crc32 atomics fphp asimdhp cpuid asimdrdm lrcpc dcpop asimddp
CPU
cat > /tmp/cpuinfo-nofp16 <<'CPU'
Features : fp asimd aes pmull sha1 sha2 crc32 asimddp
CPU
CPUINFO_FILE=/tmp/cpuinfo-fp16 sh -c '. /tmp/llm-funcs.sh; cpu_march' > /tmp/t22.txt 2>&1
contains "+fp16" "$(cat /tmp/t22.txt)"; chk "cpu_march adds +fp16 when fphp present" $?
CPUINFO_FILE=/tmp/cpuinfo-fp16 sh -c '. /tmp/llm-funcs.sh; cpu_march' > /tmp/t22b.txt 2>&1
contains "+dotprod" "$(cat /tmp/t22b.txt)"; chk "cpu_march keeps dotprod mapping" $?
CPUINFO_FILE=/tmp/cpuinfo-nofp16 sh -c '. /tmp/llm-funcs.sh; cpu_march' > /tmp/t22c.txt 2>&1
contains "+fp16" "$(cat /tmp/t22c.txt)"; [ $? -eq 1 ]; chk "cpu_march omits +fp16 when absent" $?

# T23: pick_compiler is OpenMP-aware (no apk in sandbox -> gcc; overrides win)
sh -c '. /tmp/llm-funcs.sh; pick_compiler' > /tmp/t23.txt 2>&1
chk "pick_compiler defaults to gcc (no libomp)" "$(grep -q '^gcc$' /tmp/t23.txt; echo $?)"
LLM_USE_CLANG=1 sh -c '. /tmp/llm-funcs.sh; pick_compiler' > /tmp/t23b.txt 2>&1
chk "LLM_USE_CLANG=1 forces clang" "$(grep -q '^clang$' /tmp/t23b.txt; echo $?)"
LLM_USE_CLANG=0 sh -c '. /tmp/llm-funcs.sh; pick_compiler' > /tmp/t23c.txt 2>&1
chk "LLM_USE_CLANG=0 forces gcc" "$(grep -q '^gcc$' /tmp/t23c.txt; echo $?)"

# T24: llm capabilities prints universal router + can/cannot + term_run
sh "$TIER" capabilities > /tmp/t24.txt 2>&1
contains "guided router: ON" "$(cat /tmp/t24.txt)"; chk "capabilities router ON (universal)" $?
contains "Cannot" "$(cat /tmp/t24.txt)"; chk "capabilities lists cannot" $?
contains "term_run" "$(cat /tmp/t24.txt)"; chk "capabilities lists term_run" $?
if grep -q "native tool loop" /tmp/t24.txt; then bad "native loop gone from capabilities"; else ok "native tool loop removed"; fi

# T25: build-status shows compiler + march + OpenMP diagnostics
sh "$TIER" build-status > /tmp/t25.txt 2>&1
contains "compiler:" "$(cat /tmp/t25.txt)"; chk "build-status reports compiler" $?
contains "+fp16" "$(cat /tmp/t25.txt)"; chk "build-status reports fp16-enabled march" $?

# T26: profile router exports for tiny models
sh -c '. /tmp/llm-funcs.sh; model_profile; echo "$ROUTER_ENABLED $ROUTER_HOPS"' > /tmp/t26.txt 2>&1
chk "router enabled + hops exported" "$(grep -q '^1 6$' /tmp/t26.txt; echo $?)"

# T27: llm wizard (skip build) - splash + step2 model reasons + complete marker
rm -f /tmp/fake-job.log /tmp/llama-server.args
printf '3\n' | WIZARD_SKIP_BUILD=1 WIZARD_NO_WAIT=1 WIZARD_MODEL=3   COMPLETION_FIXTURE=/tmp/fixtures/completion.json   HELP_FIXTURE=/tmp/fixtures/help-answer.json   sh "$TIER" wizard > /tmp/t27.txt 2>&1
contains "LLM setup wizard" "$(cat /tmp/t27.txt)"; chk "wizard splash appears" $?
contains "Step 2" "$(cat /tmp/t27.txt)"; chk "wizard model step labelled" $?
contains "SmolLM2" "$(cat /tmp/t27.txt)"; chk "wizard lists curated models" $?
contains "recommended" "$(cat /tmp/t27.txt)"; chk "wizard gives model reasons" $?
contains "wizard complete" "$(cat /tmp/t27.txt)"; chk "wizard reaches completion" $?

# T27b: FB-131 - wizard tour must not emit unquoted <placeholder> redirections
# (ash: "can't open task/q/question"); placeholders print inside quotes.
if grep -qE "can't open|cannot open" /tmp/t27.txt; then
  bad "wizard tour has no redirection errors"
else
  ok "wizard tour has no redirection errors"
fi
contains '--task "<task>"' "$(cat /tmp/t27.txt)"; chk "tour prints --task placeholder quoted" $?
contains '--web "<q>"' "$(cat /tmp/t27.txt)"; chk "tour prints --web placeholder quoted" $?
contains '--docs "<question>"' "$(cat /tmp/t27.txt)"; chk "tour prints --docs placeholder quoted" $?

# T27c: llm help must not emit redirection errors either (tier/llm help block)
sh "$TIER" help > /tmp/t27c.txt 2>&1
if grep -qE "can't open|cannot open" /tmp/t27c.txt; then
  bad "llm help has no redirection errors"
else
  ok "llm help has no redirection errors"
fi
contains '--docs "<q>"' "$(cat /tmp/t27c.txt)"; chk "help prints --docs placeholder quoted" $?

# T27d: FB-132 - wizard wait loop prints data cards ONCE, then live progress
# (build-log tail + elapsed line + done marker) instead of re-dumping all the
# cards every poll and flooding the scrollback.
mkdir -p /etc/aetherix/help/cards
cat > /etc/aetherix/help/cards/06-setup.md <<'CARD'
# CARD 06 - SETUP
WHAT: hub card for setup
RELATED: 07 INSTALL
CARD
cat > /etc/aetherix/help/cards/25-llm.md <<'CARD'
# CARD 25 - LLM
WHAT: llm hub card
RELATED: 27 LLM-SETUP
CARD
: > /var/log/llm-build.log
echo "line1 config" >> /var/log/llm-build.log
echo "line2 generating" >> /var/log/llm-build.log
echo "line3 compiling ggml" >> /var/log/llm-build.log
echo building > /etc/aetherix/llm.build.state
sh -c 'sleep 25 # /opt/aetherix/llm-build.sh' >/dev/null 2>&1 &
FAKEBUILD=$!
PATH=/usr/bin:/bin WIZARD_POLL=1 sh -c '. /tmp/llm-funcs.sh; BSTATE=/etc/aetherix/llm.build.state; BLOG=/var/log/llm-build.log; HELP=/etc/aetherix/help; need_llama() { :; }; wf_build' > /tmp/t27d.txt 2>&1 &
WIZPID=$!
sleep 2
echo done > /etc/aetherix/llm.build.state
wait "$WIZPID"; WIZRC=$?
kill "$FAKEBUILD" 2>/dev/null
[ "$WIZRC" -eq 0 ]; chk "wizard wait loop exits cleanly" $?
n=$(grep -c '^----- 06-setup -----$' /tmp/t27d.txt)
[ "$n" -eq 1 ]; chk "wizard prints 06-setup card once" $?
n=$(grep -c '^----- 25-llm -----$' /tmp/t27d.txt)
[ "$n" -eq 1 ]; chk "wizard prints 25-llm card once" $?
contains "line3 compiling ggml" "$(cat /tmp/t27d.txt)"; chk "wizard shows live build-log tail" $?
contains "build still running" "$(cat /tmp/t27d.txt)"; chk "wizard shows elapsed progress line" $?
contains "build finished" "$(cat /tmp/t27d.txt)"; chk "wizard detects build completion" $?

# T27e: WIZARD_SHOW_CARDS=0 skips the card dump but still waits + reports
: > /var/log/llm-build.log
echo "line3 compiling ggml" >> /var/log/llm-build.log
echo building > /etc/aetherix/llm.build.state
sh -c 'sleep 25 # /opt/aetherix/llm-build.sh' >/dev/null 2>&1 &
FAKEBUILD=$!
PATH=/usr/bin:/bin WIZARD_SHOW_CARDS=0 WIZARD_POLL=1 sh -c '. /tmp/llm-funcs.sh; BSTATE=/etc/aetherix/llm.build.state; BLOG=/var/log/llm-build.log; HELP=/etc/aetherix/help; need_llama() { :; }; wf_build' > /tmp/t27e.txt 2>&1 &
WIZPID=$!
sleep 2
echo done > /etc/aetherix/llm.build.state
wait "$WIZPID"
kill "$FAKEBUILD" 2>/dev/null
if grep -q '^----- ' /tmp/t27e.txt; then bad "WIZARD_SHOW_CARDS=0 skips cards"; else ok "WIZARD_SHOW_CARDS=0 skips cards"; fi
contains "build finished" "$(cat /tmp/t27e.txt)"; chk "show-cards=0 still waits + reports done" $?
rm -f /etc/aetherix/help/cards/06-setup.md /etc/aetherix/help/cards/25-llm.md

# T28: term_run allowlist auto-runs
sh -c '. /tmp/llm-funcs.sh; term_run "echo hello-terminal"' > /tmp/t28.txt 2>&1
contains "hello-terminal" "$(cat /tmp/t28.txt)"; chk "term_run allowlist auto-runs" $?

# T29: term_run rejects shell metacharacters
sh -c '. /tmp/llm-funcs.sh; term_run "echo hi; poweroff"' > /tmp/t29.txt 2>&1
contains "refused" "$(cat /tmp/t29.txt)"; chk "term_run rejects metacharacters" $?

# T30: non-allowlist + non-tty -> declined; denylist refuses
sh -c '. /tmp/llm-funcs.sh; term_run "top"' > /tmp/t30.txt 2>&1
contains "declined" "$(cat /tmp/t30.txt)"; chk "term_run non-tty confirm declined" $?
sh -c '. /tmp/llm-funcs.sh; term_run "rm -rf /"' > /tmp/t30b.txt 2>&1
contains "refused" "$(cat /tmp/t30b.txt)"; chk "term_run denies destructive targets" $?

# T31: removed legacy commands exit non-zero
for cmd in ask web agent ask-help; do
  sh "$TIER" "$cmd" "" > /tmp/t31-$cmd.txt 2>&1
  code=$?
  [ "$code" -ne 0 ]; chk "legacy 'llm $cmd' removed (exit $code)" $?
done

# T32: capabilities shows term_run OFF with LLM_TERM=0
LLM_TERM=0 sh "$TIER" capabilities > /tmp/t32.txt 2>&1
contains "term_run: OFF" "$(cat /tmp/t32.txt)"; chk "LLM_TERM=0 disables term_run" $?

# T33: context hub lists the term-tools card
sh "$TIER" context > /tmp/t33.txt 2>&1
contains "57 TERM-TOOLS" "$(cat /tmp/t33.txt)"; chk "context hub lists 57 TERM-TOOLS" $?

# T34: llm help mentions the unified chat command
sh "$TIER" help > /tmp/t34.txt 2>&1
contains "llm chat" "$(cat /tmp/t34.txt)"; chk "help mentions llm chat" $?
if grep -q "llm ask \|llm web \|llm agent \|ask-help" /tmp/t34.txt; then bad "help still lists legacy cmds"; else ok "help lists no legacy cmds"; fi

# T35: chat on unknown flag exits non-zero with usage
sh "$TIER" chat --bogus > /tmp/t35.txt 2>&1
code=$?
[ "$code" -ne 0 ]; chk "chat unknown flag exits non-zero" $?
contains "usage: llm chat" "$(cat /tmp/t35.txt)"; chk "chat unknown flag prints usage" $?

# T36: aetherix-menu --items lists each category (idx|label|command)
for _cat in llm modules files system help; do
  sh "$ROOT/config/modules/core-module/tier/menu.sh" --items "$_cat" > /tmp/t36-$_cat.txt 2>&1
  code=$?
  [ "$code" -eq 0 ]; chk "menu --items $_cat exits 0" $?
  grep -q "|" /tmp/t36-$_cat.txt; chk "menu --items $_cat rows are idx|label|command" $?
done

# T37: menu --items llm includes chat/status/hf entries
contains "llm status" "$(cat /tmp/t36-llm.txt)"; chk "menu llm lists llm status" $?
contains "llm chat" "$(cat /tmp/t36-llm.txt)"; chk "menu llm lists llm chat" $?
contains "llm hf" "$(cat /tmp/t36-llm.txt)"; chk "menu llm lists llm hf" $?

# T38: menu --items system includes app requests (copy/clear/exit)
for _req in copy clear exit; do
  contains "$_req" "$(cat /tmp/t36-system.txt)"; chk "menu system lists $_req request" $?
done

# T39: menu --selftest reports OK
sh "$ROOT/config/modules/core-module/tier/menu.sh" --selftest > /tmp/t39.txt 2>&1
contains "selftest OK" "$(cat /tmp/t39.txt)"; chk "menu --selftest reports OK" $?

# T40: menu --items with an unknown category falls back to a menu-help row
sh "$ROOT/config/modules/core-module/tier/menu.sh" --items bogus > /tmp/t40.txt 2>&1
[ $? -eq 0 ]; chk "menu --items bogus exits 0 with help row" $?
contains "Menu help" "$(cat /tmp/t40.txt)"; chk "menu --items bogus prints category help" $?

# T41: say() folds long text at the terminal width (FB-132); widths below
# the 40-col clamp fold at 40.
SAY_WIDTH=30 sh -c '. /tmp/llm-funcs.sh; say "one two three four five six seven eight nine ten"' > /tmp/t41.txt 2>&1
awk 'length($0)>40' /tmp/t41.txt | grep -q .; [ $? -eq 1 ]; chk "say folds all lines to width (40 min)" $?
SAY_WIDTH=30 sh -c '. /tmp/llm-funcs.sh; say "0123456789012345678901234567890123456789"' > /tmp/t41b.txt 2>&1
contains "0123456789" "$(cat /tmp/t41b.txt)"; chk "say hard-cuts overlong tokens" $?
SAY_WIDTH=63 sh -c '. /tmp/llm-funcs.sh; say "  llm chat --once \"<q>\"      one-shot question (auto web/docs/file/terminal)"' > /tmp/t41c.txt 2>&1
awk 'length($0)>63' /tmp/t41c.txt | grep -q .; [ $? -eq 1 ]; chk "say wraps quoted help line at 63" $?

# T42: help / capabilities / context / wizard tour fit a 63-col device
SAY_WIDTH=63 sh "$TIER" help > /tmp/t42.txt 2>&1
awk 'length($0)>63' /tmp/t42.txt | grep -q .; [ $? -eq 1 ]; chk "llm help fits 63 cols" $?
SAY_WIDTH=63 sh "$TIER" capabilities > /tmp/t42b.txt 2>&1
awk 'length($0)>63' /tmp/t42b.txt | grep -q .; [ $? -eq 1 ]; chk "capabilities fits 63 cols" $?
SAY_WIDTH=63 sh "$TIER" context > /tmp/t42c.txt 2>&1
awk 'length($0)>63' /tmp/t42c.txt | grep -q .; [ $? -eq 1 ]; chk "context fits 63 cols" $?
printf '3\n' | WIZARD_SKIP_BUILD=1 WIZARD_NO_WAIT=1 WIZARD_MODEL=3 SAY_WIDTH=63   COMPLETION_FIXTURE=/tmp/fixtures/completion.json   HELP_FIXTURE=/tmp/fixtures/help-answer.json   sh "$TIER" wizard > /tmp/t42d.txt 2>&1
awk 'length($0)>63' /tmp/t42d.txt | grep -q .; [ $? -eq 1 ]; chk "wizard tour fits 63 cols" $?

echo ""
echo "=== llm sandbox: $PASS passed, $FAIL failed ==="
[ "$FAIL" -eq 0 ]
