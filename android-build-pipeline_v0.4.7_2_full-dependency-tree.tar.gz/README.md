# Aetherix Android Build Pipeline Bundle

Project: Aetherix-Alpine
Version: v0.4.7_2
Git commit: 63d92d7a6c7e7145c0a81483f6fc33c16c7a4b1e
Bundle date UTC: 2026-08-21

This bundle contains the current fork source, complete Android build pipeline, resolved Gradle dependency trees, Android variant dependency output, AGP/buildscript dependency output, exact-version Gradle lock data, and the successful build verification log.

## Contents

- `aetherix-alpine-fork-v0.4.7_2/` — clean buildable source snapshot.
- `dependency-reports/` — full text dependency graphs.
- `app/gradle.lockfile` inside the source snapshot — exact resolved project artifact versions.
- `gradle/init-scripts/enable-dependency-locking.init.gradle` — activates lock enforcement for all configurations.
- `BUILD_ENVIRONMENT.txt` — JDK, Gradle, SDK path, commit, and generation metadata.
- `BUILD_VERIFICATION.txt` — successful `assembleDebug` run.
- `SHA256SUMS` — integrity checksums for bundle contents.

## Toolchain

- Java: OpenJDK 21 (project source/target compatibility: Java 17)
- Gradle Wrapper: 8.5
- Android Gradle Plugin: 8.3.2
- Compile SDK: android-34
- Build Tools: 34.0.0 (local manual pipeline also uses installed 35.0.0)
- Minimum SDK: 26
- Target SDK: 34
- Android SDK location used during verification: `/root/Android`

## Reproduce Build

1. Extract this archive.
2. Enter `aetherix-alpine-fork-v0.4.7_2`.
3. Create `local.properties` containing your SDK path, for example:

   ```properties
   sdk.dir=/path/to/Android/Sdk
   ```

4. Build with dependency locking:

   ```bash
   ./gradlew --no-daemon \
     --init-script gradle/init-scripts/enable-dependency-locking.init.gradle \
     :app:assembleDebug
   ```

5. Optional release build:

   ```bash
   ./gradlew --no-daemon \
     --init-script gradle/init-scripts/enable-dependency-locking.init.gradle \
     :app:assembleRelease
   ```

## Regenerate Dependency Reports

```bash
./gradlew --no-daemon :app:dependencies
./gradlew --no-daemon :app:androidDependencies
./gradlew --no-daemon buildEnvironment
./gradlew --no-daemon :app:dependencies --configuration releaseRuntimeClasspath
```

## Dependency Summary

- Direct runtime implementation dependencies: `androidx.appcompat:appcompat:1.6.1`, `com.google.android.material:material:1.11.0`, `androidx.constraintlayout:constraintlayout:2.1.4`.
- Resolved project dependency coordinates: 64.
- Unique resolved project artifacts: 60.
- Full transitive expansion is available under `dependency-reports/`.
