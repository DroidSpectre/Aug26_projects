package com.budsommelier.report;

import com.budsommelier.data.models.EffectInfo;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReportProcessor {

    private static final Pattern[] ARTIFACT_PATTERNS = {
        Pattern.compile("(?i)cookie|privacy policy|terms of service|gdpr|ccpa|consent"),
        Pattern.compile("(?i)log\\s*(in|out|on)|sign\\s*(in|up|out)|register|create account"),
        Pattern.compile("(?i)add a listing|advertise on|sponsored|promoted|advertisement"),
        Pattern.compile("(?i)are you over \\d+|age verification|age.gate|confirm your age"),
        Pattern.compile("(?i)all rights reserved|\\binc\\.?\\s*$|\\bltd\\b|\\bcorp\\b|™|©"),
        Pattern.compile("\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}"),
        Pattern.compile("(?i)by .+? • (jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)"),
        Pattern.compile("alt=\"[^\"]*\""),
        Pattern.compile("https?://[^\\s]+"),
        Pattern.compile("(?i)photo by|image by|credit:|source: http"),
        Pattern.compile("(?i)share this|tweet|facebook|instagram|pinterest|reddit"),
        Pattern.compile("^[-–—|=*]{3,}$"),
        Pattern.compile("^\\s*$"),
        Pattern.compile("(?i)need to login|subscribe|newsletter|get the app|download"),
        Pattern.compile("(?i)menu|home|about|contact|search|back to top"),
        Pattern.compile("(?i)show\\s+more"),
        Pattern.compile("(?i)show\\s+details"),
        Pattern.compile("(?i)#{2,}\\s*"),
        Pattern.compile("(?i)w\\.{5,}\\s*\\d+"),
        Pattern.compile("(?i)\\|\\s*leafly"),
        Pattern.compile("(?i)write a review"),
        Pattern.compile("(?i)loading\\.\\.\\."),
        Pattern.compile("(?i)usa flag|canadian flag"),
        Pattern.compile("(?i)^\\d+\\.\\d+\\(\\d+\\)"),
        Pattern.compile("(?i)consumption method:"),
        Pattern.compile("(?i)(?:effects|help me|aromas|flavors)\\s+i\\s+(?:feel|with|me)"),
        Pattern.compile("(?i)june\\s+\\d+"),
        Pattern.compile("(?i)allbud logo"),
        Pattern.compile("(?i)\\[\\s*\\.\\.\\.\\s*\\]"),
        Pattern.compile("(?i)[a-z](?:help|aromas|flavors|effects|me|with|method|aroma|flavor)[a-z]"),
    };

    private static final Pattern[] NUMERIC_CLAIM_PATTERNS = {
        Pattern.compile("(?i)(thc|cbd|cbn|cbg|thca)\\s*[:]?\\s*([\\d.]+)\\s*%"),
        Pattern.compile("(?i)(thc|cbd|cbn|cbg|thca)\\s*[:]?\\s*([\\d.]+)\\s*percent"),
        Pattern.compile("(?i)([\\d.]+)\\s*%\\s*(thc|cbd|cbn|cbg|thca)"),
        Pattern.compile("(?i)(thc|cbd|cbn|cbg|thca)\\s*[:]?\\s*(less than|<)\\s*([\\d.]+)\\s*%"),
        Pattern.compile("(?i)(thc|cbd|cbn|cbg|thca)\\s*[:]?\\s*(low|high|moderate|trace)"),
        Pattern.compile("(?i)([\\d.]+)[–-]([\\d.]+)\\s*%\\s*(thc|cbd|cbn|cbg|thca)"),
        Pattern.compile("(?i)(thc|cbd|cbn|cbg|thca)\\s*[:]?\\s*([\\d.]+)[–-]([\\d.]+)\\s*%"),
    };

    public static ProcessedReport process(String[] rawResults, String strainName) {
        int n = rawResults.length;
        ProcessedReport pr = new ProcessedReport(n);

        for (int i = 0; i < n; i++) {
            pr.cleanedResults[i] = rawResults[i] != null ? stripArtifacts(rawResults[i]) : "";
        }

        pr.cleanedResults = deduplicate(pr.cleanedResults);
        pr.reconciliationTable = buildReconciliationTable(rawResults);
        pr.executiveSummary = buildExecutiveSummary(rawResults, pr.reconciliationTable);

        String allText = combineText(rawResults);
        String combinedClean = combineText(pr.cleanedResults);

        Map<String, Integer> otherPhrases = getOtherStrainPhrases(allText, strainName);
        boolean hasTargetData = isDominantStrain(allText, strainName);
        String closestStrain = findClosestMatch(otherPhrases);

        if (!hasTargetData && !pr.executiveSummary.isEmpty()) {
            pr.executiveSummary = pr.executiveSummary.replace(
                "── Executive Summary ──\n\n",
                "── Executive Summary ──\n\n⚠ No strain-specific data found; showing general cannabis information.\n\n");
        }

        if (hasTargetData) {
            String strainSpecific = filterOtherStrainSentences(allText, otherPhrases);
            pr.strainOverviewBullets = extractStrainOverview(strainSpecific);
            pr.effectsBullets = extractEffects(strainSpecific);
            pr.warningsBullets = extractWarnings(strainSpecific);
        }

        if (closestStrain != null) {
            String closestText = filterToStrainSentences(allText, closestStrain);
            if (!closestText.isEmpty()) {
                pr.strainOverviewClosestName = closestStrain;
                pr.strainOverviewClosestBullets = extractStrainOverview(closestText);
                pr.effectsClosestName = closestStrain;
                pr.effectsClosestBullets = extractEffects(closestText);
                pr.warningsClosestName = closestStrain;
                pr.warningsClosestBullets = extractWarnings(closestText);

                if (!hasTargetData) {
                    pr.strainOverviewBullets.add("Exact strain match unavailable — closest match: " + closestStrain);
                    pr.effectsBullets.add("Exact strain match unavailable — closest match: " + closestStrain);
                    pr.warningsBullets.add("Exact strain match unavailable — closest match: " + closestStrain);
                }
            }
        }

        String cleanForSynthesis = filterOtherStrainSentences(combinedClean, otherPhrases);
        pr.qualitativeAssessment = smallWorldTextRank(cleanForSynthesis);

        pr.terpeneAssociations = analyzePmi(combineText(rawResults));

        pr.topicClusters = clusterTopics(combineText(rawResults));

        if (hasTargetData && pr.topicClusters != null && !pr.topicClusters.isEmpty()) {
            StringBuilder combined = new StringBuilder();
            for (String text : pr.topicClusters.values()) {
                combined.append(text.toLowerCase()).append(" ");
            }
            String clusterText = combined.toString();

            appendUnique(pr.strainOverviewBullets, extractStrainOverview(clusterText));
            appendUnique(pr.effectsBullets, extractEffects(clusterText));
            appendUnique(pr.warningsBullets, extractWarnings(clusterText));

            if (!pr.executiveSummary.contains("Common side effects:")) {
                String[] sideEffects = {"dry mouth", "dry eyes", "paranoia", "dizziness",
                        "headache", "anxiety", "cough"};
                List<String> found = new ArrayList<>();
                for (String se : sideEffects) {
                    if (clusterText.contains(se)) found.add(se);
                }
                if (!found.isEmpty()) {
                    pr.executiveSummary = pr.executiveSummary.replace(
                        "── Executive Summary ──\n\n",
                        "── Executive Summary ──\n\n• Common side effects: " + join(", ", found) + "\n");
                }
            }
        }

        return pr;
    }

    private static String stripArtifacts(String text) {
        StringBuilder result = new StringBuilder();
        String[] lines = text.split("\\n");
        for (String line : lines) {
            boolean isArtifact = false;
            for (Pattern p : ARTIFACT_PATTERNS) {
                if (p.matcher(line).find()) {
                    isArtifact = true;
                    break;
                }
            }
            if (!isArtifact) {
                result.append(line).append("\n");
            }
        }
        return result.toString().trim();
    }

    private static String[] deduplicate(String[] results) {
        int n = results.length;
        Set<String> seenSentences = new HashSet<>();
        String[] deduped = new String[n];
        for (int i = 0; i < n; i++) deduped[i] = "";

        for (int idx = 0; idx < n; idx++) {
            String text = results[idx];
            if (text.isEmpty()) continue;

            StringBuilder dedupedBuilder = new StringBuilder();
            String[] parts = text.split("(?<=[.!?])\\s+|\\n");
            for (String part : parts) {
                part = part.trim();
                if (part.isEmpty()) continue;

                String normalized = part.toLowerCase()
                        .replaceAll("[^a-z0-9\\s]", "")
                        .replaceAll("\\s+", " ")
                        .trim();

                if (normalized.length() < 10) {
                    dedupedBuilder.append(part).append(" ");
                    continue;
                }

                boolean isDuplicate = false;
                String[] normWords = normalized.split("\\s+");
                if (normWords.length < 4) {
                    dedupedBuilder.append(part).append(" ");
                    continue;
                }

                Set<String> normWordSet = new HashSet<>(Arrays.asList(normWords));

                for (String seen : seenSentences) {
                    String[] seenWords = seen.split("\\s+");
                    Set<String> seenWordSet = new HashSet<>(Arrays.asList(seenWords));

                    Set<String> intersection = new HashSet<>(normWordSet);
                    intersection.retainAll(seenWordSet);
                    Set<String> union = new HashSet<>(normWordSet);
                    union.addAll(seenWordSet);

                    double jaccard = union.isEmpty() ? 0 : (double) intersection.size() / union.size();
                    if (jaccard > 0.7) {
                        isDuplicate = true;
                        break;
                    }

                    String longer = normalized.length() >= seen.length() ? normalized : seen;
                    String shorter = normalized.length() < seen.length() ? normalized : seen;
                    if (longer.contains(shorter) && longer.length() > 20 && shorter.length() > 10) {
                        isDuplicate = true;
                        break;
                    }
                }

                if (!isDuplicate) {
                    seenSentences.add(normalized);
                    dedupedBuilder.append(part).append(" ");
                }
            }

            deduped[idx] = dedupedBuilder.toString().trim();
        }

        return deduped;
    }

    static String buildReconciliationTable(String[] rawResults) {
        Map<String, List<String>> claimsByMetric = new LinkedHashMap<>();

        for (String result : rawResults) {
            if (result == null) continue;
            String lower = result.toLowerCase();
            for (Pattern p : NUMERIC_CLAIM_PATTERNS) {
                Matcher m = p.matcher(lower);
                while (m.find()) {
                    String metric;
                    String value;
                    if (m.groupCount() == 2) {
                        String g1 = m.group(1);
                        String g2 = m.group(2);
                        if (g1.matches("(?i)(thc|cbd|cbn|cbg|thca|low|high|moderate|trace)")) {
                            metric = g1.toUpperCase();
                            value = g2;
                        } else if (g2.matches("(?i)(thc|cbd|cbn|cbg|thca)")) {
                            metric = g2.toUpperCase();
                            value = g1;
                        } else {
                            continue;
                        }
                        if (metric.equals("LOW") || metric.equals("HIGH") || metric.equals("MODERATE") || metric.equals("TRACE")) {
                            String tmp = metric;
                            metric = value;
                            value = tmp.toLowerCase();
                        } else {
                            value = value + "%";
                        }
                    } else if (m.groupCount() == 3) {
                        String g1 = m.group(1);
                        String g2 = m.group(2);
                        String g3 = m.group(3);
                        if (g1.matches("(?i)(thc|cbd|cbn|cbg|thca)")) {
                            metric = g1.toUpperCase();
                            value = g2 + "-" + g3 + "%";
                        } else {
                            metric = g3.toUpperCase();
                            value = g1 + "-" + g2 + "%";
                        }
                    } else {
                        continue;
                    }
                    if (!metric.equals("THC") && !metric.equals("THCA")) {
                        String numStr = value.replaceAll("[^\\d.]", "");
                        if (!numStr.isEmpty()) {
                            double numVal;
                            try { numVal = Double.parseDouble(numStr); } catch (NumberFormatException e) { numVal = 0; }
                            if ((metric.equals("CBG") || metric.equals("CBN") || metric.equals("CBD")) && numVal > 10) {
                                continue;
                            }
                        }
                    }
                    claimsByMetric.computeIfAbsent(metric, k -> new ArrayList<>()).add(value);
                }
            }
        }

        if (claimsByMetric.isEmpty()) return "";

        StringBuilder table = new StringBuilder();
        table.append("## Data Reconciliation\n\n");
        table.append("| Metric | Reported Values | Consensus |\n");
        table.append("|--------|-----------------|-----------|\n");

        for (Map.Entry<String, List<String>> entry : claimsByMetric.entrySet()) {
            String metric = entry.getKey();
            List<String> values = entry.getValue();

            Map<String, Integer> freq = new HashMap<>();
            for (String v : values) freq.merge(v, 1, Integer::sum);

            String consensus = "";
            double maxWeightedFreq = 0;
            for (Map.Entry<String, Integer> fe : freq.entrySet()) {
                double weight = isCannabinoidDescriptor(fe.getKey()) ? 0.5 : 1.0;
                double weighted = fe.getValue() * weight;
                if (weighted > maxWeightedFreq) {
                    maxWeightedFreq = weighted;
                    consensus = fe.getKey();
                }
            }

            Set<String> uniqueValues = new LinkedHashSet<>(values);
            String reported = join(", ", uniqueValues);

            StringBuilder outlierNotes = new StringBuilder();
            for (String v : uniqueValues) {
                if (!v.equals(consensus)) {
                    int f = freq.getOrDefault(v, 0);
                    if (f == 1) {
                        if (outlierNotes.length() > 0) outlierNotes.append("; ");
                        outlierNotes.append(v).append(" flagged as outlier");
                    }
                }
            }

            String consensusStr = consensus;
            if (outlierNotes.length() > 0) {
                consensusStr += " (" + outlierNotes + ")";
            }

            table.append("| ").append(metric).append(" | ").append(reported).append(" | ").append(consensusStr).append(" |\n");
        }

        table.append("\n");
        return table.toString();
    }

    static String buildExecutiveSummary(String[] rawResults, String reconciliationTable) {
        StringBuilder summary = new StringBuilder();
        summary.append("── Executive Summary ──\n\n");

        String allText = "";
        for (String s : rawResults) {
            if (s != null) allText += s.toLowerCase() + " ";
        }

        if (allText.contains("sativa") && allText.contains("indica")) {
            Pattern p = Pattern.compile("(?:(\\d+)\\s*%\\s*indica\\s*/\\s*(\\d+)\\s*%\\s*sativa|(\\d+)\\s*%\\s*sativa\\s*/\\s*(\\d+)\\s*%\\s*indica)", Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(allText);
            if (m.find()) {
                if (m.group(1) != null) {
                    summary.append("• Type: Indica-dominant hybrid (").append(m.group(1)).append("% indica / ").append(m.group(2)).append("% sativa)\n");
                } else {
                    summary.append("• Type: Sativa-dominant hybrid (").append(m.group(3)).append("% sativa / ").append(m.group(4)).append("% indica)\n");
                }
            } else {
                summary.append("• Type: Sativa/Indica hybrid\n");
            }
        } else if (allText.contains("sativa")) {
            summary.append("• Type: Sativa\n");
        } else if (allText.contains("indica")) {
            summary.append("• Type: Indica\n");
        } else {
            summary.append("• Type: Not specified in search results\n");
        }

        String[] commonTerpenes = {"myrcene", "caryophyllene", "pinene", "limonene",
                "linalool", "terpinolene", "humulene", "ocimene", "bisabolol"};
        List<String> found = new ArrayList<>();
        for (String t : commonTerpenes) {
            if (allText.contains(t)) found.add(capitalize(t));
        }
        if (!found.isEmpty()) {
            summary.append("• Top terpenes: ").append(join(", ", found)).append("\n");
        }

        if (allText.contains("relax") || allText.contains("euphoria") || allText.contains("creative")) {
            summary.append("• Effects: Relaxation, euphoria, creativity\n");
        }

        String[] medicalTerms = {"pain", "stress", "anxiety", "depression",
                "insomnia", "inflammation", "fatigue", "nausea", "cramps", "headache"};
        List<String> medicalFound = new ArrayList<>();
        for (String t : medicalTerms) {
            String textLower = allText;
            if (textLower.contains(t)) {
                String capitalized = t.substring(0, 1).toUpperCase() + t.substring(1);
                if (t.equals("anxiety") && allText.contains("reduce anxiety")) {
                    medicalFound.add(capitalized);
                } else if (allText.contains(t + " ") || allText.contains(t + "\n") || allText.contains(t + ",")) {
                    medicalFound.add(capitalized);
                }
            }
        }
        if (!medicalFound.isEmpty()) {
            summary.append("• Medical uses: ").append(join(", ", medicalFound)).append("\n");
        }

        String[] sideEffects = {"dry mouth", "dry eyes", "paranoia", "dizziness",
                "headache", "anxiety", "cough"};
        List<String> sideFound = new ArrayList<>();
        for (String t : sideEffects) {
            if (allText.contains(t)) sideFound.add(t);
        }
        if (!sideFound.isEmpty()) {
            summary.append("• Common side effects: ").append(join(", ", sideFound)).append("\n");
        }

        summary.append("\n");
        return summary.toString();
    }

    private static String combineText(String[] rawResults) {
        StringBuilder sb = new StringBuilder();
        for (String s : rawResults) {
            if (s != null) sb.append(s.toLowerCase()).append(" ");
        }
        return sb.toString();
    }

    private static boolean isCannabinoidDescriptor(String value) {
        String clean = value.replaceAll("%$", "");
        return clean.equalsIgnoreCase("low") || clean.equalsIgnoreCase("high")
                || clean.equalsIgnoreCase("moderate") || clean.equalsIgnoreCase("trace");
    }

    private static Map<String, Integer> getOtherStrainPhrases(String allText, String strainName) {
        String lowerName = strainName.toLowerCase();
        Pattern phrasePattern = Pattern.compile("\\b[A-Z][a-z]+(?:\\s+[A-Z][a-z]+)+\\b");
        Matcher m = phrasePattern.matcher(allText);
        Map<String, Integer> freq = new HashMap<>();

        Set<String> nonStrain = new HashSet<>(Arrays.asList(
            "primary flavors", "side effects", "medical uses", "also known",
            "common side", "top effects", "best strains", "top terpenes",
            "flowering time", "parent strains", "strain type", "care tips"
        ));

        while (m.find()) {
            String phrase = m.group().toLowerCase();
            if (phrase.length() > 5 && phrase.length() < 40 && !phrase.equals(lowerName)) {
                boolean skip = false;
                for (String ns : nonStrain) {
                    if (phrase.contains(ns)) { skip = true; break; }
                }
                if (!skip) freq.merge(phrase, 1, Integer::sum);
            }
        }
        Map<String, Integer> result = new HashMap<>();
        for (Map.Entry<String, Integer> e : freq.entrySet()) {
            if (e.getValue() >= 2) result.put(e.getKey(), e.getValue());
        }
        return result;
    }

    private static String findClosestMatch(Map<String, Integer> otherPhrases) {
        String best = null;
        int bestCount = 0;
        for (Map.Entry<String, Integer> e : otherPhrases.entrySet()) {
            if (e.getValue() > bestCount) {
                bestCount = e.getValue();
                best = e.getKey();
            }
        }
        if (best == null) return null;
        // Title case
        String[] words = best.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(capitalize(w));
        }
        return sb.toString();
    }

    private static String filterOtherStrainSentences(String text, Map<String, Integer> otherPhrases) {
        if (otherPhrases == null || otherPhrases.isEmpty()) return text;
        String[] sentences = text.split("(?<=[.!?])\\s+");
        StringBuilder result = new StringBuilder();
        for (String s : sentences) {
            String lower = s.toLowerCase();
            boolean hasOther = false;
            for (String phrase : otherPhrases.keySet()) {
                if (lower.contains(phrase)) {
                    hasOther = true;
                    break;
                }
            }
            if (!hasOther) {
                result.append(s).append(" ");
            }
        }
        return result.toString().trim();
    }

    private static String filterToStrainSentences(String text, String strainName) {
        String lowerName = strainName.toLowerCase();
        String[] sentences = text.split("(?<=[.!?])\\s+");
        StringBuilder result = new StringBuilder();
        for (String s : sentences) {
            if (s.toLowerCase().contains(lowerName)) {
                result.append(s).append(" ");
            }
        }
        return result.toString().trim();
    }

    private static final Set<String> EFFECT_KEYWORD_WORDS = new HashSet<>(Arrays.asList(
        "relaxed", "happy", "uplifted", "euphoric", "sleepy", "focused",
        "energetic", "creative", "hungry", "giggly", "aroused", "tingly", "talkative"
    ));

    private static final Set<String> CONTEXT_STOP_WORDS = new HashSet<>(Arrays.asList(
        "are", "was", "were", "been", "have", "has", "had", "do", "does", "did",
        "will", "would", "can", "could", "may", "might", "shall", "should",
        "report", "reported", "found", "known", "feel", "feels", "get", "gets",
        "cause", "causes", "experience", "experiences", "some", "many", "most",
        "more", "this", "that", "these", "those", "also", "very", "just", "even"
    ));

    private static final Set<String> CONTEXT_KEYWORD_WORDS = new HashSet<>();
    static {
        CONTEXT_KEYWORD_WORDS.addAll(EFFECT_KEYWORD_WORDS);
        CONTEXT_KEYWORD_WORDS.addAll(Arrays.asList(
            "pain", "stress", "anxiety", "depression", "insomnia", "inflammation",
            "fatigue", "nausea", "cramps", "headache", "appetite", "muscle", "tension",
            "dry", "mouth", "eyes", "dizziness", "paranoia", "cough", "confusion"
        ));
    }

    private static String extractContext(String text, String keyword) {
        String lower = text.toLowerCase();
        String lowerKw = keyword.toLowerCase();
        String[] sentences = lower.split("(?<=[.!?])\\s+");
        for (String s : sentences) {
            if (!s.contains(lowerKw)) continue;
            String[] words = s.split("\\s+");
            String kwFirstWord = lowerKw.split("\\s+")[0];
            int wordIdx = -1;
            for (int i = 0; i < words.length; i++) {
                String clean = words[i].replaceAll("[^a-zA-Z]", "").toLowerCase();
                if (clean.equals(kwFirstWord)) {
                    wordIdx = i;
                    break;
                }
            }
            if (wordIdx < 0) continue;

            List<String> ctxWords = new ArrayList<>();
            if (wordIdx > 0) {
                String prev = words[wordIdx - 1].replaceAll("[^a-zA-Z]", "");
                String prevLower = prev.toLowerCase();
                Set<String> prepositions = new HashSet<>(Arrays.asList(
                    "of", "for", "with", "in", "on", "at", "by", "to", "from"));
                if (prev.length() >= 2 && !CONTEXT_KEYWORD_WORDS.contains(prevLower)
                    && !prev.equalsIgnoreCase("and") && !prev.equalsIgnoreCase("or")
                    && !prev.equalsIgnoreCase("but") && !prepositions.contains(prevLower)
                    && !CONTEXT_STOP_WORDS.contains(prevLower)) {
                    ctxWords.add(prev);
                }
            }
            ctxWords.add(keyword.substring(0, 1).toUpperCase() + keyword.substring(1));

            String result = join(" ", ctxWords);
            if (result.equalsIgnoreCase(keyword)) return null;
            return result;
        }
        return null;
    }

    private static List<String> extractStrainOverview(String allText) {
        List<String> bullets = new ArrayList<>();
        String t = allText;

        // Breeder
        Matcher m = Pattern.compile("(?:bred|created|developed|produced|grown)\\s+by\\s+([A-Z][a-zA-Z\\s']+?)(?:\\.(?!\\w)|,|$)", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            String breeder = m.group(1).trim();
            if (breeder.length() < 60) bullets.add("Breeder: " + breeder.replaceAll("\\s+", " "));
        }

        // Genetics
        m = Pattern.compile("(?:genetics(?!\\s*:)\\b|parentage|lineage|parents?|cross(?:ing)?)\\s*(?:[:;]|of|between)\\s*([^.\n]+?)(?:\\.|$)", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            String g = m.group(1).trim();
            if (g.length() < 80 && g.split("\\s+").length > 2) {
                bullets.add("Genetics: " + g.replaceAll("\\s+", " "));
            }
        }

        // Type ratio
        m = Pattern.compile("(\\d+)\\s*%\\s*(indica)\\s*/\\s*(\\d+)\\s*%\\s*(sativa)", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            String i = m.group(2).toLowerCase();
            String s = m.group(4).toLowerCase();
            bullets.add("Type: " + i + "-dominant hybrid (" + m.group(1) + "% " + i + " / " + m.group(3) + "% " + s + ")");
        } else if (t.contains("indica-dominant")) {
            bullets.add("Type: Indica-dominant hybrid");
        } else if (t.contains("sativa-dominant")) {
            bullets.add("Type: Sativa-dominant hybrid");
        } else if (t.contains("hybrid") && t.contains("indica") && t.contains("sativa")) {
            bullets.add("Type: Indica/Sativa hybrid");
        } else if (t.contains("indica")) {
            bullets.add("Type: Indica");
        } else if (t.contains("sativa")) {
            bullets.add("Type: Sativa");
        }

        // Flowering
        m = Pattern.compile("(?:flowering|flowers|finish)\\s*(?:time|period|in|within)?\\s*[:.]?\\s*(\\d+[-–]\\d+|about\\s+\\d+)\\s*(?:weeks|days)", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            bullets.add("Flowering: " + m.group(1) + " weeks");
        }

        // Awards
        m = Pattern.compile("(\\d+(?:st|nd|rd|th)?\\s*(?:prize|place|cup)[^.]{3,60}\\d{4})", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            bullets.add("Awards: " + m.group(1).trim().replaceAll("\\s+", " "));
        }

        // Also known as
        m = Pattern.compile("(?:also known as|aka|also called)\\s*[:.]?\\s*([^.\n]+)(?:\\.|$)", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            String aka = m.group(1).trim();
            if (aka.length() < 60) bullets.add("Also known as: " + aka.replaceAll("\\s+", " "));
        }

        // THC from text extraction (prefer ranges)
        m = Pattern.compile("thc\\s*[:.]?\\s*(<?\\s*\\d+[-–]\\d+)\\s*%", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            bullets.add("THC: " + m.group(1).trim() + "%");
        } else {
            m = Pattern.compile("thc\\s*[:.]?\\s*(\\d+\\.?\\d*)\\s*%", Pattern.CASE_INSENSITIVE).matcher(t);
            if (m.find()) {
                bullets.add("THC: " + m.group(1).trim() + "%");
            }
        }

        // CBD from text
        m = Pattern.compile("cbd\\s*[:.]?\\s*(<?\\s*\\d+\\.?\\d*)\\s*%", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            bullets.add("CBD: " + m.group(1).trim() + "%");
        }

        if (bullets.size() > 10) bullets = bullets.subList(0, 10);
        return bullets;
    }

    private static List<String> extractEffects(String allText) {
        List<String> bullets = new ArrayList<>();
        String t = allText;

        // Positive effects with context extraction + DB fallback
        String[] effectKeywords = {"relaxed", "happy", "uplifted", "euphoric", "sleepy",
                "focused", "energetic", "creative", "hungry", "giggly", "aroused", "tingly", "talkative"};
        for (String kw : effectKeywords) {
            if (!t.contains(kw)) continue;
            String ctx = extractContext(t, kw);
            EffectInfo info = EffectDatabase.getPositive(kw);
            if (ctx != null) {
                bullets.add(capitalize(ctx));
            } else if (info != null) {
                bullets.add(info.displayName + " — " + info.description);
            } else {
                bullets.add(capitalize(kw));
            }
        }

        // Medical uses with percentages
        Matcher m = Pattern.compile("(\\d+)\\s*%\\s*of\\s+people\\s+say\\s+it\\s+helps\\s+with\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(t);
        while (m.find()) {
            bullets.add(capitalize(m.group(2)) + " — " + m.group(1) + "% of patients report relief");
        }

        // Medical uses fallback from DB
        String[] medicalKeywords = {"pain", "stress", "anxiety", "depression", "insomnia",
                "inflammation", "fatigue", "nausea", "cramps", "headache", "appetite", "muscle tension"};
        if (!t.contains("% of people")) {
            for (String kw : medicalKeywords) {
                if (!t.contains(kw)) continue;
                EffectInfo info = EffectDatabase.getMedical(kw);
                if (info != null) {
                    bullets.add(info.displayName + " — " + info.description);
                } else {
                    bullets.add(capitalize(kw));
                }
            }
        }

        // Side effects from DB
        String[] sideKeywords = {"dry mouth", "dry eyes", "dizziness", "paranoia",
                "headache", "anxiety", "cough", "confusion"};
        List<String> sideBullets = new ArrayList<>();
        for (String kw : sideKeywords) {
            if (!t.contains(kw)) continue;
            String ctx = extractContext(t, kw);
            EffectInfo info = EffectDatabase.getSide(kw);
            if (ctx != null) {
                sideBullets.add(capitalize(ctx));
            } else if (info != null) {
                sideBullets.add(info.displayName + " — " + info.description);
            } else {
                sideBullets.add(capitalize(kw));
            }
        }
        if (!sideBullets.isEmpty()) {
            bullets.add("");
            bullets.add("Side effects:");
            bullets.addAll(sideBullets);
        }

        if (bullets.size() > 10) bullets = bullets.subList(0, 10);
        return bullets;
    }

    private static List<String> extractWarnings(String allText) {
        List<String> bullets = new ArrayList<>();
        String t = allText;

        Map<String, String> warnKeywords = new LinkedHashMap<>();
        warnKeywords.put("overconsumption", "overconsum|overdo|excessive|too much");
        warnKeywords.put("low tolerance", "low tolerance|new user|beginner|start low");
        warnKeywords.put("medical disclaimer", "consult|healthcare professional|medical advice|health professional");
        warnKeywords.put("contraindications", "avoid|contraindicated|not for");
        warnKeywords.put("age restriction", "age");

        for (Map.Entry<String, String> entry : warnKeywords.entrySet()) {
            String kw = entry.getKey();
            String pattern = entry.getValue();
            if (!Pattern.compile(pattern, Pattern.CASE_INSENSITIVE).matcher(t).find()) continue;
            EffectInfo info = EffectDatabase.getWarning(kw);
            if (info != null) {
                bullets.add(info.displayName + " — " + info.description);
            }
        }

        boolean hasSideEffect = false;
        for (String se : new String[]{"dry mouth", "dry eyes", "dizziness", "paranoia", "anxiety"}) {
            if (t.contains(se)) { hasSideEffect = true; break; }
        }
        if (hasSideEffect) {
            EffectInfo info = EffectDatabase.getWarning("common side effects");
            if (info != null) bullets.add(info.displayName + " — " + info.description);
        }

        if (bullets.isEmpty()) {
            bullets.add("No strain-specific warnings identified; general cannabis precautions apply");
        }

        if (bullets.size() > 10) bullets = bullets.subList(0, 10);
        return bullets;
    }

    private static void appendUnique(List<String> target, List<String> candidates) {
        List<String> normalized = new ArrayList<>();
        for (String t : target) {
            normalized.add(t.toLowerCase().replaceAll("[^a-z0-9\\s]", "").trim());
        }
        for (String c : candidates) {
            if (c.isEmpty() || c.endsWith(":")) continue;
            String norm = c.toLowerCase().replaceAll("[^a-z0-9\\s]", "").trim();
            if (norm.length() < 5) continue;
            boolean dup = false;
            for (String n : normalized) {
                Set<String> cSet = new HashSet<>(Arrays.asList(norm.split("\\s+")));
                Set<String> nSet = new HashSet<>(Arrays.asList(n.split("\\s+")));
                Set<String> intersection = new HashSet<>(cSet);
                intersection.retainAll(nSet);
                Set<String> union = new HashSet<>(cSet);
                union.addAll(nSet);
                double j = union.isEmpty() ? 0 : (double) intersection.size() / union.size();
                if (j > 0.7) { dup = true; break; }
            }
            if (!dup) {
                target.add(c);
                normalized.add(norm);
            }
        }
    }

    private static boolean isDominantStrain(String allText, String strainName) {
        String lower = allText.toLowerCase();
        String lowerName = strainName.toLowerCase();

        Pattern phrasePattern = Pattern.compile("\\b[A-Z][a-z]+(?:\\s+[A-Z][a-z]+)+\\b");
        Matcher m = phrasePattern.matcher(allText);
        Map<String, Integer> phraseFreq = new HashMap<>();
        while (m.find()) {
            String phrase = m.group().toLowerCase();
            if (phrase.length() > 5 && phrase.length() < 40) {
                phraseFreq.merge(phrase, 1, Integer::sum);
            }
        }

        int targetCount = 0;
        int maxOtherCount = 0;
        for (Map.Entry<String, Integer> e : phraseFreq.entrySet()) {
            String phrase = e.getKey();
            int count = e.getValue();
            if (count < 2) continue;
            if (phrase.equals(lowerName)) {
                targetCount += count;
            } else if (count > maxOtherCount) {
                maxOtherCount = count;
            }
        }

        return targetCount >= maxOtherCount * 0.3;
    }

    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
        "a", "an", "the", "is", "was", "are", "were", "be", "been", "have",
        "has", "had", "do", "does", "did", "will", "would", "could", "should",
        "may", "might", "can", "at", "by", "for", "with", "about", "against",
        "between", "into", "through", "during", "before", "after", "above",
        "below", "from", "to", "up", "down", "in", "out", "on", "off", "over",
        "under", "of", "and", "or", "nor", "but", "if", "because", "as",
        "until", "while", "that", "this", "these", "those", "it", "its",
        "we", "you", "they", "them", "their", "what", "which", "who", "whom",
        "not", "no", "very", "just", "also", "more", "some", "any", "each",
        "every", "all", "both", "few", "most", "other", "into", "onto", "upon",
        "than", "then", "like", "such", "only", "own", "same", "so"
    ));

    private static class ScoredSentence {
        final int index;
        final double score;
        final String text;
        ScoredSentence(int index, double score, String text) {
            this.index = index;
            this.score = score;
            this.text = text;
        }
    }

    private static double cosineSimilarity(Map<String, Double> vecA, Map<String, Double> vecB) {
        double dot = 0, normA = 0, normB = 0;
        for (Map.Entry<String, Double> e : vecA.entrySet()) {
            double v = e.getValue();
            normA += v * v;
            Double bv = vecB.get(e.getKey());
            if (bv != null) dot += v * bv;
        }
        for (Map.Entry<String, Double> e : vecB.entrySet()) {
            double v = e.getValue();
            normB += v * v;
        }
        double denom = Math.sqrt(normA) * Math.sqrt(normB);
        return denom > 0 ? dot / denom : 0;
    }

    private static Map<String, Double> tfidfVector(String sentence, Map<String, Integer> docFreq, int totalDocs) {
        Map<String, Double> vec = new HashMap<>();
        String[] tokens = sentence.toLowerCase().split("[^a-z0-9']+");
        Map<String, Integer> termFreq = new HashMap<>();
        for (String t : tokens) {
            if (t.length() >= 3 && !STOP_WORDS.contains(t)) {
                termFreq.put(t, termFreq.getOrDefault(t, 0) + 1);
            }
        }
        int maxFreq = 0;
        for (int v : termFreq.values()) maxFreq = Math.max(maxFreq, v);
        for (Map.Entry<String, Integer> e : termFreq.entrySet()) {
            double tf = maxFreq > 0 ? (double) e.getValue() / maxFreq : 0;
            int df = docFreq.getOrDefault(e.getKey(), 1);
            double idf = Math.log((double) totalDocs / df);
            vec.put(e.getKey(), tf * idf);
        }
        return vec;
    }

    private static String smallWorldTextRank(String combinedText) {
        if (combinedText == null || combinedText.length() < 30) {
            return "No qualitative analysis available for this strain.";
        }

        String[] rawSentences = combinedText.split("(?<=[.!?])\\s+");
        List<String> filtered = new ArrayList<>();

        for (String s : rawSentences) {
            s = s.trim();
            if (s.length() < 20 || s.length() > 600) continue;
            boolean hasArtifact = false;
            for (Pattern p : ARTIFACT_PATTERNS) {
                if (p.matcher(s).find()) { hasArtifact = true; break; }
            }
            if (hasArtifact) continue;
            if (s.length() > 200 && !s.contains(".")) continue;
            filtered.add(s);
        }

        int n = filtered.size();
        if (n < 3) {
            return filtered.isEmpty() ? "No qualitative analysis available." : filtered.get(0);
        }

        Map<String, Integer> docFreq = new HashMap<>();
        for (String s : filtered) {
            Set<String> seen = new HashSet<>();
            String[] tokens = s.toLowerCase().split("[^a-z0-9']+");
            for (String t : tokens) {
                if (t.length() >= 3 && !STOP_WORDS.contains(t)) {
                    seen.add(t);
                }
            }
            for (String t : seen) docFreq.put(t, docFreq.getOrDefault(t, 0) + 1);
        }

        List<Map<String, Double>> vectors = new ArrayList<>();
        for (String s : filtered) {
            vectors.add(tfidfVector(s, docFreq, n));
        }

        double[][] sim = new double[n][n];
        double edgeThreshold = 0.2;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) { sim[i][j] = 0; continue; }
                double cs = cosineSimilarity(vectors.get(i), vectors.get(j));
                sim[i][j] = cs >= edgeThreshold ? cs : 0;
            }
        }

        int[] degrees = new int[n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (sim[i][j] > 0) degrees[i]++;
            }
        }
        double[] degSorted = new double[n];
        for (int i = 0; i < n; i++) degSorted[i] = degrees[i];
        Arrays.sort(degSorted);
        double hubThreshold = degSorted[(int)(n * 0.75)];

        double[] scores = new double[n];
        Arrays.fill(scores, 1.0);
        double d = 0.85;
        double convThreshold = 0.0001;

        for (int iter = 0; iter < 30; iter++) {
            double[] newScores = new double[n];
            double maxDiff = 0;
            for (int i = 0; i < n; i++) {
                double sum = 0;
                for (int j = 0; j < n; j++) {
                    if (i == j || sim[j][i] <= 0) continue;
                    double rowSum = 0;
                    for (int k = 0; k < n; k++) {
                        if (j != k) rowSum += sim[j][k];
                    }
                    if (rowSum > 0) {
                        double penalty = degrees[j] > hubThreshold ? 0.5 : 1.0;
                        sum += (sim[j][i] / rowSum) * scores[j] * penalty;
                    }
                }
                newScores[i] = (1 - d) + d * sum;
                maxDiff = Math.max(maxDiff, Math.abs(newScores[i] - scores[i]));
            }
            scores = newScores;
            if (maxDiff < convThreshold) break;
        }

        List<Integer> assigned = new ArrayList<>();
        for (int i = 0; i < n; i++) assigned.add(-1);
        int nextCommunity = 0;
        for (int i = 0; i < n; i++) {
            if (assigned.get(i) >= 0) continue;
            assigned.set(i, nextCommunity);
            for (int j = i + 1; j < n; j++) {
                if (assigned.get(j) >= 0) continue;
                if (sim[i][j] > 0.3) {
                    assigned.set(j, nextCommunity);
                }
            }
            nextCommunity++;
        }

        List<ScoredSentence> scored = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            scored.add(new ScoredSentence(i, scores[i], filtered.get(i)));
        }

        Map<Integer, ScoredSentence> communityBests = new HashMap<>();
        for (ScoredSentence ss : scored) {
            int c = assigned.get(ss.index);
            ScoredSentence best = communityBests.get(c);
            if (best == null || ss.score > best.score) {
                communityBests.put(c, ss);
            }
        }

        List<ScoredSentence> selected = new ArrayList<>();
        for (Map.Entry<Integer, ScoredSentence> e : communityBests.entrySet()) {
            selected.add(e.getValue());
        }

        List<ScoredSentence> remaining = new ArrayList<>(scored);
        remaining.removeAll(selected);
        Collections.sort(remaining, (a, b) -> Double.compare(b.score, a.score));

        int targetCount = Math.min(7, n);
        for (ScoredSentence ss : remaining) {
            if (selected.size() >= targetCount) break;
            boolean tooSimilar = false;
            for (ScoredSentence existing : selected) {
                double jaccard = jaccardSimilarity(vectors.get(ss.index).keySet(),
                        vectors.get(existing.index).keySet());
                if (jaccard > 0.4) { tooSimilar = true; break; }
            }
            if (!tooSimilar) selected.add(ss);
        }

        List<Integer> topIndices = new ArrayList<>();
        for (ScoredSentence ss : selected) topIndices.add(ss.index);
        Collections.sort(topIndices);

        StringBuilder result = new StringBuilder();
        for (int idx : topIndices) {
            result.append(filtered.get(idx)).append(" ");
        }

        return result.toString().trim();
    }

    private static double jaccardSimilarity(Set<String> a, Set<String> b) {
        Set<String> intersection = new HashSet<>(a);
        intersection.retainAll(b);
        Set<String> union = new HashSet<>(a);
        union.addAll(b);
        return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
    }

    private static final String[] EFFECT_KEYWORDS = {
        "relaxed", "euphoric", "happy", "uplifted", "creative", "focused",
        "energetic", "sleepy", "hungry", "giggly", "aroused",
        "pain", "stress", "anxiety", "depression", "insomnia", "inflammation",
        "nausea", "fatigue", "headache", "cramps",
        "sweet", "citrus", "diesel", "earthy", "pine", "berry", "grape",
        "vanilla", "skunk", "cheese", "gas", "cream", "lemon", "orange"
    };

    private static Map<String, String> analyzePmi(String combinedText) {
        Map<String, String> associations = new LinkedHashMap<>();
        if (combinedText == null || combinedText.length() < 50) return associations;

        String[] sentences = combinedText.toLowerCase().split("(?<=[.!?])\\s+");
        int window = 2;

        Map<String, Integer> terpeneCount = new HashMap<>();
        Map<String, Integer> effectCount = new HashMap<>();
        Map<String, Map<String, Integer>> cooccur = new HashMap<>();

        Set<String> terpeneNames = new HashSet<>(Arrays.asList(
            "myrcene", "caryophyllene", "limonene", "linalool", "pinene",
            "humulene", "terpinolene", "ocimene", "bisabolol", "eucalyptol",
            "geraniol", "camphene", "valencene", "phellandrene", "terpineol",
            "nerolidol", "guaiol", "cedrene", "fenchol", "sabinene"
        ));

        for (int si = 0; si < sentences.length; si++) {
            int start = Math.max(0, si - window / 2);
            int end = Math.min(sentences.length, si + window / 2 + 1);

            Set<String> windowTerpenes = new HashSet<>();
            Set<String> windowEffects = new HashSet<>();

            for (int wi = start; wi < end; wi++) {
                String s = sentences[wi];
                for (String tn : terpeneNames) {
                    if (s.contains(tn)) windowTerpenes.add(tn);
                }
                for (String ek : EFFECT_KEYWORDS) {
                    if (s.contains(ek)) windowEffects.add(ek);
                }
            }

            for (String tn : windowTerpenes) {
                terpeneCount.put(tn, terpeneCount.getOrDefault(tn, 0) + 1);
                if (!cooccur.containsKey(tn)) cooccur.put(tn, new HashMap<>());
                for (String ek : windowEffects) {
                    Map<String, Integer> cm = cooccur.get(tn);
                    cm.put(ek, cm.getOrDefault(ek, 0) + 1);
                }
            }
            for (String ek : windowEffects) {
                effectCount.put(ek, effectCount.getOrDefault(ek, 0) + 1);
            }
        }

        double totalWindows = Math.max(1, sentences.length);

        for (Map.Entry<String, Map<String, Integer>> entry : cooccur.entrySet()) {
            String tn = entry.getKey();
            Map<String, Integer> coMap = entry.getValue();

            double pT = terpeneCount.getOrDefault(tn, 0) / totalWindows;

            List<Map.Entry<String, Double>> scoredEffects = new ArrayList<>();
            for (Map.Entry<String, Integer> ce : coMap.entrySet()) {
                String ek = ce.getKey();
                double pE = effectCount.getOrDefault(ek, 0) / totalWindows;
                double pTE = ce.getValue() / totalWindows;
                double pmi = 0;
                if (pTE > 0 && pT > 0 && pE > 0) {
                    pmi = Math.log(pTE / (pT * pE));
                }
                if (pmi > 0) {
                    scoredEffects.add(new AbstractMap.SimpleEntry<>(ek, pmi));
                }
            }

            Collections.sort(scoredEffects, (a, b) -> Double.compare(b.getValue(), a.getValue()));

            StringBuilder sb = new StringBuilder();
            int take = Math.min(3, scoredEffects.size());
            for (int i = 0; i < take; i++) {
                if (i > 0) sb.append(", ");
                sb.append(scoredEffects.get(i).getKey())
                  .append(" (").append(String.format("%.2f", scoredEffects.get(i).getValue())).append(")");
            }
            if (sb.length() > 0) {
                associations.put(capitalize(tn), sb.toString());
            }
        }

        return associations;
    }

    private static Map<String, String> clusterTopics(String combinedText) {
        Map<String, String> clusters = new LinkedHashMap<>();
        if (combinedText == null || combinedText.length() < 50) return clusters;

        String[] rawSentences = combinedText.split("(?<=[.!?])\\s+");
        List<String> sentences = new ArrayList<>();
        for (String s : rawSentences) {
            s = s.trim();
            if (s.length() >= 20 && s.length() <= 600) sentences.add(s);
        }

        int n = sentences.size();
        if (n < 10) return clusters;

        int k = 5;
        double alpha = 0.1;
        double beta = 0.01;

        Map<String, Integer> vocabMap = new HashMap<>();
        List<List<Integer>> docWords = new ArrayList<>();
        for (String s : sentences) {
            String[] tokens = s.toLowerCase().split("[^a-z0-9']+");
            List<Integer> ids = new ArrayList<>();
            for (String t : tokens) {
                if (t.length() >= 3 && !STOP_WORDS.contains(t)) {
                    if (!vocabMap.containsKey(t)) vocabMap.put(t, vocabMap.size());
                    ids.add(vocabMap.get(t));
                }
            }
            docWords.add(ids);
        }

        int V = vocabMap.size();
        if (V < 10) return clusters;

        int[][] z = new int[n][];
        int[][] nw = new int[k][V];
        int[][] nd = new int[n][k];
        int[] nwSum = new int[k];
        Random rng = new Random(42);

        for (int d = 0; d < n; d++) {
            List<Integer> words = docWords.get(d);
            z[d] = new int[words.size()];
            for (int w = 0; w < words.size(); w++) {
                int topic = rng.nextInt(k);
                z[d][w] = topic;
                nw[topic][words.get(w)]++;
                nwSum[topic]++;
                nd[d][topic]++;
            }
        }

        for (int iter = 0; iter < 100; iter++) {
            for (int d = 0; d < n; d++) {
                int lenD = docWords.get(d).size();
                List<Integer> words = docWords.get(d);
                for (int w = 0; w < words.size(); w++) {
                    int wid = words.get(w);
                    int topic = z[d][w];

                    nw[topic][wid]--;
                    nwSum[topic]--;
                    nd[d][topic]--;

                    double[] probs = new double[k];
                    double sum = 0;
                    for (int t = 0; t < k; t++) {
                        double pWord = (nw[t][wid] + beta) / (nwSum[t] + V * beta);
                        double pTopic = (nd[d][t] + alpha) / (lenD + k * alpha);
                        probs[t] = pWord * pTopic;
                        sum += probs[t];
                    }

                    double r = rng.nextDouble() * sum;
                    double cumulative = 0;
                    int newTopic = 0;
                    for (int t = 0; t < k; t++) {
                        cumulative += probs[t];
                        if (r <= cumulative) { newTopic = t; break; }
                    }

                    z[d][w] = newTopic;
                    nw[newTopic][wid]++;
                    nwSum[newTopic]++;
                    nd[d][newTopic]++;
                }
            }
        }

        List<Set<Integer>> topicSentences = new ArrayList<>();
        for (int t = 0; t < k; t++) topicSentences.add(new HashSet<>());

        for (int d = 0; d < n; d++) {
            Map<Integer, Integer> topicCount = new HashMap<>();
            for (int w = 0; w < z[d].length; w++) {
                int t = z[d][w];
                topicCount.put(t, topicCount.getOrDefault(t, 0) + 1);
            }
            int bestTopic = 0;
            int bestCount = 0;
            for (Map.Entry<Integer, Integer> e : topicCount.entrySet()) {
                if (e.getValue() > bestCount) {
                    bestCount = e.getValue();
                    bestTopic = e.getKey();
                }
            }
            topicSentences.get(bestTopic).add(d);
        }

        String[][] topicTopWords = new String[k][3];
        String[] knownLabels = {"effects", "medical", "flavor", "potency", "general"};

        for (int t = 0; t < k; t++) {
            List<Map.Entry<String, Integer>> wordList = new ArrayList<>();
            for (Map.Entry<String, Integer> ve : vocabMap.entrySet()) {
                int count = nw[t][ve.getValue()];
                if (count > 0) {
                    wordList.add(new AbstractMap.SimpleEntry<>(ve.getKey(), count));
                }
            }
            Collections.sort(wordList, (a, b) -> Integer.compare(b.getValue(), a.getValue()));

            for (int i = 0; i < 3 && i < wordList.size(); i++) {
                topicTopWords[t][i] = wordList.get(i).getKey();
            }

            String label = "Topic " + (t + 1);
            if (wordList.size() >= 3) {
                Set<String> topSet = new HashSet<>();
                for (int i = 0; i < 3; i++) topSet.add(wordList.get(i).getKey());
                if (topSet.contains("relax") || topSet.contains("happy") || topSet.contains("euphoric"))
                    label = "Effects";
                else if (topSet.contains("pain") || topSet.contains("stress") || topSet.contains("anxiety"))
                    label = "Medical";
                else if (topSet.contains("sweet") || topSet.contains("citrus") || topSet.contains("berry"))
                    label = "Flavor";
                else if (topSet.contains("thc") || topSet.contains("strong") || topSet.contains("heavy"))
                    label = "Potency";
                else if (topSet.contains("strain") || topSet.contains("review") || topSet.contains("user"))
                    label = "General";
            }

            StringBuilder sb = new StringBuilder();
            List<Integer> sIndices = new ArrayList<>(topicSentences.get(t));
            Collections.sort(sIndices);
            for (int si : sIndices) {
                sb.append(sentences.get(si)).append(" ");
            }
            String text = sb.toString().trim();
            if (text.length() > 50) {
                if (clusters.containsKey(label)) {
                    label = label + " (" + (t + 1) + ")";
                }
                clusters.put(label, text);
            }
        }

        return clusters;
    }

    private static String join(String delimiter, Iterable<?> items) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (Object item : items) {
            if (!first) sb.append(delimiter);
            sb.append(item.toString());
            first = false;
        }
        return sb.toString();
    }

    private static String join(String delimiter, String[] items) {
        return join(delimiter, Arrays.asList(items));
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
