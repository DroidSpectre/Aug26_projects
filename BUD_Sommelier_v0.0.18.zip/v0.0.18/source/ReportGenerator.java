package com.budsommelier.report;

import com.budsommelier.data.models.*;

import java.util.List;
import java.util.Map;

public class ReportGenerator {

    public static String generateStrainReport(
            String strainName,
            ProcessedReport processed,
            List<TerpeneConcentration> terpenes,
            List<ScoredFlavor> pairings,
            List<ScoredCategory> categories) {

        StringBuilder r = new StringBuilder();

        r.append("  ").append(strainName).append("\n");
        r.append("  ").append("=".repeat(Math.max(0, strainName.length() + 2))).append("\n\n");

        if (processed.executiveSummary != null && !processed.executiveSummary.isEmpty()) {
            r.append(processed.executiveSummary).append("\n");
        }

        if (!processed.strainOverviewBullets.isEmpty()) {
            r.append("── Strain Overview ──\n");
            r.append("[SOURCE: Web Search]\n");
            for (String bullet : processed.strainOverviewBullets) {
                r.append("  • ").append(bullet).append("\n");
            }
            r.append("\n");
        }

        if (processed.strainOverviewClosestName != null) {
            r.append("  Closest match data (").append(processed.strainOverviewClosestName).append("):\n");
            for (String bullet : processed.strainOverviewClosestBullets) {
                r.append("  • ").append(bullet).append("\n");
            }
            r.append("\n");
        }

        if (terpenes != null && !terpenes.isEmpty()) {
            r.append("── Terpene Profile ──\n");
            r.append("[SOURCE: Synthesis from search results]\n");
            for (TerpeneConcentration tc : terpenes) {
                r.append("  • ").append(tc.terpene.name)
                        .append(" (").append(String.format("%.0f", tc.concentration * 100)).append("%)")
                        .append(" — Aroma: ").append(tc.terpene.aroma)
                        .append(" — Effect: ").append(tc.terpene.effects).append("\n");
                if (processed.terpeneAssociations != null && !processed.terpeneAssociations.isEmpty()) {
                    String pmi = processed.terpeneAssociations.get(tc.terpene.name);
                    if (pmi != null) {
                        r.append("    Search associations: ").append(pmi).append("\n");
                    }
                }
            }
            r.append("\n");
        }

        if (!processed.effectsBullets.isEmpty()) {
            r.append("── Effects & Medical Uses ──\n");
            r.append("[SOURCE: Web Search]\n");
            for (String bullet : processed.effectsBullets) {
                if (bullet.isEmpty()) {
                    r.append("\n");
                } else if (bullet.endsWith(":")) {
                    r.append("  ").append(bullet).append("\n");
                } else {
                    r.append("  • ").append(bullet).append("\n");
                }
            }
            r.append("\n");
        }

        if (processed.effectsClosestName != null) {
            r.append("  Closest match data (").append(processed.effectsClosestName).append("):\n");
            for (String bullet : processed.effectsClosestBullets) {
                r.append("  • ").append(bullet).append("\n");
            }
            r.append("\n");
        }

        if (processed.reconciliationTable != null && !processed.reconciliationTable.isEmpty()) {
            r.append(processed.reconciliationTable).append("\n");
        }

        if (pairings != null && !pairings.isEmpty()) {
            r.append("── Cigar Pairings ──\n");
            r.append("[SOURCE: Algorithmic pairing engine]\n");
            int rank = 1;
            for (ScoredFlavor sf : pairings) {
                String spotlight = sf.spotlight ? " ★" : "";
                r.append("  ").append(rank).append(". ").append(sf.flavor.name)
                        .append(" — score: ").append(String.format("%.1f", sf.score))
                        .append(spotlight).append("\n");
                rank++;
            }
            r.append("\n");
        }

        if (categories != null && !categories.isEmpty()) {
            r.append("── Flavor Category Profile ──\n");
            r.append("[SOURCE: Algorithmic pairing engine]\n");
            for (ScoredCategory sc : categories) {
                r.append("  • ").append(sc.category.name)
                        .append(" — ").append(String.format("%.1f", sc.score)).append("\n");
            }
            r.append("\n");
        }

        if (!processed.warningsBullets.isEmpty()) {
            r.append("── Warnings ──\n");
            r.append("[SOURCE: Web Search]\n");
            for (String bullet : processed.warningsBullets) {
                r.append("  • ").append(bullet).append("\n");
            }
            r.append("\n");
        }

        if (processed.warningsClosestName != null) {
            r.append("  Closest match data (").append(processed.warningsClosestName).append("):\n");
            for (String bullet : processed.warningsClosestBullets) {
                r.append("  • ").append(bullet).append("\n");
            }
            r.append("\n");
        }

        if (processed.topicClusters != null && !processed.topicClusters.isEmpty()) {
            r.append("── Qualitative Assessment ──\n");
            for (Map.Entry<String, String> entry : processed.topicClusters.entrySet()) {
                r.append("  ").append(entry.getKey()).append(":\n");
                String indented = entry.getValue().replace("\n", "\n    ");
                r.append("    ").append(indented).append("\n\n");
            }
        } else if (processed.qualitativeAssessment != null && !processed.qualitativeAssessment.isEmpty()) {
            r.append("── Qualitative Assessment ──\n");
            r.append(processed.qualitativeAssessment).append("\n\n");
        }

        r.append("───\n");
        r.append("Generated by Bud Sommelier v0.0.18\n");

        return r.toString();
    }

    public static String generateDefaultReport(
            List<Terpene> selectedTerpenes,
            List<ScoredFlavor> pairings,
            List<ScoredCategory> categories) {

        StringBuilder r = new StringBuilder();

        r.append("  Default Pairings\n");
        r.append("  ===============\n\n");

        if (selectedTerpenes != null && !selectedTerpenes.isEmpty()) {
            r.append("Selected Terpenes\n");
            r.append("─────────────────\n");
            for (Terpene t : selectedTerpenes) {
                r.append("  [x] ").append(t.name).append("\n");
                r.append("    Aroma: ").append(t.aroma).append("\n");
                r.append("    Effect: ").append(t.effects).append("\n");
                r.append("    Best for: ").append(t.timeOfDay).append("\n\n");
            }
        }

        if (pairings != null && !pairings.isEmpty()) {
            r.append("Cigar Pairings\n");
            r.append("──────────────\n");
            int rank = 1;
            for (ScoredFlavor sf : pairings) {
                String spotlight = sf.spotlight ? " *" : "";
                r.append("  ").append(rank).append(". ").append(sf.flavor.name)
                        .append(" - score: ").append(String.format("%.1f", sf.score))
                        .append(spotlight).append("\n");
                rank++;
            }
            r.append("\n");
        }

        if (categories != null && !categories.isEmpty()) {
            r.append("Flavor Category Profile\n");
            r.append("───────────────────────\n");
            for (ScoredCategory sc : categories) {
                r.append("  . ").append(sc.category.name)
                        .append(" - ").append(String.format("%.1f", sc.score)).append("\n");
            }
        }

        r.append("\n---\n");
        r.append("Generated by Bud Sommelier\n");

        return r.toString();
    }

    public static String generateTerpeneExplorerReport(
            List<TerpeneConcentration> terpenes,
            List<ScoredFlavor> pairings,
            List<ScoredCategory> categories) {

        StringBuilder r = new StringBuilder();

        r.append("  Terpene Explorer Report\n");
        r.append("  ======================\n\n");

        if (terpenes != null && !terpenes.isEmpty()) {
            r.append("Selected Terpenes\n");
            r.append("─────────────────\n");
            for (TerpeneConcentration tc : terpenes) {
                r.append("  • ").append(tc.terpene.name)
                        .append(" (").append(String.format("%.0f", tc.concentration * 100)).append("%)\n")
                        .append("    Effects: ").append(tc.terpene.effects).append("\n")
                        .append("    Medical: ").append(tc.terpene.medicalUses).append("\n")
                        .append("    Best for: ").append(tc.terpene.timeOfDay).append("\n\n");
            }
        }

        if (pairings != null && !pairings.isEmpty()) {
            r.append("Cigar Pairings\n");
            r.append("──────────────\n");
            int rank = 1;
            for (ScoredFlavor sf : pairings) {
                String spotlight = sf.spotlight ? " ★" : "";
                r.append("  ").append(rank).append(". ").append(sf.flavor.name)
                        .append(" — ").append(String.format("%.1f", sf.score))
                        .append(spotlight).append("\n");
                rank++;
            }
            r.append("\n");
        }

        if (categories != null && !categories.isEmpty()) {
            r.append("Flavor Category Profile\n");
            r.append("───────────────────────\n");
            for (ScoredCategory sc : categories) {
                r.append("  • ").append(sc.category.name)
                        .append(" — ").append(String.format("%.1f", sc.score)).append("\n");
            }
        }

        return r.toString();
    }
}
