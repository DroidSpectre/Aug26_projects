package com.budsommelier.ui;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.budsommelier.R;
import com.budsommelier.data.AppDatabase;
import com.budsommelier.data.models.*;
import com.budsommelier.pairing.PairingEngine;
import com.budsommelier.report.ProcessedReport;
import com.budsommelier.report.ReportGenerator;
import com.budsommelier.report.ReportProcessor;
import com.budsommelier.report.ReportRenderer;
import com.budsommelier.search.SearchPipeline;
import com.budsommelier.search.TavilyClient;

public class StrainProfileFragment extends Fragment {
    private AppDatabase database;
    private TavilyClient tavilyClient;
    private TerpeneViewModel terpeneViewModel;
    private EditText searchInput;
    private Button searchButton;
    private Button shareButton;
    private TextView resultsView;
    private TextView creditStatus;
    private ProgressBar progressBar;
    private TextView progressLabel;
    private ScrollView scrollView;
    private ReportRenderer reportRenderer;
    private String currentReportMarkdown;
    private TavilyClient.CreditInfo lastCreditInfo;

    public void setDatabase(AppDatabase db) { this.database = db; }
    public void setTavilyClient(TavilyClient tc) { this.tavilyClient = tc; }
    public void setTerpeneViewModel(TerpeneViewModel vm) { this.terpeneViewModel = vm; }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_strain_profile, container, false);

        searchInput = contentView.findViewById(R.id.searchInput);
        searchButton = contentView.findViewById(R.id.searchButton);
        shareButton = contentView.findViewById(R.id.shareButton);
        resultsView = contentView.findViewById(R.id.resultsView);
        creditStatus = contentView.findViewById(R.id.creditStatus);
        progressBar = contentView.findViewById(R.id.progressBar);
        progressLabel = contentView.findViewById(R.id.progressLabel);
        scrollView = contentView.findViewById(R.id.scrollView);

        searchButton.setOnClickListener(v -> performSearch());
        shareButton.setOnClickListener(v -> shareReport());
        contentView.findViewById(R.id.clearButton).setOnClickListener(v -> {
            searchInput.setText("");
            resultsView.setText("");
            currentReportMarkdown = null;
            progressBar.setVisibility(View.GONE);
            progressLabel.setVisibility(View.GONE);
        });

        reportRenderer = new ReportRenderer(getContext());

        if (savedInstanceState != null) {
            String savedMarkdown = savedInstanceState.getString("report_markdown", "");
            if (!savedMarkdown.isEmpty()) {
                currentReportMarkdown = savedMarkdown;
                reportRenderer.renderReport(savedMarkdown, resultsView);
            }
            String savedSearch = savedInstanceState.getString("search_input", "");
            searchInput.setText(savedSearch);
        }

        checkCreditBalance();

        return contentView;
    }

    @Override
    public void onResume() {
        super.onResume();
        checkCreditBalance();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (currentReportMarkdown != null) {
            outState.putString("report_markdown", currentReportMarkdown);
        }
        outState.putString("search_input", searchInput.getText().toString());
    }

    private void checkCreditBalance() {
        SharedPreferences prefs = getActivity().getSharedPreferences("bud_sommelier_prefs", 0);
        String apiKey = prefs.getString("tavily_api_key", "").trim();
        if (TextUtils.isEmpty(apiKey)) {
            creditStatus.setText("Credits: No API key");
            return;
        }
        new Thread(() -> {
            TavilyClient client = new TavilyClient(apiKey);
            TavilyClient.CreditInfo info = client.checkCredits();
            if (!isAdded() || getActivity() == null) return;
            getActivity().runOnUiThread(() -> {
                lastCreditInfo = info;
                updateCreditDisplay();
            });
        }).start();
    }

    private void updateCreditDisplay() {
        if (lastCreditInfo == null) {
            creditStatus.setText("Credits: --");
            return;
        }
        if (lastCreditInfo.isError()) {
            creditStatus.setText("Credits: ?");
            return;
        }
        creditStatus.setText("Credits: " + lastCreditInfo.remaining + "/" + lastCreditInfo.limit);
    }

    private void performSearch() {
        String query = searchInput.getText().toString().trim();
        if (TextUtils.isEmpty(query)) {
            Toast.makeText(getContext(), "Enter a strain name", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getActivity().getSharedPreferences("bud_sommelier_prefs", 0);
        String apiKey = prefs.getString("tavily_api_key", "").trim();
        if (TextUtils.isEmpty(apiKey)) {
            Toast.makeText(getContext(), "Set your Tavily API key first (menu->Settings)", Toast.LENGTH_LONG).show();
            return;
        }

        resultsView.setText("");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        progressBar.setMax(5);
        progressLabel.setVisibility(View.VISIBLE);
        progressLabel.setText("Starting search...");
        searchButton.setEnabled(false);

        tavilyClient = new TavilyClient(apiKey);

        SearchPipeline pipeline = new SearchPipeline(tavilyClient);
        pipeline.searchStrainMultiTopic(query, new SearchPipeline.MultiTopicCallback() {
            @Override
            public void onProgress(int completed, int total, String label) {
                if (!isAdded() || getActivity() == null) return;
                progressBar.setProgress(completed);
                progressLabel.setText("Query " + completed + "/" + total + ": " + label);
            }

            @Override
            public void onComplete(String[] allTaggedResults, double[] avgScores) {
                if (!isAdded() || getActivity() == null) return;
                try {
                    progressBar.setVisibility(View.GONE);
                    progressLabel.setVisibility(View.GONE);
                    searchButton.setEnabled(true);

                    String dateStr = new SimpleDateFormat("yyyy_MM_dd", Locale.US).format(new Date());
                    String safeName = query.toLowerCase().replaceAll("[^a-z0-9]", "_");

                    String[] cleanResults = new String[allTaggedResults.length];
                    for (int i = 0; i < allTaggedResults.length; i++) {
                        cleanResults[i] = allTaggedResults[i].replaceAll(
                                "\\[TOPIC:[^\\]]+\\]\\s*\\[SCORE:[^\\]]+\\]\\s*", "");
                    }

                    String[] topicLabels = {"General"};
                    double[] topicAvgs = {0};
                    for (double s : avgScores) topicAvgs[0] += s;
                    if (avgScores.length > 0) topicAvgs[0] /= avgScores.length;

                    String reportStr = buildFullReport(query, cleanResults, topicAvgs, 0, 1, topicLabels);
                    String markdown = ReportRenderer.toMarkdown(reportStr);
                    String filename = safeName + "-" + dateStr + ".pdf";
                    savePdf(markdown, filename);

                    currentReportMarkdown = markdown;
                    reportRenderer.renderReport(markdown, resultsView);
                    scrollView.scrollTo(0, 0);

                    checkCreditBalance();

                    Toast.makeText(getContext(), "Report saved to Downloads/Bud_Reports/",
                            Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    resultsView.setText("Error generating report: " + e.getMessage());
                }
            }

            @Override
            public void onError(String error) {
                if (!isAdded() || getActivity() == null) return;
                try {
                    progressBar.setVisibility(View.GONE);
                    progressLabel.setVisibility(View.GONE);
                    searchButton.setEnabled(true);
                    resultsView.setText("Error: " + error);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private String buildFullReport(String strainName, String[] results,
                                    double[] topicAvgs, int topicIndex, int totalTopics, String[] topicLabels) {
        List<TerpeneConcentration> terpenes = extractTerpenes(results);

        if (terpeneViewModel != null) {
            terpeneViewModel.setLastSearchTerpenes(terpenes);
        }

        PairingEngine engine = new PairingEngine(database);
        List<ScoredFlavor> pairings = engine.computeFlavorPairings(terpenes);
        List<ScoredCategory> categories = engine.computeCategoryPairings(terpenes);

        if ((pairings == null || pairings.isEmpty()) && !terpenes.isEmpty()) {
            List<Terpene> allTerps = new ArrayList<>();
            for (TerpeneConcentration tc : terpenes) {
                allTerps.add(tc.terpene);
            }
            pairings = engine.computeDefaultFlavorPairings(allTerps);
            categories = engine.computeDefaultCategoryPairings(allTerps);
        }

        ProcessedReport processed = ReportProcessor.process(results, strainName);
        String report = ReportGenerator.generateStrainReport(
                strainName, processed, terpenes, pairings, categories);

        if (topicAvgs != null && totalTopics > 0) {
            report += "\nSearch Quality Score\n";
            report += "=====================\n";
            for (int t = 0; t < totalTopics; t++) {
                String label = topicLabels != null && t < topicLabels.length ? topicLabels[t] : "Topic" + (t + 1);
                double score = topicAvgs[t] * 100;
                report += String.format("%-9s: %.0f%%\n", label, score);
            }
            report += "\n";
            if (lastCreditInfo != null && !lastCreditInfo.isError()) {
                int expectedRemaining = Math.max(0, lastCreditInfo.remaining - 5);
                report += "Credits: " + expectedRemaining + "/" + lastCreditInfo.limit
                        + " remaining\n";
            }
        }

        return report;
    }

    private List<TerpeneConcentration> extractTerpenes(String[] searchResults) {
        List<TerpeneConcentration> result = new ArrayList<>();
        if (database == null) return result;

        StringBuilder allTextBuilder = new StringBuilder();
        for (String s : searchResults) {
            if (s != null) allTextBuilder.append(s.toLowerCase()).append("\n");
        }
        String allText = allTextBuilder.toString();

        List<Terpene> allTerpenes = database.getAllTerpenes();
        for (Terpene t : allTerpenes) {
            String tname = t.name.toLowerCase();
            if (allText.contains(tname)) {
                float conc = estimateConcentration(allText, tname);
                result.add(new TerpeneConcentration(t, conc));
            }
        }

        if (result.isEmpty() && !allTerpenes.isEmpty()) {
            float share = 1.0f / Math.min(allTerpenes.size(), 5);
            for (int i = 0; i < Math.min(allTerpenes.size(), 5); i++) {
                result.add(new TerpeneConcentration(allTerpenes.get(i), share));
            }
        }

        float total = 0;
        for (TerpeneConcentration tc : result) total += tc.concentration;
        if (total > 0) {
            for (TerpeneConcentration tc : result) tc.concentration /= total;
        }

        if (result.size() > 1) {
            float first = result.get(0).concentration;
            boolean allEqual = true;
            for (int i = 1; i < result.size(); i++) {
                if (Math.abs(result.get(i).concentration - first) > 0.01f) {
                    allEqual = false;
                    break;
                }
            }
            if (allEqual) {
                result.clear();
            }
        }

        return result;
    }

    private void shareReport() {
        String report = resultsView.getText().toString();
        if (TextUtils.isEmpty(report)) {
            Toast.makeText(getContext(), "Generate a report first", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(share, "Share Report"));
    }

    private void savePdf(String markdown, String filename) {
        if (markdown == null || markdown.isEmpty()) return;

        CharSequence formattedText = reportRenderer.renderToSpannable(markdown);

        PdfDocument document = new PdfDocument();
        TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(10);

        int pageWidth = 595;
        int pageHeight = 842;
        int margin = 36;
        int contentWidth = pageWidth - 2 * margin;
        int contentHeight = pageHeight - 2 * margin - 30;

        StaticLayout layout = StaticLayout.Builder.obtain(formattedText, 0, formattedText.length(), textPaint, contentWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(4f, 1.0f)
                .build();

        int totalHeight = layout.getHeight();
        int pageCount = Math.max(1, (int) Math.ceil((double) totalHeight / contentHeight));

        for (int i = 0; i < pageCount; i++) {
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, i + 1).create();
            PdfDocument.Page page = document.startPage(pageInfo);
            Canvas canvas = page.getCanvas();
            canvas.save();
            canvas.translate(margin, margin);
            canvas.clipRect(0, 0, contentWidth, contentHeight);
            canvas.translate(0, -i * contentHeight);
            layout.draw(canvas);
            canvas.restore();
            document.finishPage(page);
        }

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Bud_Reports");
            Uri uri = getActivity().getContentResolver()
                    .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri != null) {
                try {
                    OutputStream os = getActivity().getContentResolver().openOutputStream(uri);
                    document.writeTo(os);
                    os.close();
                } catch (Exception e) {
                    android.util.Log.w("StrainProfileFragment", "PDF export failed: " + e.getMessage());
                }
            }
        } else {
            if (getActivity().checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "Bud_Reports");
                dir.mkdirs();
                File file = new File(dir, filename);
                try {
                    FileOutputStream fos = new FileOutputStream(file);
                    document.writeTo(fos);
                    fos.close();
                } catch (Exception e) {
                    android.util.Log.w("StrainProfileFragment", "PDF export failed: " + e.getMessage());
                }
            } else {
                requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
            }
        }
        document.close();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    }

    private float estimateConcentration(String text, String terpeneName) {
        String escape = terpeneName.replaceAll("([.*+?^${}()|\\[\\]\\\\])", "\\\\$1");
        String[] patterns = {
                escape + "\\s*[:.]?\\s*(<?)\\s*(\\d+\\.?\\d*)\\s*%",
                escape + ".*?(\\d+\\.?\\d*)\\s*%",
                escape + "\\s*(?:is|at|about|approximately|~)?\\s*(\\d+\\.?\\d*)\\s*%"};
        for (String pattern : patterns) {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern, java.util.regex.Pattern.CASE_INSENSITIVE);
            java.util.regex.Matcher m = p.matcher(text);
            if (m.find()) {
                try {
                    float val = Float.parseFloat(m.group(1));
                    if (val > 50) continue;
                    return val / 100f;
                } catch (NumberFormatException e) {
                    continue;
                }
            }
        }
        String lowerText = text.toLowerCase();
        String lowerName = terpeneName.toLowerCase();
        int count = 0;
        int idx = 0;
        while ((idx = lowerText.indexOf(lowerName, idx)) != -1) {
            count++;
            idx += lowerName.length();
        }
        return count > 0 ? Math.min(0.5f, count * 0.1f) : 0.2f;
    }
}
