# Aetherix-Alpine

**A pocket Linux computer and private AI assistant for locked Samsung phones.**

Aetherix-Alpine is an Android app that turns a normal, *not rooted* Samsung
phone into a real Linux computer. It works on phones that other Linux apps
cannot work on — including corporate and government devices locked down by
Samsung's Knox security. And in recent versions it also runs a private,
on-device AI chatbot that answers questions about your phone, your files, and
even the live internet — all without sending your data anywhere.

This README tells the whole story in plain language: what the app is, how it
manages to run on locked phones, everything you can do with it today, and how
it got here version by version from the very first build to the latest one.

---

## The problem it solves

Most people never think about this, but your Samsung phone is a very strict
building:

- Every program must show a "badge" to enter (a security label called an
  *SELinux domain*).
- Guards (Samsung Knox) check the badge at every door.
- Programs written for desktop computers carry the "wrong" badge and get
  stopped before they can run.

The popular Linux-on-phone app **Termux** works around this by changing its
badge. On most phones the guards accept that. On Samsung phones with Knox,
the guards are trained to catch exactly that trick and kill the program.

Aetherix-Alpine takes a different road: it **never changes its badge**. It
walks through a door that every app is allowed to use (the special folder
where Android keeps an app's own helper programs) and keeps every Linux
program it runs in that same allowed room. The guards check — and every check
passes, because nothing suspicious ever happens. That is the core discovery
this project is built on, and it is what lets the app run a full Linux system
on phones where Termux simply cannot.

**The result:** no root, no jailbreak, no unlocking the bootloader — just an
app you install like any other.

---

## What you can do with it today

- **A real Linux terminal.** Bash shell, hundreds of installable programs
  (Python, Git, Node.js, compilers, databases, SSH, and more) through the
  Alpine package manager.
- **Private, on-device AI.** Chat with a small AI model that runs entirely on
  your phone (nothing leaves the device). The model can:
  - Answer plain questions, explain commands, and help you use the terminal.
  - Search the web (with cited answers, if you add a Tavily search key).
  - Read files you drop into the **Input** folder and analyze them (e.g.
    "find the bug in this code file").
  - Look things up in the app's built-in help library.
- **Your phone's files, accessible.** The app can read and write your
  Downloads and other storage, and gives the Linux side convenient shortcuts
  to them.
- **An Input/Output "dropbox."** Two folders the app creates and maintains in
  your Downloads: put files in `Aetherix-Alpine_INPUT` for the AI to read,
  and every report, export, and AI answer you save lands in
  `Aetherix-Alpine_OUTPUT`.
- **Long jobs that keep running.** Model downloads, package installs, and AI
  builds run in the background with a live progress bar, so the terminal
  stays usable and the phone screen can even turn off.

---

## How it works (the longer plain-language version)

Inside the app is a tiny, complete Linux system called **Alpine Linux**
(about the size of a photo album when unpacked). To run it, the app uses a
tool called **PRoot** — think of PRoot as a translator. When a Linux program
asks for a file or tries to start another program, PRoot quietly translates
that request into something Android will allow, and hands the answer back.

The clever part is *where* PRoot runs from. Android gives every app a small
folder of helper programs it is allowed to run (the "back door" mentioned
above). Aetherix-Alpine runs PRoot, and every Linux program inside the sandbox,
from that same folder. Because the program never leaves the room it was
allowed into, Samsung's extra security never triggers. That one insight —
proven after 24 failed experiments — is what makes the whole app possible.

A one-time setup wizard (7 steps, a few minutes) extracts the Linux system,
connects it to the internet for packages, and tests that everything works.
After that, the app is just a terminal on top of a real Linux computer in
your pocket.

---

## The story so far — every version, start to finish

### Chapter 1 — The breakthrough (v0.0.1 → v0.2.0, July 2026)

The project started as **DevEnv-PRoot**, a research effort to answer one
question: *can you run Linux on a locked Samsung phone at all?* The first 24
builds were mostly failures — every approach the Linux-on-Android community
normally uses was blocked by Samsung's Knox security. Then, in build
v0.0.23 (released as **v0.1.0**), the "back door" discovery landed: the first
successful `echo OK` inside a Linux sandbox on the target phone. Later builds
in this chapter added a usable terminal, working internet for the package
manager, and the 6-step setup wizard (v0.1.7 → v0.2.0).

### Chapter 2 — Becoming Aetherix-Alpine (v0.2.1 → v0.2.25, July–August 2026)

The project was renamed from DevEnv-PRoot to **Aetherix-Alpine** (v0.2.1)
because it had outgrown its research origins. This chapter turned the
proof-of-concept into a product:

- A real interactive terminal. The first versions drew the terminal inside a
  web page, which was slow and unreliable, so the team rewrote it **four
  times**, finally landing on a fast native terminal view (v0.2.11).
- A rewritten helper program that avoids a rare crash Samsung's kernel causes
  (v0.2.5).
- The setup flow grew from 6 steps to a hardened 7-step pipeline with live
  diagnostics.
- Versioning was put on a proper scheme (v0.3.0), replacing the old letter
  suffixes.

### Chapter 3 — The v0.3 series: setup polish, storage, modules (v0.3.1 → v0.3.3)

- **v0.3.1** — the 7-step setup got finished: correct step counts, real
  self-tests, helpful info popups, and a fix for an annoying bug where the
  first typed character could be eaten by Bluetooth keyboards.
- **v0.3.2** — the **storage tier**: the app can now read your phone's real
  files (with your permission), and a **module system** was introduced —
  optional feature packs that install into the Linux side, starting with a
  self-test "hello" module.
- **v0.3.3** — the **telemetry tier**: the phone's hardware info (model,
  RAM, battery, GPU) is collected and shown on the dashboard — the
  foundation the fork later polished into the Hardware card.

### Chapter 4 — The fork (v0.3a.0 → v0.3a.14_13, August 2026)

Development moved to an independent fork (a separate copy of the project with
its own identity, `com.aetherix.alpine.a`, so it can be installed alongside
the original). The fork line then rapidly hardened the app through 28
releases:

- Side-by-side install identity and self-test fixes (v0.3a.0–v0.3a.2).
- Dashboard-first boot, an install walkthrough, and a live package counter
  (v0.3a.3–v0.3a.4).
- The module system matured: bundled sample module, per-module versions,
  diagnostics, and a true "factory reset" (v0.3a.5–v0.3a.9).
- **Three new capability tiers** shipped together in v0.3a.7:
  - **Elevation** (`elv`) — connect to the phone's own debugging service
    over Wi-Fi for deeper control.
  - **GUI** (`gui`) — run graphical Linux apps and view them over VNC.
  - **LLM** (`llm`) — build and run a local AI chat server on the phone.
- Reliability wave: switching apps no longer loses your terminal session,
  killed apps recover cleanly, and long AI builds stay alive with the screen
  off (v0.3a.8–v0.3a.14_13).
- The **docked AI response window** arrived (v0.3a.14_12): AI answers appear
  in a panel above the keyboard instead of flooding the terminal, plus a
  multi-turn chat mode.
- The GUI tier was retired as out of scope (v0.3a.14_13); everything else was
  kept and archived for history.

### Chapter 5 — Core-stable v0.4.x (v0.4.0 → v0.4.3, August 2026)

The core — app, Linux system, and terminal — was declared **frozen and
stable** at **v0.4.0**. From here on, features ship through the modules, and
every released version gets its own folder on the phone with the app, source
code, and documentation.

- **v0.4.0** — modules now ship *inside* the app (nothing to sideload), the
  AI build got a phone-safe CPU detection fix, and long tasks got a proper
  background "job" system with a stacked progress dock.
- **v0.4.1** — **web search**: add a Tavily key in the dashboard (stored
  encrypted), and the AI can answer questions with up-to-date, cited web
  results.
- **v0.4.2** — **model-aware AI**: the AI learns the phone model, your
  terminal state, and the built-in help library; `llm ask` automatically
  routes questions to the right style of answer; an **agent mode** lets
  capable models look things up and read files in a loop.
- **v0.4.3** — **the workflow release**: the sparkle ✨ key opens the AI
  response window (instead of typing an emoji), model downloads run in the
  background with progress, the AI builds much faster (same compiler the
  Termux community uses), and the Input/Output dropbox plus
  `llm export`/`replies` make it easy to hand files to the AI and get
  reports back.

### Version map (quick reference)

| Version | What it was | Highlights |
|---|---|---|
| v0.0.1 – v0.1.6 | Research (DevEnv-PRoot) | 24 experiments; the Knox "back door" breakthrough at v0.1.0 |
| v0.1.7 – v0.2.0 | First usable app | Terminal, internet packages, 6-step wizard |
| v0.2.1 – v0.2.5 | Rebrand + hardening | Renamed Aetherix-Alpine; 7-step setup; native terminal path |
| v0.2.11 – v0.2.25 | Terminal rewrite | Fast native terminal replacing the web-based one |
| v0.3.0 – v0.3.3 | Product polish | Setup UX, storage tier, module system, hardware card |
| v0.3a.0 – v0.3a.14_13 | Fork era (28 builds) | Modules, dependency system, elevation/GUI/LLM tiers, docked AI window, reliability |
| v0.4.0 | Core freeze | Modules bundled in-app; job dock; safe CPU detection |
| v0.4.1 | Web search | Tavily key + cited AI answers |
| v0.4.2 | Model-aware AI | Profiles, context, auto-router, agent loop, help corpus |
| v0.4.3 | Workflow release | Sparkle key fix, background downloads, faster builds, Input/Output dropbox, AI export |

---

## Getting started

1. **Install the app.** Because the app is self-signed (like most independent
   Android apps), Samsung requires it to be installed from a computer with
   `adb`: enable Developer Mode and USB debugging, connect the phone, and run
   `adb install Aetherix-Alpine-v0.4.3.apk`. This is a Samsung policy, not
   something the app can bypass.
2. **Run the 7-step setup** (internet needed). Tap through the wizard — it
   installs the Linux system and verifies everything works.
3. **Install the modules** from the dashboard's Modules page (in order):
   core → hello → llm → help. These add the toolchain, self-tests, the AI
   tier, and the help library.
4. **Give the AI a model.** In the terminal: `llm hf` (pick from a menu of
   phone-friendly models), then `llm model ~/models/<file>.gguf` and
   `llm start`.
5. **Chat.** `llm ask "what does this command do?"`, or use `llm chat` for a
   back-and-forth conversation. Answers appear in the docked window above the
   keyboard — tap ✨ to open it.
6. **Use the dropbox.** Drop a file into `Downloads/Aetherix-Alpine_INPUT`,
   then `llm ask "review INPUT/code.py for bugs"`. Export the result with
   `llm export` — it lands in `Downloads/Aetherix-Alpine_OUTPUT`.

### Handy terminal commands (plain-English cheat sheet)

- `sd` — work with your phone's storage (list, copy, external drives).
- `module status` — see which feature packs are installed.
- `aetherix-selftest` — check that everything is healthy.
- `llm setup` / `llm build-status` — build the AI server / check on the build.
- `llm hf get <repo> <file>` — download a model in the background.
- `llm ask <question>` — ask the AI (it picks the best style automatically).
- `llm web <question>` — search the web with cited answers.
- `llm agent <task>` — let a capable model work through a task with tools.
- `llm replies` / `llm export` / `llm chat-log` — bring AI answers back as
  files and text.
- `io` — the Input/Output dropbox helper (`io env`, `io in`, `io out`).

---

## Honest limitations

- **No root, no jailbreak — by design.** The app stays inside Android's
  normal app sandbox. That keeps it safe, but also means some things remain
  off-limits (e.g. full system-wide background scheduling).
- **Background tasks can still be limited.** Android's "phantom process
  killer" trims background work after a while — a limit every Linux-on-phone
  app faces. The app holds a wake lock during long jobs (builds/downloads) to
  protect them.
- **AI speed and quality are phone-bound.** The AI runs on the phone's CPU,
  so answers come in at a few words per second and the best models for this
  hardware are small ones. Small models can occasionally make things up —
  treat important answers as a starting point, and verify.
- **The app is self-signed**, so first install requires ADB (Samsung policy).
- **GUI apps (VNC) were retired** as out of project scope. The terminal,
  storage, and AI tiers are the product.

---

## Where the documentation lives

This repository is organized so every version's story is preserved:

- `docs/BUGS.md` — the master bug register (every fix ever made, with IDs).
- `docs/v0.3-series/` — versioning policy, full changelog, layer plan, module
  architecture, package inventory.
- `docs/v0.4.0/` … `docs/v0.4.3/` — per-release READMEs, changelogs, and
  reports for the current series.
- `research/` and `reports/` — the deep technical research: how the Knox
  breakthrough works, terminal rewrites, and academic-style project reports.
- `config/modules/help-module/docs/` — the in-app help library the AI reads
  from.
- `archive/` — per-version source snapshots; built APKs are also exported to
  `/sdcard/Download/Aetherix-Alpine_v<version>/` on the device.

---

*Latest release: **v0.4.3** (versionCode 40003). The core is stable; new
features ship through modules. The app's own code is proprietary — only the
bundled third-party components carry their original open-source licenses
(listed in the app's Licenses page).*
