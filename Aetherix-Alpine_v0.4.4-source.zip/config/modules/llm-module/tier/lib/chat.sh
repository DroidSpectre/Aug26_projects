# Aetherix-Alpine LLM tier - chat capability library (sourced). Interactive
# chat, help-assistant, docs-completion personas.

docs_completion() { # $1 = q  $2 = system persona
  q="$1"; persona="$2"
  snips=$(docs_snippets "$q")
  ctx=$(ctx_block)
  escq=$(printf '%s' "$q" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escsnips=$(printf '%s' "$snips" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escctx=$(printf '%s' "$ctx" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escpers=$(printf '%s' "$persona" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escpers\"},{\"role\":\"user\",\"content\":\"HELP CORPUS (from llm docs):\\n$escsnips\\n\\nSYSTEM CONTEXT:\\n$esctx\\n\\nQUESTION: $escq\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  llm_reply "$q" "$resp"
}

answer_help() { # $1 = question - Help-Assistant persona
  if [ ! -d "$HELP" ]; then
    echo "help corpus not installed - install help-module (llm docs / llm ask-help need it); direct answer instead:"
    plain_answer "$1"
    return 0
  fi
  docs_completion "$1" "You are the Aetherix-Alpine Help Assistant. Answer using ONLY the help corpus and context below; cite source file names in parentheses. If it is not covered, say what you know and suggest 'llm docs add <dir>' for custom docs. Be concise."
}

answer_docs() { # $1 = question - project-doc persona
  if [ ! -d "$HELP" ]; then
    echo "docs corpus not installed - install help-module; direct answer instead:"
    plain_answer "$1"
    return 0
  fi
  docs_completion "$1" "You are the Aetherix-Alpine project assistant. Answer from the bundled project docs (versions, changelog, bug register). Cite the source file name in parentheses. If the docs do not cover it, say so."
}

ask_help() { # $1 = question (empty = interactive)
  ensure_server
  if [ -n "$1" ]; then
    answer_help "$1"
    return 0
  fi
  echo "help chat: ask about Aetherix-Alpine, commands, modules, troubleshooting (type Exit to leave)"
  while :; do
    printf 'help> '
    IFS= read -r q || { echo ""; break; }
    q=$(printf '%s' "$q" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
    case "$q" in
      Exit) break ;;
      "") continue ;;
    esac
    answer_help "$q"
    echo ""
  done
  echo "help chat ended"
}

