# Aetherix-Alpine LLM tier - agent capability library (sourced). Native
# tool loop (TOOL_CAPABLE) + the small-world guided router for 135M-1B models.

parse_tool_calls() { # stdin: response body
  awk '
    function unesc(s,    n, i, c, out) {
      n = length(s); out = ""
      for (i = 1; i <= n; i++) {
        c = substr(s, i, 1)
        if (c == "\\") {
          i++
          if (i <= n) {
            c = substr(s, i, 1)
            if (c == "n") out = out "\n"
            else if (c == "t") out = out "\t"
            else if (c == "\"") out = out "\""
            else out = out c
          }
          continue
        }
        out = out c
      }
      return out
    }
    function field(s, key,   klen, i, n, p, c, v) {
      n = length(s); klen = length(key) + 3
      for (i = 1; i + klen - 1 <= n; i++) {
        if (substr(s, i, klen) == "\"" key "\":") { p = i + klen; break }
      }
      if (i + klen - 1 > n) return ""
      while (p <= n && (substr(s, p, 1) == " " || substr(s, p, 1) == "\t")) p++
      if (p > n) return ""
      if (substr(s, p, 1) != "\"") return ""
      p++; v = ""
      while (p <= n) {
        c = substr(s, p, 1)
        if (c == "\\") {
          p++
          if (p <= n) {
            c = substr(s, p, 1)
            if (c == "n") v = v "\n"
            else if (c == "t") v = v "\t"
            else if (c == "r") v = v "\r"
            else v = v c
          }
          p++
          continue
        }
        if (c == "\"") break
        v = v c
        p++
      }
      return v
    }
    {
      line = $0
      p = index(line, "\"tool_calls\":")
      if (!p) exit 0
      rest = substr(line, p + 13)
      n = length(rest)
      seg = ""; inside = 0; esc = 0; depth = 0; i = 1
      while (i <= n) {
        c = substr(rest, i, 1)
        if (inside) {
          seg = seg c
          if (esc) esc = 0
          else if (c == "\\") esc = 1
          else if (c == "\"") inside = 0
          i++; continue
        }
        if (c == "\"") { inside = 1; seg = seg c; i++; continue }
        if (c == "{") { depth++; seg = seg c; i++; continue }
        if (c == "}") {
          seg = seg c; depth--; i++
          if (depth == 0) {
            id = field(seg, "id")
            nm = field(seg, "name")
            ar = unesc(field(seg, "arguments"))
            printf "ID:%s\nNAME:%s\nARGS:%s\n", id, nm, ar
            seg = ""
            while (i <= n && substr(rest, i, 1) != "{") i++
            if (i > n) exit 0
          }
          continue
        }
        if (c == "[" && depth == 0) { i++; continue }
        if (c == "]" && depth == 0) exit 0
        seg = seg c; i++
      }
    }
  '
}

# Extract the assistant "message":{...} object verbatim (for tool-call history).

msg_json() { # stdin: response body
  awk '{
    line = $0
    p = index(line, "\"message\":")
    if (!p) exit 0
    rest = substr(line, p + 10)
    n = length(rest)
    out = ""; depth = 0; inside = 0; esc = 0; i = 1
    while (i <= n) {
      c = substr(rest, i, 1)
      if (inside) {
        out = out c
        if (esc) esc = 0
        else if (c == "\\") esc = 1
        else if (c == "\"") inside = 0
        i++; continue
      }
      if (c == "\"") { inside = 1; out = out c; i++; continue }
      out = out c
      if (c == "{") depth++
      else if (c == "}") { depth--; if (depth == 0) { print out; exit 0 } }
      i++
    }
  }'
}

# Agent tool: read a text file / list a dir, read-only, restricted to the help
# corpus, the home dir, and ~/storage.

safe_file_read() { # $1 = path
  p="$1"
  case "$p" in
    '') echo "ERROR: empty path"; return 0 ;;
    *'..'*) echo "ERROR: path traversal not allowed"; return 0 ;;
  esac
  case "$p" in
    /*) : ;;
    *) p="$HOME/$p" ;;
  esac
  rp=$(command -v readlink >/dev/null 2>&1 && readlink -f "$p" 2>/dev/null || echo "$p")
  ok=0
  case "$rp" in
    /etc/aetherix/help|/etc/aetherix/help/*) ok=1 ;;
  esac
  h=$(command -v readlink >/dev/null 2>&1 && readlink -f "$HOME" 2>/dev/null || echo "$HOME")
  case "$rp" in
    "$h"|"$h"/*) ok=1 ;;
  esac
  # v0.4.4: the app's INPUT dropbox is an explicit read target (context lists
  # it), even when it is not under $HOME.
  ir=$(command -v readlink >/dev/null 2>&1 && readlink -f "$INPUT_DIR" 2>/dev/null || echo "$INPUT_DIR")
  case "$rp" in
    "$ir"|"$ir"/*) ok=1 ;;
  esac
  if [ "$ok" != "1" ]; then
    echo "ERROR: file_read is limited to the help corpus, your home dir, and ~/storage"
    return 0
  fi
  if [ -d "$rp" ]; then
    ls -1 "$rp" 2>/dev/null | head -30 | sed 's/^/  /'
  elif [ -f "$rp" ]; then
    sed -n '1,60p' "$rp" 2>/dev/null | head -c 4000
  else
    echo "ERROR: not found: $rp"
  fi
}

# Agent tool dispatch. Result text goes to stdout.

run_tool() { # $1 = tool name  $2 = args (JSON object or raw text)
  case "$1" in
    web_search)
      if ! tavily_key_ok; then
        echo "ERROR: web_search needs a Tavily key (Dashboard > Tavily Key)"
        return 0
      fi
      qq=$(printf '%s' "$2" | json_val query)
      [ -n "$qq" ] || qq="$2"
      code=$(tavily_search "$qq" 4 /tmp/tavily-agent.json)
      if [ "$code" = "200" ]; then
        tavily_extract < /tmp/tavily-agent.json
      else
        echo "ERROR: Tavily search failed (HTTP $code)"
      fi
      rm -f /tmp/tavily-agent.json
      ;;
    help_lookup)
      tt=$(printf '%s' "$2" | json_val terms)
      [ -n "$tt" ] || tt="$2"
      docs_snippets "$tt"
      ;;
    file_read)
      p=$(printf '%s' "$2" | json_val path)
      [ -n "$p" ] || p="$2"
      safe_file_read "$p"
      ;;
    done)
      ans=$(printf '%s' "$2" | json_val answer)
      [ -n "$ans" ] || ans="$2"
      printf '%s\n' "$ans"
      ;;
    *)
      echo "ERROR: unknown tool '$1'"
      ;;
  esac
}

# v1 agent: non-streaming tool loop over web_search / help_lookup / file_read /
# done. Gated on TOOL_CAPABLE (model profile).

AGENT_TOOLS='[{"type":"function","function":{"name":"web_search","description":"Search the web (Tavily) for current information and return cited snippets.","parameters":{"type":"object","properties":{"query":{"type":"string","description":"search query"}},"required":["query"]}}},{"type":"function","function":{"name":"help_lookup","description":"Search the bundled Aetherix-Alpine help corpus for documentation on commands, modules, and troubleshooting.","parameters":{"type":"object","properties":{"terms":{"type":"string","description":"space-separated search terms"}},"required":["terms"]}}},{"type":"function","function":{"name":"file_read","description":"Read a text file or list a directory within the help corpus, your home dir, ~/storage, or the INPUT dropbox.","parameters":{"type":"object","properties":{"path":{"type":"string","description":"absolute path"}},"required":["path"]}}},{"type":"function","function":{"name":"done","description":"Report the final answer and finish the task.","parameters":{"type":"object","properties":{"answer":{"type":"string","description":"final answer text"}},"required":["answer"]}}}]'


agent_run() { # $1 = task; server must be running; TOOL_CAPABLE checked
  task="$1"
  ctx=$(ctx_block)
  sys="You are the Aetherix-Alpine agent on an Android phone running Alpine Linux under PRoot. Your knowledge is outdated, so ground answers by searching (web_search) and checking local docs (help_lookup, file_read). Work toward a final answer. When a tool provides what you need, call done with the final answer. Tool call format (pick one): the API tool_calls format, or a line exactly like: tool: <name> <json-args or plain text>"
  esctx=$(printf '%s' "$ctx" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  esctask=$(printf '%s' "$task" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escsys=$(printf '%s' "$sys" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  msgs=/tmp/llm-agent.msgs
  : > "$msgs"
  printf '%s\n' "{\"role\":\"system\",\"content\":\"$escsys\"}" > "$msgs"
  printf '%s\n' "{\"role\":\"user\",\"content\":\"$esctask\"}" >> "$msgs"
  round=0
  while [ "$round" -lt "$AGENT_LOOP" ]; do
    round=$((round+1))
    list=$(tr '\n' ',' < "$msgs" | sed 's/,$//')
    resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
      -H 'Content-Type: application/json' \
      -d "{\"messages\":[$list],\"tools\":$AGENT_TOOLS,\"max_tokens\":$LLM_MAX_TOKENS}")
    am=$(printf '%s' "$resp" | msg_json)
    [ -n "$am" ] && printf '%s\n' "$am" >> "$msgs"
    calls=$(printf '%s' "$resp" | parse_tool_calls)
    if [ -n "$calls" ]; then
      printf '%s\n' "$calls" > /tmp/llm-agent.calls
      id=""; name=""; args=""
      while IFS= read -r l; do
        case "$l" in
          ID:*) id=${l#ID:}; continue ;;
          NAME:*) name=${l#NAME:}; continue ;;
        esac
        case "$l" in
          ARGS:*) args=${l#ARGS:} ;;
          *) continue ;;
        esac
        [ -n "$id" ] && [ -n "$name" ] || continue
        if [ "$name" = "done" ]; then
          ans=$(printf '%s' "$args" | json_val answer)
          [ -n "$ans" ] || ans="$args"
          llm_out "$task" "$ans"
          echo ""
          rm -f /tmp/llm-agent.calls
          return 0
        fi
        result=$(run_tool "$name" "$args")
        escres=$(printf '%s' "$result" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
        printf '%s\n' "{\"role\":\"tool\",\"tool_call_id\":\"$id\",\"content\":\"$escres\"}" >> "$msgs"
        id=""; name=""; args=""
      done < /tmp/llm-agent.calls
      rm -f /tmp/llm-agent.calls
      continue
    fi
    text=$(parse_reply "$resp")
    tl=$(printf '%s' "$text" | sed -n 's/^tool: //p' | head -1)
    if [ -n "$tl" ]; then
      tname=$(printf '%s' "$tl" | awk '{print $1}')
      targs=$(printf '%s' "$tl" | sed 's/^[^ ]* *//')
      if [ "$tname" = "done" ]; then
        llm_out "$task" "$targs"
        echo ""
        return 0
      fi
      tresult=$(run_tool "$tname" "$targs")
      tescre=$(printf '%s' "$tresult" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
      printf '%s\n' "{\"role\":\"user\",\"content\":\"TOOL RESULT ($tname): $tescre\"}" >> "$msgs"
      continue
    fi
    if [ -n "$text" ]; then
      llm_reply "$task" "$resp"
      echo ""
      return 0
    fi
    echo "agent: the model produced no tool call and no reply - stopping" >&2
    return 1
  done
  echo "agent: reached the $AGENT_LOOP-round tool limit - last model output below" >&2
  llm_reply "$task" "$resp"
  echo ""
}

# v0.4.4: small-world guided router. Small models (135M-1B) are rarely trained
# for native tool-calling, so a hardwired binary decision tree drives the tool
# box instead: each hop shows 2-4 data-card-style options and the model replies
# with one letter/number; the tier runs the selected tool and hands the results
# to the next hop. Any task resolves in <= 3 hops + final synthesis (small-world
# theory; mirrors the card hub network). No native tool-calling required and no
# SearXNG - the web hop stays on the Tavily pipeline (Vane-style: search ->
# cite [n] -> synthesize). LLM_ROUTER_MAX caps hops (default 4).

router_complete() { # $1 = system  $2 = payload  -> full reply text
  escsys=$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  # the ROUTER FINAL marker stays visible to the payload so logs/tests can key it
  escpl=$(printf '%s' "$2\n\nROUTER FINAL" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions     -H 'Content-Type: application/json'     -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escsys\"},{\"role\":\"user\",\"content\":\"$escpl\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  parse_reply "$resp"
}

router_pick() { # $1 = marker  $2 = system  $3 = payload -> first token, lowercased
  escsys=$(printf '%s' "$2" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  # the marker (ROUTER STEP 1 / ROUTER FILE) rides in the payload so logs and
  # the test fixtures can key on the decision hop
  escpl=$(printf '%s' "$3\n\nROUTER CHOICE: $1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions     -H 'Content-Type: application/json'     -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escsys\"},{\"role\":\"user\",\"content\":\"$escpl\"}],\"max_tokens\":16}")
  parse_reply "$resp" | tr -c 'a-zA-Z0-9' ' ' | awk '{print $1}' | tr 'A-Z' 'a-z'
}

router_run() { # $1 = task; server must be running; used when TOOL_CAPABLE=0
  task="$1"
  maxhops=${LLM_ROUTER_MAX:-4}
  case "$maxhops" in ''|*[!0-9]*) maxhops=4;; esac
  ctx=$(ctx_block)
  step1="TASK: $task

What does the task need FIRST?
A) current or external information only the web knows
B) Aetherix-Alpine help or project docs
C) a file on this phone (INPUT dropbox, home, or storage)
D) just answer from what you know

Reply with a single letter.

TERMINAL CONTEXT:
$ctx"
  choice=$(router_pick "ROUTER STEP 1" "You are the Aetherix-Alpine tiny assistant on Android (Alpine Linux inside PRoot). Reply with a single letter only - no explanation." "$step1")
  gathered=""
  src_tag=""
  case "$choice" in
    a)
      src_tag="WEB RESULTS"
      if ! tavily_key_ok; then
        echo "router: web needs a Tavily key (Dashboard > Tavily Key) - answering from knowledge"
        choice=d
      else
        code=$(tavily_search "$task" 4 /tmp/router-web.json)
        if [ "$code" = "200" ]; then
          gathered=$(tavily_extract < /tmp/router-web.json)
        else
          echo "router: web search failed (HTTP $code) - answering from knowledge"
          choice=d
        fi
        rm -f /tmp/router-web.json
      fi
      ;;
    b)
      src_tag="LOCAL DOCS"
      if [ ! -d "$HELP" ]; then
        echo "router: help corpus missing (install help-module) - answering from knowledge"
        choice=d
      else
        gathered=$(docs_snippets "$task")
      fi
      ;;
    c)
      src_tag="FILE CONTENTS"
      if [ ! -d "$INPUT_DIR" ]; then
        echo "router: INPUT dropbox not mounted - answering from knowledge"
        choice=d
      else
        i=0; files=""
        for f in "$INPUT_DIR"/*; do
          [ -f "$f" ] || continue
          i=$((i+1))
          [ "$i" -gt 10 ] && break
          files="$files
  $i) $(basename "$f") ($(wc -c < "$f" 2>/dev/null) bytes)"
        done
        if [ -z "$files" ]; then
          echo "router: INPUT dropbox is empty - answering from knowledge"
          choice=d
        else
          pick=$(router_pick "ROUTER FILE" "Reply with a single file number, or 0 if none of these files can help. Nothing else." "TASK: $task

FILES IN Aetherix-Alpine_INPUT:$files

Which file should I read? Reply with its number, or 0 to skip.")
          case "$pick" in
            0|''|none|skip)
              echo "router: no file chosen - answering from knowledge"
              choice=d
              ;;
            *)
              n=$(printf '%s' "$pick" | tr -cd '0-9')
              case "$n" in ''|0) choice=d ;; *)
                tgt=$(ls -1 "$INPUT_DIR" 2>/dev/null | sed -n "${n}p")
                if [ -n "$tgt" ]; then
                  got=$(safe_file_read "$INPUT_DIR/$tgt")
                  case "$got" in
                    ERROR:*) echo "router: cannot read '$tgt' - answering from knowledge"; choice=d ;;
                    *) gathered="$got" ;;
                  esac
                else
                  echo "router: no file #$n - answering from knowledge"
                  choice=d
                fi
                ;;
              esac
              ;;
          esac
        fi
      fi
      ;;
  esac
  if [ "$choice" != "d" ] && [ -z "$gathered" ]; then choice=d; fi
  if [ "$choice" = "d" ]; then
    src_tag="KNOWLEDGE"
    gathered="(no tools used - answer from your own knowledge)"
  fi
  echo "router: hop done - $src_tag - synthesizing final answer"
  final=$(router_complete "You are the Aetherix-Alpine tiny assistant. Answer the task concisely using ONLY the provided $src_tag. Cite web sources as [n]. If the material is not enough, say exactly what is missing." "$src_tag:
$gathered

TASK: $task

Final answer:")
  llm_out "$task" "$final"
  echo ""
}

# ---- routing (FB-105): ask classifies and dispatches plain/help/docs/web ----
