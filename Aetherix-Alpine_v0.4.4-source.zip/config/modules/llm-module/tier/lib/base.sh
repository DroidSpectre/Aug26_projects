# Aetherix-Alpine LLM tier - base capability library (sourced by the
# llm dispatcher; never run standalone). Server/model lifecycle, context,
# profiles, plain ask, routing, reply plumbing, capabilities manifest.

# Shared config. Guarded so the dispatcher header wins when present (same
# values); the defaults keep the libs usable standalone, e.g. under tests.
: "${STATE:=/etc/aetherix/llm.state}"
: "${CONF:=/etc/aetherix/llm.conf}"
: "${BSTATE:=/etc/aetherix/llm.build.state}"
: "${BLOG:=/var/log/llm-build.log}"
: "${CHATLOG:=/etc/aetherix/llm-chat.log}"
: "${RESPDIR:=/etc/aetherix/responses}"
: "${LPORT:=8080}"
: "${MODELS:=/root/models}"
: "${LLM_MAX_TOKENS:=512}"
: "${PROFILES:=/etc/aetherix/model-profiles.conf}"
: "${TCONTEXT:=/etc/aetherix/term.context}"
: "${HELP:=/etc/aetherix/help}"
: "${INPUT_DIR:=${AETHERIX_INPUT_DIR:-$HOME/storage/input}}"
: "${OUTPUT_DIR:=${AETHERIX_OUTPUT_DIR:-$HOME/storage/output}}"


model() { grep -m1 '^model=' "$CONF" 2>/dev/null | cut -d= -f2; }

running() { pgrep -f llama-server >/dev/null 2>&1; }

# FB-064: a build counts as live only while the detached script (or its
# cmake --build child) actually exists. Android can kill the app's process
# group even though the state file still says 'building'.

parse_reply() { # $1 = raw response body
  if printf '%s' "$1" | grep -q '"content":"'; then
    printf '%s' "$1" \
      | sed -n 's/.*"content":"//p' \
      | sed 's/"},"refusal".*//; s/"}}],"created".*//' \
      | sed 's/\\n/\n/g; s/\\t/\t/g; s/\\"/"/g'
  elif [ -z "$1" ]; then
    echo "no response - is the server running? (llm start)"
  else
    printf '%s' "$1" | head -c 2000
  fi
}

# FB-102: turn a Tavily JSON body into numbered result lines for the model.
# BusyBox-safe (no jq): a quote/escape-aware scanner walks the flat results
# array, so titles/URLs/content with escaped quotes, ] or }, inside them parse
# correctly. Tavily is asked for basic depth (flat result objects only).

transcript() { # $1 = speaker (you|llm)  $2 = text
  mkdir -p /etc/aetherix 2>/dev/null
  ts=$(date +%H:%M:%S 2>/dev/null || echo --:--:--)
  printf '[%s] %s: %s\n' "$ts" "$1" "$2" >> "$CHATLOG" 2>/dev/null
  lines=$(wc -l < "$CHATLOG" 2>/dev/null | tr -d ' ')
  case "$lines" in ''|*[!0-9]*) return 0;; esac
  if [ "$lines" -gt 200 ]; then
    tail -n 200 "$CHATLOG" > "$CHATLOG.tmp" 2>/dev/null \
      && mv -f "$CHATLOG.tmp" "$CHATLOG" 2>/dev/null
  fi
}

# v0.4.3 (FB-113): keep one file per reply so 'llm replies' and 'llm export'
# work outside the app, and ask the app to open the response dock whenever a
# reply lands (the app polls + clears /etc/aetherix/dock.request).

save_reply() { # $1 = question  $2 = reply text
  mkdir -p "$RESPDIR" 2>/dev/null || return 0
  ts=$(date +%Y%m%d-%H%M%S 2>/dev/null || echo unknown)
  { printf '# Q: %s\n\n' "$1"; printf '%s\n' "$2"; } > "$RESPDIR/$ts.md" 2>/dev/null
  n=0
  for f in $(ls -1t "$RESPDIR"/*.md 2>/dev/null); do
    n=$((n+1))
    [ "$n" -gt 50 ] && rm -f "$f"
  done
  if [ "$AETHERIX_DOCK" = "1" ]; then
    printf 'show\n' > /etc/aetherix/dock.request 2>/dev/null
  fi
}

# FB-081: when the launcher exports AETHERIX_DOCK=1 the app shows replies in
# the docked response window (transcript only, no terminal output); otherwise
# print the reply inline exactly like 14_11.

llm_reply() { # $1 = question  $2 = raw response body
  out=$(parse_reply "$2")
  save_reply "$1" "$out"
  if [ "$AETHERIX_DOCK" = "1" ]; then
    transcript you "$1"
    transcript llm "$out"
  else
    printf '%s\n' "$out"
  fi
}

# v0.4.4 (Q8): OpenMP-aware compiler. clang needs the LLVM OpenMP runtime
# (libomp); when libomp is unavailable (the best-effort 'apk add libomp' fails)
# gcc is used so -DGGML_OPENMP=ON links via gcc's bundled libgomp. Otherwise
# cmake silently falls back to GGML_OPENMP=OFF and inference loses parallel
# kernels. LLM_USE_CLANG=1 forces clang (accepting the OpenMP-OFF fallback),
# =0 forces gcc.

capabilities() {
  model_profile
  march=$(cpu_march)
  echo "== Aetherix-Alpine LLM capabilities =="
  echo ""
  echo "Base:"
  echo "  - llm ask/chat with 135M-10B GGUF models (llama.cpp, loopback only)"
  echo "  - start/stop/status, per-model profiles (ctx/batch/agent rounds)"
  echo "  - replies, chat-log, export to the OUTPUT dropbox"
  echo "  - build llama-server from source; hf browse/download"
  echo "Context (llm context):"
  echo "  - terminal tail snapshot (~40 lines), system/module/job state"
  echo "  - INPUT dropbox listing, storage map, knowledge-card map"
  echo "Web:"
  echo "  - Tavily search + cited synthesis (needs Dashboard > Tavily Key)"
  echo "  - no keyless web fallback (SearXNG deferred)"
  echo "RAG/docs:"
  echo "  - llm docs find/add + ask-help over the help-module corpus and cards"
  echo "Agent tools: web_search, help_lookup, file_read, done"
  if [ "$TOOL_CAPABLE" -eq 1 ]; then
    echo "  - native tool loop: ON (profile rounds = $AGENT_LOOP)"
  else
    echo "  - native tool loop: OFF (profile rounds = 0)"
    if [ "$ROUTER_CAPABLE" -eq 1 ]; then
      echo "  - guided router: ON - hardwired A/B/C/D tool menu, <=${LLM_ROUTER_MAX:-4} hops (small-world)"
    else
      echo "  - guided router: OFF (LLM_ROUTER=0)"
    fi
  fi
  echo "File access:"
  echo "  - read-only: help corpus, home, ~/storage, INPUT dropbox (<=60 lines/4KB)"
  echo "Cannot:"
  echo "  - run shell commands, write to the prompt/scrollback, live scrollback reads"
  echo "  - keyless web search, vision/multimodal, cloud sync"
  echo "Build (device):"
  echo "  - compiler: $(pick_compiler) (LLM_USE_CLANG=${LLM_USE_CLANG:-auto})"
  echo "  - openmp: $(openmp_state)   march: ${march:-none}"
  if [ -s "$BLOG" ]; then
    grep -o 'Performing Test HAVE_[A-Z0-9_]* - Success\|Performing Test HAVE_[A-Z0-9_]* - Failed' "$BLOG" 2>/dev/null | sort -u | sed 's/^/  probes: /'
  fi
}

# ---- v0.4.2: model profiles, terminal context, routing, agent tools, help ----

model_profile() {
  f=$(model)
  [ -n "$f" ] || f="$LLM_MODEL"
  f=$(basename "$f" 2>/dev/null | tr 'A-Z' 'a-z')
  ctx=2048; batch=512; loop=0
  if [ -f "$PROFILES" ]; then
    while IFS= read -r line; do
      case "$line" in ''|\#*) continue;; esac
      pat=$(printf '%s' "$line" | awk '{print $1; exit}')
      vctx=$(printf '%s' "$line" | awk '{print $2; exit}')
      vbatch=$(printf '%s' "$line" | awk '{print $3; exit}')
      vloop=$(printf '%s' "$line" | awk '{print $4; exit}')
      case "$pat" in ''|*[!a-z0-9*?]*) continue;; esac
      case "$vctx" in ''|*[!0-9]*) continue;; esac
      case "$vbatch" in ''|*[!0-9]*) continue;; esac
      case "$vloop" in ''|*[!0-9]*) continue;; esac
      case "$f" in
        $pat) ctx=$vctx; batch=$vbatch; loop=$vloop; break ;;
      esac
    done < "$PROFILES"
  fi
  case "$LLM_CTX" in ''|*[!0-9]*) ;; *) ctx=$LLM_CTX ;; esac
  case "$LLM_BATCH" in ''|*[!0-9]*) ;; *) batch=$LLM_BATCH ;; esac
  case "$LLM_AGENT" in ''|*[!0-9]*) ;; *) loop=$LLM_AGENT ;; esac
  [ "$batch" -gt "$ctx" ] && batch=$ctx
  [ "$loop" -gt 0 ] || loop=0
  CTX_SIZE=$ctx
  BATCH_SIZE=$batch
  AGENT_LOOP=$loop
  TOOL_CAPABLE=0
  [ "$loop" -gt 0 ] && TOOL_CAPABLE=1
  # v0.4.4: the guided router (hardwired A/B/C/D tool menu) is available to
  # every model - it does not depend on native tool-calling training.
  case "$LLM_ROUTER" in
    0) ROUTER_CAPABLE=0 ;;
    *) ROUTER_CAPABLE=1 ;;
  esac
  export CTX_SIZE BATCH_SIZE AGENT_LOOP TOOL_CAPABLE ROUTER_CAPABLE
}

# Spawn llama-server with the active model's profile (ctx/batch from
# model_profiles.conf). Caller checks the model file first.

spawn_server() {
  model_profile
  nohup llama-server --host 127.0.0.1 --port $LPORT -m "$m" \
    --ctx-size $CTX_SIZE --batch-size $BATCH_SIZE >/var/log/llama-server.log 2>&1 &
  echo running > "$STATE"
  sleep 1
  echo "llama-server starting on 127.0.0.1:$LPORT (OpenAI-compatible API)"
}

# Start the server if needed (model must be set and present).

ensure_server() {
  need_llama
  m=$(model)
  if [ -z "$m" ]; then
    echo "no model set - run 'llm model ~/models/<file>.gguf' first" >&2; exit 2; fi
  if [ ! -f "$m" ]; then echo "model file not found: $m" >&2; exit 2; fi
  if ! running; then
    spawn_server
  fi
}

# FB-104: terminal + system snapshot. The app writes the last ~40 terminal
# lines to $TCONTEXT on resume/resize (TerminalActivity); ask/agent inject
# this block so the model is aware of what the user is doing.

term_tail() {
  if [ -s "$TCONTEXT" ]; then
    tail -n 40 "$TCONTEXT" 2>/dev/null
  else
    echo "(no terminal context yet - open the terminal session)"
  fi
}

core_line() {
  if command -v core >/dev/null 2>&1; then
    out=$(core status 2>/dev/null | head -1)
    [ -n "$out" ] && echo "$out"
  fi
}

modules_line() {
  out=""
  for d in /etc/aetherix/modules.d/*/; do
    [ -d "$d" ] || continue
    nm=$(basename "$d")
    ver=$(grep -m1 '^version:' "$d/info" 2>/dev/null | cut -d: -f2 | tr -d ' ')
    [ -n "$ver" ] || ver="?"
    out="$out $nm($ver)"
  done
  [ -n "$out" ] || out=" none"
  echo "installed modules:$out"
}

jobs_line() {
  n=0
  for sf in /etc/aetherix/jobs/*.state; do
    [ -f "$sf" ] || continue
    id=$(sed -n 's/^id=//p' "$sf" | head -1)
    st=$(sed -n 's/^status=//p' "$sf" | head -1)
    pct=$(sed -n 's/^pct=//p' "$sf" | head -1)
    case "$pct" in ''|*[!0-9]*) pct=0;; esac
    if [ "$st" = "running" ]; then
      printf '  %s: running %s%%\n' "$id" "$pct"
      n=$((n+1))
    fi
  done
  [ "$n" -eq 0 ] && echo "  (no running jobs)"
}

storage_line() {
  if [ -s /etc/aetherix/storage.map ]; then
    sed 's/^/  /' /etc/aetherix/storage.map 2>/dev/null
  else
    echo "  (no storage map - run 'sd mount')"
  fi
}

ctx_block() {
  echo "=== terminal (last visible lines) ==="
  term_tail
  echo ""
  echo "=== environment ==="
  echo "pwd: $(pwd 2>/dev/null)"
  echo "tty size: $(stty size 2>/dev/null || echo unknown)"
  core_line
  modules_line
  jobs_line
  if running; then echo "llm server: running (model: $(model))"; else echo "llm server: stopped"; fi
  if tavily_key_ok; then echo "web search: tavily (key set)"; else echo "web search: tavily (no key)"; fi
  echo ""
  echo "=== user input dropbox (Aetherix-Alpine_INPUT) ==="
  echo "=== knowledge cards (small-world, /etc/aetherix/help/cards) ==="
  if [ -d "$HELP/cards" ]; then
    echo "  Tool-tip cards: start at 00 HOME and follow RELATED links (any answer within 6 hops)."
    echo "  Hubs: 06 SETUP, 11 TERMINAL, 15 STORAGE, 19 MODULES, 25 LLM, 38 APP, 43 TROUBLESHOOTING, 48 RESEARCH, 56 CAPABILITIES."
    echo "  Fetch a card via 'llm docs find <topic>' or the agent's file_read; DEEP: lines name the full docs."
  else
    echo "  (cards not deployed - reinstall help-module)"
  fi
  echo ""
  if [ -d "$INPUT_DIR" ]; then
    ls -1 "$INPUT_DIR" 2>/dev/null | head -20 | while read -r f; do
      [ -z "$f" ] && continue
      sz=$(wc -c < "$INPUT_DIR/$f" 2>/dev/null | tr -d ' ')
      case "$sz" in ''|*[!0-9]*) sz=0;; esac
      printf '  %s (%s bytes)\n' "$f" "$sz"
    done
  else
    echo "  (input dropbox not mounted - put files in Downloads/Aetherix-Alpine_INPUT)"
  fi
  echo ""
  echo "=== storage map ==="
  storage_line
}

# ---- help corpus (help-module) ----

json_val() { # $1 = key; reads a JSON object on stdin
  awk -v key="$1" '
    function val(s, k,   klen, i, n, p, c, v) {
      n = length(s); klen = length(k) + 3
      for (i = 1; i + klen - 1 <= n; i++) {
        if (substr(s, i, klen) == "\"" k "\":") break
      }
      if (i + klen - 1 > n) return ""
      p = i + klen
      while (p <= n && (substr(s, p, 1) == " " || substr(s, p, 1) == "\t")) p++
      if (p > n || substr(s, p, 1) != "\"") return ""
      p++; v = ""
      while (p <= n) {
        c = substr(s, p, 1)
        if (c == "\\") {
          p++
          if (p <= n) {
            c = substr(s, p, 1)
            if (c == "n") v = v " "; else v = v c
          }
          p++
          continue
        }
        if (c == "\"") break
        v = v c
        p++
      }
      return v
    }
    { print val($0, key); exit }
  '
}

# Parse an OpenAI chat.completions body for "tool_calls": emit for each call
#   ID:<id>
#   NAME:<function name>
#   ARGS:<unescaped arguments JSON>

llm_out() { # $1 = user text  $2 = plain assistant text
  save_reply "$1" "$2"
  if [ "$AETHERIX_DOCK" = "1" ]; then
    transcript you "$1"
    transcript llm "$2"
  else
    printf '%s\n' "$2"
  fi
}

plain_answer() { # $1 = question - direct completion with system persona + ctx
  q="$1"
  ctx=$(ctx_block)
  system="You are the Aetherix-Alpine assistant on an Android phone (Alpine Linux inside PRoot). Be concise and practical. The terminal context below is what the user is currently doing - answer with it in mind."
  escq=$(printf '%s' "$q" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escsys=$(printf '%s' "$system" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  esctx=$(printf '%s' "$ctx" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"$escsys\"},{\"role\":\"user\",\"content\":\"$escq\\n\\nTerminal context:\\n$esctx\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  llm_reply "$q" "$resp"
}

classify_question() { # $1 = question -> plain|help|docs|web|unknown
  q="$1"
  escq=$(printf '%s' "$q" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  cl=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"Classify the user request into exactly one category:\\n- web: needs current or external information the model cannot know\\n- help: asks how to use Aetherix-Alpine, its commands, modules, or app troubleshooting\\n- docs: asks about project versions, changelogs, bug history, or the bundled docs\\n- plain: casual chat, general knowledge, anything else\\nReply with the single word only.\"},{\"role\":\"user\",\"content\":\"$escq\"}],\"max_tokens\":12}")
  out=$(parse_reply "$cl" | tr -c 'a-zA-Z' ' ' | awk '{print $1}' | tr 'A-Z' 'a-z')
  case "$out" in
    web|help|docs|plain) echo "$out" ;;
    *) echo "unknown" ;;
  esac
}

router_ask() { # $1 = question
  q="$1"
  catg=$(classify_question "$q")
  case "$catg" in
    unknown)
      if tavily_key_ok; then catg=web; else catg=plain; fi
      ;;
  esac
  echo "ask: routing as $catg (use 'llm ask --plain' to force a direct answer)"
  case "$catg" in
    plain) plain_answer "$q" ;;
    help) answer_help "$q" ;;
    docs) answer_docs "$q" ;;
    web)
      if ! tavily_key_ok; then
        echo "ask: this needs web search but no Tavily key is set - direct answer instead:"
        plain_answer "$q"
      else
        web_answer "$q"
      fi
      ;;
  esac
}
