# Aetherix-Alpine LLM tier - web capability library (sourced). Tavily
# pipeline: search -> Vane-style cited synthesis. No SearXNG dependency.

tavily_extract() { # stdin: Tavily JSON -> "[n] title\n    url\n    content\n"
  awk '
    function val(s, key,   klen, i, n, p, c, v) {
      n = length(s)
      klen = length(key) + 3
      for (i = 1; i + klen - 1 <= n; i++) {
        if (substr(s, i, klen) == "\"" key "\":") break
      }
      if (i + klen - 1 > n) return ""
      p = i + klen
      while (p <= n && (substr(s, p, 1) == " " || substr(s, p, 1) == "\t")) p++
      if (p > n || substr(s, p, 1) != "\"") return ""
      p++
      v = ""
      while (p <= n) {
        c = substr(s, p, 1)
        if (c == "\\") {
          p++
          if (p <= n) {
            c = substr(s, p, 1)
            if (c == "n") v = v " "; else v = v c
          }
          p++
          continue
        }
        if (c == "\"") break
        v = v c
        p++
      }
      return v
    }
    BEGIN { RS = "" }
    {
      line = $0
      p = index(line, "\"results\":[")
      if (p == 0) exit 0
      rest = substr(line, p + 11)
      n = length(rest)
      seg = ""; inside = 0; esc = 0; count = 0
      for (i = 1; i <= n; i++) {
        c = substr(rest, i, 1)
        if (inside) {
          if (esc) esc = 0
          else if (c == "\\") esc = 1
          else if (c == "\"") inside = 0
          seg = seg c
          continue
        }
        if (c == "\"") { inside = 1; seg = seg c; continue }
        if (c == "}") {
          seg = seg c
          nx = substr(rest, i + 1, 1)
          if (nx == "," || nx == "]") {
            count++
            t = val(seg, "title"); u = val(seg, "url"); co = val(seg, "content")
            printf "[%d] %s\n    %s\n    %s\n", count, t, u, co
            seg = ""
            if (nx == "]") exit 0
            i++
          }
          continue
        }
        if (c == "]") exit 0
        seg = seg c
      }
    }
  '
}

# FB-081: append one speaker line to the docked transcript and cap the file
# at the last 200 lines so it can never grow unbounded.

tavily_key_ok() { [ -s /etc/aetherix/tavily.key ]; }

# Shared Tavily search: writes the JSON body to $3 and echoes the HTTP code.

tavily_search() { # $1 = query  $2 = max results  $3 = output file
  escq=$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  curl -s -o "$3" -w '%{http_code}' --max-time 30 -X POST \
    https://api.tavily.com/search \
    -H "Authorization: Bearer $(cat /etc/aetherix/tavily.key 2>/dev/null)" \
    -H 'Content-Type: application/json' \
    -d "{\"query\":\"$escq\",\"search_depth\":\"basic\",\"max_results\":${2:-5}}"
}

# FB-103: per-model profiles drive llama-server ctx/batch and the agent tool
# loop. The active model's file name is matched (case-insensitive, first-match
# glob) against /etc/aetherix/model-profiles.conf; LLM_CTX / LLM_BATCH /
# LLM_AGENT env overrides always win (pi-agent lesson: fit context/batch to
# the model, user override wins).

web_answer() { # $1 = question; Tavily key required (router checks first)
  q="$1"
  ensure_server
  ctx=$(ctx_block)
  escq=$(printf '%s' "$q" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  escctx=$(printf '%s' "$ctx" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  qr=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"You generate web search queries. Write 1-2 short web search queries that best answer the question. One query per line, nothing else.\"},{\"role\":\"user\",\"content\":\"Question: $escq\\n\\nTerminal context:\\n$escctx\"}],\"max_tokens\":80}")
  queries=$(parse_reply "$qr" | sed 's/".*//' | grep -v '^[[:space:]]*$' | head -2)
  if [ -z "$queries" ]; then queries="$q"; fi
  printf '%s\n' "$queries" | sed '/^[[:space:]]*$/d' | head -2 > /tmp/tavily-queries.txt
  : > /tmp/tavily-merged.txt
  i=0
  while IFS= read -r qq; do
    [ -z "$qq" ] && continue
    i=$((i+1))
    echo "web: searching Tavily: $qq"
    code=$(tavily_search "$qq" 4 "/tmp/tavily-web-$i.json")
    if [ "$code" = "200" ]; then
      tavily_extract < "/tmp/tavily-web-$i.json" >> /tmp/tavily-merged.txt
    else
      echo "web: search $i failed (HTTP $code) - see llm web --test"
    fi
  done < /tmp/tavily-queries.txt
  rm -f /tmp/tavily-queries.txt /tmp/tavily-web-*.json
  results=$(awk '/^\[[0-9]+\]/{n++; sub(/^\[[0-9]+\]/, "[" n "]")} {print}' /tmp/tavily-merged.txt)
  rm -f /tmp/tavily-merged.txt
  if [ -z "$results" ]; then
    echo "web: no results found - nothing to synthesize"
    return 0
  fi
  nres=$(printf '%s\n' "$results" | grep -c '^\[')
  echo "web: $nres results - synthesizing..."
  prompt="Search results:
$results

Question: $q

Answer the question using ONLY the search results above. Cite each source as [n] next to the claim it supports. If the results do not contain the answer, say so."
  escprompt=$(printf '%s' "$prompt" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
  resp=$(curl -s http://127.0.0.1:$LPORT/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"system\",\"content\":\"You are the Aetherix assistant. Answer concisely in a few sentences using only the provided search results; cite [n].\"},{\"role\":\"user\",\"content\":\"$escprompt\"}],\"max_tokens\":$LLM_MAX_TOKENS}")
  llm_reply "$q" "$resp"
}
