# llm-module on-device test plan

Install via Modules & Storage. Run `llm-selftest` inside the terminal after
`llm setup` and setting a model.

1. **L1 — Install** — Modules & Storage shows `llm-module` (bundled, v1.0.0);
   Install succeeds; `/etc/aetherix/llm-module.installed` exists.
2. **L2 — CLI present** — `command -v llm` resolves; `llm status` prints
   `state: stopped` before first run.
3. **L3 — Setup** — `llm setup` installs llama.cpp + curl (large download,
   needs internet); `llama-server --version` works; `~/models/` exists.
4. **L4 — Model** — `llm model ~/models/<file>.gguf` persists to
   `/etc/aetherix/llm.conf`; `llm status` shows the model path.
5. **L5 — Start/ask/stop** — with a light `.gguf` in `~/models/` (e.g.
   `Qwen3.5-0.8B-IQ4_XS.gguf` or `SmolLM2-360M-IQ4_XS.gguf`):
   `llm start` -> `curl http://127.0.0.1:8080/v1/models` responds;
   `llm ask "hello"` returns a completion; `llm stop` cleans up.
6. **L6 — Selftest** — `llm-selftest` exits 0 with all checks passed.
