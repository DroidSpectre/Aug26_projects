#!/bin/sh
# llm-module self-test — full functionality check (run inside the terminal).
FAIL=0
pass() { echo "PASS  $1"; }
fail() { echo "FAIL  $1"; FAIL=$((FAIL+1)); }

echo "== llm-module self-test =="
command -v llm >/dev/null 2>&1 && pass "llm CLI installed" || fail "llm CLI missing"
llm status >/dev/null 2>&1 && pass "llm status runs" || fail "llm status failed"
command -v llama-server >/dev/null 2>&1 && pass "llama.cpp installed" || fail "llama.cpp missing (run 'llm setup' with internet)"
command -v curl >/dev/null 2>&1 && pass "curl installed" || fail "curl missing"

MODEL=$(grep -m1 '^model=' /etc/aetherix/llm.conf 2>/dev/null | cut -d= -f2)
if [ -n "$MODEL" ]; then
  [ -f "$MODEL" ] && pass "model file exists: $MODEL" || fail "model file not found: $MODEL"
  llm start >/dev/null 2>&1
  sleep 3
  curl -s http://127.0.0.1:8080/v1/models >/dev/null 2>&1 && pass "server responding on 127.0.0.1:8080" || fail "server not responding"
  llm ask "Reply with OK" >/dev/null 2>&1 && pass "llm ask returns a completion" || fail "llm ask failed"
  llm stop >/dev/null 2>&1
  sleep 1
  pgrep -f llama-server >/dev/null 2>&1 && fail "llama-server still running after stop" || pass "llm stop clean"
else
  echo "NOTE: no model set - set one with 'llm model ~/models/<file>.gguf' to test start/ask"
fi

echo ""
if [ "$FAIL" -eq 0 ]; then echo "ALL CHECKS PASSED"; exit 0; fi
echo "$FAIL CHECK(S) FAILED"; exit 1
