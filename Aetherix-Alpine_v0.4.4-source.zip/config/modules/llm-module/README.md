# llm-module — local LLM (llama.cpp) as an installable module

Ships inside the APK as `assets/modules/llm-module.bundle` (gzip tar).
Regenerate all bundles with `scripts/build-modules.sh`.

Adds the `llm` tier CLI: llama.cpp server on `127.0.0.1:8080`
(OpenAI-compatible API, loopback only).

## Requires
- **core-module** — install it first (Modules & Storage page). This module is
  **Blocked** until core-module is installed. core-module provides the build
  toolchain (including `linux-headers`, which llama.cpp needs to compile).

## Install & use (inside the terminal)
- Modules & Storage -> Install `llm-module` (deploys `/usr/local/bin/llm`)
- `llm setup` — clones llama.cpp and starts an **adaptive, detached** build
  (10-30 min; survives screen-off; probes this device's CPU features; jobs scale
  with RAM/cores, override with `LLM_JOBS=<n>`). Watch with `llm build-log`,
  then rerun `llm setup` when it completes.
- drop a `.gguf` in `~/models/` — recommended light models:
  `Qwen3.5-0.8B-IQ4_XS.gguf` or `SmolLM2-360M-IQ4_XS.gguf`
- `llm model ~/models/<file>.gguf` — select the model
- `llm start` — server on 127.0.0.1:8080
- `llm ask "hello"` — chat completion
- `llm stop`, `llm status`
- `llm-selftest` — full functionality check (exit 0 = pass)

## Uninstall
Modules & Storage -> Uninstall. Removes bookkeeping; the `llm` script stays in
`/usr/local/bin` (remove with `rm /usr/local/bin/llm`).
