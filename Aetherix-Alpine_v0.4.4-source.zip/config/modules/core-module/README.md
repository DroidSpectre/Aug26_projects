# core-module — shared base + build toolchain (dependency module)

Ships inside the APK as `assets/modules/core-module.bundle` (gzip tar).
Regenerate all bundles with `scripts/build-modules.sh`.

Every other bundled module (`hello-module`, `llm-module`) declares
`requires: core-module` and is **not installable** until core-module is
installed. core-module's post-install installs the shared dependency set via
Alpine:

- **Base:** `bash coreutils ncurses-terminfo ca-certificates-bundle`
- **Toolchain (llm):** `build-base cmake git curl linux-headers openssl-dev ccache ninja`
- **Optional:** `libomp` (best effort — OpenMP runtime)

`linux-headers` is required — llama.cpp fails to build without it
(`linux/limits.h: No such file or directory`).

## Install & use
- Dashboard > Modules & Storage -> Install `core-module` (first module to install)
- `core status` — verify base + toolchain
- `core setup` — reinstall the package set if it was removed
- `core help` — what this module provides

## Uninstall
Uninstall is refused while hello/llm modules are installed. Uninstall those
first, then core-module (Full Erase also removes the `core` CLI).
