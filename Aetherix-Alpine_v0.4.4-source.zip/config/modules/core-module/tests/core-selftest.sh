#!/bin/sh
# core-module self-test - check the shared base + toolchain (run in terminal).
FAIL=0
pass() { echo "PASS  $1"; }
fail() { echo "FAIL  $1"; FAIL=$((FAIL+1)); }

echo "== core-module self-test =="
[ -f /etc/aetherix/core-module.installed ] && pass "core-module marker" || fail "core-module marker missing"
for c in bash coreutils cmake git curl gcc ccache ninja; do
  command -v "$c" >/dev/null 2>&1 && pass "$c present" || fail "$c missing"
done
[ -f /usr/include/linux/limits.h ] && pass "linux-headers (linux/limits.h)" || fail "linux-headers missing"
[ -r /etc/ssl/cert.pem ] && pass "TLS CA cert (/etc/ssl/cert.pem)" || fail "TLS CA cert missing"
grep -q OpenSSL /usr/include/openssl/opensslv.h 2>/dev/null && pass "openssl-dev headers" || fail "openssl-dev headers missing"
command -v libomp >/dev/null 2>&1; apk info -e libomp >/dev/null 2>&1 && pass "libomp (optional)" || echo "NOTE: libomp optional not installed (fine)"
command -v core >/dev/null 2>&1 && pass "core CLI" || fail "core CLI missing"
core status >/dev/null 2>&1 && pass "core status runs" || fail "core status failed"

echo ""
if [ "$FAIL" -eq 0 ]; then echo "ALL CHECKS PASSED"; exit 0; fi
echo "$FAIL CHECK(S) FAILED"; exit 1
