#!/bin/sh
# core-module post-install - install the shared base + build toolchain that
# every other module depends on (hello/llm). Idempotent; safe to rerun.
MODULE_DIR=$(dirname "$0")
mkdir -p /etc/aetherix /etc/ssl/certs

# Hard dependencies: base runtime + the toolchain llm needs to build llama.cpp
# (linux-headers is required - the build fails without it), plus openssl-dev for
# HTTPS in llama-server and ccache/ninja to keep rebuilds fast.
PKGS="bash coreutils ncurses-terminfo ca-certificates-bundle build-base cmake clang git curl linux-headers openssl-dev ccache ninja"
echo "installing core packages (needs internet, ~1-2 min)..."
apk add $PKGS || {
  echo "ERROR: apk add core packages failed (check internet/repo; retry 'module install core-module' or 'core setup')" >&2
  exit 1
}

# Optional dependencies - best effort; a failure here must not block the module.
echo "installing optional packages (best-effort): libomp..."
if apk add libomp >/dev/null 2>&1; then
  echo "  optional libomp OK"
else
  echo "  optional libomp skipped (OpenMP not available)"
fi

# FB-043: git/curl default their CA file to /etc/ssl/cert.pem; make it point at
# the installed bundle so TLS works even if SSL_CERT_FILE is not honored.
ln -sfn /etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem

# Deploy the core tier CLI (status/help) alongside the other module tiers.
mkdir -p /usr/local/bin
for f in "$MODULE_DIR"/tier/*; do
  [ -f "$f" ] || continue
  cp -f "$f" "/usr/local/bin/$(basename "$f")"
  chmod +x "/usr/local/bin/$(basename "$f")"
done

echo "installed $(date -u +%Y-%m-%dT%H:%M:%SZ)" > /etc/aetherix/core-module.installed
GCCV=$(gcc --version 2>/dev/null | head -1 | awk '{print $3}')
CMV=$(cmake --version 2>/dev/null | head -1 | awk '{print $3}')
CLV=$(clang --version 2>/dev/null | head -1 | awk '{print $3}')
echo "core-module OK: base + toolchain ready (gcc $GCCV, clang $CLV, cmake $CMV)"
