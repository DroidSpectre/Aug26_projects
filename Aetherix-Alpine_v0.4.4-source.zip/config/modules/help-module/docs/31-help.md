# Help system (help-module)

'help-module' ships a curated corpus to /etc/aetherix/help/ that the llm uses
to answer help questions with citations - no more hunting through individual
help commands.

## Commands
- llm docs find <terms>   top 5 matching corpus docs + matched lines
- llm docs add <dir>      copy your .md/.txt files into
                          /etc/aetherix/help/user/<name>/ (searchable at once)
- llm ask-help <question> Help-Assistant chat - answers from the corpus,
                          cites source file names; interactive mode exits
                          with Exit (or Ctrl-D)

## Auto-routing
'llm ask' classifies each question as plain/help/docs/web. help/docs answers
pull the top corpus snippets (capped ~6KB) into the prompt together with the
terminal context snapshot; web answers run Tavily searches (1-2 generated
queries) and synthesize with numbered citations [n].

## Context awareness
The app writes the last ~40 terminal lines to /etc/aetherix/term.context on
resume/resize; 'llm context' shows it plus pwd, tty size, core/mods/jobs
state, storage map, and server state. ask/agent inject this so replies fit
what the user is actually doing.
