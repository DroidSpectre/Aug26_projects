# Package inventory

What gets installed, and where in the process.

## App-bundled (APK assets / native libs - no apk)
- alpine-minirootfs.tar: bootstrap Alpine 3.19 rootfs (Step 2)
- proot-arm64 / libproot.so: PRoot user-mode sandbox (Step 3)
- libpty-bridge.so: fork/PTY/exec bridge proof (Step 6)
- libpty-jni.so: TIOCSWINSZ ioctl shim
- libfaketty.so: isatty shim (LD_PRELOAD)
- libandroid-shmem.so, libtalloc.so.2, ca-certificates.crt

## Step 5 init (StepRunner.java)
apk update/upgrade, ca-certificates-bundle, bash coreutils ncurses-terminfo,
alpine-base alpine-conf openrc tzdata util-linux shadow procps nano htop
bash-completion openssh iproute2

## core-module (post-install)
Re-asserts the Step-5 base + adds build-base cmake git curl linux-headers
openssl-dev ccache ninja (+ optional libomp best-effort)

## llm-module fallback
If core-module is missing, 'llm setup' installs the same toolchain itself.

## hello-module / help-module
No packages - pure shell scripts + the docs corpus.
