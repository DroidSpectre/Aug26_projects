# Bug register (condensed)

Full per-fix history lives in docs/BUGS.md (FB-000..FB-114) and the
per-version docs. Highlights by theme:

## Terminal / PTY
FB-007 graceful exit (143 treated clean), FB-036/FB-052 first-digit warmup,
FB-038 clear scrollback, FB-042 toolbar spacing, FB-081 docked replies,
FB-086 dock 5/10 lines, FB-098 sparkles reply key, FB-109 sparkles opens the
reply window instead of typing the emoji.

## Setup / storage
FB-021 apk db path, FB-023 evidence-gated readiness, FB-024 real factory
reset, FB-026 device.conf mkdirs, FB-047 bin/sh heal, FB-054 symlink races,
FB-089 numbered permission popups, FB-090 Samsung battery path, FB-091
install-only dashboard, FB-092 reset at bottom, FB-093 log toggle label.

## Modules
FB-009 bundled assets, FB-011 bundle version peek, FB-094 module cards,
FB-095 APK-only module source, FB-096 module version bumps, FB-097 banner
gating, FB-048 no drop-folder downgrades.

## I/O dropbox
FB-112 unified INPUT/OUTPUT folders created/maintained by the app across
volumes, ~/storage/input|output symlinks, io helper (env/in/out/clean),
INPUT files injected into llm context.

## LLM / builds
FB-030 build from source, FB-032 /dev/urandom + clone retries, FB-053 wake
lock, FB-079 parse replies, FB-080 version banner, FB-083 512-token default,
FB-084 no-progress bars + dock, FB-087 PRoot-safe -march, FB-088 detached
jobs + 5-job dock, FB-102 Tavily web tier, FB-103..FB-108 v0.4.2 model
profiles / context / router / agent / help corpus, FB-110 detached hf
downloads, FB-111 clang Release build speed, FB-113 llm export/replies/
chat-log + auto-opening dock, FB-114 build-status thermal/cgroup readout.

## Open / environmental
ENV-001 Samsung kernel blocks TIOCSWINSZ/TIOCSIG (userspace bypass in place)
ENV-002 /proc/stat denied for untrusted_app (no fix)
