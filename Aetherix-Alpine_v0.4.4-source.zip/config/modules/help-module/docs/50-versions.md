# Version history (condensed)

## v0.3a series (0-14)
Established the fork: side-by-side app id (com.aetherix.alpine.a), 7-step
setup hardening, storage tier, module system, terminal PTY stability
(exit/back handling, resize debounce), hardware card, battery/permission
flows, llama.cpp tier, docked reply window + chat, archived gui-module,
detached job runner, numbered permissions, install-only dashboard, per-module
cards, APK-only modules with own versions.

## v0.4.0 (core-stable)
v0.3a.14_14 renamed v0.4.0. Core (app + Alpine + terminal) frozen as the
base; modules become the update vehicle. Per-version source snapshots +
academic reports in docs/v0.4.x. PRoot-safe CPU probe fixed llama.cpp builds.

## v0.4.1
Tavily web search: Dashboard Tavily Key entry (keystore-encrypted), guest key
sync, llm web/status/--test, dashboard spacing fixes.

## v0.4.2
Model-aware llm: per-model profiles (ctx/batch/agent), terminal context
snapshot (llm context), auto-router llm ask (plain/help/docs/web), llm agent
tool loop, help-module corpus + llm docs find/add + llm ask-help, reply-dock
sparkles key already shipped in 0.4.1. Bug IDs for this release: FB-103..FB-108.

## v0.4.3
Sparkles key fix (opens the reply window instead of typing the emoji),
detached model downloads (job dock), clang + Release build with
jobs=min(cores,4) (Termux-parity speed), unified INPUT/OUTPUT dropbox +
io helper, llm export/replies/chat-log + auto-opening reply dock,
build-status thermal/cgroup readout. Bug IDs: FB-109..FB-114.

## Versioning scheme
- App: v0.4.<p> -> versionCode 40000 + p
- Modules: own versions, bumped per content change (core 1.2.0, hello 1.2.0,
  llm 1.5.0, help 1.2.0)
- Each released app version gets its own folder in the device download tree:
  APK + source snapshot + docs
