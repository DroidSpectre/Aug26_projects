# CARD 21 · CORE-MODULE — The shared base + toolchain
TAG: modules
WHAT: Installs the packages every other module depends on (shell, TLS, build tools).
WHY: The AI build needs a full toolchain; core provides it once, cleanly.
KEYS:
- Packages: bash, coreutils, ncurses-terminfo, ca-certificates-bundle, build-base, cmake, clang, git, curl, linux-headers, openssl-dev, ccache, ninja (+ best-effort libomp).
- linux-headers is required for the llama.cpp build (linux/limits.h).
- clang (v1.2.0+) gives Termux-parity AI build speed (see 27 LLM-SETUP).
- Installs /etc/ssl/cert.pem symlink so git/curl TLS works.
- Post-install is idempotent and re-run safe.
USE:
- core status → prints toolchain versions (gcc, clang, cmake).
RELATED: 19 MODULES, 20 MODULE-SYSTEM, 27 LLM-SETUP, 43 TROUBLESHOOTING, 53 PACKAGE-INVENTORY
DEEP: docs/v0.3-series/package-inventory.md §C


