# CARD 37 · MODEL-PROFILES — Per-model tuning
TAG: llm
WHAT: Automatic settings (context size, batch, agent rounds) per model, from /etc/aetherix/model-profiles.conf.
WHY: One size doesn't fit all: tiny models need small windows; bigger models unlock the agent.
KEYS:
- File: /etc/aetherix/model-profiles.conf; first-match glob on the .gguf name; '*' = default.
- Fields: ctx, batch, agent rounds. Example: *1b* 2048 512 0 ; *3b* 4096 1024 4.
- Overrides: LLM_CTX=<n>, LLM_BATCH=<n>, LLM_AGENT=<0|n> win over the file.
- Tool-capable models (2B+) unlock llm agent; smaller models use the auto-router.
- llm status prints the active profile so you can see what applies.
USE:
- LLM_CTX=4096 llm start → force a bigger window for one session.
RELATED: 25 LLM, 28 LLM-MODELS, 32 LLM-AGENT, 26 LLM-OVERVIEW
DEEP: docs/v0.4.2/README.md (FB-103)


