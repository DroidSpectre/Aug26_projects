# CARD 17 · IO-DROPBOX — The INPUT/OUTPUT dropbox
TAG: storage
WHAT: Two app-owned folders in Downloads that make file exchange with the AI trivial and device-agnostic.
WHY: Users can hand the AI files (INPUT) and collect reports (OUTPUT) without learning Linux paths.
KEYS:
- Download/Aetherix-Alpine_INPUT = user dropbox; files here are listed in llm context.
- Download/Aetherix-Alpine_OUTPUT = exports: AI replies, build logs, reports.
- io helper: io env | io in [path] | io out <src> [name] | io clean (30-day prune).
- ~/storage/input and ~/storage/output are symlinks to the same folders.
- Launcher exports AETHERIX_INPUT_DIR / AETHERIX_OUTPUT_DIR for shells.
USE:
- "review INPUT/code.py for bugs" → llm ask; then llm export → report in OUTPUT.
RELATED: 15 STORAGE, 16 STORAGE-TIER, 35 LLM-REPLIES, 36 LLM-BUILD, 29 LLM-ASK
DEEP: docs/v0.4.3/README.md, docs/BUGS.md (FB-114)


