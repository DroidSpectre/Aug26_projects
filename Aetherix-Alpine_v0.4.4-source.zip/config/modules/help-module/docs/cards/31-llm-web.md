# CARD 31 · LLM-WEB — Web search with citations
TAG: llm
WHAT: Answers questions using live web search (Tavily) with numbered citations.
WHY: The small local model doesn't know current facts; web grounding fixes that.
KEYS:
- Requires a Tavily API key: Dashboard → Tavily Key (stored encrypted in Android Keystore; synced to /etc/aetherix/tavily.key, 0600).
- llm web <q> → 1–2 generated queries → cited synthesis (renumbered citations).
- llm web status → key state; llm web --test → live check (HTTP 200).
- No key → llm web explains how to add one; router falls back to plain.
CAUTION:
- If Tavily returns 401/403, the saved key was rejected — re-add it.
RELATED: 25 LLM, 29 LLM-ASK, 39 DASHBOARD, 44 TROUBLE-LLM
DEEP: docs/v0.4.1/ANALYSIS.md §8, docs/v0.4.1/README.md


