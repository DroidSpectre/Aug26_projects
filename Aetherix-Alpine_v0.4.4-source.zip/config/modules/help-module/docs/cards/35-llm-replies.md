# CARD 35 · LLM-REPLIES — Saving and exporting answers
TAG: llm
WHAT: Every reply is saved to disk; you can print, re-open, or export answers from the terminal.
WHY: Answers shouldn't vanish when the dock closes.
KEYS:
- Saved: /etc/aetherix/responses/<timestamp>.md (keeps newest 50).
- llm replies [n] → print the last n replies inline.
- llm chat-log [n] → show the last n chat turns (transcript at /etc/aetherix/llm-chat.log, capped 200 lines).
- llm export [path] → copy a reply (or any file) into the OUTPUT dropbox with a timestamped name.
- The dock auto-opens after a reply via /etc/aetherix/dock.request (app polls + clears it).
USE:
- llm ask "review INPUT/x" → llm export → report in Downloads/Aetherix-Alpine_OUTPUT.
RELATED: 25 LLM, 17 IO-DROPBOX, 14 DOCK, 29 LLM-ASK
DEEP: docs/v0.4.3/README.md (FB-113)


