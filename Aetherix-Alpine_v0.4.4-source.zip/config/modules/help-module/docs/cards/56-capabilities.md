# CARD 56 · CAPABILITIES — What the on-device AI can and cannot do
TAG: hub
WHAT: Honest can/cannot manifest for the local LLM tier; `llm capabilities` prints the same list on-device.
WHY: Knowing the boundaries prevents wasted prompts — no shell access, no vision, no keyless web.
KEYS:
- CAN: local chat/ask (135M-10B GGUF), Tavily web answers (key from Dashboard), native agent loop on capable models, guided router for small models, RAG docs find/add + ask-help, replies + OUTPUT export, read-only file access (help corpus, home, ~/storage, INPUT).
- CANNOT: run shell commands, write to the prompt/scrollback, live terminal reads (only a ~40-line snapshot), keyless web search (SearXNG deferred), vision/multimodal, cloud sync.
- Small models: hardwired A/B/C/D tool menu, <=6 hops (small-world) — no tool-calling training needed; LLM_ROUTER=0 disables.
- Build readout: llm build-status shows compiler, OpenMP, -march (+fp16) and cmake probe results.
USE:
- "Can it read my file / search the web / run this command?" — read KEYS, then 32 LLM-AGENT or 17 IO-DROPBOX.
- "Why is it slow?" — check build-status first (FP16/OpenMP on?), 36 LLM-BUILD.
RELATED: 25 LLM, 32 LLM-AGENT, 29 LLM-ASK, 33 LLM-CONTEXT, 37 MODEL-PROFILES, 36 LLM-BUILD, 17 IO-DROPBOX
DEEP: docs/v0.4.4/README.md (Q6/Q8), docs/v0.4.4/RESEARCH.md (small-model router)
