# CARD 32 · LLM-AGENT — Tool-using task loop
TAG: llm
WHAT: Gives capable models read-only tools: web_search, help_lookup, file_read, done.
WHY: Multi-step tasks (research, analyze a file, check the docs) need tools, not one-shot answers.
KEYS:
- Command: llm agent <task>; loop ends when the model calls done.
- Tools: web_search (Tavily), help_lookup (corpus), file_read (guest files, incl. INPUT dropbox), done.
- Rounds are gated by the model profile: 2B+ models unlock the NATIVE tool loop; smaller models fall back to the guided router (56 CAPABILITIES) — a hardwired A/B/C/D menu, <=6 hops, no tool-calling training needed (LLM_ROUTER=0 disables).
- JSON tool_calls with a tool:-line fallback; BusyBox-safe parsing.
- Read-only by design — the agent cannot modify your system.
USE:
- llm agent "check the docs for llm setup, then summarize the terminal"
RELATED: 25 LLM, 37 MODEL-PROFILES, 29 LLM-ASK, 34 LLM-DOCS, 17 IO-DROPBOX
DEEP: docs/v0.4.2/README.md (FB-106)


