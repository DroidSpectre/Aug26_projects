# CARD 25 · LLM — LLM/AI cluster hub
TAG: hub
WHAT: Hub for the private, on-device AI: setup, models, asking, chat, web, agent, docs, export.
WHY: Most interesting questions about "the AI" resolve inside this cluster.
KEYS:
- Local llama.cpp server; loopback only; CPU-only; replies in the dock.
- Lifecycle: 27 LLM-SETUP → 28 LLM-MODELS → start → ask/chat.
- Modes: 29 LLM-ASK (auto-router), 30 LLM-CHAT, 31 LLM-WEB (Tavily), 32 LLM-AGENT (tools).
- Awareness: 33 LLM-CONTEXT; built-in docs: 34 LLM-DOCS; export: 35 LLM-REPLIES.
- Build/logs: 36 LLM-BUILD; per-model tuning: 37 MODEL-PROFILES.
USE:
- "How do I make it answer better?" → 37 MODEL-PROFILES + 33 LLM-CONTEXT.
- "It's slow / broken" → 36 LLM-BUILD + 44 TROUBLE-LLM.
RELATED: 00 HOME, 23 LLM-MODULE, 26 LLM-OVERVIEW, 29 LLM-ASK, 44 TROUBLE-LLM
DEEP: docs/v0.4.2/README.md, docs/v0.4.3/README.md


