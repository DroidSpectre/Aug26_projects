# CARD 23 · LLM-MODULE — The local AI feature pack
TAG: modules
WHAT: Installs/registers the llama.cpp AI tier (server, models, chat, tools).
WHY: It is the app's flagship feature: private, on-device AI.
KEYS:
- Version 1.5.0 (v0.4.3): detached model downloads, clang/Release build, INPUT/OUTPUT dropbox, export/replies.
- Provides: llm setup/start/stop/status, chat, ask, web, agent, context, docs, hf, replies/export.
- Server: llama-server, OpenAI-compatible API, loopback only (127.0.0.1:8080).
- CPU-only by design; models live in ~/models/.
- Requires core-module (toolchain) installed first.
USE:
- Everything AI: go to the 25 LLM hub.
RELATED: 19 MODULES, 25 LLM, 21 CORE-MODULE, 27 LLM-SETUP, 26 LLM-OVERVIEW, 53 PACKAGE-INVENTORY
DEEP: docs/v0.3-series/package-inventory.md §D


