# CARD 30 · LLM-CHAT — Multi-turn conversation
TAG: llm
WHAT: An interactive back-and-forth chat with the model (history included).
WHY: Follow-up questions need the model to remember earlier turns.
KEYS:
- Command: llm chat; exit with the word Exit or Ctrl-D (Exit-only convention).
- Keeps the last ~10 turns of history; replies go to the same docked transcript.
- Whitespace/empty lines are trimmed before send.
- Same model/profile rules as ask; 512-token reply cap applies.
USE:
- llm chat → type messages → Exit to end.
RELATED: 25 LLM, 29 LLM-ASK, 14 DOCK, 35 LLM-REPLIES
DEEP: docs/BUGS.md (FB-082, FB-085, FB-101)


