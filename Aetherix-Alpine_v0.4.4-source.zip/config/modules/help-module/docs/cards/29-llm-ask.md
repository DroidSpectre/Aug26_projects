# CARD 29 · LLM-ASK — Ask questions (auto-router)
TAG: llm
WHAT: llm ask <q> answers a question, automatically choosing the best style: plain / help / docs / web.
WHY: One command handles most needs; the router picks the source of truth.
KEYS:
- Routing: plain (direct completion) | help (corpus) | docs (search) | web (Tavily, if key set).
- Unknown intent → web if a Tavily key exists, else plain.
- llm ask --plain forces a direct completion (no router).
- Prompts include terminal/system context (33 LLM-CONTEXT) + INPUT dropbox file list.
- Answers render in the dock and are saved to disk (35 LLM-REPLIES).
USE:
- llm ask "review INPUT/code.py for bugs"  /  llm ask --plain "summarize: <text>"
RELATED: 25 LLM, 34 LLM-DOCS, 31 LLM-WEB, 33 LLM-CONTEXT, 35 LLM-REPLIES
DEEP: docs/v0.4.2/README.md (FB-105)


