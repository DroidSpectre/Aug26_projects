# CARD 33 · LLM-CONTEXT — Terminal + system awareness
TAG: llm
WHAT: A snapshot of your terminal and system that is injected into AI prompts.
WHY: Context is what lets the AI answer "what have I got installed?" instead of guessing.
KEYS:
- llm context prints: terminal tail (last ~40 lines), pwd, tty size, core/module/job state, storage map, server + key status.
- The app writes /etc/aetherix/term.context on resume/settle; ctx_block() injects it into plain/help/docs/web prompts.
- INPUT dropbox files are listed with sizes so the AI knows what it can read.
USE:
- Run llm context to see exactly what the model can see.
RELATED: 25 LLM, 29 LLM-ASK, 17 IO-DROPBOX, 12 TERMINAL-BASICS
DEEP: docs/v0.4.2/README.md (FB-104)


