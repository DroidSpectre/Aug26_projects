# CARD 00 · HOME — Aetherix-Alpine knowledge map
TAG: hub
WHAT: Entry card for every topic about Aetherix-Alpine, an app that turns a locked Samsung phone into a Linux computer with a private on-device AI.
WHY: Always start here. Every question is answerable by following RELATED links; you should reach the answer in six hops or fewer.
KEYS:
- The app runs a real Linux system (Alpine) + a local AI chatbot on a NON-rooted Samsung.
- No root, no jailbreak. Works on Knox-locked phones where Termux cannot.
- Current release: v0.4.4 (versionCode 40004). Core frozen at v0.4.0; features ship via modules.
- Eight clusters: overview, setup, terminal, storage, modules, llm, app/dashboard, troubleshooting, research.
- Model rule: ground answers in cards — follow RELATED, do not improvise specifics.
USE:
- "What/why/how" questions: 01 WHAT-IS → 03 HOW-IT-WORKS.
- Commands: jump to a hub — 11 TERMINAL, 15 STORAGE, 19 MODULES, 25 LLM.
- Problems: 43 TROUBLESHOOTING.
CAUTION:
- Cards are summaries; cite 50 VERSIONING / 51 BUG-REGISTER for exact IDs.
RELATED: 01 WHAT-IS, 03 HOW-IT-WORKS, 06 SETUP, 25 LLM, 43 TROUBLESHOOTING
DEEP: docs/BUGS.md, docs/v0.3-series/CHANGELOG.md


