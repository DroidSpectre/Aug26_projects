# CARD 27 · LLM-SETUP — Building the AI server
TAG: llm
WHAT: Compiles llama-server from source inside Alpine (no package exists for it).
WHY: This is the long step users ask about; it runs detached with progress.
KEYS:
- Command: llm setup (or build-restart to resume a stale build; build-status to check).
- v0.4.3 uses clang + -DCMAKE_BUILD_TYPE=Release → Termux-parity speed (~2x vs gcc).
- jobs = min(cores, 4); drops to 2 only below 3 GiB RAM; LLM_JOBS overrides.
- PRoot-safe CPU probe: derives -march from /proc/cpuinfo (GGML_NATIVE=OFF).
- Build runs DETACHED (survives screen-off); ccache + ninja resume quickly.
- Needs core-module toolchain (clang, cmake, ninja, ccache, linux-headers, openssl-dev).
USE:
- llm setup → wait for the dock job → llm build-status → llm start.
CAUTION:
- Do not let the phone overheat; watch thermal zones in build-status.
RELATED: 25 LLM, 21 CORE-MODULE, 36 LLM-BUILD, 18 JOBS, 44 TROUBLE-LLM
DEEP: docs/BUGS.md (FB-087), docs/v0.4.0/REPORT.md §2, docs/v0.4.3/README.md


