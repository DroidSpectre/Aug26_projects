# LLM module (llama.cpp)

Local AI chat via llama.cpp's OpenAI-compatible server, loopback only
(127.0.0.1:8080 - it never listens on the network).

## Verbs
- llm setup / build-log / build-status / build-restart
  Builds llama-server from source (Alpine has no llama.cpp package);
  clang + Release + jobs=min(cores,4), PRoot-safe -march derived from
  /proc/cpuinfo (GGML_NATIVE=OFF). Build runs DETACHED (survives
  screen-off/resizes); ccache resumes; build-status adds thermal zones.
- llm hf | llm hf list <repo> | llm hf get <repo> <file>
  HuggingFace Hub downloads into ~/models/ + sets active model.
  Downloads run DETACHED through the job dock (prompt returns asap).
- llm model ~/models/<file>.gguf   select a model (idempotent re-link)
- llm start / stop / status
- llm chat          interactive multi-turn (exit: Exit or Ctrl-D)
- llm ask <q>       AUTO-ROUTED: plain / help / docs / web
- llm ask --plain   force a direct completion
- llm web <q>       Tavily search + cited synthesis (needs Dashboard key)
- llm web status / llm web --test
- llm context       print the terminal + system snapshot
- llm agent <task>  tool loop (web_search/help_lookup/file_read/done)
- llm replies [n]   print the last n saved replies (default 1)
- llm export [path] save a reply into the OUTPUT folder (default: last)
- llm chat-log [n]  show the last n chat turns
- llm docs find/add, llm ask-help (help-module)
- io env|in|out|clean   INPUT/OUTPUT dropbox helper (below)
- llm-selftest      exit 0 = pass

## Input / Output dropbox
The app creates two folders in Downloads, kept in sync on every volume:
  Download/Aetherix-Alpine_INPUT   place files here for the llm to read
  Download/Aetherix-Alpine_OUTPUT  exports (reports, logs) land here
`io in <path>` copies a file into INPUT (or lists INPUT with `io in`),
`io out <src> [name]` copies a file from INPUT into OUTPUT (or from any
path), `io clean` empties both. ~/storage/input and ~/storage/output are
symlinks to the same folders. Files in INPUT are listed with sizes in the
llm context block, so "llm ask 'review INPUT/foo.py for bugs'" works with
no extra setup; the analysis report can be exported with `llm export`.

## Responses
Every reply is saved to /etc/aetherix/replies/<n>.md and shown in the
docked response window, which also auto-opens after a reply. From the
terminal, `llm replies`, `llm chat-log`, and `llm export` (writes into
the OUTPUT folder) give you the same content back as files.

## Model profiles (auto)
/etc/aetherix/model-profiles.conf maps the active .gguf name to
ctx/batch/agent-rounds (first-match glob; '*' = default). Overrides:
LLM_CTX=<n>, LLM_BATCH=<n>, LLM_AGENT=<0|n>. Tool-capable models (2B+)
unlock llm agent; smaller models use the auto-router instead.

## Recommended phone models
Qwen3-0.6B | Qwen2.5-0.5B/1.5B | SmolLM2-360M | Llama-3.2-1B | Gemma-3-1B
(recommended Q4 variants via 'llm hf' menu)

## Limits

## Knowledge cards (help-module v1.2.0)

The model can answer from a set of tool-tip data cards deployed to
/etc/aetherix/help/cards/ (small-world: start at 00 HOME, follow RELATED,
any answer within 6 hops; DEEP: lines point to the full docs). `llm docs
find <topic>` returns them like any other corpus doc, and `llm context`
lists the hubs.
LLM_MAX_TOKENS (default 512) caps completion length. Replies go to the
docked response window in-app (AETHERIX_DOCK=1).
