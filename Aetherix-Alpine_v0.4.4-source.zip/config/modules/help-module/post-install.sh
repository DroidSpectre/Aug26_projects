#!/bin/sh
# help-module post-install - deploy the curated help + project-doc corpus.
# The corpus feeds 'llm docs find' / 'llm docs add' / 'llm ask-help' (llm
# tier). Requires llm-module; install core-module before that.
MODULE_DIR=$(dirname "$0")
HELP=/etc/aetherix/help
mkdir -p "$HELP"
for f in "$MODULE_DIR"/docs/*.md "$MODULE_DIR"/docs/*.txt; do
  [ -f "$f" ] || continue
  cp -f "$f" "$HELP/$(basename "$f")"
done
# keyword index (informational - docs find greps the files directly)
: > "$HELP/.index"
# v0.4.3+ (data cards): deploy the small-world tool-tip card set for the
# on-device model. The llm tier's docs search already scans recursively, so
# cards under $HELP/cards are instantly findable + agent file_read-able.
mkdir -p "$HELP/cards"
for f in "$MODULE_DIR"/docs/cards/*.md; do
  [ -f "$f" ] || continue
  cp -f "$f" "$HELP/cards/$(basename "$f")"
done
for f in "$HELP"/*.md "$HELP"/*.txt "$HELP"/cards/*.md; do
  [ -f "$f" ] || continue
  title=$(sed -n 's/^#\+[[:space:]]*//p' "$f" | head -1)
  kw=$(grep -Eih '^#' "$f" 2>/dev/null | tr 'A-Z' 'a-z' | tr -cs 'a-z0-9 ' ' ' | tr -s ' ' | head -c 400)
  printf '%s\t%s\t%s\n' "$(basename "$f")" "$title" "$kw" >> "$HELP/.index"
done
echo "installed $(date -u +%Y-%m-%dT%H:%M:%SZ)" > /etc/aetherix/help-module.installed
echo "help-module OK: 'llm docs find <terms>' and 'llm ask-help' now answer from the bundled corpus"
