#!/bin/bash
# verify-apk.sh — host-side APK checks for a built fork release.
# usage: bash verify-apk.sh [v0.3a.<n>]   (default: versionName from app/build.gradle)
set -u
PROJECT_DIR="$(cd "$(dirname "$0")/../../../.." && pwd)"  # tests -> module -> modules -> config -> repo root
cd "$PROJECT_DIR"
VERSION="${1:-$(grep -oP 'versionName "\K[^"]+' app/build.gradle | head -1)}"
VERSION="${VERSION#Aetherix-Alpine-}"   # strip app-name prefix from apk filename
VERSION="${VERSION%.apk}"   # tolerate passing the apk filename
APP="Aetherix-Alpine"
APK="$PROJECT_DIR/${APP}-${VERSION}.apk"
ANDROID_HOME="${ANDROID_HOME:-/root/Android}"
BUILD_TOOLS="${ANDROID_HOME}/build-tools/35.0.0"
AAPT="$(command -v aapt 2>/dev/null || echo "$BUILD_TOOLS/aapt")"
APKSIGNER="$(command -v apksigner 2>/dev/null || echo "$BUILD_TOOLS/apksigner")"
DEV_DIR="/sdcard/Download/Aetherix-Alpine-Fork"
pass=0; fail=0
check() { if [ "$2" -eq 0 ]; then pass=$((pass+1)); echo "PASS  $1"; else fail=$((fail+1)); echo "FAIL  $1"; fi; }
[ -f "$APK" ]; check "APK exists: ${APP}-${VERSION}.apk" $?
# v0.3a.<n>(_<k>): 30000 + n*10 + k; v0.4.<p>: 40000 + p (core-stable line).
if [[ "$VERSION" =~ ^v0\.3a\.([0-9]+)(_([0-9]+))?$ ]]; then
  CODE=$((30000 + ${BASH_REMATCH[1]} * 10 + ${BASH_REMATCH[3]:-0}))
elif [[ "$VERSION" =~ ^v0\.4\.([0-9]+)$ ]]; then
  CODE=$((40000 + ${BASH_REMATCH[1]}))
else
  echo "FAIL  badging: unparseable version $VERSION"; fail=$((fail+1)); CODE=""
fi
if [ -n "$CODE" ]; then
  BADGE=$("$AAPT" dump badging "$APK" 2>/dev/null)
  echo "$BADGE" | grep -qE "package: name='com\.aetherix\.alpine\.a' versionCode='$CODE' versionName='$VERSION'"
  check "badging: com.aetherix.alpine.a / $VERSION / $CODE" $?
fi
SIG=$("$APKSIGNER" verify --verbose "$APK" 2>&1)
echo "$SIG" | grep -q "v2 scheme (APK Signature Scheme v2): true" && echo "$SIG" | grep -q "v3 scheme (APK Signature Scheme v3): true"
check "signature v2+v3" $?
D=$(unzip -p "$APK" classes.dex 2>/dev/null | strings)
echo "$D" | grep -qE "startAutoInstall|getStepInfo|getTelemetry|packageCount|SELF_TEST_PASS|missing dependencies|Installing base Alpine packages"
check "DEX feature markers present" $?
if echo "$D" | grep -qE "Verifying Shell Environment|Step 5/6 \(PTY Bridge\)|Step 4 \(Alpine Init\)"; then
  check "DEX stale labels absent" 1; else check "DEX stale labels absent" 0; fi
L=$(unzip -l "$APK" 2>/dev/null)
for a in assets/www/dashboard.html assets/www/modules.html assets/proot-arm64 assets/alpine-minirootfs.tar assets/modules/core-module.bundle assets/modules/hello-module.bundle lib/arm64-v8a/libproot.so lib/arm64-v8a/libpty-bridge.so; do
  if echo "$L" | grep -q "$a"; then check "asset present: $a" 0; else check "asset present: $a" 1; fi
done
[ -f "$DEV_DIR/${APP}-${VERSION}.apk" ] && [ -f "$DEV_DIR/snapshots/${APP}-${VERSION}-source.zip" ]
check "device export: APK + snapshot present" $?
HB=$(mktemp); trap 'rm -f "$HB"' EXIT
unzip -p "$APK" assets/modules/hello-module.bundle > "$HB" 2>/dev/null
for t in tier/io tier/sd; do
  if tar -tzf "$HB" 2>/dev/null | grep -q "$t"; then check "hello bundle helper: $t" 0; else check "hello bundle helper: $t" 1; fi
done
echo ""
echo "=== Result: $pass passed, $fail failed ($VERSION) ==="
[ "$fail" -eq 0 ]
