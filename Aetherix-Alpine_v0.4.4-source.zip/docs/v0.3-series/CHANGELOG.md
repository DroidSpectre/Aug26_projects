# Aetherix-Alpine — Changelog (fork line)

## v0.3a.0 (2026-08-04) — fork baseline (versionCode 30000)

- Fork created from the upstream v0.3.3 WIP (versionCode 27) into
  `/root/Documents/Codex/2026-08-04/aetherix-alpine-fork/` — independent of the
  opencode-owned tree.
- Fork version line `v0.3a.x`; versionCode `30000+n`; artifacts and module drop
  use the fork export tree `/sdcard/Download/Aetherix-Alpine-Fork/`.
- Source mirrors the upstream in-progress v0.3.3 telemetry state; see
  `FORK-NOTES.md` for compile status.

## v0.3.2 (2026-08-04) — versionCode 26 (upstream, pre-fork)


**Storage tier + module system:**

- **All-files access:** `MANAGE_EXTERNAL_STORAGE` (`usesPermissionFlags="neverForLocation"`); dashboard/modules UI shows grant state; "Grant All-files Access" opens the All-files settings page directly.
- **Full-storage binds:** launcher now maps `-b /storage/emulated/0:/mnt/sdcard` (writable primary store) plus one dynamic `-b <volume>:/mnt/sd-ext<n>` per removable volume; `ensureLauncher()` re-derives binds on every app start.
- **`sd` CLI:** `sd list`, `sd ext`, `sd ls <path>`, `sd cp <src> <dst>` in the rootfs (`/usr/local/bin/sd`), deployed idempotently on every start; all commands refuse until All-files is granted (gate on `/etc/aetherix/storage.state`).
- **Module loader (`ModuleManager`):** modules are gzip tars at `Download/Aetherix-Alpine/modules/<name>.tar.gz` with `module.yml` + optional `post-install.sh`. Install = name/version validation (tar peek), staged atomic extraction into `var/lib/aetherix-modules/<name>/`, `etc/aetherix/modules.d/<name>/info` bookkeeping, then `post-install.sh` through the normal launcher shell (180 s timeout). Re-install overwrites; uninstall cleans both trees.
- **Frontend:** new `modules.html` (storage card + Install/Reinstall/Uninstall, gated by grant state); dashboard gains "Modules & Storage" button and Storage / Modules rows.
- **Sample module:** `hello-module.tar.gz` (v0.1.0, post-install writes `/etc/aetherix/hello-module.installed`) exported to the phone.

**Bug fix:**

- **Terminal session persistence on config change:** connecting a Bluetooth keyboard (or any hardware keyboard) previously triggered an activity restart that lost the 8+ hour session, resetting the timer and splash prompt. Root cause: `TerminalActivity` did not declare `keyboard|keyboardHidden|navigation` in `configChanges`, so the OS destroyed and recreated the activity on keyboard attach; the session was never registered in `TerminalSessionManager`, so `isSessionActive()` returned false and `startShell()` spawned a fresh session. Fix: added the missing config changes to the manifest, registered the session in `TerminalSessionManager` during `startShell()`, and extended `cleanupProot()` to also kill orphaned `libpty-bridge.so` processes.

## v0.3.1 (2026-08-03) — versionCode 25

**StepRunner UX completion (condensed from five planned PATCH releases):**

- **BUG-009** — Dashboard step count is now dynamic: replaced hard-coded `6/6` with `completedCount/stepCount` from `getDashboardData()` (7-step setup).
- **BUG-011** — Internal step methods renamed to match the display order (`step3Diagnostics`, `step4Launcher`, `step5AlpineInit`, `step6PtyBridge`, `step7ShellVerify`); stale "Fix 1–3" name entries removed.
- **BUG-010** — Final step is now "Test & Verify": renames step 7 and adds a real self-test (`VERSION=…`, `proot --version`, `bash --version`, `SELF_TEST_PASS` marker) before the step can pass.
- **BUG-012** — Main log now records `Step N [PASS]: <output>` / `[FAIL]: <output>` for every install and test run.
- **BUG-013** — Every step shows a short blue info popup (why it matters) before it runs; distinct `.btn-info` styling.
- **BUG-014** — Terminal warm-up fix: `warmUpReadline()` no longer injects SPACE+DEL when the command line has typed content (previously the DEL erased the last typed digit after a keyboard resize). New pure-Java `TerminalPromptGuard` with a 9-assertion host test suite (`tools/WarmUpGuardTest.java`).

## v0.3.0 (2026-08-03) — versionCode 24

- First v0.3 release under the new semantic-versioning scheme (supersedes v0.2.25_15x letter suffixes).
- Terminal, PRoot setup, dashboard, error reporting as shipped in v0.2.25_15x, stabilized.
- Version now read from `app/build.gradle` by the build script (`GRADLE_VERSION_NAME`/`GRADLE_VERSION_CODE`); per-build snapshot dirs retired.

## v0.3a.1 (fork)

Package identity fix (FB-003): applicationId com.aetherix.alpine.a so the fork installs side-by-side with upstream.

## v0.3a.2 (fork)

Fix Step 7 self-test (FB-004): drop invalid in-guest proot --version check

## v0.3a.3 (fork)

UX completion: dashboard-first boot, Initiate Install walkthrough + auto install (1 step 1 test), storage in Step 3 permission chain, step-label audit (FB-005), telemetry dashboard card (FB-006)

## v0.3a.4 (fork)

Fix false 'killed by system' popup on Exit (FB-007) + live dashboard package counter (FB-008)

## v0.3a.5 (2026-08-05) — versionCode 30005

**Bundled module + telemetry CLI (plan Parts 3–4 reconciliation):**

- **FB-009 — bundled hello-module:** `ModuleManager` now lists `assets/modules/*.tar.gz`
  as "bundled with app" and installs them via a fallback copy into
  `Download/Aetherix-Alpine-Fork/modules/`. Ships `hello-module` v1.0.0 (in-guest
  `aetherix-selftest` / `aetherix-smoke`, 10-check `TESTPLAN.md`, host
  `verify-apk.sh`); `scripts/build-hello-module.sh` regenerates the bundle (`assets/modules/hello-module.bundle` — aapt strips `.tar.gz` asset names).
- **FB-010 — `device-info` CLI:** `StorageTier.writeDeviceInfo()` deploys an
  idempotent `/usr/local/bin/device-info` (device/board/soc/abi, battery,
  memory, GPU, thermal in `key: value` lines) on every app start — completes
  the plan Part 4 in-Alpine verification command.
- **Plan reconciliation:** `aetherix-v0.3-series-device-layers-plan.md` gains a
  "Fork status" map; Parts 2–4 marked shipped (`[x]` on all 25 Part 2 tasks),
  Parts 5–7 (elevation, GUI, LLM) remain roadmap.

## v0.3a.6 (2026-08-05) — versionCode 30006

**Hardware card, notifications, storage mapping, module UX:**

- **FB-011 — module list UX:** modules show their real `module.yml` version
  before install; badge counts available + a second badge counts installed;
  per-entry `setupReady` with an amber "Setup not finished" hint.
- **FB-012 — notification tap-to-open:** foreground notification now has a
  content intent that opens the terminal when a session is active, else the
  dashboard (`FLAG_ACTIVITY_NEW_TASK|SINGLE_TOP|CLEAR_TOP`, `FLAG_IMMUTABLE`).
- **FB-013 — Hardware card expansion:** RAM avail/total, Storage avail/total
  (+ per removable volume), App data/apk size, charging state (AC/USB/wireless),
  CPU cores+model, GPU vendor+busy, NPU, thermal, network transport
  (Wi-Fi/Cellular LTE/etc). New `ACCESS_NETWORK_STATE` permission.
- **FB-014 — Termux-style `~/storage`:** home link tree (`shared`,
  `downloads/dcim/pictures/music/movies/documents`) + adaptive `sd mount`
  command that maps bound removable/USB volumes to `external`/`usb`/`externalN`.
- **FB-015 — module install UX:** `rootfsReady()` gates on `bin/sh` + apk db;
  clearer "run Initiate Install on the dashboard first" error.

## v0.3a.7 (2026-08-05) — versionCode 30007

**Final tweaks + all remaining tier foundations in one build:**

- **FB-016 — storage cd aliases:** `storage`, `shared`, `external`, `usb` in the
  guest `.bashrc` (`shared` == `cd ~/storage/shared`).
- **FB-017 — `module status` CLI:** in-terminal module listing (plan Part 3
  carryover); installs still via the Modules page.
- **FB-018 — Elevation foundation (Part 5):** `elv` CLI — `setup` (apk add
  android-tools), `pair <port> <pin>`, `connect`, `shell <cmd>` (uid 2000),
  `status`, `disconnect`; dashboard card with Wireless Debugging shortcut +
  pairing form. Degrades to sandbox if loopback adb is blocked.
- **FB-019 — GUI foundation (Part 6):** `gui` CLI — Xvfb :1 + openbox + x11vnc
  on 127.0.0.1:5901 (loopback), `app <cmd>`; dashboard card. In-app VNC viewer
  still roadmap.
- **FB-020 — LLM foundation (Part 7):** `llm` CLI — llama.cpp server
  (OpenAI-compatible) on 127.0.0.1:8080, models in `~/models/`, `ask "<q>"`;
  dashboard card. In-app chat UI still roadmap.
- **Plumbing:** `assets/tier/*.sh` deployed idempotently to `/usr/local/bin` on
  app start; bridge `getTierStatus()` / `runTier()` / `openWirelessDebugging()`;
  three dashboard cards with 10s auto-refresh + command console.
- **Plan:** Parts 5–7 marked "shipped foundation" (on-device verification
  pending); deliberate one-build condensation noted.

## v0.3a.8 (2026-08-05) — versionCode 30008

**On-device regression fixes:**

- **FB-021 — module install blocked after fresh setup:** `rootfsReady()` now
  checks `lib/apk/db/installed` (Alpine's real apk db location, same path the
  dashboard package counter reads) instead of the non-existent
  `var/lib/apk/db/installed`.
- **FB-022 — deploy after setup:** `StorageTier.deploy()` is now triggered
  idempotently from the 5s dashboard refresh and when the final setup step
  passes, so the `~/storage` links, bash aliases (`shared`/`external`/`usb`),
  and `elv`/`gui`/`llm`/`module` CLIs appear without killing and reopening the
  app.

## v0.3a.9 (fork)

harden module rootfs-ready check with diagnostics (FB-023); true factory reset (FB-024)
- FB-023: `rootfsReady()` accepts broad evidence (alpine-release/bin/sh + apk db or setup_complete.marker written on Step 7 success); `rootfsDiagnostics()` added to dashboard/tier status/error report/modules page.
- FB-024: `factoryReset()` kills proot, wipes rootfs/proot/sdk + marker, clears prefs/logs; dashboard Reset & Reinstall confirms the wipe.

## v0.3a.10 (fork)

deploy reliability: instrument StorageTier.deploy, extra triggers, device.conf parent fix, guest-side tier self-heal (FB-025..FB-027)
- FB-025: `StorageTier.deploy()` failures now logged to BridgeLogBuffer (error report visible); extra triggers at Step 5 end, terminal start, and module install.
- FB-026: `device.conf` write now creates `etc/aetherix` first (was FileNotFoundException on fresh rootfs).
- FB-027: hello-module v1.1.0 post-install self-heals tier helpers, `~/storage` links, aliases, `storage.state`, `device.conf` from the bundle; build script syncs `assets/tier/*.sh` into the module.

## v0.3a.11 (fork)

app-switch returns to live terminal; GUI + LLM become standalone installable modules; llama.cpp builds from source (FB-028..FB-030)
- FB-028: `MainActivity.onResume()` reorders `TerminalActivity` to front when a session is active, unless the user closed it to the dashboard (`close_to_dashboard` pref).
- FB-029: `gui-module` + `llm-module` standalone bundles; dashboard GUI/LLM cards removed; `assets/tier` now only `elv.sh` + `module.sh`; generic `scripts/build-modules.sh`.
- FB-030: `llm setup` source-builds `llama-server` (no llama.cpp package in any Alpine branch); `gui stop` removes stale X sockets.

## v0.3a.12 (fork)

GPU card: make/model only (cached EGL identity, no usage polling); llm setup clone fixed: urandom binds + visible errors + retries (FB-031, FB-032)
- FB-031: removed `gpu_busy` polling from the main-thread telemetry; GPU make + model queried once per process via EGL GL_RENDERER (sysfs/vendor fallbacks).
- FB-032: launcher binds `/dev/urandom` + `/dev/random` into the guest; `llm setup` installs ca-certificates, retries clone 3x, cleans partial clones, prints the real git error.

## v0.3a.13 (fork)

Kill recovery + RAM breakdown, install chooser, collapsible hardware card, warmup input race fix, gui vnc docs, clear-scrollback action, splash cheatsheet

- FB-033: system-kill recovery (marker + notice + fresh-shell reopen) and RAM breakdown (`free X · cached Y`) on the Hardware card.
- FB-034: single Install button with Auto/Manual/Cancel chooser; hidden at 7/7.
- FB-035: Hardware card title toggles collapse/expand.
- FB-036: warmup SPACE+DEL prime is cancelled by real user input (BT-keyboard first-digit race).
- FB-037: `gui vnc` prints phone + PC client instructions; usage updated.
- FB-038: toolbar Clear wipes visible screen + scrollback transcript.
- Feature: login splash lists installed modules and command cheatsheet (shared `WelcomeScript`, refreshed idempotently).

## v0.3a.14 (fork)

UI polish: default-minimized persistent Hardware/System cards, module page color semantics (Installed green / Available blue / Uninstall blue), Termux-style terminal splash

## v0.3a.14_1 (fork)

Fix build: toolbar spacing + Copy All/Clear All, 1-row docked keys, two-mode uninstall, deploy reliability, llm clone TLS fix (/etc/ssl/cert.pem). Version scheme 30000+major*10+patch.

## v0.3a.14_2 (fork)

Fix build 2: lag root-cause (deploy gate + package-count cache), bin/sh symlink heal (helpers now deploy), bundled modules always from APK, gui setup progress, full module activity log, terminal spinner for silent commands

## v0.3a.14_3 (fork)

Fix build 3: session wakelock keeps long builds alive (llama.cpp), broken-symlink idempotency (no more 5s exception spam), proprietary notice + Dashboard Licenses page with citations, drop last Termux mention, unify downloads link

## v0.3a.14_8 (fork)

HF model downloader + verified Q4 links, full-system wake lock, spinner/prompt/scrollback fixes, device-agnostic storage map (FB-068..FB-075)

## v0.3a.14_9 (fork)

full-system wake lock owned by foreground service + notification for the whole session lifetime (FB-076)

## v0.3a.14_10 (fork)

llm hf dispatch fixed + curated model menu; full ~/storage tree seeded at app start (FB-077, FB-078)

## v0.3a.14_11 (fork)

llm ask prints only the reply (no raw JSON); llama-server version shown in build-status (FB-079, FB-080)

## v0.3a.14_12 (fork)

docked LLM response window (keybar REPLY) + llm chat multi-turn mode (FB-081, FB-082)

## v0.3a.14_13 (fork)

gui-module archived; LLM reply cap 512 + activity dock (clean apk/curl/build output); chat whitespace fix; reply dock 5/10 rows

## v0.4.0 (fork)

Core-stable v0.4.0: archive gui; modules bundled/APK-only; numbered permission prompts; install-only dashboard; per-module cards; PRoot-safe CPU probe for llama.cpp; stacked 5-job dock; detached job CLI
