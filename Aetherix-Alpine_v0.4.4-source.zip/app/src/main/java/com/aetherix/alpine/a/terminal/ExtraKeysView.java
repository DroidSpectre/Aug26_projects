package com.aetherix.alpine.a.terminal;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.PopupWindow;
import android.widget.ToggleButton;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class ExtraKeysView extends GridLayout {

    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int BUTTON_COLOR = 0x00000000;
    private static final int INTERESTING_COLOR = 0xFF80DEEA;
    private static final int BUTTON_PRESSED_COLOR = 0x7FFFFFFF;

    private TerminalView mTerminalView;
    private Runnable mPasteCallback;
    private Runnable mReplyCallback;
    private Runnable mKeyboardToggleCallback;
    private Button mReplyButton;

    /** v0.4.3 (FB-109): the keybar sparkle is the REPLY key - it must toggle
     *  the docked LLM response window, not type an emoji. Kept as a named
     *  constant so the DEX marker check in verify-apk.sh can assert it. */
    static final String SPARKLE_REPLY_KEY = "\u2728";

    public ExtraKeysView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(0xFF1a1a2e);
    }

    public void setTerminalView(TerminalView view) {
        mTerminalView = view;
    }

    public void setPasteCallback(Runnable cb) {
        mPasteCallback = cb;
    }

    /** FB-081: the REPLY key toggles the app's docked LLM response window. */
    public void setReplyCallback(Runnable cb) {
        mReplyCallback = cb;
    }

    /** FB-081: highlight the REPLY key while the response window is visible. */
    public void setReplyActive(boolean active) {
        if (mReplyButton != null) {
            mReplyButton.setTextColor(active ? INTERESTING_COLOR : TEXT_COLOR);
        }
    }

    public void setKeyboardToggleCallback(Runnable cb) {
        mKeyboardToggleCallback = cb;
    }

    public enum SpecialButton {
        CTRL, ALT, FN
    }

    private static class SpecialButtonState {
        boolean isOn = false;
        ToggleButton button = null;
    }

    private Map<SpecialButton, SpecialButtonState> specialButtons = new HashMap<SpecialButton, SpecialButtonState>() {{
        put(SpecialButton.CTRL, new SpecialButtonState());
        put(SpecialButton.ALT, new SpecialButtonState());
        put(SpecialButton.FN, new SpecialButtonState());
    }};

    private ScheduledExecutorService scheduledExecutor;
    private PopupWindow popupWindow;
    private int longPressCount;

    public boolean readSpecialButton(SpecialButton name) {
        SpecialButtonState state = specialButtons.get(name);
        if (state == null) return false;
        if (!state.isOn) return false;
        if (state.button.isPressed()) return true;
        if (!state.button.isChecked()) return false;
        state.button.setChecked(false);
        state.button.setTextColor(TEXT_COLOR);
        return true;
    }

    void showPopup(View view, String text) {
        int width = view.getMeasuredWidth();
        int height = view.getMeasuredHeight();
        Button button = new Button(getContext(), null, android.R.attr.buttonBarButtonStyle);
        button.setText(text);
        button.setTextColor(TEXT_COLOR);
        button.setPadding(0, 0, 0, 0);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinimumHeight(0);
        button.setWidth(width);
        button.setHeight(height);
        button.setBackgroundColor(BUTTON_PRESSED_COLOR);
        popupWindow = new PopupWindow(this);
        popupWindow.setWidth(LayoutParams.WRAP_CONTENT);
        popupWindow.setHeight(LayoutParams.WRAP_CONTENT);
        popupWindow.setContentView(button);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(false);
        popupWindow.showAsDropDown(view, 0, -2 * height);
    }

    void sendKey(String keyName) {
        if (mTerminalView == null) return;

        Integer keyCode = keyCodesForString.get(keyName);
        if (keyCode != null) {
            KeyEvent event = new KeyEvent(KeyEvent.ACTION_UP, keyCode);
            mTerminalView.onKeyDown(keyCode, event);
        } else if ("KEYBOARD".equals(keyName)) {
            if (mKeyboardToggleCallback != null) mKeyboardToggleCallback.run();
        } else if ("PASTE".equals(keyName)) {
            if (mPasteCallback != null) mPasteCallback.run();
        } else if ("REPLY".equals(keyName) || SPARKLE_REPLY_KEY.equals(keyName)) {
            if (mReplyCallback != null) mReplyCallback.run();
        } else {
            TerminalSession session = mTerminalView.mTermSession;
            if (session != null) session.write(keyName);
        }
    }

    static final Map<String, Integer> keyCodesForString = new HashMap<String, Integer>() {{
        put("ESC", KeyEvent.KEYCODE_ESCAPE);
        put("TAB", KeyEvent.KEYCODE_TAB);
        put("HOME", KeyEvent.KEYCODE_MOVE_HOME);
        put("END", KeyEvent.KEYCODE_MOVE_END);
        put("PGUP", KeyEvent.KEYCODE_PAGE_UP);
        put("PGDN", KeyEvent.KEYCODE_PAGE_DOWN);
        put("INS", KeyEvent.KEYCODE_INSERT);
        put("DEL", KeyEvent.KEYCODE_FORWARD_DEL);
        put("BKSP", KeyEvent.KEYCODE_DEL);
        put("UP", KeyEvent.KEYCODE_DPAD_UP);
        put("LEFT", KeyEvent.KEYCODE_DPAD_LEFT);
        put("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT);
        put("DOWN", KeyEvent.KEYCODE_DPAD_DOWN);
        put("ENTER", KeyEvent.KEYCODE_ENTER);
    }};

    static class CleverMap<K,V> extends HashMap<K,V> {
        V get(K key, V defaultValue) {
            if (containsKey(key)) return get(key);
            return defaultValue;
        }
    }

    static class CharDisplayMap extends CleverMap<String, String> {}

    static final CharDisplayMap classicArrowsDisplay = new CharDisplayMap() {{
        put("LEFT", "\u2190");
        put("RIGHT", "\u2192");
        put("UP", "\u2191");
        put("DOWN", "\u2193");
    }};

    static final CharDisplayMap wellKnownCharactersDisplay = new CharDisplayMap() {{
        put("ENTER", "\u21B2");
        put("TAB", "\u21B9");
        put("BKSP", "\u232B");
        put("DEL", "\u2326");
    }};

    static final CharDisplayMap lessKnownCharactersDisplay = new CharDisplayMap() {{
        put("HOME", "\u21F1");
        put("END", "\u21F2");
        put("PGUP", "\u21D1");
        put("PGDN", "\u21D3");
    }};

    static final CharDisplayMap nicerLookingDisplay = new CharDisplayMap() {{
        put("-", "\u2015");
    }};

    public static final CharDisplayMap defaultCharDisplay = new CharDisplayMap() {{
        putAll(classicArrowsDisplay);
        putAll(wellKnownCharactersDisplay);
        putAll(nicerLookingDisplay);
    }};

    static final CharDisplayMap controlCharsAliases = new CharDisplayMap() {{
        put("ESCAPE", "ESC");
        put("CONTROL", "CTRL");
        put("RETURN", "ENTER");
        put("FUNCTION", "FN");
        put("LT", "LEFT");
        put("RT", "RIGHT");
        put("DN", "DOWN");
        put("PAGEUP", "PGUP");
        put("PAGE_UP", "PGUP");
        put("PAGE UP", "PGUP");
        put("PAGE-UP", "PGUP");
        put("PAGEDOWN", "PGDN");
        put("PAGE_DOWN", "PGDN");
        put("PAGE-DOWN", "PGDN");
        put("PAGE-DOWN", "PGDN");
        put("DELETE", "DEL");
        put("BACKSPACE", "BKSP");
        put("BACKSLASH", "\\");
        put("QUOTE", "\"");
        put("APOSTROPHE", "'");
    }};

    void replaceAliases(String[][] buttons) {
        for (int i = 0; i < buttons.length; i++)
            for (int j = 0; j < buttons[i].length; j++)
                buttons[i][j] = controlCharsAliases.get(buttons[i][j], buttons[i][j]);
    }

    static int maximumLength(String[][] matrix) {
        int m = 0;
        for (String[] aMatrix : matrix) m = Math.max(m, aMatrix.length);
        return m;
    }

    public void reload(String[][] buttons, Map<String, String> charDisplayMap) {
        for (SpecialButtonState state : specialButtons.values())
            state.button = null;
        mReplyButton = null;

        removeAllViews();
        replaceAliases(buttons);

        final int rows = buttons.length;
        final int cols = maximumLength(buttons);
        setRowCount(rows);
        setColumnCount(cols);

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < buttons[row].length; col++) {
                final String buttonText = buttons[row][col];

                Button button;
                if (Arrays.asList("CTRL", "ALT", "FN").contains(buttonText)) {
                    SpecialButtonState state = specialButtons.get(SpecialButton.valueOf(buttonText));
                    state.isOn = true;
                    button = state.button = new ToggleButton(getContext(), null, android.R.attr.buttonBarButtonStyle);
                    button.setClickable(true);
                } else {
                    button = new Button(getContext(), null, android.R.attr.buttonBarButtonStyle);
                }
                if ("REPLY".equals(buttonText) || SPARKLE_REPLY_KEY.equals(buttonText)) {
                    mReplyButton = button;
                }

                final String displayedText = charDisplayMap.containsKey(buttonText) ? charDisplayMap.get(buttonText) : buttonText;
                button.setText(displayedText);
                button.setTextColor(TEXT_COLOR);
                button.setPadding(0, 0, 0, 0);

                final Button finalButton = button;
                button.setOnClickListener(v -> {
                    finalButton.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    if (Arrays.asList("CTRL", "ALT", "FN").contains(buttonText)) {
                        ToggleButton self = (ToggleButton) finalButton;
                        self.setChecked(self.isChecked());
                        self.setTextColor(self.isChecked() ? INTERESTING_COLOR : TEXT_COLOR);
                    } else {
                        sendKey(buttonText);
                    }
                });

                button.setOnTouchListener((v, event) -> {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            longPressCount = 0;
                            v.setBackgroundColor(BUTTON_PRESSED_COLOR);
                            if (Arrays.asList("UP", "DOWN", "LEFT", "RIGHT").contains(buttonText)) {
                                scheduledExecutor = Executors.newSingleThreadScheduledExecutor();
                                scheduledExecutor.scheduleWithFixedDelay(() -> {
                                    longPressCount++;
                                    sendKey(buttonText);
                                }, 400, 80, TimeUnit.MILLISECONDS);
                            }
                            return true;

                        case MotionEvent.ACTION_MOVE:
                            if (Arrays.asList("/", "-").contains(buttonText)) {
                                if (popupWindow == null && event.getY() < 0) {
                                    v.setBackgroundColor(BUTTON_COLOR);
                                    String text = "-".equals(buttonText) ? "|" : "\\";
                                    showPopup(v, text);
                                }
                                if (popupWindow != null && event.getY() > 0) {
                                    v.setBackgroundColor(BUTTON_PRESSED_COLOR);
                                    popupWindow.dismiss();
                                    popupWindow = null;
                                }
                            }
                            return true;

                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            v.setBackgroundColor(BUTTON_COLOR);
                            if (scheduledExecutor != null) {
                                scheduledExecutor.shutdownNow();
                                scheduledExecutor = null;
                            }
                            if (longPressCount == 0) {
                                if (popupWindow != null && Arrays.asList("/", "-").contains(buttonText)) {
                                    popupWindow.setContentView(null);
                                    popupWindow.dismiss();
                                    popupWindow = null;
                                    sendKey("-".equals(buttonText) ? "|" : "\\");
                                } else {
                                    v.performClick();
                                }
                            }
                            return true;

                        default:
                            return true;
                    }
                });

                LayoutParams param = new GridLayout.LayoutParams();
                param.width = 0;
                param.height = (int) (37.5 * getResources().getDisplayMetrics().density + 0.5);
                param.setMargins(0, 0, 0, 0);
                param.columnSpec = GridLayout.spec(col, GridLayout.FILL, 1.f);
                param.rowSpec = GridLayout.spec(row, GridLayout.FILL, 1.f);
                button.setLayoutParams(param);

                addView(button);
            }
        }
    }
}
